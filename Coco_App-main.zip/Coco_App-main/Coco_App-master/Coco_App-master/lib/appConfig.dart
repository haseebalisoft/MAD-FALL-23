class AppConfig{

  static const String FCM_NOTIFICCATION_TOKEN = "AAAAXdpQ0_g:APA91bHwVbCxd30zZH-ne-W4pK7sYo_bIVqSqs1Mi4XK2XkTRsQmC4MDt2Qv9cW7FlDzIgT0L9-oZ-Nj5BuyJqa0RTZHD0HAJKi34RyV51oYcXrXnbzz1TfDzhbaXKf1g7NygJcqA3GC";

  static const String FCM_URL = "https://fcm.googleapis.com/fcm/send";



  static const String APP_NAME = "COCO";
  static const String DOMAIN = "https://coco-app.io";
  static const String API = "api";
  static const String BASE_URL = "$DOMAIN/$API";
  static const String DEVICE_TOKEN = "$BASE_URL/register-token"; //POST METHOD
  static const String LOGIN = "$BASE_URL/login"; //POST METHOD
  static const String LOGIN_WITH_GOOGLE = "$BASE_URL/google-login"; //POST METHOD
  static const String SIGNUP = "$BASE_URL/registration"; //POST METHOD
  static const String UPDATE_LAT_LNG = "$BASE_URL/update/location"; //POST METHOD
  static const String EMAIL_OTP_SEND = "$BASE_URL/email/verification"; //POST METHOD
  static const String VERYFY_EMAIL_OTP = "$BASE_URL/email/verify"; //POST METHOD
  static const String ROLE_SELECTION = "$BASE_URL/select/role"; //POST METHOD
  static const String CHECK_USER = "$BASE_URL/check/user"; //POST METHOD
  static const String USER_INFORMATION = "$BASE_URL/user/info"; //GET METHOD

  static const String FREELACNER_PROFILE_CREATE_ONE = "$BASE_URL/freelancer/step_1"; //POST METHOD
  static const String FREELACNER_PROFILE_CREATE_TWO = "$BASE_URL/freelancer/step_2"; //POST METHOD
  static const String FREELACNER_PROFILE_CREATE_THREE = "$BASE_URL/freelancer/step_3"; //POST METHOD
  static const String FREELANCER_ADD_SERVICES = "$BASE_URL/add/service"; //POST METHOD


  static const String CLIENT_PROFILE_CREATE_ONE = "$BASE_URL/client/step_1"; //POST METHOD
  static const String CLIENT_PROFILE_CREATE_TWO = "$BASE_URL/client/step_2"; //POST METHOD
  static const String CLIENT_PROFILE_CREATE_THREE = "$BASE_URL/client/step_3"; //POST METHOD

  static const String ALL_COUNTERY = "$BASE_URL/all/country"; //GET METHOD
  static const String ALL_STATE = "$BASE_URL/all/state/"; //GET METHOD END POINT SEND COUNTRY ID
  static const String ALL_CITY = "$BASE_URL/all/city/"; //GET METHOD END POINT SEND STATE ID


  //static const String ALL_POST = "$BASE_URL/user/all/post"; //GET METHOD END POINT SEND STATE ID
  static const String ALL_POST = "$BASE_URL/role/post/"; //GET METHOD END POINT SEND STATE ID
  static const String SINGE_USER_POST = "$BASE_URL/post/"; //GET METHOD END POINT SEND STATE ID
  static const String CREATE_POST = "$BASE_URL/add/post"; //GET METHOD END POINT SEND STATE ID
  static const String POST_LIKE = "$BASE_URL/post/like"; //POST METHOD END POINT SEND STATE ID
  static const String STORY_LIKE = "$BASE_URL/story/like"; //POST METHOD END POINT SEND STATE ID
  static const String STORY_DISLIKE = "$BASE_URL/story/dislike"; //POST METHOD END POINT SEND STATE ID
  static const String POST_UNLIKE = "$BASE_URL/post/dislike"; //POST METHOD END POINT SEND STATE ID
  static const String EDIT_POST = "$BASE_URL/edit/post/"; //POST METHOD END POINT SEND STATE ID
  static const String DELETE_POST = "$BASE_URL/delete/post/"; //POST METHOD END POINT SEND STATE ID
  static const String DELETE_POST_IMAGE = "$BASE_URL/post/image/delete/"; //POST METHOD END POINT SEND STATE ID
  static const String COMMENT_LIST_MODEL = "$BASE_URL/single/post/comment/"; //POST METHOD END POINT SEND STATE ID
  static const String ADD_COMMENT = "$BASE_URL/post/comment"; //POST METHOD END POINT SEND STATE ID
  static const String EDIT_COMMENT = "$BASE_URL/post/comment/"; //POST METHOD END POINT SEND STATE ID
  static const String DELETE_COMMENT = "$BASE_URL/comment/delete/"; //POST METHOD END POINT SEND STATE ID


  static const String PROFILE_UPLOAD = "$BASE_URL/profile/image"; //POST METHOD END POINT SEND STATE ID
  static const String COVER_IMAGE = "$BASE_URL/cover/image"; //POST METHOD END POINT SEND STATE ID
  static const String SOTRY_UPLOAD = "$BASE_URL/add/story"; //POST METHOD END POINT SEND STATE ID


  /////////////// story /////////
  static const String ALL_STORY = "$BASE_URL/all/stories"; //POST METHOD END POINT SEND STATE ID
  static const String SINGLE_USER_STORY = "$BASE_URL/user/all/story"; //POST METHOD END POINT SEND STATE ID
  static const String DELETE_USER_STORY = "$BASE_URL/delete/story/";



  ///////// User Search ////////
  static const String USER_SEARCH = "$BASE_URL/user/search/";
  static const String PUBLISH_ALERT = "$BASE_URL/publish/alert";
  static const String PUBLISH_ALERT_STATUS_CHANGE = "$BASE_URL/publish/alert/STATUS";
  static const String SINGLE_PUBLISH_ALERT = "$BASE_URL/alert/";

  //////Edit profiless
  static const String EditProfile = "$BASE_URL/edit/profile";


  //Single user
  static const String CLIENT_USER_INFO = "$BASE_URL/client/profile/info/";
  static const String FREELANCER_USER_INFO = "$BASE_URL/profile/info";
  static const String SINGLE_USER_INFO = "$BASE_URL/freelancer/info/"; //POST METHOD END POINT SEND STATE ID
  static const String SINGLE_USER_PROFILE = "$BASE_URL/freelancer/details/info/"; //POST METHOD END POINT SEND STATE ID
  static const String CLIENT_ABOUT_ME = "$BASE_URL/freelancer/details/info/"; //POST METHOD END POINT SEND STATE ID
  static const String SINGLE_USER_PORTFOLIO = "$BASE_URL/post/"; //POST METHOD END POINT SEND STATE ID
  static const String USER_FOLLOW = "$BASE_URL/follow/"; //POST METHOD END POINT SEND STATE ID
  static const String USER_FOLLOWING_LIST = "$BASE_URL/following"; //get METHOD
  static const String USER_FOLLOWERS_LIST = "$BASE_URL/folloW"; //get METHOD
  static const String EQUIPMENTS_LIST = "$BASE_URL/all/equipments"; //POST METHOD END POINT SEND STATE ID
  static const String SERVICE_LIST = "$BASE_URL/all/service"; //POST METHOD END POINT SEND STATE ID
  static const String USER_BY_SERVICE_LIST = "$BASE_URL/search/service/"; //POST METHOD END POINT SEND STATE ID
  static const String USER_BY_BUSINESS_LIST = "$BASE_URL/search/business/"; //POST METHOD END POINT SEND STATE ID
  static const String BUSINESS_TYPE_LIST = "$BASE_URL/all/business/type"; //POST METHOD END POINT SEND STATE ID
  static const String LANGUAGES = "$BASE_URL/all/language"; //POST METHOD END POINT SEND STATE ID
  static const String Add_LANGUAGES = "$BASE_URL/add/language"; //POST METHOD END POINT SEND STATE ID
  static const String ALL_USERS_WITH_SERVICE = "$BASE_URL/all/user/"; //POST METHOD END POINT SEND STATE ID
  static const String ADD_BUSINESS_HOURS = "$BASE_URL/add/business/hours"; //POST METHOD END POINT SEND STATE ID
  static const String BUSINESS_HOURS = "$BASE_URL/business/hours/"; //POST METHOD END POINT SEND STATE ID
  static const String TERMS_CONDITION = "$BASE_URL/terms-conditions"; //POST METHOD END POINT SEND STATE ID
  static const String PRIVACY_POLICY = "$BASE_URL/privacy-policy"; //POST METHOD END POINT SEND STATE ID
  static const String TOUTORIALS = "$BASE_URL/tutorials"; //POST METHOD END POINT SEND STATE ID
  static const String FILTER_FOR_CLIENT = "$BASE_URL/all/filter"; //POST METHOD END POINT SEND STATE ID
  static const String HIDE_COMMENT = "$BASE_URL/hide/post/comment/"; //POST METHOD END POINT SEND STATE ID

  static const String ADD_TO_FAV = "$BASE_URL/user-fav";
  static const String GET_ALL_FAV = "$BASE_URL/all-favs";


  ///Forgot password
  //forgot/password (post) => required field => email . return status 200 if match and send email with a reset code.
  static const String FORGOT_PASSWORD = "$BASE_URL/forgot/password";
  //reset-token/verify (post) => required fields => email, code . return status 200 if match
  static const String RESET_TOKEN_VERIFY = "$BASE_URL/reset-token/verify";
  //reset-password (post) => required fields => email, password . return status 200 if password changed
  static const String RESET_PASSWORD = "$BASE_URL/reset-password";


  ///Post Favorite
  static const String POST_FAVORITE = "$BASE_URL/post/favorite";
  static const String POST_UNFAVORITE = "$BASE_URL/post/remove-favorite";

  static const String ALLFAVPOSTS = "$BASE_URL/user/favorite/post";


  static const String alert = "$BASE_URL/alert"; //POST METHOD END POINT SEND STATE ID



}