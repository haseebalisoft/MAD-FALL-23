import 'package:get/get.dart';

import '../appConst.dart';
import '../helper/helperFunctions.dart';
import '../model/authModel/allBusinessTypeModel.dart';
import '../model/authModel/allUserList.dart';
import '../model/authModel/languesModel.dart';
import '../model/authModel/serviceModle.dart';
import 'authController.dart';

class AllFilterController extends GetxController{
  Rx<AllBusnissType?> getBusinessType = Rx<AllBusnissType?>(null);
  Rx<ServiceModel?> getServices = Rx<ServiceModel?>(null);

  Rx<LanguesModel?> languages = Rx<LanguesModel?>(null);

  RxList<String> selectedLangauges = <String>[].obs;

  RxList<String> service = <String>[].obs;

  RxBool isLoading = true.obs;

  var role = "".obs;

  RxBool isOpenForCollaration = false.obs;
  RxInt leftTypeLength = 0.obs;
  RxInt leftLanguagelengh = 0.obs;

  refreshUI(){
    isLoading.value = true;

    isLoading.value = false;
  }
  getAllNecessaryData() async {
    getBusinessType.value  = null;
    getServices.value = null;
    languages.value = null;
    leftTypeLength.value = 0;
    leftLanguagelengh.value = 0;

    isLoading.value = true;



    role.value = await HelperFunction.getUserRole();

    AllUserModel getAllUser = await AuthController.getAllUsers();

    if(role.value == AppConst.CLIENT_ROLE){
      print(AppConst.CLIENT_ROLE);
      getServices.value = await AuthController.getServiceList();
      leftTypeLength.value = getServices.value!.data!.length - 4;


      if(getServices.value?.data != null) {
        for (int i = 0; i < getServices.value!.data!.length; i++) {
          int count = 0;

          print("getServices.value!.data![i].id => ");
          print(getServices.value!.data![i].id);
          print(getServices.value!.data![i].name);

          for (int j = 0; j < getAllUser.data!.length; j++) {

            print("getAllUser.data![j].userInfo?.serviceList => ");
            print(getAllUser.data![j].userInfo?.serviceList);

            if (HelperFunction.convertStringToListInt(getAllUser.data![j].userInfo?.serviceList).contains(getServices.value!.data![i].id)) {
              count++;

              print("count => ");
              print(count);
            }
          }
          getServices.value!.data![i].totalUser = count;

          print("=====================================");
        }
      }
    }
    else{

      getBusinessType.value = await AuthController.getBusinessTypes();
      leftTypeLength.value = getBusinessType.value!.data!.length - 4;

      if(getBusinessType.value?.data != null) {
        for (int i = 0; i < getBusinessType.value!.data!.length; i++) {
          int count = 0;

          print("getBusinessType.value!.data![i].id => ");
          print(getBusinessType.value!.data![i].id);

          for (int j = 0; j < getAllUser.data!.length; j++) {

            print("getAllUser.data![j].userInfo?.businessList => ");
            print(getAllUser.data![j].userInfo?.businessList);

            if (HelperFunction.convertStringToListInt(getAllUser.data![j].userInfo?.businessList).contains(getBusinessType.value!.data![i].id)) {
              count++;

              print("count => ");
              print(count);
            }
          }
          getBusinessType.value!.data![i].totalUser = count;
          print("=====================================");



        }
      }
    }

    languages.value = await AuthController.getLanguages();
    leftLanguagelengh.value = languages.value!.data!.length;

    if(languages.value?.data != null) {
      for (int i = 0; i < languages.value!.data!.length; i++) {
        int count = 0;

        for (int j = 0; j < getAllUser.data!.length; j++) {
          if (HelperFunction.convertStringToListInt(getAllUser.data![j].userInfo?.languages).contains(languages.value!.data![i].id)) {
            count++;
          }
        }
        languages.value!.data![i].totalUser = count;
      }
    }







    isLoading.value = false;
  }




}