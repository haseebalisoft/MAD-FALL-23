import 'package:coco/controller/postController.dart';
import 'package:coco/controller/profileToInfoController.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../appConfig.dart';
import '../model/AllFavorite.dart';
import '../model/FavUserWithDetails.dart';
import '../model/authModel/allUserList.dart';
import '../model/authModel/singleUserInfo.dart';
import '../model/authModel/userInfoModel.dart';
import '../model/postModel/PostModel.dart';
import '../model/post_fav_model.dart';
import 'authController.dart';
import 'package:http/http.dart' as http;


class ProfileFavoriteController extends GetxController {
  RxBool isLoading = true.obs;
  Rx<AllUserModel?> getAllUser =  Rx<AllUserModel?>(null);

  Rx<AllPostModel?> getAllPost =  Rx<AllPostModel?>(null);

  Rx<PostFavModel?> post_favorite =  Rx<PostFavModel?>(null);
  Rx<AllPostModel?> getAllFavPost =  Rx<AllPostModel?>(null);



  var user_id = "".obs;

  Rx<SingleUserInfoModel?> singleUserFollowFollowingFuture = Rx<SingleUserInfoModel?>(null);

  Rx<UserInformation?> userInformation = Rx<UserInformation?>(null);

  RxList<UserFavorite?> favoriteList = <UserFavorite?>[].obs;

  RxList<FavUserWithDetails?> favoriteListWithDetails = <FavUserWithDetails?>[].obs;

  RxList<FavUserWithDetails?> searchFavoriteList = <FavUserWithDetails?>[].obs;


  getAllData() async {
    isLoading.value = true;
    favoriteList.clear();
    favoriteListWithDetails.clear();
    searchFavoriteList.clear();

    userInformation.value = await AuthController.getUserInfo();

    SharedPreferences pref = await SharedPreferences.getInstance();
    user_id.value = pref.getString("user_id").toString();

    singleUserFollowFollowingFuture.value  = await AuthController.getSingleUserInfo(user_id.value);

    for (var i in singleUserFollowFollowingFuture.value!.data!.user![0].userFavorite!) {
      favoriteList.add(i);
    }

    getAllUser.value = await AuthController.getAllUsers();

    for (var i in favoriteList) {
      for (var j in getAllUser.value!.data!) {
        if (i!.favoriteUserId == j.id) {
          favoriteListWithDetails.add(FavUserWithDetails(
              id: j.id,
              name: j.name,
              email: j.email,
              userName: j.userName,
              profileImage: j.profileImage));
        }
      }
    }

    getAllPost.value = await PostController.getAllPost();

    post_favorite.value = await PostController.getAllFavPosts();

    AllPostModel? allPostModel = AllPostModel(
        status: true,
        massage: "success",
        data: []
    );

    if(post_favorite.value!.data != null) {
      for (var i in post_favorite.value!.data!) {
        for (var j in getAllPost.value!.data!) {
          if (i == j.post!.id!) {
            allPostModel.data!.add(j);
          }
        }
      }
    }

    getAllFavPost.value = allPostModel;

    print("getAllFavPost.value!.data!.length === ${getAllFavPost.value!.data!.length}");


    isLoading.value = false;
  }

  removeFromFav(int fav_user_id) async{
    isLoading.value = true;
    favoriteList.clear();
    favoriteListWithDetails.clear();
    searchFavoriteList.clear();

    SharedPreferences pref = await SharedPreferences.getInstance();
    var token = pref.getString("token");
    var response = await http.post(Uri.parse(AppConfig.ADD_TO_FAV),
        headers: {
          "Authorization": "Bearer $token",
          "Accept": "application/json",
        },
        body: {
          "favorite_user_id": fav_user_id.toString(),
        }
    );


    userInformation.value = await AuthController.getUserInfo();

    user_id.value = pref.getString("user_id").toString();

    singleUserFollowFollowingFuture.value  = await AuthController.getSingleUserInfo(user_id.value);

    for (var i in singleUserFollowFollowingFuture.value!.data!.user![0].userFavorite!) {
      favoriteList.add(i);
    }

    getAllUser.value = await AuthController.getAllUsers();

    for (var i in favoriteList) {
      for (var j in getAllUser.value!.data!) {
        if (i!.favoriteUserId == j.id) {
          favoriteListWithDetails.add(FavUserWithDetails(
              id: j.id,
              name: j.name,
              email: j.email,
              userName: j.userName,
              profileImage: j.profileImage));
        }
      }
    }

    ProfileToInfoController controller = Get.find<ProfileToInfoController>();
    controller.favCount.value = favoriteListWithDetails.length;


    getAllPost.value = await PostController.getPostByUser(user_id.value);

    isLoading.value = false;

  }
}