import 'dart:convert';

import 'package:coco/appConfig.dart';
import 'package:coco/model/service/filterServiceModel.dart';
import 'package:coco/model/service/serviceModel.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ServiceController{
  //////////////// get freelancer service list ///////////////

  static Future<ServiceDataModel>? getUserByServiceId(ID)async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var res = await http.get(Uri.parse(AppConfig.USER_BY_SERVICE_LIST+ID),
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token"
        }
    );

    print("data user ===== ${res.body}");

    return ServiceDataModel.fromJson(jsonDecode(res.body));
  }


  static Future<ServiceDataModel>? getUserByBusinessTypeId(ID)async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var res = await http.get(Uri.parse(AppConfig.USER_BY_BUSINESS_LIST+ID),
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token"
        }
    );

    print("data user ===== ${res.body}");

    return ServiceDataModel.fromJson(jsonDecode(res.body));
  }


  //filter

//   static Future<FilterFreelancerListModel>? filterForClient({
//    required String collaboration,
//    required String maxPrice,
//    required String minPrice,
//    required dynamic serviceId,
//    required dynamic languageId,
// })async{
//     SharedPreferences _pref = await SharedPreferences.getInstance();
//     var token = _pref.getString("token");
//     print("languageId => ");
//     print(languageId);
//     var res = await http.post(Uri.parse(AppConfig.FILTER_FOR_CLIENT),
//         body: {
//           "service_id": serviceId ?? "",
//           "language_id": languageId ?? "",
//           "max_price": maxPrice ?? "",
//           "min_price": minPrice ?? "",
//           "collaboration": collaboration ?? "",
//         },
//         headers: {
//           "Accept" : "application/json",
//           "Authorization" : "Bearer $token"
//         }
//     );
//
//     print("data user ===== ${res.statusCode}");
//     return FilterFreelancerListModel.fromJson(jsonDecode(res.body));
//   }

  static Future<FilterFreelancerListModel>? filterForClient({
    required String collaboration,
    required String maxPrice,
    required String minPrice,
    required List<dynamic> serviceId,
    required List<dynamic> languageId,
  }) async {
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    print("languageId => ");
    print(languageId);

    // Convert List<dynamic> to String representation of JSON arrays
    String serviceIdJson = jsonEncode(serviceId);
    String languageIdJson = jsonEncode(languageId);

    var res = await http.post(Uri.parse(AppConfig.FILTER_FOR_CLIENT),
        body: {
          "service_id": serviceIdJson,
          "language_id": languageIdJson,
          "max_price": maxPrice ?? "",
          "min_price": minPrice ?? "",
          "collaboration": collaboration ?? "",
        },
        headers: {
          "Accept": "application/json",
          "Authorization": "Bearer $token"
        });

    print("data user ===== ${res.statusCode}");
    return FilterFreelancerListModel.fromJson(jsonDecode(res.body));
  }







}