import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class InAppLinkController{

  ///////// phone number /////
  static Future<void> makePhoneCall(String phoneNumber) async {
    final Uri launchUri = Uri(
      scheme: 'tel',
      path: phoneNumber,
    );
    await launchUrl(launchUri);
  }

  ///////// phone number /////
  static Future<void> makeEmail(String email) async {
    final Uri launchUri = Uri(
      scheme: 'mailto',
      path: email,
      query: 'subject=Contact%20from%20COCO', // Replace with the email subject
    );
    await launchUrl(launchUri);
  }


  static Future<void> launchInBrowserView(Uri url) async {
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $url');
    }
  }

}