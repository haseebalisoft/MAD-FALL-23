import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../appConst.dart';
import '../helper/helperFunctions.dart';
import '../helper/helperWidgets.dart';
import '../model/authModel/allBusinessTypeModel.dart';
import '../model/authModel/allUserList.dart';
import '../model/authModel/serviceModle.dart';
import 'authController.dart';

class SearchFreelancerClientProfileController extends GetxController {
  Rx<AllBusnissType?> getBusinessType = Rx<AllBusnissType?>(null);
  Rx<ServiceModel?> getServices = Rx<ServiceModel?>(null);

  Rx<AllUserModel?> getAllUser =  Rx<AllUserModel?>(null);

  RxList<String> service = <String>[].obs;

  RxBool isLoadingForAllData = true.obs;
  RxBool isLoadingForCards = true.obs;
  var role = "".obs;


  bool isAllFiltered = false;
  AllUserModel? filteredResultData;

  reset() {
    getAllUser.value = null;
    getBusinessType.value = null;
    getServices.value = null;
    isLoadingForAllData.value = true;
    isLoadingForCards.value = true;
  }

  getAllBusinessTypeOrServices() async {
    await Future.delayed(Duration(seconds: 1));

    HelperWidget.changeSystemUIColor(Colors.black, Colors.black);

    getAllUser.value = null;
    getBusinessType.value = null;
    getServices.value = null;

    isLoadingForAllData.value = true;
    isLoadingForCards.value = true;

    service.clear();
    role.value = await HelperFunction.getUserRole();

    if(role.value == AppConst.CLIENT_ROLE){
      getServices.value = await AuthController.getServiceList();
    }
    else{
      getBusinessType.value = await AuthController.getBusinessTypes();
    }

    getAllUser.value = await AuthController.getAllUsers();

    isAllFiltered = false;
    filteredResultData = getAllUser.value;

    isLoadingForAllData.value = false;
    isLoadingForCards.value = false;

  }


  getUserByIDWithRole(int id)async{
    getAllUser.value = null;

    isLoadingForAllData.value = false;
    isLoadingForCards.value = true;

    role.value = await HelperFunction.getUserRole();


    getAllUser.value = await AuthController.getAllUsers();


    AllUserModel? newGetAllUser = AllUserModel(
      data: [],
      status: getAllUser.value!.status,
      massage: getAllUser.value!.massage,
    );



    if(newGetAllUser != null){
      for(int i = 0; i < getAllUser.value!.data!.length; i++){

        if(role == AppConst.CLIENT_ROLE){
          if(HelperFunction.convertStringToListInt(getAllUser.value!.data![i].userInfo?.serviceList).contains(id)){
            newGetAllUser.data!.add(getAllUser.value!.data![i]);
          }
        }
        else{
          if(HelperFunction.convertStringToListInt(getAllUser.value!.data![i].userInfo?.businessList).contains(id)){
            newGetAllUser.data!.add(getAllUser.value!.data![i]);
          }
        }
      }
    }

    getAllUser.value = newGetAllUser;
    isAllFiltered = true;
    filteredResultData = getAllUser.value;


    isLoadingForAllData.value = false;
    isLoadingForCards.value = false;

  }

  allFilter(String collaboration, String maxPrice,   String minPrice,  List<dynamic> serviceId,  List<dynamic> languageId) async {

    print("languageId => ");
    print(languageId);
    print("serviceId => ");
    print(serviceId);
    print("maxPrice => ");
    print(maxPrice);
    print("minPrice => ");
    print(minPrice);
    print("collaboration => ");
    print(collaboration);

    getAllUser.value = null;

    isLoadingForAllData.value = false;
    isLoadingForCards.value = true;

    getAllUser.value = await AuthController.getAllUsers();

    AllUserModel? newGetAllUser = AllUserModel(
      data: [],
      status: getAllUser.value!.status,
      massage: getAllUser.value!.massage,
    );

    //Service Filter
    if(serviceId.length > 0){

      role.value = await HelperFunction.getUserRole();

      if(role.value == AppConst.CLIENT_ROLE){
        for(int i = 0; i < getAllUser.value!.data!.length; i++){
          if(HelperFunction.convertStringToListInt(getAllUser.value!.data![i].userInfo?.serviceList).contains(int.parse(serviceId[0]))){
            newGetAllUser.data!.add(getAllUser.value!.data![i]);
          }
        }
      }
      else{
        for(int i = 0; i < getAllUser.value!.data!.length; i++){
          if(HelperFunction.convertStringToListInt(getAllUser.value!.data![i].userInfo?.businessList).contains(int.parse(serviceId[0]))){
            newGetAllUser.data!.add(getAllUser.value!.data![i]);
          }
        }
      }
    }

    //Language Filter
    if(languageId.length > 0){
      for(int i = 0; i < getAllUser.value!.data!.length; i++){
        if(HelperFunction.convertStringToListInt(getAllUser.value!.data![i].userInfo?.languages).contains(int.parse(languageId[0]))){
          newGetAllUser.data!.add(getAllUser.value!.data![i]);
        }
      }
    }

    //Price Filter
    if(collaboration == "collaboration"){
      for(int i = 0; i < getAllUser.value!.data!.length; i++){

        if(getAllUser.value!.data![i].userInfo?.pricePerDay == "collaborate"){
          newGetAllUser.data!.add(getAllUser.value!.data![i]);
        }
      }
    }
    else {
      for (int i = 0; i < getAllUser.value!.data!.length; i++) {
        String? pricePerDay = getAllUser.value!.data![i].userInfo?.pricePerDay;

        print("pricePerDay => ");
        print(pricePerDay);
        try{
          if (pricePerDay != null) {
            int parsedPrice = int.parse(pricePerDay);

            // print("maxPrice => ");
            // print(maxPrice);
            // print("minPrice => ");
            // print(minPrice);

            if(maxPrice != null && maxPrice != "" && minPrice == null && minPrice == ""){
              if (parsedPrice <= int.parse(maxPrice)) {
                newGetAllUser.data!.add(getAllUser.value!.data![i]);
              }
            }
            if(minPrice != null && minPrice != "" && maxPrice == null && maxPrice == ""){
              if (parsedPrice >= int.parse(minPrice)) {
                newGetAllUser.data!.add(getAllUser.value!.data![i]);
              }
            }

            if(maxPrice != null && maxPrice != "" && minPrice != null && minPrice != ""){
              if (parsedPrice <= int.parse(maxPrice) || parsedPrice >= int.parse(minPrice)) {
                newGetAllUser.data!.add(getAllUser.value!.data![i]);
              }
            }



          }
        }
        catch(e){
          print("e => ");
          print(e);
        }
      }

    }


    getAllUser.value = newGetAllUser;

    isAllFiltered = true;
    filteredResultData = getAllUser.value;

    isLoadingForAllData.value = false;
    isLoadingForCards.value = false;
  }


  searchByName(String name) async {
    //getAllUser.value = null;

    isLoadingForAllData.value = false;
    isLoadingForCards.value = true;



    if(name == "" || name == null){
      if(isAllFiltered){
        getAllUser.value = filteredResultData;
      }
      else{
        getAllUser.value = await AuthController.getAllUsers();
      }
    }
    {
      AllUserModel? newGetAllUser = AllUserModel(
        data: [],
        status: getAllUser.value!.status,
        massage: getAllUser.value!.massage,
      );

      for (int i = 0; i < getAllUser.value!.data!.length; i++) {
        String? userName = getAllUser.value!.data![i].name;

        if (userName != null &&
            userName.toLowerCase().contains(name.toLowerCase())) {
          newGetAllUser.data!.add(getAllUser.value!.data![i]);
        }
      }


      getAllUser.value = newGetAllUser;
    }

    isLoadingForAllData.value = false;
    isLoadingForCards.value = false;
  }

  filterByServiceClick(int  serviceIndex) async {
    role.value = await HelperFunction.getUserRole();
    print("serviceIndex => ");
    print(serviceIndex);

    if(service.contains(serviceIndex.toString())){
      isLoadingForAllData.value = false;
      isLoadingForCards.value = true;

      service.remove(serviceIndex.toString());
      getAllUser.value = await AuthController.getAllUsers();

      isAllFiltered = false;

      isLoadingForAllData.value = false;
      isLoadingForCards.value = false;

    }
    else{
      service.clear();
      service.add(serviceIndex.toString());
      if(role.value == AppConst.CLIENT_ROLE){
        getUserByIDWithRole(getServices.value!.data![serviceIndex].id!);
      }
      else{
        getUserByIDWithRole(getBusinessType.value!.data![serviceIndex].id!);
      }

    }
  }

  selectedEffectByServiceClick(int  serviceIndex) async {
    print("serviceIndex => ");
    print(serviceIndex);
    print(service);

    if(service.contains(serviceIndex.toString())){

      service.remove(serviceIndex.toString());

    }
    else{
      // service.clear();
      service.add(serviceIndex.toString());

    }
    print(service);

  }
  // selectedEffectByServiceClickDeselect(int  serviceIndex) async {
  //   print("serviceIndex => ");
  //   print(serviceIndex);
  //
  //   if(service.contains(serviceIndex.toString())){
  //
  //     service.remove(serviceIndex.toString());
  //
  //   }
  //   else{
  //     // service.clear();
  //     service.add(serviceIndex.toString());
  //
  //   }
  // }

}