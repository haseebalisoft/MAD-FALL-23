import 'dart:convert';

import 'package:coco/appConfig.dart';
import 'package:coco/model/setting/policayModel.dart';
import 'package:coco/model/setting/termsConditionModel.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
class SettingController{

  static Future<TermsConditionModel> getTramsCondition()async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.get(Uri.parse("${AppConfig.TERMS_CONDITION}"),
      headers: {
        "Accept" : "application/json",
        "Authorization" : "Bearer $token"
      }
    );
    return TermsConditionModel.fromJson(jsonDecode(response.body));
  }

  static Future <PolicyModel> getPrivacyPolicay()async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.get(Uri.parse("${AppConfig.PRIVACY_POLICY}"),
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token"
        }
    );

    print("re === ${response.body}");
    return PolicyModel.fromJson(jsonDecode(response.body));
  }

}