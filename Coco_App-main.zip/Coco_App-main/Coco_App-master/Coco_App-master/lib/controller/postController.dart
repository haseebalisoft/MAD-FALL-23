import 'dart:convert';
import 'dart:io';

import 'package:coco/appConfig.dart';
import 'package:coco/appConst.dart';
import 'package:coco/model/postModel/PostModel.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../model/postModel/commentListModel.dart';
import '../model/postModel/singleUserPostModel.dart';
import '../model/post_fav_model.dart';


class PostController{

  ///////////////////////////////////////#######################/////////////////////////////////
  ///////////////////////////////////////ALL Post Controller/////////////////////////////////
  ///////////////////////////////////////#######################/////////////////////////////////
  static Future<AllPostModel> getAllPost()async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var role;
    if(_pref.getString("role") == AppConst.CLIENT_ROLE){
      role = AppConst.FREELANCER_ROLE;
    }else{
      role = AppConst.CLIENT_ROLE;
    }
    var token = _pref.getString("token");
    print("token === $token");
    print(AppConfig.ALL_POST+role!);
    var response = await http.get(Uri.parse(AppConfig.ALL_POST+role!),
      headers: {
        "Authorization" : "Bearer $token",
        "Accept" : "application/json"
      }
    );

    print("api === ${AppConfig.ALL_POST+role!}");
    print("data ==== ${response.body}");
    print("data ==== ${response.statusCode}");


    return AllPostModel.fromJson(jsonDecode(response.body));
  }



  ///////////////////////////////////////#######################/////////////////////////////////
  ///////////////////////////////////////ALL Post Controller/////////////////////////////////
  ///////////////////////////////////////#######################/////////////////////////////////
  static Future<AllPostModel> getPostByUser(id)async{
    var response = await http.get(Uri.parse(AppConfig.SINGE_USER_POST+id!),
        headers: {
          "Accept" : "application/json"
        }
    );
    print("data ==== ${response.body}");
    print("data ==== ${response.statusCode}");
    return AllPostModel.fromJson(jsonDecode(response.body));
  }

  static Future<PostFavModel> getAllFavPosts()async{
    SharedPreferences pref = await SharedPreferences.getInstance();
    var token = pref.getString("token");
    var response = await http.get(Uri.parse(AppConfig.ALLFAVPOSTS),
        headers: {
          "Authorization" : "Bearer $token",
          "Accept" : "application/json"
        }
    );
    return PostFavModel.fromJson(jsonDecode(response.body));

  }

  static Future<int> getAllFavPostsCount()async{
    SharedPreferences pref = await SharedPreferences.getInstance();
    var token = pref.getString("token");
    var response = await http.get(Uri.parse(AppConfig.ALLFAVPOSTS),
        headers: {
          "Authorization" : "Bearer $token",
          "Accept" : "application/json"
        }
    );

    var data = jsonDecode(response.body);
    return data["data"].length;
  }



  ///////////////////////////////////////#######################/////////////////////////////////
  ///////////////////////////////////////ALL Post Controller/////////////////////////////////
  ///////////////////////////////////////#######################/////////////////////////////////
  static Future<AllPostModel> getSingleUserPortfolio(userID)async{

    print("getSingleUserPortfolio === ${AppConfig.SINGLE_USER_PORTFOLIO+userID}");
    var response = await http.get(Uri.parse(AppConfig.SINGLE_USER_PORTFOLIO+userID),
        headers: {
          "Accept" : "application/json"
        }
    );
    return AllPostModel.fromJson(jsonDecode(response.body));
  }

  ///////////////////////////////////////#######################/////////////////////////////////
  ///////////////////////////////////////Create Post Controller end//////////////////////////////
  ///////////////////////////////////////#######################/////////////////////////////////
  static Future<http.StreamedResponse> createPost({
  required String dec,
    required List images,
})async{
    print("get image === ${images}");
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");

    var header = {
      "Authorization" : "Bearer $token",
      "Accept" : "application/json"
    };
    var body = {
    "description" : dec,
    };
    // Create a multipart request
    var request = http.MultipartRequest(
      'POST',
      Uri.parse(AppConfig.CREATE_POST), // Replace with your server endpoint URL
    );

    // Add the image file to the request
    for (var i = 0; i < images!.length; i++) {
      request.files.add(
        await http.MultipartFile.fromPath(
          'images[]', // Server expects a field named 'images'
          images![i],
        ),
      );
    }
    request.headers.addAll(header);
    request.fields.addAll(body);

    // Send the request
    final response = await request.send();

    return response;
  }



  ///////////////////////////////////////#######################/////////////////////////////////
  ///////////////////////////////////////Like Post Controller/////////////////////////////////
  ///////////////////////////////////////#######################/////////////////////////////////
  static Future<http.Response> likePost({
    required String post_id,
  })async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.post(Uri.parse(AppConfig.POST_LIKE),
        body: {
          "post_id" : post_id,
        },
        headers: {
          "Authorization" : "Bearer $token",
          "Accept" : "application/json"
        }
    );
    return response;
  }

  static Future<http.Response> unLikePost({
    required String post_id,
  })async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.post(Uri.parse(AppConfig.POST_UNLIKE),
        body: {
          "post_id" : post_id,
        },
        headers: {
          "Authorization" : "Bearer $token",
          "Accept" : "application/json"
        }
    );
    return response;
  }

  ///////////////////////////////////////#######################/////////////////////////////////
  ///////////////////////////////////////Comment Post Controller/////////////////////////////////
  ///////////////////////////////////////#######################/////////////////////////////////
  static Future<http.Response> commentPost({
    required String post_id,
  })async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.post(Uri.parse(AppConfig.POST_LIKE),
        body: {
          "post_id" : post_id,
        },
        headers: {
          "Authorization" : "Bearer $token",
          "Accept" : "application/json"
        }
    );
    return response;
  }


///////////////////////////////////////#######################/////////////////////////////////
///////////////////////////////////////Client Post Controller/////////////////////////////////
///////////////////////////////////////#######################/////////////////////////////////
  static Future<http.Response> deletePost({
    required String post_id,
  })async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.get(Uri.parse("${AppConfig.DELETE_POST}$post_id"),
        headers: {
          "Authorization" : "Bearer $token",
          "Accept" : "application/json"
        }
    );
    return response;
  }



///////////////////////////////////////#######################/////////////////////////////////
///////////////////////////////////////delete image Post Controller/////////////////////////////////
///////////////////////////////////////#######################/////////////////////////////////
  static Future<http.Response> deleteImage({
    required String post_id,
  })async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.get(Uri.parse("${AppConfig.DELETE_POST_IMAGE}$post_id"),
        headers: {
          "Authorization" : "Bearer $token",
          "Accept" : "application/json"
        }
    );
    return response;
  }




///////////////////////////////////////#######################/////////////////////////////////
///////////////////////////////////////Edit image Post Controller/////////////////////////////////
///////////////////////////////////////#######################/////////////////////////////////
  static Future<http.Response> editPost({
    required String post_id,
    required String description,
  })async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.post(Uri.parse("${AppConfig.EDIT_POST}$post_id"),
        body: {
          "description" : description
        },
        headers: {
          "Authorization" : "Bearer $token",
          "Accept" : "application/json"
        }
    );
    return response;
  }


  ///////////////////////////////////////#######################/////////////////////////////////
  ///////////////////////////////////////Like Post Controller/////////////////////////////////
  ///////////////////////////////////////#######################/////////////////////////////////
  static Future<http.Response> addComment({
    required String post_id,
    required String comment,
  })async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.post(Uri.parse(AppConfig.ADD_COMMENT),
        body: {
          "post_id" : post_id,
          "comment":comment
        },
        headers: {
          "Authorization" : "Bearer $token",
          "Accept" : "application/json"
        }
    );
    return response;
  }




///////////////////////////////////////#######################/////////////////////////////////
///////////////////////////////////////Comment Post Controller/////////////////////////////////
///////////////////////////////////////#######################/////////////////////////////////
  static Future<SinglePostCommentListModel> commentList({
    required String post_id,
  })async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.get(Uri.parse("${AppConfig.COMMENT_LIST_MODEL}$post_id"),
        headers: {
          "Authorization" : "Bearer $token",
          "Accept" : "application/json"
        }
    );
    print('commmentsss ------  ${response.body}');
    return SinglePostCommentListModel.fromJson(jsonDecode(response.body));
  }



///////////////////////////////////////#######################/////////////////////////////////
///////////////////////////////////////Client Post Controller/////////////////////////////////
///////////////////////////////////////#######################/////////////////////////////////



//hide comment
static Future<http.Response> hidePostComment(id)async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var res = await http.get(Uri.parse(AppConfig.HIDE_COMMENT+"$id"),
        headers: {
          "Authorization" : "Bearer $token"
        }
    );
    print("res === ${res.body}");
    print("res === ${res.statusCode}");

    return res;
}

}