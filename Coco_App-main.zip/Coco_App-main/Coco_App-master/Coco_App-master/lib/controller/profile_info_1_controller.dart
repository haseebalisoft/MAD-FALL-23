import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ProfileInfo1Controller extends GetxController{
    RxString name = "".obs;
    Rx<TextEditingController> displayName = TextEditingController().obs;
    Rx<TextEditingController> description = TextEditingController().obs;
    RxList<String> selectBusinessType = <String>[].obs;

    Rx<TextEditingController> country = TextEditingController().obs;
    Rx<TextEditingController> countryId = TextEditingController().obs;
    Rx<TextEditingController> zipcode = TextEditingController().obs;
    Rx<TextEditingController> city = TextEditingController().obs;
    Rx<TextEditingController> cityId = TextEditingController().obs;
    Rx<TextEditingController> state = TextEditingController().obs;
    Rx<TextEditingController> stateId = TextEditingController().obs;
    Rx<TextEditingController> address = TextEditingController().obs;
}