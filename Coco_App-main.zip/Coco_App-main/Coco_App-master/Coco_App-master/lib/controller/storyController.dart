import 'dart:convert';

import 'package:coco/appConfig.dart';
import 'package:coco/model/storyModel/allStoryModel.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class StoryController{

  //////// get story list
  static Future<AllStoryModel> getStroyList()async{

    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var res = await http.get(Uri.parse(AppConfig.ALL_STORY),
      headers: {
        "Accept" : "application/json",
        'Authorization' : "Bearer $token"
      }
    );
    print("Story Api = ${AppConfig.ALL_STORY}");
    print("Token $token");
    print("stroy === ${res.statusCode}");
    print("stroy === ${res.body}");
    return AllStoryModel.fromJson(jsonDecode(res.body));

  }


  static Future<http.Response> deleteStory({
    required String story_id,
  })async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.get(Uri.parse("${AppConfig.DELETE_USER_STORY}$story_id"),
        headers: {
          "Authorization" : "Bearer $token",
          "Accept" : "application/json"
        }
    );
    return response;
  }


  static Future<http.Response> likeStory({
    required String story_id,
  })async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.post(Uri.parse(AppConfig.STORY_LIKE),
        body: {
          "story_id" : story_id,
        },
        headers: {
          "Authorization" : "Bearer $token",
          "Accept" : "application/json"
        }
    );
    return response;
  }


  static Future<http.Response> dislikeStory({
    required String story_id,
  })async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.post(Uri.parse(AppConfig.STORY_DISLIKE),
        body: {
          "story_id" : story_id,
        },
        headers: {
          "Authorization" : "Bearer $token",
          "Accept" : "application/json"
        }
    );
    return response;
  }
}