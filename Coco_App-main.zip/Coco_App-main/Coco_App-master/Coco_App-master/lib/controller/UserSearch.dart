import 'dart:convert';

import 'package:coco/appConfig.dart';
import 'package:coco/model/storyModel/allStoryModel.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'package:shared_preferences/shared_preferences.dart';

import '../model/searchUserModel/searchUserModel.dart';

class UserSearchController{


  //////// get story list
  static Future<SearchUserModel> userSearch(name)async{

    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var res = await http.get(Uri.parse(AppConfig.USER_SEARCH+name),
        headers: {
          "Accept" : "application/json",
          'Authorization' : "Bearer $token"
        }
    );
    // print("search status === ${res.statusCode}");

    var data =  SearchUserModel.fromJson(jsonDecode(res.body));

    return data;

  }
}