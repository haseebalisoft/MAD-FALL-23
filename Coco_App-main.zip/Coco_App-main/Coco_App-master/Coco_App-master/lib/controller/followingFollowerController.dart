import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../model/authModel/singleUserInfo.dart';
import 'authController.dart';

class FollowingFollowerController extends GetxController{
  var user_id = "".obs;
  RxBool isLoading = true.obs;

  Rx<SingleUserInfoModel?> singleUserFollowFollowingFuture = Rx<SingleUserInfoModel?>(null);

  RxList<Followers?> followersList = <Followers?>[].obs;

  RxList<Following?> followingList = <Following?>[].obs;

  RxList<Followers?> searchFollowersList = <Followers?>[].obs;
  RxList<Following?> searchFollowingList = <Following?>[].obs;



  getgetFollowFollowingList(String targetUserID)async{
    await Future.delayed(Duration(seconds: 1));

    followersList.clear();
    followingList.clear();

    searchFollowersList.clear();
    searchFollowingList.clear();
    isLoading.value = true;

    SharedPreferences pref = await SharedPreferences.getInstance();
    user_id.value = pref.getString("user_id").toString();

    var res = await AuthController.getSingleUserInfo(targetUserID);
    var users = res.data?.user![0];


    for (var i in users!.followers!) {
      followersList.add(i);
    }

    for (var i in users.following!) {
      followingList.add(i);
    }
    // if (users != null) {
    //   for(var i in users){
    //     var followers = i.followers;
    //     if (followers != null) {
    //       for(var follower in followers){
    //         followersList.add(follower);
    //       }
    //     }
    //
    //     var followings = i.following;
    //     if (followings != null) {
    //       for(var following in followings){
    //         followingList.add(following);
    //       }
    //     }
    //   }
    // }

    isLoading.value = false;
  }

}