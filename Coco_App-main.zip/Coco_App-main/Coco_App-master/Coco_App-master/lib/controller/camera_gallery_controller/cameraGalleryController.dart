import 'dart:io';

import 'package:coco/viewController/uploadphotos_videos.dart';
import 'package:flutter/material.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:wechat_assets_picker/wechat_assets_picker.dart';
import 'package:wechat_camera_picker/wechat_camera_picker.dart';

import '../../view/storys/upload_story_preview.dart';

class CameraGalleryController{

  ///= =============------ use set here isStory = true =========//
  static Future<void> pickGalleryAndCameraForStory({required BuildContext context, required String from}) async {
    FlashMode flashMode = FlashMode.off;
    List<AssetEntity>? result = await AssetPicker.pickAssets(
      context,
      pickerConfig: AssetPickerConfig(
          requestType: RequestType.common,
          pageSize: 3,
          gridThumbnailSize: ThumbnailSize(100, 200),
          previewThumbnailSize: ThumbnailSize(100, 200),
          specialPickerType: SpecialPickerType.values[1],
          keepScrollOffset: true,
          textDelegate: const EnglishAssetPickerTextDelegate(),
          specialItemBuilder: (context, widget, int){
            return CameraOpen(
                onClick: ()async{
                  final AssetEntity? entity = await CameraPicker.pickFromCamera(
                    locale:  Locale.fromSubtags(languageCode: "en"),
                    context,
                    pickerConfig:  const CameraPickerConfig(
                      enableRecording: true,
                      enableAudio: true,
                      enableTapRecording: true,
                      shouldDeletePreviewFile: true,
                        preferredFlashMode: FlashMode.off
                    ),
                  );
                  if (entity != null) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => UploadStroyProview(
                          cameraFile: entity.file,
                          form: from,
                        ),
                      ),
                    );
                  }
                }
            );
          },
          specialItemPosition: SpecialItemPosition.prepend,

          //pathThumbnailSize: ThumbnailSize(100, 150),
          gridCount: 3,
          filterOptions: PMFilter.defaultValue(),
          maxAssets: 1
      ),
    );

    if (result != null) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => UploadStroyProview(
              list: List.from(result), form: from,),
        ),
      );
    }else{
      // Navigator.pop(context);
    }


    // Navigator.push(
    //   context,
    //   MaterialPageRoute(
    //     builder: (context) => CustomMediaPicker(),
    //   ),
    // );

  }


  static Future<void> pickGalleryAndCameraForPost({required BuildContext context,}) async {
    List<AssetEntity>? result = await AssetPicker.pickAssets(
      context,
      pickerConfig: AssetPickerConfig(
          requestType: RequestType.all,
          pageSize: 3,
          gridThumbnailSize: ThumbnailSize(100, 200),
          previewThumbnailSize: ThumbnailSize(100, 200),
          keepScrollOffset: true,
          textDelegate: const EnglishAssetPickerTextDelegate(),
          specialItemBuilder: (context, widget, int){
            return CameraOpen(
                onClick: ()async{
                  final AssetEntity? entity = await CameraPicker.pickFromCamera(
                    locale:  Locale.fromSubtags(languageCode: "en"),
                    context,
                    pickerConfig: CameraPickerConfig(
                      enableRecording: true,
                      enableAudio: true,
                      enableTapRecording: true,
                      shouldAutoPreviewVideo: true,
                    ),
                  );
                  if (entity != null) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => UploadPhotosVideos(
                          cameraFile: entity.file,
                        ),
                      ),
                    );
                  }
                }
            );
          },
          specialItemPosition: SpecialItemPosition.prepend,

          //pathThumbnailSize: ThumbnailSize(100, 150),
          gridCount: 3,
          filterOptions: PMFilter.defaultValue(),
          maxAssets: 10
      ),
    );

    if (result != null) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => UploadPhotosVideos(
              list: List.from(result)),
        ),
      );
    }else{
      // Navigator.pop(context);
    }


    // Navigator.push(
    //   context,
    //   MaterialPageRoute(
    //     builder: (context) => CustomMediaPicker(),
    //   ),
    // );
  }








  // this for profile
  ///= =============------ use set here isStory = true =========//
  static Future<void> pickProfilePic({required BuildContext context}) async {
    List<AssetEntity>? result = await AssetPicker.pickAssets(
      context,
      pickerConfig: AssetPickerConfig(
          requestType: RequestType.image,
          pageSize: 3,
          gridThumbnailSize: ThumbnailSize(100, 200),
          previewThumbnailSize: ThumbnailSize(100, 200),
          specialPickerType: SpecialPickerType.values[1],
          keepScrollOffset: true,
          textDelegate: const EnglishAssetPickerTextDelegate(),
          specialItemBuilder: (context, widget, int){
            return CameraOpen(
                onClick: ()async{
                  final AssetEntity? entity = await CameraPicker.pickFromCamera(
                    locale:  Locale.fromSubtags(languageCode: "en"),
                    context,
                    pickerConfig:  const CameraPickerConfig(
                        enableRecording: true,
                        enableAudio: true,
                        enableTapRecording: true,
                        shouldDeletePreviewFile: true,
                        preferredFlashMode: FlashMode.off
                    ),
                  );
                  if (entity != null) {
                    // Navigator.push(
                    //   context,
                      // MaterialPageRoute(
                      //   builder: (context) => UploadStroyProview(
                      //     cameraFile: entity.file,
                      //     form: from,
                      //   ),
                      // ),
                    //);
                  }
                }
            );
          },
          specialItemPosition: SpecialItemPosition.prepend,

          //pathThumbnailSize: ThumbnailSize(100, 150),
          gridCount: 3,
          filterOptions: PMFilter.defaultValue(),
          maxAssets: 1
      ),
    );

    if (result != null) {
      // Navigator.push(
      //   context,
      //   MaterialPageRoute(
      //     builder: (context) => UploadStroyProview(
      //       list: List.from(result), form: from,),
      //   ),
      // );
    }else{
      // Navigator.pop(context);
    }


    // Navigator.push(
    //   context,
    //   MaterialPageRoute(
    //     builder: (context) => CustomMediaPicker(),
    //   ),
    // );

  }

}







class CameraOpen extends StatelessWidget {
  const CameraOpen({Key? key, required this.onClick}) : super(key: key);

  final VoidCallback onClick;
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onClick,
      child: Container(
        width: 100,
        height: 100,
        color: Colors.black,
        child: const Icon(Icons.camera_alt_outlined, color: Colors.white, size: 30,),
      ),
    );
  }










}
