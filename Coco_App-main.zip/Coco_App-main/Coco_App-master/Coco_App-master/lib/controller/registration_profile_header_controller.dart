import 'dart:io';

import 'package:get/get.dart';

class RegistrationProfileHeaderController extends GetxController{
  Rx<File?> image = Rx<File?>(null);
  Rx<File?> croppedFile = Rx<File?>(null);

}