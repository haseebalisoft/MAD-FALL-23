import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../appConfig.dart';
import '../model/FollowFollowingModel/followingListModel.dart';

class FollowUnFollowController{


  ////////////////////// get single user info /////////////////////
  static Future<http.Response> followUnfollow(id)async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.get(Uri.parse(AppConfig.USER_FOLLOW+id),
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token"
        }
    );
    return response;
  }

  ////////////////////// get single user info /////////////////////
  static Future<FollowingListModel> followingList(id)async{
    print("user id == ${id}");
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.get(Uri.parse(AppConfig.USER_FOLLOWING_LIST+id),
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token"
        }
    );
    print("user follow list === ${response.body}");
    print("user follow list === ${response.statusCode}");
    return FollowingListModel.fromJson(jsonDecode(response.body));
  }
  //
  // ////////////////////// get single user info /////////////////////
  // static Future<FollowingListModel> followersList(id)async{
  //   SharedPreferences _pref = await SharedPreferences.getInstance();
  //   var token = _pref.getString("token");
  //   var response = await http.get(Uri.parse(AppConfig.USER_FOLLOWERS_LIST+id),
  //       headers: {
  //         "Accept" : "application/json",
  //         "Authorization" : "Bearer $token"
  //       }
  //   );
  //   return FollowingListModel.fromJson(jsonDecode(response.body));
  // }




}