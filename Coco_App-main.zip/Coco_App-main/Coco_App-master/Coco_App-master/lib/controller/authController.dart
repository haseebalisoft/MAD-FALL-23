import 'dart:convert';

import 'package:coco/appConfig.dart';
import 'package:coco/appConst.dart';
import 'package:coco/model/ClientAboutModel.dart';
import 'package:coco/model/authModel/allCountryModel.dart';
import 'package:coco/model/authModel/allUserList.dart';
import 'package:coco/model/authModel/equpmentsListModel.dart';
import 'package:coco/model/authModel/loginModel.dart';
import 'package:coco/model/authModel/userInfoModel.dart';
import 'package:coco/model/tutorialsModel/tutorials_model.dart';
import 'package:coco/view/auth/role_selector.dart';
import 'package:coco/view/auth/sign_in.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../model/FreelancerModel.dart';
import '../model/authModel/allBusinessTypeModel.dart';
import '../model/authModel/businessHoursModel.dart';
import '../model/authModel/languesModel.dart';
import '../model/authModel/serviceModle.dart';
import '../model/authModel/singleUserInfo.dart';
import '../model/authModel/userAboutMe.dart';
import '../model/userProfile/ClientProfileInfo.dart';
import '../model/userProfile/ClientProfileInfo.dart';
import '../model/userProfile/ClientProfileInfo.dart';
import '../model/userProfile/FreelancerProfileModel.dart';
import '../model/userinfo_model.dart';


class AuthController{

  //google signin
  static Future googleAuth()async{
    //
    final GoogleSignInAccount? gUser = await GoogleSignIn().signIn();
    //
    final GoogleSignInAuthentication gAuth = await gUser!.authentication;
    //create ne google user
    final credential = GoogleAuthProvider.credential(
      accessToken: gAuth.accessToken,
      idToken: gAuth.idToken
    );
    //final lets signin
    return await FirebaseAuth.instance.signInWithCredential(credential);
  }

  //Login with gmail with api.....
  static Future<http.Response> loginWithGoogleAPI({required String email})async{
    final UserCredential? user = await googleAuth();
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var response = await http.post(Uri.parse(AppConfig.LOGIN_WITH_GOOGLE),
        body: {
          "email" : user?.user?.email,
        },
        headers: {
          "Accept" : "application/json"
        }
    );
    if(response.statusCode == 200){
      var data = jsonDecode(response.body);
      LoginModel.fromJson(data);
      print("google login id ==== ${data["data"]["id"]}");
      prefs.setString("token", data["data"]["token"]);
      prefs.setString("user_id", data["data"]["id"].toString());
      // prefs.setString('name', data["data"]["name"].toString());
      // prefs.setString('email', data["data"]["email"].toString());
      storeDeviceToken(); //once signup done, call device token save method
      if(data["data"]["role"] != null){
        prefs.setString("role", data["data"]["role"]);
      }

    }
    return response;
  }

  //google sign out
  static Future signOut()async{
    //
    final SharedPreferences prefs = await SharedPreferences.getInstance();
     await GoogleSignIn().signOut();
     await FirebaseAuth.instance.signOut();
     prefs.remove("token");
     prefs.remove("tole");
     prefs.remove("user_id");
    Get.offAll(SignInPage());
    //
  }


  //loagin user checking
  static Future getLoginToken()async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token").toString();
    return token;
  }
  //loagin user checking
  static Future getRole()async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var role = _pref.getString("role").toString();
    return role;
  }


  //signup
  static Future login({
    required String email,
    required String password,
  })async{
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    var response = await http.post(Uri.parse(AppConfig.LOGIN),
        body: {
          "email" : email,
          "password" : password
        },
        headers: {
          "Accept" : "application/json"
        }
    );
    if(response.statusCode == 200){
      var data = jsonDecode(response.body);
      LoginModel.fromJson(data);
      prefs.setString("token", data["data"]["token"].toString());
      prefs.setString("user_id", data["data"]["id"].toString());
      storeDeviceToken(); //once sign done, call device token save method
      if(data["data"]["role"] != null){
        prefs.setString("role", data["data"]["role"]);
      }else{
        Get.offAll(Role_selector());
      }

      print("token ===== ${data["data"]["token"]}");
    }

    return response;
  }

  //signup
  static Future signup({
    required String? email,
    required String? password,
    required String? user_name,
    required String phone,
    required String? lat,
    required String? lng,
  })async{
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var response = await http.post(Uri.parse(AppConfig.SIGNUP),
        body: {
          "email" : email,
          "password" : password,
          "user_name" : user_name,
          "phone" : phone,
          "password_confirmation" : password,
          "latitude" : lat,
          "longitude" : lng
        },
        headers: {
          "Accept" : "application/json"
        }
    );
    print("Signup Staus ===== ${response.statusCode}");
    print("Signup Staus ===== ${response.body}");

    var data = jsonDecode(response.body);
    prefs.setString("token", data["data"]["token"].toString());
    prefs.setString("user_id", data["data"]["id"].toString());

    storeDeviceToken(); //once signup done, call device token save method

    print("Signup token ===== ${data["data"]["token"]}");


    return response;
  }


  //email opt send
  static Future emailOtpSend({
    required String email,
  })async{

    var response = await http.post(Uri.parse(AppConfig.EMAIL_OTP_SEND),
        body: {
          "email" : email,
        },
        headers: {
          "Accept" : "application/json"
        }
    );
    print("otp email === ${response.body}");
    return response;
  }


  //email opt send
  static Future emailOTPMatch({
    required String OTP,
    required String email,
  })async{

    var response = await http.post(Uri.parse(AppConfig.VERYFY_EMAIL_OTP),
        body: {
          "email" : email,
          "otp" : OTP
        },
        headers: {
          "Accept" : "application/json"
        }
    );
    print("otp email === ${response.body}");
    return response;
  }



  //existing data check
  static Future checkExitingUser({
    required String email,
    required String phone,
    required String userName,
  })async{

    var response = await http.post(Uri.parse(AppConfig.CHECK_USER),
        body: {
          "email" : email,
          "phone": phone,
          "user_name" : userName
        },
        headers: {
          "Accept" : "application/json"
        }
    );
    return response;
  }


 static Future forgotPassword({
    required String email,
  })async{

    var response = await http.post(Uri.parse(AppConfig.FORGOT_PASSWORD),
        body: {
          "email" : email,
        },
        headers: {
          "Accept" : "application/json"
        }
    );
    return response;
  }


  static Future resetTokenVerify({
    required String email,
    required String otp,
  })async{

    var response = await http.post(Uri.parse(AppConfig.RESET_TOKEN_VERIFY),
        body: {
          "email" : email,
          "code" : otp
        },
        headers: {
          "Accept" : "application/json"
        }
    );
    return response;
  }

  static Future resetPassword({
    required String email,
    required String password,
  })async{

    var response = await http.post(Uri.parse(AppConfig.RESET_PASSWORD),
        body: {
          "email" : email,
          "password" : password
        },
        headers: {
          "Accept" : "application/json"
        }
    );
    return response;
  }


  //select role user;
  //email opt send
  static Future selectRole({
    required String role,
    required String? token,
  })async{

    SharedPreferences _prefs = await SharedPreferences.getInstance();
    //var token = _prefs.getString("token");
    print("role token === ${token}");
    var response = await http.post(Uri.parse(AppConfig.ROLE_SELECTION),
        body: {
          "role" : role,
        },
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token"
        }
    );
    return response;
  }


  //////////get user info
  static Future<UserInformation> getUserInfo()async{
    SharedPreferences _prefs = await SharedPreferences.getInstance();
    var token = _prefs.getString("token");

    print("AppConfig.USER_INFORMATION => ");
    print(AppConfig.USER_INFORMATION);
    print("signing token ==== ${token}");
    var response = await http.get(Uri.parse(AppConfig.USER_INFORMATION),
      headers: {
        "Authorization" : "Bearer $token",
        "Accept" : "application/json"
      }
    );

    return UserInformation.fromJson(jsonDecode(response.body));
  }



  ///////////////////////////////////////////////////////////////////////////
////////////////////// UPLOAD PROFILE/////////////////// /////////////////////
///////////////////////////////////////////////////////////////////////////

  static Future<http.StreamedResponse> uploadProfile({
    required dynamic images,
  })async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");

    print("token === ${token}");

    var header = {
      "Authorization" : "Bearer $token",
      "Accept" : "application/json"
    };
    // Create a multipart request
    var request = http.MultipartRequest(
      'POST',
      Uri.parse(AppConfig.PROFILE_UPLOAD), // Replace with your server endpoint URL
    );

    // Add the image file to the request
    request.files.add(
      await http.MultipartFile.fromPath(
        'image', // Server expects a field named 'images'
        images!.path,
      ),
    );
    request.headers.addAll(header);

    // Send the request
    final response = await request.send();

    return response;
  }


  ///////////////////////////////////////////////////////////////////////////
////////////////////// Story Upload PROFILE/////////////////// /////////////////////
///////////////////////////////////////////////////////////////////////////


  ///////////////////////////////////////////////////////////////////////////
////////////////////// UPLOAD PROFILE/////////////////// /////////////////////
///////////////////////////////////////////////////////////////////////////

  static Future<http.StreamedResponse> uploadCoverImage({
    required dynamic images,
  })async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");

    print("token === ${token}");

    var header = {
      "Authorization" : "Bearer $token",
      "Accept" : "application/json"
    };
    // Create a multipart request
    var request = http.MultipartRequest(
      'POST',
      Uri.parse(AppConfig.COVER_IMAGE), // Replace with your server endpoint URL
    );

    // Add the image file to the request
    request.files.add(
      await http.MultipartFile.fromPath(
        'image', // Server expects a field named 'images'
        images!.path,
      ),
    );
    request.headers.addAll(header);

    // Send the request
    final response = await request.send();

    return response;
  }


  static Future uploadStory({
    required dynamic images,
    required String description,
  })async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");

    var body = {
      'description': description ?? "",
    };
    var header = {
      "Authorization" : "Bearer $token",
      "Accept" : "application/json"
    };

    try{
      // Create a multipart request
      var request = http.MultipartRequest(
        'POST',
        Uri.parse(AppConfig.SOTRY_UPLOAD), // Replace with your server endpoint URL
      );

      // Add the image file to the request
      request.files.add(
        await http.MultipartFile.fromPath(
          'image', // Server expects a field named 'images'
          images!,
        ),
      );
      request.fields.addAll(body);
      request.headers.addAll(header);

      // Send the request
      final response = await request.send();
      return response;

    }catch(e){
      print("error --- ${e}");
      return "";
    }

  }

  ///////////////////////////////////////////////////////////////
  ////////////////////// freelancer profile /////////////////////
  ///////////////////////////////////////////////////////////////
  ////////////////////// freelancer profile step info 1 /////////////////////
  static Future freelacnerProfileStepOne({
  required String name,
  required String description,
  required String phone,
  required String email,
})async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.post(Uri.parse(AppConfig.FREELACNER_PROFILE_CREATE_ONE),
      body: {
        "name":name,
        "business_email":email,
        "business_phone":phone,
        "description" : description
      },
      headers: {
        "Accept" : "application/json",
        "Authorization" : "Bearer $token",
      }
    );
    return response;
  }

  ////////////////////// freelancer profile step info 2 /////////////////////
  static Future freelacnerProfileStepTwo({
    required dynamic serviceList,
    required dynamic equipmentsList,
    required dynamic extraEquipments,
    required String pricePerDay,
    required String website,
  })async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.post(Uri.parse(AppConfig.FREELACNER_PROFILE_CREATE_TWO),
        body: {
          "service_list":serviceList,
          "equipments_list":equipmentsList,
          "extra_equipments":extraEquipments,
          "price_per_day" : pricePerDay,
          "website" : website
        },
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token",
        }
    );
    return response;
  }

  ////////////////////// freelancer profile step info 3 /////////////////////
  static Future freelacnerProfileStepThree({
    required String facebook,
    required String instagram,
    required String youtube,
    required String tiktok,
    required String behance,
    required String dribble,
    required String vimeo,
  })async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.post(Uri.parse(AppConfig.FREELACNER_PROFILE_CREATE_THREE),
        body: {
          "facebook":facebook,
          "instagram":instagram,
          "youtube":youtube,
          "tiktok":tiktok,
          "behance":behance,
          "dribble":dribble,
          "vimeo":vimeo,
        },
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token",
        }
    );
    return response;
  }


  static Future addFreelancerService({
  required String
})async{

  }

///////////////////////////////////////////////////////////////////////////
////////////////////// End Freelancer profile create /////////////////////
///////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////
////////////////////// Create Client profile create /////////////////////
///////////////////////////////////////////////////////////////////////////

  ////////////////////// Client profile step info 1 /////////////////////
  static Future clientProfileStepOne({
    required String name,
    required String description,
    required String country,
    required String zipcode,
    required String city,
    required String state,
    required String address,
    required String open_from,
    required String open_to,
    required String day_to,
    required String day_from,
    required List<String> business_list,
  })async{
    String business_string = business_list.join(', ');
    print("========================================");

    print({
      "name":name,
      "description":description,
      "zipcode":zipcode,
      "country":country,
      "city" : city,
      "state" : state,
      "address" : address,
      "open_from" : open_from,
      "open_to" : open_to,
      "day_to" : day_to,
      "day_from" : day_from,
      "busness_list" : "[$business_string]"
    });

    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    print(AppConfig.CLIENT_PROFILE_CREATE_ONE);
    var response = await http.post(Uri.parse(AppConfig.CLIENT_PROFILE_CREATE_ONE),
        body: {
          "name":name,
          "description":description,
          "zipcode":zipcode,
          "country":country,
          "city" : city,
          "state" : state,
          "address" : address,
          "open_from" : open_from,
          "open_to" : open_to,
          "day_to" : day_to,
          "day_from" : day_from,
          "business_list" : "[$business_string]"
        },
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token",
        }
    );
    return response;
  }

  ////////////////////// Client profile step info 2 /////////////////////
  static Future ClientProfileStepTwo({
    required String business_phone,
    required String business_email,
    required String website,
  })async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.post(Uri.parse(AppConfig.CLIENT_PROFILE_CREATE_TWO),
        body: {
          "business_phone":business_phone,
          "business_email":business_email,
          "website":website,
        },
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token",
        }
    );
    return response;
  }

  ////////////////////// Client profile step info 3 /////////////////////
  static Future clientProfileStepThree({
    required String facebook,
    required String instagram,
    required String youtube,
    required String tiktok,
    required String behance,
    required String dribble,
    required String vimeo,
  })async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.post(Uri.parse(AppConfig.CLIENT_PROFILE_CREATE_THREE),
        body: {
          "facebook":facebook,
          "instagram":instagram,
          "youtube":youtube,
          "tiktok":tiktok,
          "behance":behance,
          "dribble":dribble,
          "vimeo":vimeo,
        },
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token",
        }
    );
    print('social ============ ${response.body}');
    return response;
  }

////////////////////// getCountry /////////////////////
static Future getAllCountrys()async{
  SharedPreferences _pref = await SharedPreferences.getInstance();
  var token = _pref.getString("token");
  var response = await http.get(Uri.parse(AppConfig.ALL_COUNTERY),
      headers: {
        "Accept" : "application/json",
        "Authorization" : "Bearer $token",
      }
  );
  print("response === ${response.statusCode}");
  print("response === ${response.body}");
  return jsonDecode(response.body);
  //return AllCountry.fromJson(jsonDecode(response.body));
}


////////////////////// getCountry /////////////////////
  static Future<OnboradingModel> getOnBoarding()async{
    var response = await http.get(Uri.parse(AppConfig.TOUTORIALS),
        headers: {
          "Accept" : "application/json",
        }
    );
    print("Apr == ${AppConfig.TOUTORIALS}");
    print("response code === ${response.statusCode}");
    print("response === ${response.body}");
    return OnboradingModel.fromJson(jsonDecode(response.body));
    //return AllCountry.fromJson(jsonDecode(response.body));
  }

////////////////////// get all state /////////////////////
  static Future getAllState(id)async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    print("AppConfig.ALL_STATE ${AppConfig.ALL_STATE+"$id"}");
    var response = await http.get(Uri.parse(AppConfig.ALL_STATE+"$id"),
        headers: {
          "Accept" : "application/json",
        }
    );
    print("response ==== ${response.body}");
    return jsonDecode(response.body);
  }
  ////////////////////// get all state /////////////////////
  static Future getAllCity(id)async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.get(Uri.parse(AppConfig.ALL_CITY+id),
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token",
        }
    );
    return jsonDecode(response.body);
  }






  ////////////////////// get single user info /////////////////////
  static Future<SingleUserInfoModel> getSingleUserInfo(id)async{

    print(AppConfig.SINGLE_USER_INFO+id);
    var response = await http.get(Uri.parse(AppConfig.SINGLE_USER_INFO+id),
        headers: {
          "Accept" : "application/json",
        }
    );
    print("user ==== ${response.body}");
    return SingleUserInfoModel.fromJson(jsonDecode(response.body));
  }


  ///FREELANCER PROFILE UP TEST /////

  static Future CLIENT_PROFILEUP({
     String  ? country,
     String  ? zipcode,
     String ?  city,
     String ?  state,
     String ?  address,
  })async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.post(Uri.parse(AppConfig.CLIENT_PROFILE_CREATE_ONE),
        body: {
          "zipcode":zipcode ?? "",
          "country":country ??"",
          "city" : city ??"",
          "state" : state??"",
          "address" : address??"",
        },
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token",
        }
    );
    print('client upppppp ${response}');
    return response;
  }

  //////////////////////  profile update /////////////////////
  static Future profileUpdate({
     String ?  username,
     String ?  description,
     String  ? phonenumber,
     String ?  email,
     String ?  country_id,
     String ?  state_id,
     String ?  city_id,
     String ?  address,
     String ?  zipcode,
    required dynamic serviceList,
    required dynamic equipmentsList,
    required dynamic extraEquipments,
    required String pricePerDay,
    required String website,

  })async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    print(AppConfig.EditProfile);
    print("username = $username");
    print("description = $description");
    print("phonenumber = $phonenumber");
    print("email = $email");
    print("serviceList = $serviceList");
    print("equipmentsList = $equipmentsList");
    print("extraEquipments = $extraEquipments");
    print("pricePerDay = $pricePerDay");
    print("website = $website");
    var response = await http.post(Uri.parse(AppConfig.EditProfile),
        body: {
          "username":username,
          "description":description,
          "phonenumber":phonenumber,
          "email":email,
          "service_list":serviceList,
          "equipments_list":equipmentsList,
          "extra_equipments":extraEquipments,
          "price_per_day" : pricePerDay,
          "website" : website,

          "country_id":country_id,
          "state_id":state_id,
          "city_id":city_id,
          "address":address,
          "zipcode":zipcode,
        },
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token",
        }
    );
    print('social ============ ${response.body}');
    return response;
  }

  ////////////////////// get single user about /////////////////////
  static Future<FreelancerModel> profileAboutMe(id)async{
    print(AppConfig.SINGLE_USER_PROFILE+id);
    var response = await http.get(Uri.parse(AppConfig.SINGLE_USER_PROFILE+id),
        headers: {
          "Accept" : "application/json",
        }
    );
    print("user ==== data ${response.body}");
    return FreelancerModel.fromJson(jsonDecode(response.body));
  }
/////freelancer about me
  static Future<ProfileAboutMeModel> FreelancerAboutMe(id)async{
    var response = await http.get(Uri.parse(AppConfig.SINGLE_USER_PROFILE+id),
        headers: {
          "Accept" : "application/json",
        }
    );
    print("user ==== ${response.body}");
    return ProfileAboutMeModel.fromJson(jsonDecode(response.body));
  }

  ////////////////////// get single user about /////////////////////
  static Future<ClientAboutMe> clientAbout(id)async{
    var response = await http.get(Uri.parse(AppConfig.SINGLE_USER_PROFILE+id),
        headers: {
          "Accept" : "application/json",
        }
    );
    print("user ==== ${response.body}");
    return ClientAboutMe.fromJson(jsonDecode(response.body));
  }

  ////////////////////// get BusinessHoursModel info /////////////////////
  static Future<BusinessHoursModel> getBusinessHours()async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var userId = _pref.getString("user_id");

    var response = await http.get(Uri.parse(AppConfig.BUSINESS_HOURS+userId!),
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token"
        }
    );
    print(AppConfig.BUSINESS_HOURS+userId!);
    print("Business Hours");
    print("user ==== ${response.body}");
    return BusinessHoursModel.fromJson(jsonDecode(response.body));
  }

  ////////////////////// get addBusinessHours info /////////////////////
  static Future<http.Response> addBusinessHours({dynamic data})async{

    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    print("data === $data");
    var response = await http.post(Uri.parse(AppConfig.ADD_BUSINESS_HOURS),
        body: {
          "data" : jsonEncode(data)
        },
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token"
        }
    );
    print("user ==== ${response.body}");
    return response;
  }



  ////////////////////// get client user info /////////////////////
  static Future<ClientProfileInfoModel> clientProfileInfo()async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.get(Uri.parse(AppConfig.CLIENT_USER_INFO),

        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token",
        }
    );
    print("CLIENT user ==== ${response.body}");
    return ClientProfileInfoModel.fromJson(jsonDecode(response.body));
  }


  ////////////////////// get freelancer user info /////////////////////
  static Future<UserInfoModel> freelancerProfileInfo()async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");

    print("freelancer user ==== ${AppConfig.FREELANCER_USER_INFO}");
    print("freelancer user ==== ${token}");
    var response = await http.get(Uri.parse(AppConfig.FREELANCER_USER_INFO),

        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token",
        }
    );
    print("freelancer user ==== ${response.body}");

    print("freelancer user ==== ${token}");
    var data =  UserInfoModel.fromJson(jsonDecode(response.body));
    print("freelancer user data ==== ${data}");
    return data;

  }



  ////////////////////// get single user info /////////////////////
  static Future<EqupmentsListModel> getEquipmentList()async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.get(Uri.parse(AppConfig.EQUIPMENTS_LIST),
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token"
        }
    );
    return EqupmentsListModel.fromJson(jsonDecode(response.body));
  }



  ////////////////////// get single user info /////////////////////
  static Future<AllBusnissType> getBusinessTypes()async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.get(Uri.parse(AppConfig.BUSINESS_TYPE_LIST),
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token"
        }
    );
    print("business === ${response.body}");
    return AllBusnissType.fromJson(jsonDecode(response.body));
  }



  ////////////////////// get single user info /////////////////////
  static Future<ServiceModel> getServiceList()async{
    print("Get service list api : ${AppConfig.SERVICE_LIST}");

    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");

    print("Token : $token");
    var response = await http.get(Uri.parse(AppConfig.SERVICE_LIST),
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token"
        }
    );

    print("get service list === ${response.body}");
    return ServiceModel.fromJson(jsonDecode(response.body));
  }



  ////////////////////// get single user info /////////////////////
  static Future<LanguesModel> getLanguages()async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var response = await http.get(Uri.parse(AppConfig.LANGUAGES),
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token"
        }
    );
    return LanguesModel.fromJson(jsonDecode(response.body));
  }


  ////////////////////// add languages /////////////////////
  static Future<LanguesModel> addLanguages({required String language_id})async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    print("token === ${token}");
    print(AppConfig.Add_LANGUAGES);
    var response = await http.post(Uri.parse(AppConfig.Add_LANGUAGES),
        body:{
          "language_id": language_id
        },
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token"
        }
    );
    print('body response ======= ${response.body}');
    print('body response ======= ${response.statusCode}');
    return LanguesModel.fromJson(jsonDecode(response.body));
  }


  ///////////////////////////////////////////////////////////////
  ///////////////////////All user list ////////////////////////
  // static Future
  static Future<AllUserModel> getAllUsers()async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var role;
    if(_pref.getString("role") == AppConst.CLIENT_ROLE){
      role = AppConst.FREELANCER_ROLE;
    }else{
      role = AppConst.CLIENT_ROLE;
    }
    print("role === ${role}");
    print("api === ${AppConfig.ALL_USERS_WITH_SERVICE+role!}");

    var token = _pref.getString("token");
    print("token === ${token}");
    var res = await http.get(Uri.parse(AppConfig.ALL_USERS_WITH_SERVICE+role!),
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token"
        }
    );

    print(AppConfig.ALL_USERS_WITH_SERVICE+role!);
    print("Service ===== ${res.body}");

    return AllUserModel.fromJson(jsonDecode(res.body));
  }

  ///////////////////////////////////////////////////////////////
  ///////////////////////All user list ////////////////////////
  // static Future
  static Future<AllUserModel> getAllUsersByServiceId(ID)async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var res = await http.get(Uri.parse(AppConfig.ALL_USERS_WITH_SERVICE+ID),
        headers: {
          "Accept" : "application/json"
        }
    );

    print("data user ===== ${res.body}");

    return AllUserModel.fromJson(jsonDecode(res.body));
  }




  static Future launchUrl(uri) async {
    if (!await launchUrl(Uri.parse("$uri"))) {
      throw Exception('Could not launch $uri');
    }else{
      launchUrl(Uri.parse("$uri"));
    }
  }



  ////////////////////// app notification /////////////////////
  // static Future appnotification()async{
  //   var response = await http.get(Uri.parse(AppConfig.alert),
  //       headers: {
  //         "Accept" : "application/json",
  //       }
  //   );
  //   print("notification ==== ${response.body}");
  //   return response.body;
  // }


  ////////////////////// get addBusinessHours info /////////////////////
  static Future<http.Response> publishAlert(id)async{

    print(AppConfig.SINGLE_PUBLISH_ALERT+id);
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var res = await http.get(Uri.parse(AppConfig.SINGLE_PUBLISH_ALERT+id),
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token"
        }
    );


    print("arerttttt ==== ${res.body}");
    return res;
  }


  ////////////////////// get addBusinessHours info /////////////////////
  static Future<http.Response> addPubishAlert({
  required String msg, status,
})async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var userId = _pref.getString("user_id");
    var res = await http.post(Uri.parse(AppConfig.PUBLISH_ALERT),
        body: {
          "status":status,
          "user_id":userId,
          "alert_msg" : msg
        },
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token"
        }
    );


    print("arerttttt ==== ${res.body}");
    print("arerttttt ==== ${res.statusCode}");
    return res;
  }

  ////////////////////// get addBusinessHours info /////////////////////
  static Future<http.Response> changlePublishAlertStatus({
    required status,
  })async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    var userId = _pref.getString("user_id");
    var res = await http.post(Uri.parse(AppConfig.PUBLISH_ALERT),
        body: {
          "status":status,
          "user_id":userId,
        },
        headers: {
          "Accept" : "application/json",
          "Authorization" : "Bearer $token"
        }
    );


    print("arerttttt ==== ${res.body}");
    return res;
  }



// //////////////////////  profile update /////////////////////
  // static Future profileUpdate({
  //   required String country_id,
  //   required String state_id,
  //   required String city_id,
  //   required String address,
  // })async{
  //   SharedPreferences _pref = await SharedPreferences.getInstance();
  //   var token = _pref.getString("token");
  //   var response = await http.post(Uri.parse(AppConfig.CLIENT_PROFILE_CREATE_TWO),
  //       body: {
  //         "business_phone":business_phone,
  //         "business_email":business_email,
  //         "website":website,
  //       },
  //       headers: {
  //         "Accept" : "application/json",
  //         "Authorization" : "Bearer $token",
  //       }
  //   );
  //   return response;
  // }


//update lat lng
static Future<http.Response> updateLatLong ({required String lat, lng})async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var userId = _pref.getString("user_id");
    var token = _pref.getString("token");
    var res = await http.post(Uri.parse(AppConfig.UPDATE_LAT_LNG),
      headers: {
        "Authorization" : "Bearer $token"
      },
      body: {
        "user_id" : userId,
        "latitude" : lat,
        "longitude" : lng
      }
    );
    return res;
}


static Future<http.Response> storeDeviceToken()async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    final FirebaseMessaging _fcm = FirebaseMessaging.instance;
    final device_token = await _fcm.getToken();

    print("device_token == ${device_token}");
    var token = _pref.getString("token");
    var res = await http.post(Uri.parse(AppConfig.DEVICE_TOKEN),
        body: {
          "device_token" : "$device_token"
        },
        headers: {
          "Authorization" : "Bearer $token"
        }
    );

    print("device token response == ${res.body}");
    print("device token response == ${res.statusCode}");

    if(res.statusCode == 200){

    }
    return res;
}


static Future<http.Response> sendNotification({
  required String device_token,
  required String msg,
  required String title,
})async{
    var data = {
      "registration_ids": [
       "${device_token}"
      ],
      "notification": {
        "body": "New Video has been uploaded",
        "title": "Inventorcode",
        "android_channel_id": "pushnotificationapp",
        "sound": false
      }

    };
    var res = await http.post(Uri.parse(AppConfig.FCM_URL),
      headers: {
        "Authorization" : "key=${AppConfig.FCM_NOTIFICCATION_TOKEN}"
      },
      body: jsonEncode(data)
    );

    return res;
}


}