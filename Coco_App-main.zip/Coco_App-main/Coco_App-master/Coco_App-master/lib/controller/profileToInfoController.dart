import 'package:coco/controller/postController.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../model/authModel/allUserList.dart';
import '../model/authModel/singleUserInfo.dart';
import 'authController.dart';

class ProfileToInfoController extends GetxController {
  RxInt favCount = 0.obs;

  getFetchUserFavCount() async{
    await Future.delayed(const Duration(seconds: 0));
    favCount.value = await PostController.getAllFavPostsCount();

    SharedPreferences pref = await SharedPreferences.getInstance();
    String user_id = pref.getString("user_id").toString();

    SingleUserInfoModel? singleUserFollowFollowingFuture = null;

    singleUserFollowFollowingFuture  = await AuthController.getSingleUserInfo(user_id);

    favCount.value = favCount.value + singleUserFollowFollowingFuture.data!.user![0].userFavorite!.length;

  }
}