import 'package:coco/helper/helperFunctions.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../model/authModel/allBusinessTypeModel.dart';
import '../model/authModel/equpmentsListModel.dart';
import '../model/authModel/serviceModle.dart';
import '../model/userProfile/FreelancerProfileModel.dart';
import '../model/userinfo_model.dart';
import 'authController.dart';

class UserEditController extends GetxController {
  Rx<UserInfoModel?> getUserInfo = Rx<UserInfoModel?>(null);
  RxBool isLoading = true.obs;
  RxString role = "".obs;
  RxString language = "".obs;


  final usernameController = TextEditingController().obs;
  final EmailController = TextEditingController().obs;
  final DescriptionController = TextEditingController().obs;
  final phoneController = TextEditingController().obs;

  Rx<EqupmentsListModel?> getEqupmentsList = Rx<EqupmentsListModel?>(null);
  Rx<ServiceModel?> getServiceModel = Rx<ServiceModel?>(null);
  Rx<AllBusnissType?> getBussinessTypeModel = Rx<AllBusnissType?>(null);

  RxList<String> selectedSkill = <String>[].obs;
  List<String> selectEquipments = <String>[].obs;
  List<String> selectedBussinessType = <String>[].obs;
  List<String> writtenExtraEquipments = <String>[].obs;


  RxBool showSkillEditPanel = false.obs;
  RxBool showEquipmentEditPanel = false.obs;
  RxBool showExtraEquipmentEditPanel = false.obs;
  RxBool showPersonalWebsiteEditingPanel = false.obs;
  RxBool showLocationEditingPanel = false.obs;



  final extraEquipmentsController = TextEditingController().obs;
  final personalWebController = TextEditingController().obs;
  final pricePerDay = TextEditingController().obs;

  RxString selectedValue = "select option".obs;

  Rx<TextEditingController> country = TextEditingController().obs;
  Rx<TextEditingController> countryId = TextEditingController().obs;
  Rx<TextEditingController> zipcode = TextEditingController().obs;
  Rx<TextEditingController> city = TextEditingController().obs;
  Rx<TextEditingController> cityId = TextEditingController().obs;
  Rx<TextEditingController> state = TextEditingController().obs;
  Rx<TextEditingController> stateId = TextEditingController().obs;
  Rx<TextEditingController> address = TextEditingController().obs;
  Rx<TextEditingController> CountrySearchController = TextEditingController().obs;




  @override
  void onInit() {
    super.onInit();
  }

  getData() async {
    Future.delayed(Duration.zero);

    isLoading.value = true;
    getUserInfo.value = null;

    getUserInfo.value = await AuthController.freelancerProfileInfo();

    print("getUserInfo.value!.data!.user!.role! => ${getUserInfo.value!.data!.user!.role!}");

    role.value = getUserInfo.value!.data!.user!.role!;
    usernameController.value.text = (getUserInfo.value!.data!.user!.name ?? getUserInfo.value!.data!.user!.userName)!;
    EmailController.value.text = getUserInfo.value!.data!.user!.email!;
    DescriptionController.value.text = getUserInfo.value!.data!.userInfo?.description ?? "";
    phoneController.value.text = getUserInfo.value!.data!.user!.phone ?? "";

    List<String?> languages = [];
    languages = getUserInfo.value!.data!.language!;

    languages.forEach((element) {
      language.value = "${language.value}$element, ";
    });
    //Remove last comma
    language.value = replaceLastComma(language.value);

    // language.value = getUserInfo.value!.data!.userInfo?.language.toString().replaceAll('[', '').replaceAll(']', '') ?? "No language found";

    getEqupmentsList.value = await AuthController.getEquipmentList();
    getServiceModel.value = await AuthController.getServiceList();

    if(getUserInfo.value!.data!.userInfo!.serviceList != null && getUserInfo.value!.data!.userInfo!.serviceList != "") {
      List<int> mySelectedSkills = HelperFunction.convertStringToListInt(getUserInfo.value!.data!.userInfo!.serviceList);
      for(int i = 0; i < mySelectedSkills.length; i++) {
        selectedSkill.add(mySelectedSkills[i].toString());
      }
    }


    if(getUserInfo.value!.data!.userInfo!.equipmentsList != null && getUserInfo.value!.data!.userInfo!.equipmentsList != "") {
      List<int> mySelectedEquipments = HelperFunction.convertStringToListInt(getUserInfo.value!.data!.userInfo!.equipmentsList);
      for(int i = 0; i < mySelectedEquipments.length; i++) {
        selectEquipments.add(mySelectedEquipments[i].toString());
      }
    }


    if(getUserInfo.value!.data!.userInfo!.extraEquipments != null && getUserInfo.value!.data!.userInfo!.extraEquipments != "") {
      //List<String> myWrittenExtraEquipments = HelperFunction.convertStringToListString(getUserInfo.value!.data!.userInfo!.extraEquipments);
      List<String> myWrittenExtraEquipments = HelperFunction.convertStringToListString( "\"[DSLR, cam, test]\"");
      for(int i = 0; i < myWrittenExtraEquipments.length; i++) {
        writtenExtraEquipments.add(myWrittenExtraEquipments[i]);
      }
    }

    // writtenExtraEquipments is  [[DSLR, cam, test]] and I want to remove the square brackets
    writtenExtraEquipments = writtenExtraEquipments.map((e) => e.replaceAll('[', '').replaceAll(']', '')).toList();

    print("writtenExtraEquipments => ${writtenExtraEquipments.toString()}");

    // Now writtenExtraEquipments is  [DSLR, cam, test] and I want to remove the square brackets and as string like "DSLR, cam, test"


    extraEquipmentsController.value.text = writtenExtraEquipments.toString().replaceAll('[', '').replaceAll(']', '') ?? "";

    personalWebController.value.text = getUserInfo.value!.data!.userInfo!.website ?? "No website found";

    if(getUserInfo.value!.data!.userInfo!.pricePerDay != null) {
      if(getUserInfo.value!.data!.userInfo!.pricePerDay.toString() == "collaborate") {
        selectedValue.value = "collaborate";
      }
      else {
        selectedValue.value = "price";
        pricePerDay.value.text = getUserInfo.value!.data!.userInfo!.pricePerDay ?? "No price found";
      }
    }

    // Set address
    country.value.text = getUserInfo.value!.data!.location?.country ?? "";
    countryId.value.text = getUserInfo.value!.data!.location?.countryId.toString() ?? "";
    zipcode.value.text = getUserInfo.value!.data!.location?.zipcode ?? "";
    city.value.text = getUserInfo.value!.data!.location?.city ?? "";
    cityId.value.text = getUserInfo.value!.data!.location?.cityId.toString() ?? "";
    state.value.text = getUserInfo.value!.data!.location?.state ?? "";
    stateId.value.text = getUserInfo.value!.data!.location?.stateId.toString() ?? "";
    address.value.text = getUserInfo.value!.data!.location?.address ?? "";



    isLoading.value = false;

  }


  String replaceLastComma(String inputString) {
    int lastCommaIndex = inputString.lastIndexOf(',');
    if (lastCommaIndex != -1) {
      // Replace the last comma with a space
      inputString = inputString.replaceRange(lastCommaIndex, lastCommaIndex + 1, ' ');
    }
    return inputString;
  }
}
