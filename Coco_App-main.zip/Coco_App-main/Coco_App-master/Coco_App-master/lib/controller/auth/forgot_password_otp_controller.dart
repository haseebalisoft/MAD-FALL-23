import 'dart:convert';

import 'package:coco/controller/authController.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../model/forgotPass/forgot_password_model.dart';
import '../../view/auth/forgot_password_otp.dart';
import '../../view/auth/reset_password.dart';

class ForgotPasswordOtpController extends GetxController{
  RxBool isLoading = false.obs;


  sendEmail(String email, BuildContext context)async{
    isLoading.value = true;

    var response = await AuthController.forgotPassword(email : email);

    if(response.statusCode == 200){
      Get.snackbar(
        "Password Reset OTP Sent",
        "Please check your email for the OTP",
        icon: const Icon(Icons.mark_email_read_rounded, color: Colors.white),
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green,
        titleText: const Text(
          "Password Reset OTP Sent",
          style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.bold
          ),
        ),
        messageText: const Text(
          "Please check your email for the OTP",
          style: TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.w400
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 8.0),

      );
    }
    else{
      var data = jsonDecode(response.body);

      Get.snackbar(
        "Something wrong happened",
        data["massage"],
        icon: const Icon(Icons.error_outline, color: Colors.white),
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        titleText: const Text(
          "Password Reset OTP Sent",
          style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.bold
          ),
        ),
        messageText:  Text(
          data["massage"],
          style: TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.w400
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 8.0),

      );
    }

    isLoading.value = false;

  }

  resetTokenVerify(String email, String otp, BuildContext context)async{
    isLoading.value = true;

    var response = await AuthController.resetTokenVerify(email : email, otp: otp);

    isLoading.value = false;


    if(response.statusCode == 200){
      var data = jsonDecode(response.body);

      Get.snackbar(
        "Verified",
        data["massage"],
        icon: const Icon(Icons.verified_rounded, color: Colors.white),
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green,
        titleText: const Text(
          "Verified",
          style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.bold
          ),
        ),
        messageText: Text(
          data["massage"],
          style: TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.w400
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 8.0),

      );
      Get.offAll(ResetPassword(email: email,));
    }
    else{
      var data = jsonDecode(response.body);

      Get.snackbar(
        "Something wrong happened",
        data["massage"],
        icon: const Icon(Icons.error_outline, color: Colors.white),
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        titleText: const Text(
          "Something wrong happened",
          style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.bold
          ),
        ),
        messageText:  Text(
          data["massage"],
          style: TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.w400
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 8.0),

      );

    }


  }
}