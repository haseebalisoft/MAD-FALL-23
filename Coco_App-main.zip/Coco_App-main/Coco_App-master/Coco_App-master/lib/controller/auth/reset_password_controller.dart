import 'dart:convert';

import 'package:coco/controller/authController.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../model/forgotPass/forgot_password_model.dart';
import '../../view/auth/forgot_password_otp.dart';
import '../../view/auth/sign_in.dart';

class ResetPasswordController extends GetxController{
  RxBool isLoading = false.obs;


  RxInt statusCode = 0.obs;
  RxString message = "".obs;



  resetPassword(String email, String password, BuildContext context)async{
    isLoading.value = true;

    statusCode.value = 0;
    message.value = "";

    var response = await AuthController.resetPassword(email : email, password: password);



    if(response.statusCode == 200){
      var data = jsonDecode(response.body);

      Get.snackbar(
        "Password Changed",
        data["massage"],
        icon: const Icon(Icons.published_with_changes_outlined, color: Colors.white),
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green,
        titleText: const Text(
          "Password Changed",
          style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.bold
          ),
        ),
        messageText: Text(
          data["massage"],
          style: TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.w400
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 8.0),

      );
      Get.offAll(SignInPage());
    }
    else{
      var data = jsonDecode(response.body);

      Get.snackbar(
        "Something wrong happened",
        data["massage"],
        icon: const Icon(Icons.error_outline, color: Colors.white),
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        titleText: const Text(
          "Something wrong happened",
          style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.bold
          ),
        ),
        messageText:  Text(
          data["massage"],
          style: TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.w400
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 8.0),

      );

    }

    isLoading.value = false;

  }
}