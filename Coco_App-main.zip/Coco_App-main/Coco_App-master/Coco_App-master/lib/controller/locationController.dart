import 'package:coco/controller/serviceController.dart';
import 'package:coco/helper/helperFunctions.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';

import '../appConst.dart';
import '../model/authModel/allBusinessTypeModel.dart';
import '../model/authModel/allUserList.dart';
import '../model/authModel/serviceModle.dart';
import '../model/service/serviceModel.dart';
import 'authController.dart';

class LocationController extends GetxController{
  Rx<AllBusnissType?> getBusinessType = Rx<AllBusnissType?>(null);
  Rx<ServiceModel?> getServices = Rx<ServiceModel?>(null);

  RxList<String> service = <String>[].obs;
  Rx<BitmapDescriptor> ownMarkerIcon = Rx<BitmapDescriptor>(BitmapDescriptor.defaultMarker);
  Rx<BitmapDescriptor> otherMarkerIcon = Rx<BitmapDescriptor>(BitmapDescriptor.defaultMarker);

  var lat = 0.0.obs;
  var lng = 0.0.obs;


  Rx<AllUserModel?> getAllUser =  Rx<AllUserModel?>(null);



  RxBool isLoading = true.obs;
  var role = "".obs;

  getAllBusinessType() async {
    getAllUser.value = null;
    getBusinessType.value  = null;
    getServices.value = null;

    isLoading.value = true;

    final byteData = await rootBundle.load('asset/image/google_map_marker_own.png');
    ownMarkerIcon.value = BitmapDescriptor.fromBytes(byteData.buffer.asUint8List());

    final byteData2 = await rootBundle.load('asset/image/other_clients_freelancer_marker.png');
    otherMarkerIcon.value = BitmapDescriptor.fromBytes(byteData2.buffer.asUint8List());


    role.value = await HelperFunction.getUserRole();

    if(role.value == AppConst.CLIENT_ROLE){
      getServices.value = await AuthController.getServiceList();
    }
    else{
      getBusinessType.value = await AuthController.getBusinessTypes();
    }

    getAllUser.value = await AuthController.getAllUsers();

    var locationData = await HelperFunction.locationData();
    lat.value = locationData.latitude!;
    lng.value = locationData.longitude!;
    // lat.value = 23.7743657;
    // lng.value = 90.3656872;
    isLoading.value = false;
  }



  getUserByIDWithRole(int id)async{
    getAllUser.value = null;
    isLoading.value = true;
    final byteData = await rootBundle.load('asset/image/google_map_marker_own.png');
    ownMarkerIcon.value = BitmapDescriptor.fromBytes(byteData.buffer.asUint8List());

    final byteData2 = await rootBundle.load('asset/image/other_clients_freelancer_marker.png');
    otherMarkerIcon.value = BitmapDescriptor.fromBytes(byteData2.buffer.asUint8List());

    role.value =  await HelperFunction.getUserRole();


    getAllUser.value = await AuthController.getAllUsers();


    AllUserModel? newGetAllUser = AllUserModel(
      data: [],
      status: getAllUser.value!.status,
      massage: getAllUser.value!.massage,
    );


    print("Baaaaaaaaaaaaaaaaaaaaaaaaaaaaal");
    if(newGetAllUser != null){
      for(int i = 0; i < getAllUser.value!.data!.length; i++){

        if(role == AppConst.CLIENT_ROLE){
          if(HelperFunction.convertStringToListInt(getAllUser.value!.data![i].userInfo?.serviceList).contains(id)){
            newGetAllUser.data!.add(getAllUser.value!.data![i]);
            print("addff");
          }
        }
        else{
          if(HelperFunction.convertStringToListInt(getAllUser.value!.data![i].userInfo?.businessList).contains(id)){
            newGetAllUser.data!.add(getAllUser.value!.data![i]);
            print("ffadd");
          }
        }


      }
    }

    getAllUser.value = newGetAllUser;

    print("getAllUser.value!.data!.length");
    print(getAllUser.value!.data!.length);

    for(int i = 0; i < getAllUser.value!.data!.length; i++){
      print(getAllUser.value!.data![i].latitude);
      print(getAllUser.value!.data![i].longitude);
    }


    isLoading.value = false;
  }


  filterByServiceClick(int  serviceIndex) async {
    role.value =  await HelperFunction.getUserRole();

    if(service.contains(serviceIndex.toString())){
      isLoading.value = true;

      service.remove(serviceIndex.toString());
      getAllUser.value = await AuthController.getAllUsers();

      isLoading.value = false;
    }
    else{
      service.clear();
      service.add(serviceIndex.toString());
      if(role.value == AppConst.CLIENT_ROLE){
        getUserByIDWithRole(getServices.value!.data![serviceIndex].id!);

      }
      else{
        getUserByIDWithRole(getBusinessType.value!.data![serviceIndex].id!);
      }
    }
  }

}