class AppConst{
  static const String FREELANCER_ROLE = "freelancer";
  static const String CLIENT_ROLE = "client";
}