
import 'package:coco/controller/authController.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/view/Client/bottomNagivation/buttom_nav.dart';
import 'package:coco/view/auth/role_selector.dart';
import 'package:coco/view/auth/sign_in.dart';
import 'package:coco/view/flashScreen/Splash_screen.dart';
import 'package:coco/view/freelancer/bottomNavigationBar/becameFreelanceBottomNavigation.dart';
import 'package:coco/view/onboarding/onboarding.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:location/location.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'local_notification/local_notification.dart';

class Cocoapp extends StatefulWidget {
  const Cocoapp({super.key});

  @override
  State<Cocoapp> createState() => _CocoappState();
}

class _CocoappState extends State<Cocoapp> {



  getLocationPermission()async{
    Location location = new Location();

    bool _serviceEnabled;
    PermissionStatus _permissionGranted;
    LocationData _locationData;

    _serviceEnabled = await location.serviceEnabled();
    if (!_serviceEnabled) {
      _serviceEnabled = await location.requestService();
      if (!_serviceEnabled) {
        return;
      }
    }

    _permissionGranted = await location.hasPermission();
    if (_permissionGranted == PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted != PermissionStatus.granted) {
        return;
      }
    }
  }


  getNotificatoin()async{
    FirebaseMessaging messaging = FirebaseMessaging.instance;

    NotificationSettings settings = await messaging.requestPermission(
      alert: true,
      announcement: false,
      badge: true,
      carPlay: false,
      criticalAlert: false,
      provisional: false,
      sound: true,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      print('User granted permission');
    } else if (settings.authorizationStatus == AuthorizationStatus.provisional) {
      print('User granted provisional permission');
    } else {
      print('User declined or has not accepted permission');
    }
  }



  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // 1. This method call when app in terminated state and you get a notification
    // when you click on notification app open from terminated state and you can get notification data in this method
    getNotificatoin();
    FirebaseMessaging.instance.getInitialMessage().then(
          (message) {
        print("FirebaseMessaging.instance.getInitialMessage");
        if (message != null) {
          print("terminet notification ");
          // if (message.data['_id'] != null) {
          //   Navigator.of(context).push(
          //     MaterialPageRoute(
          //       builder: (context) => DemoScreen(
          //         id: message.data['_id'],
          //       ),
          //     ),
          //   );
          // }
        }
      },
    );

    // 2. This method only call when App in forground it mean app must be opened
    FirebaseMessaging.onMessage.listen(
          (message) {
        print("FirebaseMessaging.onMessage.listen");
        if (message.notification != null) {
          print(message.notification!.title);
          print(message.notification!.body);
          print("message.data11 ${message.data}");
           LocalNotificationService.createanddisplaynotification(message);
        }
      },
    );

    // 3. This method only call when App in background and not terminated(not closed)
    FirebaseMessaging.onMessageOpenedApp.listen(
          (message) {
        print("FirebaseMessaging.onMessageOpenedApp.listen");
        if (message.notification != null) {
          print(message.notification!.title);
          print(message.notification!.body);
          print("message.data22 ${message.data['_id']}");
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
   return Sizer(
        builder: (context, orientation, deviceType) {
         return GetMaterialApp(
            debugShowCheckedModeBanner: false,
            theme: ThemeData(
              canvasColor: Colors.transparent,
              inputDecorationTheme:  InputDecorationTheme(


                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide.none
                ),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide.none
                ),
                fillColor: AppColors.formColorUp,
                hintStyle: TextStyle(
                    fontWeight: FontWeight.w400,
                    fontSize: 12,

                    color: AppColors.textgrey),
                labelStyle: TextStyle(
                  color: AppColors.white,
                  fontSize: 14
                ),

                contentPadding: EdgeInsets.symmetric(horizontal: 25, vertical: 16),
                filled: true,
                border: OutlineInputBorder(borderSide: BorderSide.none),




              ),

              elevatedButtonTheme: ElevatedButtonThemeData(
                  style: ElevatedButton.styleFrom(
                      textStyle: TextStyle(
                        color: Color(0xffEEEEEE),
                        fontSize: 14,
                        fontFamily: 'Poppins-Bold',
                      ),
                      backgroundColor: AppColors.mainColor,
                      padding: EdgeInsets.symmetric(vertical: 15),
                      elevation: 3,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8)
                      )
                  )
              ),
              fontFamily: 'Poppins',
            ),
           // home: OnBoarding(),
            home: Splash_screen(),
            localizationsDelegates: const <LocalizationsDelegate<dynamic>>[
             GlobalWidgetsLocalizations.delegate,
             GlobalMaterialLocalizations.delegate,
             GlobalCupertinoLocalizations.delegate,
           ],
          );
        }
    );
  }
}
