class UserInfoModel {
  Data? data;
  bool? status;
  String? massage;

  UserInfoModel({this.data, this.status, this.massage});

  UserInfoModel.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
    status = json['status'];
    massage = json['massage'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    data['status'] = this.status;
    data['massage'] = this.massage;
    return data;
  }
}

class Data {
  User? user;
  UserInfo? userInfo;
  List<String>? serviceName;
  List<String>? language;
  Location? location;
  List<String>? equipmentsName;
  Social? socialLink;

  Data(
      {this.user,
        this.userInfo,
        this.serviceName,
        this.language,
        this.location,
        this.equipmentsName,
        this.socialLink});

  Data.fromJson(Map<String, dynamic> json) {
    user = json['user'] != null ? new User.fromJson(json['user']) : null;
    userInfo = json['user_info'] != null
        ? new UserInfo.fromJson(json['user_info'])
        : null;
    serviceName = json['service_name'].cast<String>();
    language = json['language'].cast<String>();
    print(json["location"]);
    print(json["location"] is List);
    location = (json["location"] is List && json["location"].length == 0) ? null : Location.fromJson(json["location"]);
    equipmentsName = json['equipments_name'].cast<String>();
    socialLink = json['social_link'] != null
        ? new Social.fromJson(json['social_link'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.user != null) {
      data['user'] = this.user!.toJson();
    }
    if (this.userInfo != null) {
      data['user_info'] = this.userInfo!.toJson();
    }
    data['service_name'] = this.serviceName;
    data['language'] = this.language;
    data['location'] = this.location;
    data['equipments_name'] = this.equipmentsName;
    if (this.socialLink != null) {
      data['social_link'] = this.socialLink!.toJson();
    }
    return data;
  }
}

class User {
  int? id;
  String? name;
  String? email;
  String? phone;
  String? userName;
  String? role;
  String? storyUpload;
  String? coverImage;
  String? twoFactorSecret;
  String? twoFactorRecoveryCodes;
  String? createdAt;
  String? updatedAt;
  String? profileImage;
  double? longitude;
  double? latitude;
  String? deviceToken;
  String? resetCode;
  UserInfo? userInfo;
  Social? social;

  User(
      {this.id,
        this.name,
        this.email,
        this.phone,
        this.userName,
        this.role,
        this.storyUpload,
        this.coverImage,
        this.twoFactorSecret,
        this.twoFactorRecoveryCodes,
        this.createdAt,
        this.updatedAt,
        this.profileImage,
        this.longitude,
        this.latitude,
        this.deviceToken,
        this.resetCode,
        this.userInfo,
        this.social});

  User.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    email = json['email'];
    phone = json['phone'];
    userName = json['user_name'];
    role = json['role'];
    storyUpload = json['StoryUpload'];
    coverImage = json['cover_image'];
    twoFactorSecret = json['two_factor_secret'];
    twoFactorRecoveryCodes = json['two_factor_recovery_codes'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    profileImage = json['profileImage'];
    longitude = json['longitude'];
    latitude = json['latitude'];
    deviceToken = json['device_token'];
    resetCode = json['reset_code'];
    userInfo = json['user_info'] != null
        ? new UserInfo.fromJson(json['user_info'])
        : null;
    social =
    json['social'] != null ? new Social.fromJson(json['social']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['email'] = this.email;
    data['phone'] = this.phone;
    data['user_name'] = this.userName;
    data['role'] = this.role;
    data['StoryUpload'] = this.storyUpload;
    data['cover_image'] = this.coverImage;
    data['two_factor_secret'] = this.twoFactorSecret;
    data['two_factor_recovery_codes'] = this.twoFactorRecoveryCodes;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['profileImage'] = this.profileImage;
    data['longitude'] = this.longitude;
    data['latitude'] = this.latitude;
    data['device_token'] = this.deviceToken;
    data['reset_code'] = this.resetCode;
    if (this.userInfo != null) {
      data['user_info'] = this.userInfo!.toJson();
    }
    if (this.social != null) {
      data['social'] = this.social!.toJson();
    }
    return data;
  }
}

class UserInfo {
  int? id;
  int? userId;
  String? description;
  String? businessPhone;
  String? businessEmail;
  String? website;
  String? language;
  String? pricePerDay;
  String? serviceList;
  String? equipmentsList;
  String? extraEquipments;
  int? step1Complete;
  int? step2Complete;
  int? step3Complete;
  String? createdAt;
  String? updatedAt;
  String? languages;
  String? businessList;

  UserInfo(
      {this.id,
        this.userId,
        this.description,
        this.businessPhone,
        this.businessEmail,
        this.website,
        this.language,
        this.pricePerDay,
        this.serviceList,
        this.equipmentsList,
        this.extraEquipments,
        this.step1Complete,
        this.step2Complete,
        this.step3Complete,
        this.createdAt,
        this.updatedAt,
        this.languages,
        this.businessList});

  UserInfo.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    description = json['description'];
    businessPhone = json['business_phone'];
    businessEmail = json['business_email'];
    website = json['website'];
    language = json['language'];
    pricePerDay = json['price_per_day'];
    serviceList = json['service_list'];
    equipmentsList = json['equipments_list'];
    extraEquipments = json['extra_equipments'];
    step1Complete = json['step_1_complete'];
    step2Complete = json['step_2_complete'];
    step3Complete = json['step_3_complete'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    languages = json['languages'];
    businessList = json['business_list'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['description'] = this.description;
    data['business_phone'] = this.businessPhone;
    data['business_email'] = this.businessEmail;
    data['website'] = this.website;
    data['language'] = this.language;
    data['price_per_day'] = this.pricePerDay;
    data['service_list'] = this.serviceList;
    data['equipments_list'] = this.equipmentsList;
    data['extra_equipments'] = this.extraEquipments;
    data['step_1_complete'] = this.step1Complete;
    data['step_2_complete'] = this.step2Complete;
    data['step_3_complete'] = this.step3Complete;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['languages'] = this.languages;
    data['business_list'] = this.businessList;
    return data;
  }
}

class Social {
  int? id;
  int? userId;
  String? facebook;
  String? instagram;
  String? youtube;
  String? tiktok;
  String? behance;
  String? dribble;
  String? vimeo;
  DateTime? createdAt;
  DateTime? updatedAt;

  Social(
      {this.id,
        this.userId,
        this.facebook,
        this.instagram,
        this.youtube,
        this.tiktok,
        this.behance,
        this.dribble,
        this.vimeo,
        this.createdAt,
        this.updatedAt});

  Social.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    facebook = json['facebook'];
    instagram = json['instagram'];
    youtube = json['youtube'];
    tiktok = json['tiktok'];
    behance = json['behance'];
    dribble = json['dribble'];
    vimeo = json['vimeo'];
    createdAt = json["created_at"] == null ? null : DateTime.parse(json["created_at"]);
    updatedAt = json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['facebook'] = this.facebook;
    data['instagram'] = this.instagram;
    data['youtube'] = this.youtube;
    data['tiktok'] = this.tiktok;
    data['behance'] = this.behance;
    data['dribble'] = this.dribble;
    data['vimeo'] = this.vimeo;
    data['created_at'] = this.createdAt?.toIso8601String();
    data['updated_at'] = this.updatedAt?.toIso8601String();
    return data;
  }
}

class Location {
  final String? country;
  final String? state;
  final String? city;
  final String? address;
  final String? zipcode;
  final int? countryId;
  final int? stateId;
  final int? cityId;

  Location({
    this.country,
    this.state,
    this.city,
    this.address,
    this.zipcode,
    this.countryId,
    this.stateId,
    this.cityId,
  });

  factory Location.fromJson(Map<String, dynamic> json) {
    return Location(
      country: (json["Country"] is String) ? json["Country"] : null,
      state: (json["State"] is String) ? json["State"] : null,
      city: (json["City"] is String) ? json["City"] : null,
      address: (json["Address"] is String) ? json["Address"] : null,
      zipcode: (json["zipcode"] is String) ? json["zipcode"] : null,
      countryId: (json["country_id"] is int) ? json["country_id"] : null,
      stateId: (json["state_id"] is int) ? json["state_id"] : null,
      cityId: (json["city_id"] is int) ? json["city_id"] : null,
    );
  }

  Map<String, dynamic> toJson() => {
    "Country": country,
    "State": state,
    "City": city,
    "Address": address,
    "zipcode": zipcode,
    "country_id": countryId,
    "state_id": stateId,
    "city_id": cityId,
  };
}