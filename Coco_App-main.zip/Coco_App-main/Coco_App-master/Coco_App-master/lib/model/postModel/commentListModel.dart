// To parse this JSON data, do
//
//     final singlePostCommentListModel = singlePostCommentListModelFromJson(jsonString);

import 'dart:convert';

SinglePostCommentListModel singlePostCommentListModelFromJson(String str) => SinglePostCommentListModel.fromJson(json.decode(str));

String singlePostCommentListModelToJson(SinglePostCommentListModel data) => json.encode(data.toJson());

class SinglePostCommentListModel {
  final List<CommentList>? data;
  final bool? status;
  final String? massage;

  SinglePostCommentListModel({
    this.data,
    this.status,
    this.massage,
  });

  factory SinglePostCommentListModel.fromJson(Map<String, dynamic> json) => SinglePostCommentListModel(
    data: json["data"] == null ? [] : List<CommentList>.from(json["data"]!.map((x) => CommentList.fromJson(x))),
    status: json["status"],
    massage: json["massage"],
  );

  Map<String, dynamic> toJson() => {
    "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x.toJson())),
    "status": status,
    "massage": massage,
  };
}

class CommentList {
  final int? id;
  final String? comments;
  final String? time;
  final String? hide;
  final CommentUser? commentUser;

  CommentList({
    this.id,
    this.comments,
    this.time,
    this.hide,
    this.commentUser,
  });

  factory CommentList.fromJson(Map<String, dynamic> json) => CommentList(
    id: json["id"],
    comments: json["Comments"],
    time: json["time"],
    hide: json["hide"],
    commentUser: json["comment_user"] == null ? null : CommentUser.fromJson(json["comment_user"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "Comments": comments,
    "time": time,
    "hide": hide,
    "comment_user": commentUser?.toJson(),
  };
}

class CommentUser {
  final int? id;
  final String? name;
  final String? email;
  final String? phone;
  final String? userName;
  final String? role;
  final DateTime? storyUpload;
  final String? coverImage;
  final dynamic twoFactorSecret;
  final dynamic twoFactorRecoveryCodes;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final String? profileImage;
  final double? longitude;
  final double? latitude;
  final dynamic deviceToken;

  CommentUser({
    this.id,
    this.name,
    this.email,
    this.phone,
    this.userName,
    this.role,
    this.storyUpload,
    this.coverImage,
    this.twoFactorSecret,
    this.twoFactorRecoveryCodes,
    this.createdAt,
    this.updatedAt,
    this.profileImage,
    this.longitude,
    this.latitude,
    this.deviceToken,
  });

  factory CommentUser.fromJson(Map<String, dynamic> json) => CommentUser(
    id: json["id"],
    name: json["name"],
    email: json["email"],
    phone: json["phone"],
    userName: json["user_name"],
    role: json["role"],
    storyUpload: json["StoryUpload"] == null ? null : DateTime.parse(json["StoryUpload"]),
    coverImage: json["cover_image"],
    twoFactorSecret: json["two_factor_secret"],
    twoFactorRecoveryCodes: json["two_factor_recovery_codes"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    profileImage: json["profileImage"],
    longitude: json["longitude"]?.toDouble(),
    latitude: json["latitude"]?.toDouble(),
    deviceToken: json["device_token"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "email": email,
    "phone": phone,
    "user_name": userName,
    "role": role,
    "StoryUpload": storyUpload?.toIso8601String(),
    "cover_image": coverImage,
    "two_factor_secret": twoFactorSecret,
    "two_factor_recovery_codes": twoFactorRecoveryCodes,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
    "profileImage": profileImage,
    "longitude": longitude,
    "latitude": latitude,
    "device_token": deviceToken,
  };
}
