// To parse this JSON data, do
//
//     final allPostModel = allPostModelFromJson(jsonString);

import 'dart:convert';

AllPostModel allPostModelFromJson(String str) => AllPostModel.fromJson(json.decode(str));

String allPostModelToJson(AllPostModel data) => json.encode(data.toJson());

// class AllPostModel {
//   final List<Datum>? data;
//   final bool? status;
//   final String? massage;
//
//   AllPostModel({
//     this.data,
//     this.status,
//     this.massage,
//   });
//
//   factory AllPostModel.fromJson(Map<String, dynamic> json) => AllPostModel(
//     data: json["data"] == null ? [] : List<Datum>.from(json["data"]!.map((x) => Datum.fromJson(x))),
//     status: json["status"],
//     massage: json["massage"],
//   );
//
//   Map<String, dynamic> toJson() => {
//     "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x.toJson())),
//     "status": status,
//     "massage": massage,
//   };
// }
//
// class Datum {
//   final Post? post;
//   final String? postTime;
//   final List<UserDatum>? userData;
//   final List<Images>? image;
//   final int? like;
//   final List<String>? postLikers;
//
//   Datum({
//     this.post,
//     this.postTime,
//     this.userData,
//     this.image,
//     this.like,
//     this.postLikers,
//   });
//
//   factory Datum.fromJson(Map<String, dynamic> json) => Datum(
//     post: json["post"] == null ? null : Post.fromJson(json["post"]),
//     postTime: json["post_time"],
//     userData: json["user_data"] == null ? [] : List<UserDatum>.from(json["user_data"]!.map((x) => UserDatum.fromJson(x))),
//     image: json["image"] == null ? [] : List<Images>.from(json["image"]!.map((x) => Images.fromJson(x))),
//     like: json["like"],
//     postLikers: json["post_likers"] == null ? [] : List<String>.from(json["post_likers"]!.map((x) => x)),
//   );
//
//   Map<String, dynamic> toJson() => {
//     "post": post?.toJson(),
//     "post_time": postTime,
//     "user_data": userData == null ? [] : List<dynamic>.from(userData!.map((x) => x.toJson())),
//     "image": image == null ? [] : List<dynamic>.from(image!.map((x) => x.toJson())),
//     "like": like,
//     "post_likers": postLikers == null ? [] : List<dynamic>.from(postLikers!.map((x) => x)),
//   };
// }
//
// class Images {
//   final int? id;
//   final String? image;
//   final String? imageType;
//   final int? refId;
//   final DateTime? createdAt;
//   final DateTime? updatedAt;
//
//   Images({
//     this.id,
//     this.image,
//     this.imageType,
//     this.refId,
//     this.createdAt,
//     this.updatedAt,
//   });
//
//   factory Images.fromJson(Map<String, dynamic> json) => Images(
//     id: json["id"],
//     image: json["image"],
//     imageType: json["image_type"],
//     refId: json["ref_id"],
//     createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
//     updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
//   );
//
//   Map<String, dynamic> toJson() => {
//     "id": id,
//     "image": image,
//     "image_type": imageType,
//     "ref_id": refId,
//     "created_at": createdAt?.toIso8601String(),
//     "updated_at": updatedAt?.toIso8601String(),
//   };
// }
//
// class Post {
//   final int? id;
//   final int? userId;
//   final String? description;
//   final DateTime? createdAt;
//   final DateTime? updatedAt;
//
//   Post({
//     this.id,
//     this.userId,
//     this.description,
//     this.createdAt,
//     this.updatedAt,
//   });
//
//   factory Post.fromJson(Map<String, dynamic> json) => Post(
//     id: json["id"],
//     userId: json["user_id"],
//     description: json["description"],
//     createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
//     updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
//   );
//
//   Map<String, dynamic> toJson() => {
//     "id": id,
//     "user_id": userId,
//     "description": description,
//     "created_at": createdAt?.toIso8601String(),
//     "updated_at": updatedAt?.toIso8601String(),
//   };
// }
//
// class UserDatum {
//   final int? id;
//   final String? name;
//   final String? email;
//   final String? phone;
//   final String? userName;
//   final String? role;
//   final DateTime? createdAt;
//   final DateTime? updatedAt;
//   final String? profileImage;
//   final dynamic longitude;
//   final dynamic latitude;
//
//   UserDatum({
//     this.id,
//     this.name,
//     this.email,
//     this.phone,
//     this.userName,
//     this.role,
//     this.createdAt,
//     this.updatedAt,
//     this.profileImage,
//     this.longitude,
//     this.latitude,
//   });
//
//   factory UserDatum.fromJson(Map<String, dynamic> json) => UserDatum(
//     id: json["id"],
//     name: json["name"],
//     email: json["email"],
//     phone: json["phone"],
//     userName: json["user_name"],
//     role: json["role"],
//     createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
//     updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
//     profileImage: json["profileImage"],
//     longitude: json["longitude"],
//     latitude: json["latitude"],
//   );
//
//   Map<String, dynamic> toJson() => {
//     "id": id,
//     "name": name,
//     "email": email,
//     "phone": phone,
//     "user_name": userName,
//     "role": role,
//     "created_at": createdAt?.toIso8601String(),
//     "updated_at": updatedAt?.toIso8601String(),
//     "profileImage": profileImage,
//     "longitude": longitude,
//     "latitude": latitude,
//   };
// }
class AllPostModel {
  List<Datum>? data;
  bool? status;
  String? massage;

  AllPostModel({this.data, this.status, this.massage});

  AllPostModel.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <Datum>[];
      json['data'].forEach((v) {
        data!.add(new Datum.fromJson(v));
      });
    }
    status = json['status'];
    massage = json['massage'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    data['status'] = this.status;
    data['massage'] = this.massage;
    return data;
  }
}

class Datum {
  Post? post;
  String? postTime;
  List<UserDatum>? userData;
  List<Images>? image;
  int? like;
  List<String>? postLikers;
  bool? isLiked;
  bool? isFav;

  Datum(
      {this.post,
        this.postTime,
        this.userData,
        this.image,
        this.like,
        this.postLikers,
        this.isLiked,
        this.isFav
      });

  Datum.fromJson(Map<String, dynamic> json) {
    post = json['post'] != null ? new Post.fromJson(json['post']) : null;
    postTime = json['post_time'];
    if (json['user_data'] != null) {
      userData = <UserDatum>[];
      json['user_data'].forEach((v) {
        userData!.add(new UserDatum.fromJson(v));
      });
    }
    if (json['image'] != null) {
      image = <Images>[];
      json['image'].forEach((v) {
        image!.add(new Images.fromJson(v));
      });
    }
    like = json['like'];
    postLikers = json['post_likers'].cast<String>();
    isLiked = json['is_liked'];
    isFav = json['is_fav'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.post != null) {
      data['post'] = this.post!.toJson();
    }
    data['post_time'] = this.postTime;
    if (this.userData != null) {
      data['user_data'] = this.userData!.map((v) => v.toJson()).toList();
    }
    if (this.image != null) {
      data['image'] = this.image!.map((v) => v.toJson()).toList();
    }
    data['like'] = this.like;
    data['post_likers'] = this.postLikers;
    data['is_liked'] = this.isLiked;
    data['is_fav'] = this.isFav;
    return data;
  }
}

class Post {
  int? id;
  int? userId;
  String? description;
  String? createdAt;
  String? updatedAt;
  UserDatum? user;

  Post(
      {this.id,
        this.userId,
        this.description,
        this.createdAt,
        this.updatedAt,
        this.user});

  Post.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    description = json['description'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    user = json['user'] != null ? new UserDatum.fromJson(json['user']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['description'] = this.description;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    if (this.user != null) {
      data['user'] = this.user!.toJson();
    }
    return data;
  }
}

class UserDatum {
  int? id;
  String? name;
  String? email;
  String? phone;
  String? userName;
  String? role;
  String? storyUpload;
  String? coverImage;
  String? twoFactorSecret;
  String? twoFactorRecoveryCodes;
  String? createdAt;
  String? updatedAt;
  String? profileImage;
  dynamic? longitude;
  dynamic? latitude;
  String? deviceToken;

  UserDatum(
      {this.id,
        this.name,
        this.email,
        this.phone,
        this.userName,
        this.role,
        this.storyUpload,
        this.coverImage,
        this.twoFactorSecret,
        this.twoFactorRecoveryCodes,
        this.createdAt,
        this.updatedAt,
        this.profileImage,
        this.longitude,
        this.latitude,
        this.deviceToken});

  UserDatum.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    email = json['email'];
    phone = json['phone'];
    userName = json['user_name'];
    role = json['role'];
    storyUpload = json['StoryUpload'];
    coverImage = json['cover_image'];
    twoFactorSecret = json['two_factor_secret'];
    twoFactorRecoveryCodes = json['two_factor_recovery_codes'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    profileImage = json['profileImage'];
    longitude = json['longitude'];
    latitude = json['latitude'];
    deviceToken = json['device_token'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['email'] = this.email;
    data['phone'] = this.phone;
    data['user_name'] = this.userName;
    data['role'] = this.role;
    data['StoryUpload'] = this.storyUpload;
    data['cover_image'] = this.coverImage;
    data['two_factor_secret'] = this.twoFactorSecret;
    data['two_factor_recovery_codes'] = this.twoFactorRecoveryCodes;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['profileImage'] = this.profileImage;
    data['longitude'] = this.longitude;
    data['latitude'] = this.latitude;
    data['device_token'] = this.deviceToken;
    return data;
  }
}

class Images {
  int? id;
  String? image;
  String? imageType;
  int? refId;
  String? createdAt;
  String? updatedAt;

  Images(
      {this.id,
        this.image,
        this.imageType,
        this.refId,
        this.createdAt,
        this.updatedAt});

  Images.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    image = json['image'];
    imageType = json['image_type'];
    refId = json['ref_id'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['image'] = this.image;
    data['image_type'] = this.imageType;
    data['ref_id'] = this.refId;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
