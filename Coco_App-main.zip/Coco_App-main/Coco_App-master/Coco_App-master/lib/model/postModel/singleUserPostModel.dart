// To parse this JSON data, do
//
//     final singleUserPostModel = singleUserPostModelFromJson(jsonString);

import 'dart:convert';

SingleUserPostModel singleUserPostModelFromJson(String str) => SingleUserPostModel.fromJson(json.decode(str));

String singleUserPostModelToJson(SingleUserPostModel data) => json.encode(data.toJson());

class SingleUserPostModel {
  final List<Datum>? data;
  final bool? status;
  final String? massage;

  SingleUserPostModel({
    this.data,
    this.status,
    this.massage,
  });

  factory SingleUserPostModel.fromJson(Map<String, dynamic> json) => SingleUserPostModel(
    data: json["data"] == null ? [] : List<Datum>.from(json["data"]!.map((x) => Datum.fromJson(x))),
    status: json["status"],
    massage: json["massage"],
  );

  Map<String, dynamic> toJson() => {
    "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x.toJson())),
    "status": status,
    "massage": massage,
  };
}

class Datum {
  final Post? post;
  final String? postTime;
  final List<UserDatum>? userData;
  final List<Image>? image;
  final int? like;
  final List<String>? postLikers;

  Datum({
    this.post,
    this.postTime,
    this.userData,
    this.image,
    this.like,
    this.postLikers,
  });

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    post: json["post"] == null ? null : Post.fromJson(json["post"]),
    postTime: json["post_time"],
    userData: json["user_data"] == null ? [] : List<UserDatum>.from(json["user_data"]!.map((x) => UserDatum.fromJson(x))),
    image: json["image"] == null ? [] : List<Image>.from(json["image"]!.map((x) => Image.fromJson(x))),
    like: json["like"],
    postLikers: json["post_likers"] == null ? [] : List<String>.from(json["post_likers"]!.map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "post": post?.toJson(),
    "post_time": postTime,
    "user_data": userData == null ? [] : List<dynamic>.from(userData!.map((x) => x.toJson())),
    "image": image == null ? [] : List<dynamic>.from(image!.map((x) => x.toJson())),
    "like": like,
    "post_likers": postLikers == null ? [] : List<dynamic>.from(postLikers!.map((x) => x)),
  };
}

class Image {
  final int? id;
  final String? image;
  final String? imageType;
  final int? refId;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  Image({
    this.id,
    this.image,
    this.imageType,
    this.refId,
    this.createdAt,
    this.updatedAt,
  });

  factory Image.fromJson(Map<String, dynamic> json) => Image(
    id: json["id"],
    image: json["image"],
    imageType: json["image_type"],
    refId: json["ref_id"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "image": image,
    "image_type": imageType,
    "ref_id": refId,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
  };
}

class Post {
  final int? id;
  final int? userId;
  final String? description;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  Post({
    this.id,
    this.userId,
    this.description,
    this.createdAt,
    this.updatedAt,
  });

  factory Post.fromJson(Map<String, dynamic> json) => Post(
    id: json["id"],
    userId: json["user_id"],
    description: json["description"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "user_id": userId,
    "description": description,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
  };
}

class UserDatum {
  final int? id;
  final String? name;
  final String? email;
  final String? phone;
  final String? userName;
  final String? role;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final String? profileImage;
  final dynamic longitude;
  final dynamic latitude;

  UserDatum({
    this.id,
    this.name,
    this.email,
    this.phone,
    this.userName,
    this.role,
    this.createdAt,
    this.updatedAt,
    this.profileImage,
    this.longitude,
    this.latitude,
  });

  factory UserDatum.fromJson(Map<String, dynamic> json) => UserDatum(
    id: json["id"],
    name: json["name"],
    email: json["email"],
    phone: json["phone"],
    userName: json["user_name"],
    role: json["role"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    profileImage: json["profileImage"],
    longitude: json["longitude"],
    latitude: json["latitude"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "email": email,
    "phone": phone,
    "user_name": userName,
    "role": role,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
    "profileImage": profileImage,
    "longitude": longitude,
    "latitude": latitude,
  };
}
