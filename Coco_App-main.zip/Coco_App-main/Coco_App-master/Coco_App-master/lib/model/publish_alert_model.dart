class PublishAlertModel {
  Data? data;

  PublishAlertModel({this.data});

  PublishAlertModel.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  int? id;
  String? alertMsg;
  String? createdAt;
  String? updatedAt;
  int? userId;
  String? status;

  Data(
      {this.id,
        this.alertMsg,
        this.createdAt,
        this.updatedAt,
        this.userId,
        this.status});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    alertMsg = json['alert_msg'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    userId = json['user_id'];
    status = json['status'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['alert_msg'] = this.alertMsg;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['user_id'] = this.userId;
    data['status'] = this.status;
    return data;
  }
}
