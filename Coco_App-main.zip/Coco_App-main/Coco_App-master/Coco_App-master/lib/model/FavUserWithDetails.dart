class FavUserWithDetails {
  int? id;
  String? name;
  String? email;
  String? userName;
  String? profileImage;

  FavUserWithDetails(
      {this.id, this.name, this.email, this.userName, this.profileImage});

  FavUserWithDetails.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    email = json['email'];
    userName = json['user_name'];
    profileImage = json['profileImage'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['email'] = this.email;
    data['user_name'] = this.userName;
    data['profileImage'] = this.profileImage;
    return data;
  }
}
