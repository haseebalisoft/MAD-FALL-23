// To parse this JSON data, do
//
//     final freelancerModel = freelancerModelFromJson(jsonString);

import 'dart:convert';

FreelancerModel freelancerModelFromJson(String str) => FreelancerModel.fromJson(json.decode(str));

String freelancerModelToJson(FreelancerModel data) => json.encode(data.toJson());

class FreelancerModel {
  final Data? data;
  final bool? status;
  final String? massage;

  FreelancerModel({
    this.data,
    this.status,
    this.massage,
  });

  factory FreelancerModel.fromJson(Map<String, dynamic> json) => FreelancerModel(
    data: json["data"] == null ? null : Data.fromJson(json["data"]),
    status: json["status"],
    massage: json["massage"],
  );

  Map<String, dynamic> toJson() => {
    "data": data?.toJson(),
    "status": status,
    "massage": massage,
  };
}

class Data {
  final User? user;
  final UserInfo? userInfo;
  final List<ServiceName>? serviceName;
  final List<String>? language;
  final Location? location;
  final List<EquipmentsName>? equipmentsName;
  final Social? socialLink;

  Data({
    this.user,
    this.userInfo,
    this.serviceName,
    this.language,
    this.location,
    this.equipmentsName,
    this.socialLink,
  });

  // factory Data.fromJson(Map<String, dynamic> json) => Data(
  //   user: json["user"] == null ? null : User.fromJson(json["user"]),
  //   userInfo: json["user_info"] == null ? null : UserInfo.fromJson(json["user_info"]),
  //   serviceName: json["service_name"] == null ? [] : List<ServiceName>.from(json["service_name"]!.map((x) => ServiceName.fromJson(x))),
  //   language: json["language"] == null ? [] : List<String>.from(json["language"]!.map((x) => x)),
  //   location: json["location"] == null ? null : Location.fromJson(json["location"]),
  //   equipmentsName: json["equipments_name"] == null ? [] : List<EquipmentsName>.from(json["equipments_name"]!.map((x) => EquipmentsName.fromJson(x))),
  //   socialLink: json["social_link"] == null ? null : Social.fromJson(json["social_link"]),
  // );


  factory Data.fromJson(Map<String, dynamic> json) {
    try {
      return Data(
        user: json["user"] == null ? null : User.fromJson(json["user"]),
        userInfo: json["user_info"] == null ? null : UserInfo.fromJson(json["user_info"]),
        serviceName: json["service_name"] == null ? [] : List<ServiceName>.from(json["service_name"].map((x) => ServiceName.fromJson(x))),
        language: json["language"] == null ? [] : List<String>.from(json["language"].map((x) => x)),
        location: json["location"] == null ? null : Location.fromJson(json["location"]),
        equipmentsName: json["equipments_name"] == null ? [] : List<EquipmentsName>.from(json["equipments_name"].map((x) => EquipmentsName.fromJson(x))),
        socialLink: json["social_link"] == null ? null : Social.fromJson(json["social_link"]),
      );
    } catch (e) {
      print('Failed to load serviceName: $e');
      return Data(
        user: json["user"] == null ? null : User.fromJson(json["user"]),
        userInfo: json["user_info"] == null ? null : UserInfo.fromJson(json["user_info"]),
        serviceName: [],
        language: json["language"] == null ? [] : List<String>.from(json["language"].map((x) => x)),
        location: json["location"] == null ? null : Location.fromJson(json["location"]),
        equipmentsName: [],
        socialLink: json["social_link"] == null ? null : Social.fromJson(json["social_link"]),
      );
    }
  }


  Map<String, dynamic> toJson() => {
    "user": user?.toJson(),
    "user_info": userInfo?.toJson(),
    "service_name": serviceName == null ? [] : List<dynamic>.from(serviceName!.map((x) => x.toJson())),
    "language": language == null ? [] : List<dynamic>.from(language!.map((x) => x)),
    "location": location?.toJson(),
    "equipments_name": equipmentsName == null ? [] : List<dynamic>.from(equipmentsName!.map((x) => x.toJson())),
    "social_link": socialLink?.toJson(),
  };
}

class EquipmentsName {
  final String? name;
  final String? image;

  EquipmentsName({
    this.name,
    this.image,
  });

  factory EquipmentsName.fromJson(Map<String, dynamic> json) => EquipmentsName(
    name: json["name"],
    image: json["image"],
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "image": image,
  };
}

class Location {
  final String? country;
  final String? state;
  final String? city;
  final String? address;

  Location({
    this.country,
    this.state,
    this.city,
    this.address,
  });

  factory Location.fromJson(Map<String, dynamic> json) => Location(
    country: json["Country"],
    state: json["State"],
    city: json["City"],
    address: json["address"],
  );

  Map<String, dynamic> toJson() => {
    "Country": country,
    "State": state,
    "City": city,
    "address": address,
  };
}

class ServiceName {
  final String? name;

  ServiceName({
    this.name,
  });

  factory ServiceName.fromJson(Map<String, dynamic> json) => ServiceName(
    name: json["name"],
  );

  Map<String, dynamic> toJson() => {
    "name": name,
  };
}

class Social {
  final int? id;
  final int? userId;
  final String? facebook;
  final String? instagram;
  final String? youtube;
  final String? tiktok;
  final String? behance;
  final String? dribble;
  final String? vimeo;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  Social({
    this.id,
    this.userId,
    this.facebook,
    this.instagram,
    this.youtube,
    this.tiktok,
    this.behance,
    this.dribble,
    this.vimeo,
    this.createdAt,
    this.updatedAt,
  });

  factory Social.fromJson(Map<String, dynamic> json) => Social(
    id: json["id"],
    userId: json["user_id"],
    facebook: json["facebook"],
    instagram: json["instagram"],
    youtube: json["youtube"],
    tiktok: json["tiktok"],
    behance: json["behance"],
    dribble: json["dribble"],
    vimeo: json["vimeo"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "user_id": userId,
    "facebook": facebook,
    "instagram": instagram,
    "youtube": youtube,
    "tiktok": tiktok,
    "behance": behance,
    "dribble": dribble,
    "vimeo": vimeo,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
  };
}

class User {
  final int? id;
  final String? name;
  final String? email;
  final String? phone;
  final String? userName;
  final String? role;
  final DateTime? storyUpload;
  final String? coverImage;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final String? profileImage;
  final double? longitude;
  final double? latitude;
  final String? deviceToken;
  final UserInfo? userInfo;
  final Social? social;
  final List<User>? followers;
  final List<dynamic>? following;
  final Pivot? pivot;

  User({
    this.id,
    this.name,
    this.email,
    this.phone,
    this.userName,
    this.role,
    this.storyUpload,
    this.coverImage,
    this.createdAt,
    this.updatedAt,
    this.profileImage,
    this.longitude,
    this.latitude,
    this.deviceToken,
    this.userInfo,
    this.social,
    this.followers,
    this.following,
    this.pivot,
  });

  factory User.fromJson(Map<String, dynamic> json) => User(
    id: json["id"],
    name: json["name"],
    email: json["email"],
    phone: json["phone"],
    userName: json["user_name"],
    role: json["role"],
    storyUpload: json["StoryUpload"] == null ? null : DateTime.parse(json["StoryUpload"]),
    coverImage: json["cover_image"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    profileImage: json["profileImage"],
    longitude: json["longitude"]?.toDouble(),
    latitude: json["latitude"]?.toDouble(),
    deviceToken: json["device_token"],
    userInfo: json["user_info"] == null ? null : UserInfo.fromJson(json["user_info"]),
    social: json["social"] == null ? null : Social.fromJson(json["social"]),
    followers: json["followers"] == null ? [] : List<User>.from(json["followers"]!.map((x) => User.fromJson(x))),
    following: json["following"] == null ? [] : List<dynamic>.from(json["following"]!.map((x) => x)),
    pivot: json["pivot"] == null ? null : Pivot.fromJson(json["pivot"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "email": email,
    "phone": phone,
    "user_name": userName,
    "role": role,
    "StoryUpload": storyUpload?.toIso8601String(),
    "cover_image": coverImage,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
    "profileImage": profileImage,
    "longitude": longitude,
    "latitude": latitude,
    "device_token": deviceToken,
    "user_info": userInfo?.toJson(),
    "social": social?.toJson(),
    "followers": followers == null ? [] : List<dynamic>.from(followers!.map((x) => x.toJson())),
    "following": following == null ? [] : List<dynamic>.from(following!.map((x) => x)),
    "pivot": pivot?.toJson(),
  };
}

class Pivot {
  final int? userId;
  final int? followerId;

  Pivot({
    this.userId,
    this.followerId,
  });

  factory Pivot.fromJson(Map<String, dynamic> json) => Pivot(
    userId: json["user_id"],
    followerId: json["follower_id"],
  );

  Map<String, dynamic> toJson() => {
    "user_id": userId,
    "follower_id": followerId,
  };
}

class UserInfo {
  final int? id;
  final int? userId;
  final String? description;
  final String? businessPhone;
  final String? businessEmail;
  final dynamic website;
  final String? language;
  final String? pricePerDay;
  final String? serviceList;
  final String? equipmentsList;
  final String? extraEquipments;
  final int? step1Complete;
  final int? step2Complete;
  final int? step3Complete;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final dynamic languages;
  final dynamic businessList;

  UserInfo({
    this.id,
    this.userId,
    this.description,
    this.businessPhone,
    this.businessEmail,
    this.website,
    this.language,
    this.pricePerDay,
    this.serviceList,
    this.equipmentsList,
    this.extraEquipments,
    this.step1Complete,
    this.step2Complete,
    this.step3Complete,
    this.createdAt,
    this.updatedAt,
    this.languages,
    this.businessList,
  });

  factory UserInfo.fromJson(Map<String, dynamic> json) => UserInfo(
    id: json["id"],
    userId: json["user_id"],
    description: json["description"],
    businessPhone: json["business_phone"],
    businessEmail: json["business_email"],
    website: json["website"],
    language: json["language"],
    pricePerDay: json["price_per_day"],
    serviceList: json["service_list"],
    equipmentsList: json["equipments_list"],
    extraEquipments: json["extra_equipments"],
    step1Complete: json["step_1_complete"],
    step2Complete: json["step_2_complete"],
    step3Complete: json["step_3_complete"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    languages: json["languages"],
    businessList: json["business_list"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "user_id": userId,
    "description": description,
    "business_phone": businessPhone,
    "business_email": businessEmail,
    "website": website,
    "language": language,
    "price_per_day": pricePerDay,
    "service_list": serviceList,
    "equipments_list": equipmentsList,
    "extra_equipments": extraEquipments,
    "step_1_complete": step1Complete,
    "step_2_complete": step2Complete,
    "step_3_complete": step3Complete,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
    "languages": languages,
    "business_list": businessList,
  };
}
