// To parse this JSON data, do
//
//     final allStoryModel = allStoryModelFromJson(jsonString);

import 'dart:convert';

AllStoryModel allStoryModelFromJson(String str) => AllStoryModel.fromJson(json.decode(str));

String allStoryModelToJson(AllStoryModel data) => json.encode(data.toJson());

class AllStoryModel {
  final List<UserStory>? userStories;

  AllStoryModel({
    this.userStories,
  });

  factory AllStoryModel.fromJson(Map<String, dynamic> json) => AllStoryModel(
    userStories: json["user_stories"] == null ? [] : List<UserStory>.from(json["user_stories"]!.map((x) => UserStory.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "user_stories": userStories == null ? [] : List<dynamic>.from(userStories!.map((x) => x.toJson())),
  };
}

class UserStory {
  final int? id;
  final String? name;
  final String? email;
  final String? phone;
  final String? userName;
  final String? role;
  final dynamic profileImage;
  final List<Story>? stories;

  UserStory({
    this.id,
    this.name,
    this.email,
    this.phone,
    this.userName,
    this.role,
    this.profileImage,
    this.stories,
  });

  factory UserStory.fromJson(Map<String, dynamic> json) => UserStory(
    id: json["id"],
    name: json["name"],
    email: json["email"],
    phone: json["phone"],
    userName: json["user_name"],
    role: json["role"],
    profileImage: json["profileImage"],
    stories: json["stories"] == null ? [] : List<Story>.from(json["stories"]!.map((x) => Story.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "email": email,
    "phone": phone,
    "user_name": userName,
    "role": role,
    "profileImage": profileImage,
    "stories": stories == null ? [] : List<dynamic>.from(stories!.map((x) => x.toJson())),
  };
}

class Story {
  final int? id;
  final String? description;
  final int? userId;
  final String? image;
  final String? time;
  final int? like;
  final bool? isLiked;

  Story({
    this.id,
    this.description,
    this.userId,
    this.image,
    this.time,
    this.like,
    this.isLiked,
  });

  factory Story.fromJson(Map<String, dynamic> json) => Story(
    id: json["id"],
    description: json["description"],
    userId: json["user_id"],
    image: json["image"],
    time: json["time"],
    like: json["like"],
    isLiked: json["is_liked"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "description": description,
    "user_id": userId,
    "image": image,
    "time": time,
    "like": like,
    "is_liked": isLiked,
  };
}
