class StateModel {
  final int id;
  final String name;
  final int countryId;

  StateModel({
    required this.id,
    required this.name,
    required this.countryId,
  });

  factory StateModel.fromJson(Map<String, dynamic> json) {
    return StateModel(
      id: json['id'],
      name: json['name'],
      countryId: json['country_id'],
    );
  }
}
