// To parse this JSON data, do
//
//     final allUserModel = allUserModelFromJson(jsonString);

import 'dart:convert';

AllUserModel allUserModelFromJson(String str) => AllUserModel.fromJson(json.decode(str));

String allUserModelToJson(AllUserModel data) => json.encode(data.toJson());

class AllUserModel {
  final List<Datum>? data;
  final bool? status;
  final String? massage;

  AllUserModel({
    this.data,
    this.status,
    this.massage,
  });

  factory AllUserModel.fromJson(Map<String, dynamic> json) => AllUserModel(
    data: json["data"] == null ? [] : List<Datum>.from(json["data"]!.map((x) => Datum.fromJson(x))),
    status: json["status"],
    massage: json["massage"],
  );

  Map<String, dynamic> toJson() => {
    "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x.toJson())),
    "status": status,
    "massage": massage,
  };
}

class Datum {
  final int? id;
  final String? name;
  final String? email;
  final String? phone;
  final String? userName;
  final String? role;
  final String? coverImage;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final String? profileImage;
  final double? longitude;
  final double? latitude;
  final dynamic deviceToken;
  final UserInfo? userInfo;

  Datum({
    this.id,
    this.name,
    this.email,
    this.phone,
    this.userName,
    this.role,
    this.coverImage,
    this.createdAt,
    this.updatedAt,
    this.profileImage,
    this.longitude,
    this.latitude,
    this.deviceToken,
    this.userInfo,
  });

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["id"],
    name: json["name"],
    email: json["email"],
    phone: json["phone"],
    userName: json["user_name"],
    role: json["role"],
    coverImage: json["cover_image"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    profileImage: json["profileImage"],
    longitude: json["longitude"]?.toDouble(),
    latitude: json["latitude"]?.toDouble(),
    deviceToken: json["device_token"],
    userInfo: json["user_info"] == null ? null : UserInfo.fromJson(json["user_info"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "email": email,
    "phone": phone,
    "user_name": userName,
    "role": role,
    "cover_image": coverImage,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
    "profileImage": profileImage,
    "longitude": longitude,
    "latitude": latitude,
    "device_token": deviceToken,
    "user_info": userInfo?.toJson(),
  };
}

class UserInfo {
  final int? id;
  final int? userId;
  final String? description;
  final String? businessPhone;
  final String? businessEmail;
  final dynamic website;
  final String? language;
  final String? pricePerDay;
  final String? serviceList;
  final String? equipmentsList;
  final String? extraEquipments;
  final int? step1Complete;
  final int? step2Complete;
  final int? step3Complete;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final dynamic languages;
  final String? businessList;

  UserInfo({
    this.id,
    this.userId,
    this.description,
    this.businessPhone,
    this.businessEmail,
    this.website,
    this.language,
    this.pricePerDay,
    this.serviceList,
    this.equipmentsList,
    this.extraEquipments,
    this.step1Complete,
    this.step2Complete,
    this.step3Complete,
    this.createdAt,
    this.updatedAt,
    this.languages,
    this.businessList,
  });

  factory UserInfo.fromJson(Map<String, dynamic> json) => UserInfo(
    id: json["id"],
    userId: json["user_id"],
    description: json["description"],
    businessPhone: json["business_phone"],
    businessEmail: json["business_email"],
    website: json["website"],
    language: json["language"],
    pricePerDay: json["price_per_day"],
    serviceList: json["service_list"],
    equipmentsList: json["equipments_list"],
    extraEquipments: json["extra_equipments"],
    step1Complete: json["step_1_complete"],
    step2Complete: json["step_2_complete"],
    step3Complete: json["step_3_complete"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    languages: json["languages"],
    businessList: json["business_list"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "user_id": userId,
    "description": description,
    "business_phone": businessPhone,
    "business_email": businessEmail,
    "website": website,
    "language": language,
    "price_per_day": pricePerDay,
    "service_list": serviceList,
    "equipments_list": equipmentsList,
    "extra_equipments": extraEquipments,
    "step_1_complete": step1Complete,
    "step_2_complete": step2Complete,
    "step_3_complete": step3Complete,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
    "languages": languages,
    "business_list": businessList,
  };
}
