// To parse this JSON data, do
//
//     final serviceModel = serviceModelFromJson(jsonString);

import 'dart:convert';

ServiceModel serviceModelFromJson(String str) => ServiceModel.fromJson(json.decode(str));

String serviceModelToJson(ServiceModel data) => json.encode(data.toJson());

class ServiceModel {
  final List<ServiceDatum>? data;
  final bool? status;
  final String? massage;

  ServiceModel({
    this.data,
    this.status,
    this.massage,
  });

  factory ServiceModel.fromJson(Map<String, dynamic> json) => ServiceModel(
    data: json["data"] == null ? [] : List<ServiceDatum>.from(json["data"]!.map((x) => ServiceDatum.fromJson(x))),
    status: json["status"],
    massage: json["massage"],
  );

  Map<String, dynamic> toJson() => {
    "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x.toJson())),
    "status": status,
    "massage": massage,
  };
}

class ServiceDatum {
  final int? id;
  final String? name;
  int? totalUser;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  ServiceDatum({
    this.id,
    this.name,
    this.totalUser,
    this.createdAt,
    this.updatedAt,
  });

  factory ServiceDatum.fromJson(Map<String, dynamic> json) => ServiceDatum(
    id: json["id"],
    name: json["name"],
    totalUser: json["total_user"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "total_user": totalUser,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
  };
}
