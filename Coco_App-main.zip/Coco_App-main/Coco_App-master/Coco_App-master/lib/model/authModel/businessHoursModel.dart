// To parse this JSON data, do
//
//     final businessHoursModel = businessHoursModelFromJson(jsonString);

import 'dart:convert';

BusinessHoursModel businessHoursModelFromJson(String str) => BusinessHoursModel.fromJson(json.decode(str));

String businessHoursModelToJson(BusinessHoursModel data) => json.encode(data.toJson());

class BusinessHoursModel {
  final List<Datum>? data;
  final String? message;
  final bool? status;

  BusinessHoursModel({
    this.data,
    this.message,
    this.status,
  });

  factory BusinessHoursModel.fromJson(Map<String, dynamic> json) => BusinessHoursModel(
    data: json["data"] == null ? [] : List<Datum>.from(json["data"]!.map((x) => Datum.fromJson(x))),
    message: json["message"],
    status: json["status"],
  );

  Map<String, dynamic> toJson() => {
    "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x.toJson())),
    "message": message,
    "status": status,
  };
}

class Datum {
  final int? id;
  final int? userId;
  final String? day;
  final String? open;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  Datum({
    this.id,
    this.userId,
    this.day,
    this.open,
    this.createdAt,
    this.updatedAt,
  });

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["id"],
    userId: json["user_id"],
    day: json["day"],
    open: json["open"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "user_id": userId,
    "day": day,
    "open": open,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
  };
}
