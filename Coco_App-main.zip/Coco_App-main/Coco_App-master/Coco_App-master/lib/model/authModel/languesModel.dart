// To parse this JSON data, do
//
//     final languesModel = languesModelFromJson(jsonString);

import 'dart:convert';

LanguesModel languesModelFromJson(String str) => LanguesModel.fromJson(json.decode(str));

String languesModelToJson(LanguesModel data) => json.encode(data.toJson());

class LanguesModel {
  final List<Datum>? data;
  final bool? status;
  final String? massage;

  LanguesModel({
    this.data,
    this.status,
    this.massage,
  });

  factory LanguesModel.fromJson(Map<String, dynamic> json) => LanguesModel(
    data: json["data"] == null ? [] : List<Datum>.from(json["data"]!.map((x) => Datum.fromJson(x))),
    status: json["status"],
    massage: json["massage"],
  );

  Map<String, dynamic> toJson() => {
    "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x.toJson())),
    "status": status,
    "massage": massage,
  };
}

class Datum {
  final int? id;
  final String? name;
  int? totalUser;
  final dynamic createdAt;
  final dynamic updatedAt;

  Datum({
    this.id,
    this.name,
    this.totalUser,
    this.createdAt,
    this.updatedAt,
  });

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["id"],
    name: json["name"],
    totalUser: json["total_user"],
    createdAt: json["created_at"],
    updatedAt: json["updated_at"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "total_user": totalUser,
    "created_at": createdAt,
    "updated_at": updatedAt,
  };
}
