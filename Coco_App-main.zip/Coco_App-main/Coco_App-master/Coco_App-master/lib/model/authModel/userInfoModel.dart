// To parse this JSON data, do
//
//     final userInformation = userInformationFromJson(jsonString);

import 'dart:convert';

UserInformation userInformationFromJson(String str) => UserInformation.fromJson(json.decode(str));

String userInformationToJson(UserInformation data) => json.encode(data.toJson());

class UserInformation {
  final Data? data;
  final bool? status;
  final String? massage;

  UserInformation({
    this.data,
    this.status,
    this.massage,
  });

  factory UserInformation.fromJson(Map<String, dynamic> json) => UserInformation(
    data: json["data"] == null ? null : Data.fromJson(json["data"]),
    status: json["status"],
    massage: json["massage"],
  );

  Map<String, dynamic> toJson() => {
    "data": data?.toJson(),
    "status": status,
    "massage": massage,
  };
}

class Data {
  final int? id;
  final String? name;
  final String? email;
  final String? phone;
  final String? userName;
  final String? role;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final dynamic profileImage;
  final double? longitude;
  final double? latitude;
  final UserInfo? userInfo;
  final Social? social;
  final List<Follow>? followers;
  final List<Follow>? following;

  Data({
    this.id,
    this.name,
    this.email,
    this.phone,
    this.userName,
    this.role,
    this.createdAt,
    this.updatedAt,
    this.profileImage,
    this.longitude,
    this.latitude,
    this.userInfo,
    this.social,
    this.followers,
    this.following,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    id: json["id"],
    name: json["name"],
    email: json["email"],
    phone: json["phone"],
    userName: json["user_name"],
    role: json["role"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    profileImage: json["profileImage"],
    longitude: json["longitude"]?.toDouble(),
    latitude: json["latitude"]?.toDouble(),
    userInfo: json["user_info"] == null ? null : UserInfo.fromJson(json["user_info"]),
    social: json["social"] == null ? null : Social.fromJson(json["social"]),
    followers: json["followers"] == null ? [] : List<Follow>.from(json["followers"]!.map((x) => Follow.fromJson(x))),
    following: json["following"] == null ? [] : List<Follow>.from(json["following"]!.map((x) => Follow.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "email": email,
    "phone": phone,
    "user_name": userName,
    "role": role,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
    "profileImage": profileImage,
    "longitude": longitude,
    "latitude": latitude,
    "user_info": userInfo?.toJson(),
    "social": social?.toJson(),
    "followers": followers == null ? [] : List<dynamic>.from(followers!.map((x) => x.toJson())),
    "following": following == null ? [] : List<dynamic>.from(following!.map((x) => x.toJson())),
  };
}

class Follow {
  final int? id;
  final String? name;
  final String? email;
  final String? phone;
  final String? userName;
  final String? role;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final dynamic profileImage;
  final double? longitude;
  final double? latitude;
  final Pivot? pivot;

  Follow({
    this.id,
    this.name,
    this.email,
    this.phone,
    this.userName,
    this.role,
    this.createdAt,
    this.updatedAt,
    this.profileImage,
    this.longitude,
    this.latitude,
    this.pivot,
  });

  factory Follow.fromJson(Map<String, dynamic> json) => Follow(
    id: json["id"],
    name: json["name"],
    email: json["email"],
    phone: json["phone"],
    userName: json["user_name"],
    role: json["role"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    profileImage: json["profileImage"],
    longitude: json["longitude"]?.toDouble(),
    latitude: json["latitude"]?.toDouble(),
    pivot: json["pivot"] == null ? null : Pivot.fromJson(json["pivot"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "email": email,
    "phone": phone,
    "user_name": userName,
    "role": role,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
    "profileImage": profileImage,
    "longitude": longitude,
    "latitude": latitude,
    "pivot": pivot?.toJson(),
  };
}

class Pivot {
  final int? followerId;
  final int? userId;

  Pivot({
    this.followerId,
    this.userId,
  });

  factory Pivot.fromJson(Map<String, dynamic> json) => Pivot(
    followerId: json["follower_id"],
    userId: json["user_id"],
  );

  Map<String, dynamic> toJson() => {
    "follower_id": followerId,
    "user_id": userId,
  };
}

class Social {
  final int? id;
  final int? userId;
  final String? facebook;
  final String? instagram;
  final String? youtube;
  final String? tiktok;
  final String? behance;
  final String? dribble;
  final String? vimeo;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  Social({
    this.id,
    this.userId,
    this.facebook,
    this.instagram,
    this.youtube,
    this.tiktok,
    this.behance,
    this.dribble,
    this.vimeo,
    this.createdAt,
    this.updatedAt,
  });

  factory Social.fromJson(Map<String, dynamic> json) => Social(
    id: json["id"],
    userId: json["user_id"],
    facebook: json["facebook"],
    instagram: json["instagram"],
    youtube: json["youtube"],
    tiktok: json["tiktok"],
    behance: json["behance"],
    dribble: json["dribble"],
    vimeo: json["vimeo"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "user_id": userId,
    "facebook": facebook,
    "instagram": instagram,
    "youtube": youtube,
    "tiktok": tiktok,
    "behance": behance,
    "dribble": dribble,
    "vimeo": vimeo,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
  };
}

class UserInfo {
  final int? id;
  final int? userId;
  final String? description;
  final String? businessPhone;
  final String? businessEmail;
  final dynamic website;
  final dynamic language;
  final String? pricePerDay;
  final String? serviceList;
  final String? equipmentsList;
  final String? extraEquipments;
  final int? step1Complete;
  final int? step2Complete;
  final int? step3Complete;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final dynamic languages;

  UserInfo({
    this.id,
    this.userId,
    this.description,
    this.businessPhone,
    this.businessEmail,
    this.website,
    this.language,
    this.pricePerDay,
    this.serviceList,
    this.equipmentsList,
    this.extraEquipments,
    this.step1Complete,
    this.step2Complete,
    this.step3Complete,
    this.createdAt,
    this.updatedAt,
    this.languages,
  });

  factory UserInfo.fromJson(Map<String, dynamic> json) => UserInfo(
    id: json["id"],
    userId: json["user_id"],
    description: json["description"],
    businessPhone: json["business_phone"],
    businessEmail: json["business_email"],
    website: json["website"],
    language: json["language"],
    pricePerDay: json["price_per_day"],
    serviceList: json["service_list"],
    equipmentsList: json["equipments_list"],
    extraEquipments: json["extra_equipments"],
    step1Complete: json["step_1_complete"],
    step2Complete: json["step_2_complete"],
    step3Complete: json["step_3_complete"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    languages: json["languages"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "user_id": userId,
    "description": description,
    "business_phone": businessPhone,
    "business_email": businessEmail,
    "website": website,
    "language": language,
    "price_per_day": pricePerDay,
    "service_list": serviceList,
    "equipments_list": equipmentsList,
    "extra_equipments": extraEquipments,
    "step_1_complete": step1Complete,
    "step_2_complete": step2Complete,
    "step_3_complete": step3Complete,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
    "languages": languages,
  };
}
