// To parse this JSON data, do
//
//     final equpmentsListModel = equpmentsListModelFromJson(jsonString);

import 'dart:convert';

EqupmentsListModel equpmentsListModelFromJson(String str) => EqupmentsListModel.fromJson(json.decode(str));

String equpmentsListModelToJson(EqupmentsListModel data) => json.encode(data.toJson());

class EqupmentsListModel {
  final List<Datum>? data;
  final bool? status;
  final String? massage;

  EqupmentsListModel({
    this.data,
    this.status,
    this.massage,
  });

  factory EqupmentsListModel.fromJson(Map<String, dynamic> json) => EqupmentsListModel(
    data: json["data"] == null ? [] : List<Datum>.from(json["data"]!.map((x) => Datum.fromJson(x))),
    status: json["status"],
    massage: json["massage"],
  );

  Map<String, dynamic> toJson() => {
    "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x.toJson())),
    "status": status,
    "massage": massage,
  };
}

class Datum {
  final int? id;
  final String? name;
  final dynamic image;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  Datum({
    this.id,
    this.name,
    this.image,
    this.createdAt,
    this.updatedAt,
  });

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["id"],
    name: json["name"],
    image: json["image"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "image": image,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
  };
}
