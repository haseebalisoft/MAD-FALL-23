// To parse this JSON data, do
//
//     final allBusnissType = allBusnissTypeFromJson(jsonString);

import 'dart:convert';

AllBusnissType allBusnissTypeFromJson(String str) => AllBusnissType.fromJson(json.decode(str));

String allBusnissTypeToJson(AllBusnissType data) => json.encode(data.toJson());

class AllBusnissType {
  final List<BusiessTypeDatum>? data;
  final bool? status;
  final String? massage;

  AllBusnissType({
    this.data,
    this.status,
    this.massage,
  });

  factory AllBusnissType.fromJson(Map<String, dynamic> json) => AllBusnissType(
    data: json["data"] == null ? [] : List<BusiessTypeDatum>.from(json["data"]!.map((x) => BusiessTypeDatum.fromJson(x))),
    status: json["status"],
    massage: json["massage"],
  );

  Map<String, dynamic> toJson() => {
    "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x.toJson())),
    "status": status,
    "massage": massage,
  };
}

class BusiessTypeDatum {
  final int? id;
  final String? name;
  int? totalUser;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  BusiessTypeDatum({
    this.id,
    this.name,
    this.totalUser,
    this.createdAt,
    this.updatedAt,
  });

  factory BusiessTypeDatum.fromJson(Map<String, dynamic> json) => BusiessTypeDatum(
    id: json["id"],
    name: json["name"],
    totalUser: json["total_user"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "total_user": totalUser,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
  };
}
