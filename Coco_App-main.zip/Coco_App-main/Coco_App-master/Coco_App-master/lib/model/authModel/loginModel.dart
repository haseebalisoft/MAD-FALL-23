// To parse this JSON data, do
//
//     final loginModel = loginModelFromJson(jsonString);

import 'dart:convert';

LoginModel loginModelFromJson(String str) => LoginModel.fromJson(json.decode(str));

String loginModelToJson(LoginModel data) => json.encode(data.toJson());

class LoginModel {
  final Data? data;

  LoginModel({
    this.data,
  });

  factory LoginModel.fromJson(Map<String, dynamic> json) => LoginModel(
    data: json["data"] == null ? null : Data.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "data": data?.toJson(),
  };
}

class Data {
  final int? id;
  final String? userName;
  final String? email;
  final String? phone;
  final String? latitude;
  final String? longitude;
  final dynamic role;
  final String? token;
  final String? tokenType;

  Data({
    this.id,
    this.userName,
    this.email,
    this.phone,
    this.latitude,
    this.longitude,
    this.role,
    this.token,
    this.tokenType,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    id: json["id"],
    userName: json["user_name"],
    email: json["email"],
    phone: json["phone"],
    latitude: json["latitude"].toString(),
    longitude: json["longitude"].toString(),
    role: json["role"],
    token: json["token"],
    tokenType: json["token_type"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "user_name": userName,
    "email": email,
    "phone": phone,
    "latitude": latitude,
    "longitude": longitude,
    "role": role,
    "token": token,
    "token_type": tokenType,
  };
}
