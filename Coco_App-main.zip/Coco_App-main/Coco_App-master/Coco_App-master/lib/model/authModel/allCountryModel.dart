// To parse this JSON data, do
//
//     final allCountry = allCountryFromJson(jsonString);

import 'dart:convert';

List<AllCountry> allCountryFromJson(String str) => List<AllCountry>.from(json.decode(str).map((x) => AllCountry.fromJson(x)));

String allCountryToJson(List<AllCountry> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class AllCountry {
  final int? id;
  final String? sortname;
  final String? name;
  final int? phonecode;
  final dynamic createdAt;
  final dynamic updatedAt;

  AllCountry({
    this.id,
    this.sortname,
    this.name,
    this.phonecode,
    this.createdAt,
    this.updatedAt,
  });

  factory AllCountry.fromJson(Map<String, dynamic> json) => AllCountry(
    id: json["id"],
    sortname: json["sortname"],
    name: json["name"],
    phonecode: json["phonecode"],
    createdAt: json["created_at"],
    updatedAt: json["updated_at"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "sortname": sortname,
    "name": name,
    "phonecode": phonecode,
    "created_at": createdAt,
    "updated_at": updatedAt,
  };
}
