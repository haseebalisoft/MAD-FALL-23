// To parse this JSON data, do
//
//     final termsConditionModel = termsConditionModelFromJson(jsonString);

import 'dart:convert';

TermsConditionModel termsConditionModelFromJson(String str) => TermsConditionModel.fromJson(json.decode(str));

String termsConditionModelToJson(TermsConditionModel data) => json.encode(data.toJson());

class TermsConditionModel {
  final Data? data;
  final bool? status;
  final String? massage;

  TermsConditionModel({
    this.data,
    this.status,
    this.massage,
  });

  factory TermsConditionModel.fromJson(Map<String, dynamic> json) => TermsConditionModel(
    data: json["data"] == null ? null : Data.fromJson(json["data"]),
    status: json["status"],
    massage: json["massage"],
  );

  Map<String, dynamic> toJson() => {
    "data": data?.toJson(),
    "status": status,
    "massage": massage,
  };
}

class Data {
  final int? id;
  final String? termsConditions;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  Data({
    this.id,
    this.termsConditions,
    this.createdAt,
    this.updatedAt,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    id: json["id"],
    termsConditions: json["terms_conditions"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "terms_conditions": termsConditions,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
  };
}
