// To parse this JSON data, do
//
//     final policyModel = policyModelFromJson(jsonString);

import 'dart:convert';

PolicyModel policyModelFromJson(String str) => PolicyModel.fromJson(json.decode(str));

String policyModelToJson(PolicyModel data) => json.encode(data.toJson());

class PolicyModel {
  final Data? data;
  final bool? status;
  final String? massage;

  PolicyModel({
    this.data,
    this.status,
    this.massage,
  });

  factory PolicyModel.fromJson(Map<String, dynamic> json) => PolicyModel(
    data: json["data"] == null ? null : Data.fromJson(json["data"]),
    status: json["status"],
    massage: json["massage"],
  );

  Map<String, dynamic> toJson() => {
    "data": data?.toJson(),
    "status": status,
    "massage": massage,
  };
}

class Data {
  final int? id;
  final String? privacyPolicy;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  Data({
    this.id,
    this.privacyPolicy,
    this.createdAt,
    this.updatedAt,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    id: json["id"],
    privacyPolicy: json["privacy_policy"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "privacy_policy": privacyPolicy,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
  };
}
