// To parse this JSON data, do
//
//     final filterFreelancerListModel = filterFreelancerListModelFromJson(jsonString);

import 'dart:convert';

FilterFreelancerListModel filterFreelancerListModelFromJson(String str) => FilterFreelancerListModel.fromJson(json.decode(str));

String filterFreelancerListModelToJson(FilterFreelancerListModel data) => json.encode(data.toJson());

class FilterFreelancerListModel {
  final List<FilterServiceList>? data;
  final bool? status;
  final String? massage;

  FilterFreelancerListModel({
    this.data,
    this.status,
    this.massage,
  });

  factory FilterFreelancerListModel.fromJson(Map<String, dynamic> json) => FilterFreelancerListModel(
    data: json["data"] == null ? [] : List<FilterServiceList>.from(json["data"]!.map((x) => FilterServiceList.fromJson(x))),
    status: json["status"],
    massage: json["massage"],
  );

  Map<String, dynamic> toJson() => {
    "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x.toJson())),
    "status": status,
    "massage": massage,
  };
}

class FilterServiceList {
  final int? id;
  final int? userId;
  final String? description;
  final String? businessPhone;
  final String? businessEmail;
  final String? website;
  final dynamic language;
  final String? pricePerDay;
  final String? serviceList;
  final String? equipmentsList;
  final String? extraEquipments;
  final int? step1Complete;
  final int? step2Complete;
  final int? step3Complete;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final String? languages;
  final BusinessList? businessList;
  final User? user;

  FilterServiceList({
    this.id,
    this.userId,
    this.description,
    this.businessPhone,
    this.businessEmail,
    this.website,
    this.language,
    this.pricePerDay,
    this.serviceList,
    this.equipmentsList,
    this.extraEquipments,
    this.step1Complete,
    this.step2Complete,
    this.step3Complete,
    this.createdAt,
    this.updatedAt,
    this.languages,
    this.businessList,
    this.user,
  });

  factory FilterServiceList.fromJson(Map<String, dynamic> json) => FilterServiceList(
    id: json["id"],
    userId: json["user_id"],
    description: json["description"],
    businessPhone: json["business_phone"],
    businessEmail: json["business_email"],
    website: json["website"],
    language: json["language"],
    pricePerDay: json["price_per_day"],
    serviceList: json["service_list"],
    equipmentsList: json["equipments_list"],
    extraEquipments: json["extra_equipments"],
    step1Complete: json["step_1_complete"],
    step2Complete: json["step_2_complete"],
    step3Complete: json["step_3_complete"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    languages: json["languages"],
    businessList: businessListValues.map[json["business_list"]],
    user: json["user"] == null ? null : User.fromJson(json["user"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "user_id": userId,
    "description": description,
    "business_phone": businessPhone,
    "business_email": businessEmail,
    "website": website,
    "language": language,
    "price_per_day": pricePerDay,
    "service_list": serviceList,
    "equipments_list": equipmentsList,
    "extra_equipments": extraEquipments,
    "step_1_complete": step1Complete,
    "step_2_complete": step2Complete,
    "step_3_complete": step3Complete,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
    "languages": languages,
    "business_list": businessListValues.reverse[businessList],
    "user": user?.toJson(),
  };
}

enum BusinessList {
  NULL,
  THE_1,
  THE_123,
  THE_13
}

final businessListValues = EnumValues({
  "null": BusinessList.NULL,
  "\"[1]\"": BusinessList.THE_1,
  "\"[1,2,3]\"": BusinessList.THE_123,
  "\"[1,3]\"": BusinessList.THE_13
});

class User {
  final int? id;
  final String? name;
  final String? email;
  final String? phone;
  final String? userName;
  final Role? role;
  final DateTime? storyUpload;
  final String? coverImage;
  final dynamic twoFactorSecret;
  final dynamic twoFactorRecoveryCodes;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final String? profileImage;
  final double? longitude;
  final double? latitude;
  final dynamic deviceToken;

  User({
    this.id,
    this.name,
    this.email,
    this.phone,
    this.userName,
    this.role,
    this.storyUpload,
    this.coverImage,
    this.twoFactorSecret,
    this.twoFactorRecoveryCodes,
    this.createdAt,
    this.updatedAt,
    this.profileImage,
    this.longitude,
    this.latitude,
    this.deviceToken,
  });

  factory User.fromJson(Map<String, dynamic> json) => User(
    id: json["id"],
    name: json["name"],
    email: json["email"],
    phone: json["phone"],
    userName: json["user_name"],
    role: roleValues.map[json["role"]]!,
    storyUpload: json["StoryUpload"] == null ? null : DateTime.parse(json["StoryUpload"]),
    coverImage: json["cover_image"],
    twoFactorSecret: json["two_factor_secret"],
    twoFactorRecoveryCodes: json["two_factor_recovery_codes"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    profileImage: json["profileImage"],
    longitude: json["longitude"]?.toDouble(),
    latitude: json["latitude"]?.toDouble(),
    deviceToken: json["device_token"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "email": email,
    "phone": phone,
    "user_name": userName,
    "role": roleValues.reverse[role],
    "StoryUpload": storyUpload?.toIso8601String(),
    "cover_image": coverImage,
    "two_factor_secret": twoFactorSecret,
    "two_factor_recovery_codes": twoFactorRecoveryCodes,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
    "profileImage": profileImage,
    "longitude": longitude,
    "latitude": latitude,
    "device_token": deviceToken,
  };
}

enum Role {
  CLIENT,
  FREELANCER
}

final roleValues = EnumValues({
  "client": Role.CLIENT,
  "freelancer": Role.FREELANCER
});

class EnumValues<T> {
  Map<String, T> map;
  late Map<T, String> reverseMap;

  EnumValues(this.map);

  Map<T, String> get reverse {
    reverseMap = map.map((k, v) => MapEntry(v, k));
    return reverseMap;
  }
}
