// To parse this JSON data, do
//
//     final businessDataTypeWithUserModel = businessDataTypeWithUserModelFromJson(jsonString);

import 'dart:convert';

BusinessDataTypeWithUserModel businessDataTypeWithUserModelFromJson(String str) => BusinessDataTypeWithUserModel.fromJson(json.decode(str));

String businessDataTypeWithUserModelToJson(BusinessDataTypeWithUserModel data) => json.encode(data.toJson());

class BusinessDataTypeWithUserModel {
  List<Datum>? data;
  bool? status;
  String? massage;

  BusinessDataTypeWithUserModel({
    this.data,
    this.status,
    this.massage,
  });

  factory BusinessDataTypeWithUserModel.fromJson(Map<String, dynamic> json) => BusinessDataTypeWithUserModel(
    data: json["data"] == null ? [] : List<Datum>.from(json["data"]!.map((x) => Datum.fromJson(x))),
    status: json["status"],
    massage: json["massage"],
  );

  Map<String, dynamic> toJson() => {
    "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x.toJson())),
    "status": status,
    "massage": massage,
  };
}

class Datum {
  int? id;
  String? name;
  String? email;
  String? phone;
  String? userName;
  String? role;
  DateTime? storyUpload;
  String? coverImage;
  DateTime? createdAt;
  DateTime? updatedAt;
  dynamic profileImage;
  double? longitude;
  double? latitude;
  dynamic deviceToken;
  UserInfo? userInfo;

  Datum({
    this.id,
    this.name,
    this.email,
    this.phone,
    this.userName,
    this.role,
    this.storyUpload,
    this.coverImage,
    this.createdAt,
    this.updatedAt,
    this.profileImage,
    this.longitude,
    this.latitude,
    this.deviceToken,
    this.userInfo,
  });

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["id"],
    name: json["name"],
    email: json["email"],
    phone: json["phone"],
    userName: json["user_name"],
    role: json["role"],
    storyUpload: json["StoryUpload"] == null ? null : DateTime.parse(json["StoryUpload"]),
    coverImage: json["cover_image"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    profileImage: json["profileImage"],
    longitude: json["longitude"]?.toDouble(),
    latitude: json["latitude"]?.toDouble(),
    deviceToken: json["device_token"],
    userInfo: json["user_info"] == null ? null : UserInfo.fromJson(json["user_info"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "email": email,
    "phone": phone,
    "user_name": userName,
    "role": role,
    "StoryUpload": storyUpload?.toIso8601String(),
    "cover_image": coverImage,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
    "profileImage": profileImage,
    "longitude": longitude,
    "latitude": latitude,
    "device_token": deviceToken,
    "user_info": userInfo?.toJson(),
  };
}

class UserInfo {
  int? id;
  int? userId;
  String? description;
  String? businessPhone;
  String? businessEmail;
  dynamic website;
  dynamic language;
  String? pricePerDay;
  String? serviceList;
  String? equipmentsList;
  String? extraEquipments;
  int? step1Complete;
  int? step2Complete;
  int? step3Complete;
  DateTime? createdAt;
  DateTime? updatedAt;
  dynamic languages;
  dynamic businessList;

  UserInfo({
    this.id,
    this.userId,
    this.description,
    this.businessPhone,
    this.businessEmail,
    this.website,
    this.language,
    this.pricePerDay,
    this.serviceList,
    this.equipmentsList,
    this.extraEquipments,
    this.step1Complete,
    this.step2Complete,
    this.step3Complete,
    this.createdAt,
    this.updatedAt,
    this.languages,
    this.businessList,
  });

  factory UserInfo.fromJson(Map<String, dynamic> json) => UserInfo(
    id: json["id"],
    userId: json["user_id"],
    description: json["description"],
    businessPhone: json["business_phone"],
    businessEmail: json["business_email"],
    website: json["website"],
    language: json["language"],
    pricePerDay: json["price_per_day"],
    serviceList: json["service_list"],
    equipmentsList: json["equipments_list"],
    extraEquipments: json["extra_equipments"],
    step1Complete: json["step_1_complete"],
    step2Complete: json["step_2_complete"],
    step3Complete: json["step_3_complete"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    languages: json["languages"],
    businessList: json["business_list"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "user_id": userId,
    "description": description,
    "business_phone": businessPhone,
    "business_email": businessEmail,
    "website": website,
    "language": language,
    "price_per_day": pricePerDay,
    "service_list": serviceList,
    "equipments_list": equipmentsList,
    "extra_equipments": extraEquipments,
    "step_1_complete": step1Complete,
    "step_2_complete": step2Complete,
    "step_3_complete": step3Complete,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
    "languages": languages,
    "business_list": businessList,
  };
}
