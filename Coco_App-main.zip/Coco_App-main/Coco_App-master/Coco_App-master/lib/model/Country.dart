class Country {
  final int id;
  final String sortname;
  final String name;
  final int phonecode;

  Country({
    required this.id,
    required this.sortname,
    required this.name,
    required this.phonecode,
  });

  factory Country.fromJson(Map<String, dynamic> json) {
    return Country(
      id: json['id'],
      sortname: json['sortname'],
      name: json['name'],
      phonecode: json['phonecode'],
    );
  }
}
