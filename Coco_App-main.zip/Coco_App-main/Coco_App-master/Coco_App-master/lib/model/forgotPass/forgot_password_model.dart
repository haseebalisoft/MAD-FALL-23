class ForgotPasswordModel {
  bool? status;
  String? massage;

  ForgotPasswordModel({this.status, this.massage});

  ForgotPasswordModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    massage = json['massage'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['massage'] = this.massage;
    return data;
  }
}
