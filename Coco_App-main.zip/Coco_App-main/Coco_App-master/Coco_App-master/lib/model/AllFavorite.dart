class AllFavorite {
  List<Favorites>? favorites;

  AllFavorite({this.favorites});

  AllFavorite.fromJson(Map<String, dynamic> json) {
    if (json['favorites'] != null) {
      favorites = <Favorites>[];
      json['favorites'].forEach((v) {
        favorites!.add(new Favorites.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.favorites != null) {
      data['favorites'] = this.favorites!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Favorites {
  int? id;
  int? userId;
  int? favoriteUserId;
  String? createdAt;
  String? updatedAt;

  Favorites(
      {this.id,
        this.userId,
        this.favoriteUserId,
        this.createdAt,
        this.updatedAt});

  Favorites.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    favoriteUserId = json['favorite_user_id'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['favorite_user_id'] = this.favoriteUserId;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
