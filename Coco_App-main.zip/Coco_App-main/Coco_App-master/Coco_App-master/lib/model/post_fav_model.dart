class PostFavModel {
  List<int>? data;
  bool status;
  String message;

  PostFavModel({this.data, required this.status, required this.message});

  factory PostFavModel.fromJson(Map<String, dynamic> json) {
    return PostFavModel(
      data: json['data'] != null ? List<int>.from(json['data']) : null,
      status: json['status'],
      message: json['massage'],
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['massage'] = this.message;
    if (this.data != null) {
      data['data'] = this.data;
    }
    return data;
  }
}
