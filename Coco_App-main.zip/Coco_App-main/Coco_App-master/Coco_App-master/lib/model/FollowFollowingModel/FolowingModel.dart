class UserFollowing {
  List<Following>? following;

  UserFollowing({this.following});

  UserFollowing.fromJson(Map<String, dynamic> json) {
    if (json['following'] != null) {
      following = <Following>[];
      json['following'].forEach((v) {
        following!.add(new Following.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.following != null) {
      data['following'] = this.following!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Following {
  int? id;
  String? name;
  String? email;
  String? phone;
  String? userName;
  String? role;
  String? latitude;
  String? longitude;
  String? createdAt;
  String? updatedAt;
  Null? profileImage;
  Pivot? pivot;

  Following(
      {this.id,
        this.name,
        this.email,
        this.phone,
        this.userName,
        this.role,
        this.latitude,
        this.longitude,
        this.createdAt,
        this.updatedAt,
        this.profileImage,
        this.pivot});

  Following.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    email = json['email'];
    phone = json['phone'];
    userName = json['user_name'];
    role = json['role'];
    latitude = json['latitude'];
    longitude = json['longitude'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    profileImage = json['profileImage'];
    pivot = json['pivot'] != null ? new Pivot.fromJson(json['pivot']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['email'] = this.email;
    data['phone'] = this.phone;
    data['user_name'] = this.userName;
    data['role'] = this.role;
    data['latitude'] = this.latitude;
    data['longitude'] = this.longitude;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['profileImage'] = this.profileImage;
    if (this.pivot != null) {
      data['pivot'] = this.pivot!.toJson();
    }
    return data;
  }
}

class Pivot {
  int? followerId;
  int? userId;

  Pivot({this.followerId, this.userId});

  Pivot.fromJson(Map<String, dynamic> json) {
    followerId = json['follower_id'];
    userId = json['user_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['follower_id'] = this.followerId;
    data['user_id'] = this.userId;
    return data;
  }
}
