// To parse this JSON data, do
//
//     final followingListModel = followingListModelFromJson(jsonString);

import 'dart:convert';

FollowingListModel followingListModelFromJson(String str) => FollowingListModel.fromJson(json.decode(str));

String followingListModelToJson(FollowingListModel data) => json.encode(data.toJson());

class FollowingListModel {
  final List<Following>? following;

  FollowingListModel({
    this.following,
  });

  factory FollowingListModel.fromJson(Map<String, dynamic> json) => FollowingListModel(
    following: json["following"] == null ? [] : List<Following>.from(json["following"]!.map((x) => Following.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "following": following == null ? [] : List<dynamic>.from(following!.map((x) => x.toJson())),
  };
}

class Following {
  final int? id;
  final String? name;
  final String? email;
  final String? phone;
  final String? userName;
  final String? role;
  final String? latitude;
  final String? longitude;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final dynamic profileImage;
  final Pivot? pivot;

  Following({
    this.id,
    this.name,
    this.email,
    this.phone,
    this.userName,
    this.role,
    this.latitude,
    this.longitude,
    this.createdAt,
    this.updatedAt,
    this.profileImage,
    this.pivot,
  });

  factory Following.fromJson(Map<String, dynamic> json) => Following(
    id: json["id"],
    name: json["name"],
    email: json["email"],
    phone: json["phone"],
    userName: json["user_name"],
    role: json["role"],
    latitude: json["latitude"],
    longitude: json["longitude"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    profileImage: json["profileImage"],
    pivot: json["pivot"] == null ? null : Pivot.fromJson(json["pivot"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "email": email,
    "phone": phone,
    "user_name": userName,
    "role": role,
    "latitude": latitude,
    "longitude": longitude,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
    "profileImage": profileImage,
    "pivot": pivot?.toJson(),
  };
}

class Pivot {
  final int? followerId;
  final int? userId;

  Pivot({
    this.followerId,
    this.userId,
  });

  factory Pivot.fromJson(Map<String, dynamic> json) => Pivot(
    followerId: json["follower_id"],
    userId: json["user_id"],
  );

  Map<String, dynamic> toJson() => {
    "follower_id": followerId,
    "user_id": userId,
  };
}
