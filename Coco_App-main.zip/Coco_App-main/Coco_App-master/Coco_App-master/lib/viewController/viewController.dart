import 'package:flutter/material.dart';

import '../utility/colors.dart';





class ViewController{
  ///////////// chose photo ///////////////
  static chosePhoto({required BuildContext context, required VoidCallback leftButton, required VoidCallback rightButton})async{
    showModalBottomSheet(
        context: context,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            topRight:  Radius.circular(40),
            topLeft:  Radius.circular(40),
          ),
        ),
        builder: (context) {
          return Container(
            color: Colors.white,
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  const SizedBox(height: 20,),
                  const Text("Upload Stories", style: TextStyle(color: AppColors.black, fontSize: 15, fontWeight: FontWeight.w600),),
                  const SizedBox(height: 30,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      InkWell(
                        onTap: leftButton,
                        child: Column(
                          children: const [
                            Icon(Icons.photo_camera_back, color: AppColors.mainColor, size: 30,),
                            SizedBox(height: 10,),
                            Text("Upload Photo", style: TextStyle(color: AppColors.mainColor),),
                          ],
                        ),
                      ),

                      SizedBox(width: 50,),
                      InkWell(
                        onTap: rightButton,
                        child: Column(
                          children: const [
                            Icon(Icons.videocam_rounded, color: Colors.blueAccent, size: 30,),
                            SizedBox(height: 10,),
                            Text("Upload Video", style: TextStyle(color: Colors.blueAccent),),
                          ],
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 20,),
                ],
              ),
            ),
          );
        });
  }
///////////// chose photo ///////////////
}