
import 'dart:io';

import 'package:coco/view/storys/story_input.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:video_player/video_player.dart';

class VideoWidget extends StatefulWidget {
  final File? file;
  final String? src;
  final bool? stop;
  VideoWidget({this.file, this.src, this.stop = true});
  @override
  _VideoWidgetState createState() => _VideoWidgetState();
}

class _VideoWidgetState extends State<VideoWidget> {
  late VideoPlayerController _controller;
  Future<void>? _initializeVideoPlayerFuture;
  @override
  void initState() {
    // Create a VideoPlayerController.
    _controller = widget.file != null
        ? VideoPlayerController.file(
      widget.file!
    )
        : VideoPlayerController.network(
      '${widget.src}',
    );
    // Initialize the controller and store the Future for later use.
    _initializeVideoPlayerFuture = initializeVideoPlayer();

    super.initState();
  }

  Future<void> initializeVideoPlayer() async {
    try {
      // Use the controller to loop the video.
      _controller.setLooping(true);
      await _controller.initialize();

      if(widget.stop == true){
        _controller.pause();
      }else{
        _controller.play();
      }

      print("widget.stop === ${widget.stop}");
    } catch (e) {
      print("Error initializing video player: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      child: SafeArea(
        child: Scaffold(
          backgroundColor: Colors.black,
          body: Center(
            child: FutureBuilder(
              future: _initializeVideoPlayerFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.done) {
                  // If the VideoPlayerController has finished initialization, use
                  // the data it provides to limit the aspect ratio of the video.
                  return AspectRatio(
                    aspectRatio: _controller.value.aspectRatio,
                    child: VideoPlayer(_controller),
                  );
                } else {
                  // If the VideoPlayerController is still initializing, show a
                  // loading spinner.
                  return Center(child: CircularProgressIndicator());
                }
              },
            ),
          ),
          bottomNavigationBar:  Container(
            color: Colors.black,
            height: 50,
            margin: EdgeInsets.all(20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                InkWell(
                  onTap: ()=>Get.back(),
                  child: Container(
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                        color: Colors.grey.shade200,
                        borderRadius: BorderRadius.circular(5)
                    ),
                    child:Text("Re upload"),
                  ),
                ),
                SizedBox(width: 20,),
                InkWell(
                  onTap: ()async{
                    _controller.pause();
                     Get.to(StoryDescription(file: widget.file,));
                  },
                  child: Container(
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(5)
                    ),
                    child:Text("Continue"),
                  ),
                )
              ],
            ),
          )
        ),
      ),
    );
  }

  @override
  void dispose() {
    // Ensure you dispose the VideoPlayerController to free up resources.
    _controller.dispose();

    super.dispose();
  }
}