import 'package:coco/utility/colors.dart';
import 'package:coco/viewController/appNetworkImage.dart';
import 'package:flutter/material.dart';

class SingleServiceDashboard extends StatelessWidget {
  const SingleServiceDashboard({Key? key,
    required this.size,
    required this.name,
    required this.profile,
    required this.amount,
    required this.bgImage,
    required this.onClick,
    required this.isCollabration,
    required this.isPrice, required this.isClient,}) : super(key: key);
  final Size size;
  final String name;
  final String profile;
  final String amount;
  final String bgImage;
  final VoidCallback onClick;
  final bool isCollabration;
  final bool isPrice;
  final bool isClient;

  @override
  Widget build(BuildContext context) {
    var isFalse  = false;

    return InkWell(
      onTap: onClick,
      child: Container(
        margin: EdgeInsets.only(bottom: 10),
        child: Stack(
          children: [
            SizedBox(height: 200,
                width: size.width,
                child: AppNetworkImage(
                  src: "${bgImage}",
                )
            ),

            //shado
            Positioned(
              bottom: 0,
              child: Container(
                height: 100,
                width: size.width,
                decoration:  BoxDecoration(
                // color: Colors.black.withOpacity(0.3),
                  boxShadow: [
                    BoxShadow(
                     color: Colors.black.withOpacity(0.8),
                      spreadRadius: 10,
                      blurRadius: 30,
                      offset: Offset(-20,10)
                    )
                  ]
                ),
              )
            ),

            Positioned(
              bottom: 15,
              left: 10,
              child:  Row(
                children: [
                  CircleAvatar(
                    radius: 20,
                    backgroundColor: Colors.white,
                    child: ClipOval(
                      child: AppNetworkImage(src: profile, width: 38, height: 38,)
                    ),
                  ),
                  SizedBox(
                    width: 5,
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            name,
                            style: TextStyle(
                                color: Colors.white,
                            fontWeight: FontWeight.bold,
                              fontFamily: 'source-sans-pro-bold',
                              fontSize: 13
                            ),
                          ),

                        ],
                      ),

                    ],
                  ),
                ],
              ),
            ),
            // Positioned(
            //   top: 0,
            //   right: 0,
            //   child: IconButton(
            //     onPressed: (){},
            //     icon: Icon(Icons.favorite, color: Colors.white, size: 30,),
            //   )
            // ),

           //  isCollabration
           //     ? Positioned(
           //   right: 10, bottom: 10,
           //   child:  Card(
           //     shape: RoundedRectangleBorder(
           //         borderRadius:
           //         BorderRadius.circular(20)),
           //     color: Colors.white,
           //     child: Padding(
           //       padding: const EdgeInsets.all(10.0),
           //       child:  Text("$collabration",
           //         style: TextStyle(
           //             fontSize: 12,
           //             color: Colors.black,
           //           fontWeight: FontWeight.w600
           //         ),
           //       ) ,
           //     ),
           //   ),
           // )
           //     : SizedBox(),

            isClient ? Center() : Positioned(
              right: 10, bottom: 10,
              child:  Card(
                shape: RoundedRectangleBorder(
                    borderRadius:
                    BorderRadius.circular(20)),
                color: Colors.white,
                child: Padding(
                  padding: const EdgeInsets.only(left: 13, right: 15, top: 5, bottom: 5),
                  child:  RichText(
                    text: TextSpan(
                      children: [
                        amount == "collaborate"? TextSpan() : TextSpan(
                          text: "From ",
                            style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.w400
                            ),
                        ),
                    amount == "collaborate" ? TextSpan(
                            text: "$amount",
                            style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.w600
                            )
                        ): TextSpan(
                            text: " $amount \$ ",
                          style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.w600
                          )
                        ),

                      ]
                    ),

                  )
                ),
              ),
            )


          ],
        ),
      ),
    );
  }
}
