import 'package:animator/animator.dart';
import 'package:flutter/material.dart';

class LikeAnimation extends StatefulWidget {
  final double begin;
  final double end;
  const LikeAnimation({Key? key, this.begin = 20.0,  this.end = 25.0}) : super(key: key);

  @override
  State<LikeAnimation> createState() => _LikeAnimationState();
}

class _LikeAnimationState extends State<LikeAnimation> {
  @override
  Widget build(BuildContext context) {
    return Animator<double>(
      duration: Duration(milliseconds: 500),
      cycles: 0,
      curve: Curves.elasticIn,
      tween: Tween<double>(begin: widget.begin, end: widget.end),
      builder: (context, animatorState, child)=>Icon(Icons.favorite, color: Colors.redAccent, size: animatorState.value*5,),
    );
  }
}
