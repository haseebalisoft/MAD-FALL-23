import 'dart:io';
import 'dart:math';

import 'package:coco/view/storys/story_input.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:coco/viewController/videoWIdgets.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';

class UploadVideoPreviews extends StatefulWidget {
  const UploadVideoPreviews({Key? key}) : super(key: key);

  @override
  State<UploadVideoPreviews> createState() => _UploadVideoPreviewsState();
}

class _UploadVideoPreviewsState extends State<UploadVideoPreviews> {

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  bool isStop = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      child: SafeArea(
        child: Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            backgroundColor: Colors.black,
            leading: IconButton(
              onPressed: ()=>Get.back(),
              icon: const Icon(Icons.arrow_back, color: Colors.white,),
            ),
            title: Text( " ${video!= null? "Preview" : "Choose video or Recorde video"}",
              style: TextStyle(
                fontSize: 15,
                color: Colors.white
              ),
            ),
          ),
          body: Column(
            children: [
              ListTile(
                onTap: ()=> _pickImage(ImageSource.gallery),
                leading: Icon(Icons.photo_camera_back, color: Colors.white,),
                title: Text("Upload from gallery",
                  style: TextStyle(
                    fontSize: 15, color: Colors.white
                  ),
                ),
              ),
              ListTile(
                onTap: ()=> _pickImage(ImageSource.camera),
                leading: Icon(Icons.video_call_sharp, color: Colors.white,),
                title: Text("Record a video",
                  style: TextStyle(
                      fontSize: 15, color: Colors.white
                  ),
                ),
              )
            ],
          ),


        ),
      ),
    );
  }


  getFileSize(String filePath) async {
    try {
      File file = File(filePath);
      int size = await file.length();
      if(size < 25000000){
        setState(() {
          video = file;
        });

        Get.to(VideoWidget(file: video));

      }else{
        AlertController.snackbar(context: context, text: "Please upload less than 25 MB Video.", bg: Colors.red);
      }
      print("size ==== ${size}");

    } catch (e) {
      print('Error getting file size: $e');
      return -1; // Return -1 in case of an error
    }
  }


  ///////////////// file picker /////////////
  File? video;
  bool isImageCroping = false;
  ////////// pick profile image////////
  Future<void> _pickImage(ImageSource type) async {
    ImagePicker picker = ImagePicker();
    XFile? pickedFile = await picker.pickVideo(source: type);
    if (pickedFile != null) {
      getFileSize(pickedFile.path);

      print("image === ${video}");
      // _uploadCoverImage(image);
      // Handle the picked image, e.g., display it in an image widget or upload it
      // to a server.
    }
  }

}
