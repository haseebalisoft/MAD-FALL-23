import 'dart:async';

import 'package:flutter/material.dart';

class DynamicHeightImage extends StatefulWidget {
  final String imageUrl;

  DynamicHeightImage({required this.imageUrl});

  @override
  _DynamicHeightImageState createState() => _DynamicHeightImageState();
}

class _DynamicHeightImageState extends State<DynamicHeightImage> {
  double? _imageHeight;

  void _getImageDimensions(Image image) {
    // Get the image dimensions
    final Completer<Size> completer = Completer<Size>();
    image.image.resolve(ImageConfiguration()).addListener(
      ImageStreamListener((ImageInfo info, bool _) {
        completer.complete(Size(
          info.image.width.toDouble(),
          info.image.height.toDouble(),
        ));
      }),
    );

    completer.future.then((Size value) {
      // Update the height based on image dimensions
      setState(() {
        _imageHeight = value.height;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        _imageHeight != null
            ? Image.network(
          widget.imageUrl,
          height: _imageHeight,
          width: MediaQuery.of(context).size.width,
          fit: BoxFit.cover,
        )
            : Image.network(
          widget.imageUrl,
          frameBuilder: (BuildContext context, Widget child, int? frame,
              bool wasSynchronouslyLoaded) {
            if (wasSynchronouslyLoaded) {
              // Image was loaded synchronously, get dimensions
              _getImageDimensions(child as Image);
              return child;
            } else {
              return Center(child: CircularProgressIndicator());
            }
          },
        ),
      ],
    );
  }
}
