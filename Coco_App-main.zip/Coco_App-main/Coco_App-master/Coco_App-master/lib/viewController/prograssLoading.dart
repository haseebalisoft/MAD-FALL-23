import 'package:flutter/material.dart';
class ProgressLoading extends StatefulWidget {
  const ProgressLoading({super.key});

  @override
  State<ProgressLoading> createState() =>
      _ProgressLoadingState();
}

class _ProgressLoadingState extends State<ProgressLoading>
    with TickerProviderStateMixin {
  late AnimationController controller;

  @override
  void initState() {
    controller = AnimationController(
      /// [AnimationController]s can be created with `vsync: this` because of
      /// [TickerProviderStateMixin].
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..addListener(() {
      setState(() {});
    });
    controller.repeat(reverse: true);
    super.initState();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: 10, bottom: 10),
      child: LinearProgressIndicator(
        value: controller.value,
        semanticsLabel: 'Linear progress indicator',
      ),
    );
  }
}
