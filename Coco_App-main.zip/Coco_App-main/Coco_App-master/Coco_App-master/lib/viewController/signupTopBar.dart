import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:sizer/sizer.dart';

import '../utility/appAssets.dart';

class SignUpTopBar extends StatelessWidget {
  const SignUpTopBar({
    super.key,
    required this.size,
  });

  final Size size;

  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.only(top: 20),
        child: SvgPicture.asset(AssetUtils.logoSvg,width: 5.w,height: 12.h,));
  }
}
