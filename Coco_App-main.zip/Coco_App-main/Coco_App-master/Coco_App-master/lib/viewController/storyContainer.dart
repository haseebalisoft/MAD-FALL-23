import 'package:coco/viewController/appNetworkImage.dart';
import 'package:flutter/material.dart';

import '../utility/appAssets.dart';

class StoryContainer extends StatelessWidget {
  const StoryContainer({
    super.key,
    required this.text,
    required this.onClick,
    this.width = 76.00,
    this.height = 76.00,
     this.image,
  });
  final String text;
  final VoidCallback onClick;
  final double width;
  final double height;
  final String? image;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onClick,
      child: Container(
        margin: EdgeInsets.only(right: 10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: width-6,
              height: height-6,
              padding: EdgeInsets.all(3),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [
                    Color(0xFF00CC83),
                    Color(0xFF53E0DB),
                  ],
                ),
              ),
              child: Container(
                width: 63,
                height: 63,
                padding: EdgeInsets.all(0),

                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Color(0xff3f3d3d),
                ),
                child: ClipOval(
                    child: image != null ? AppNetworkImage(src: image!,) : Image.asset("asset/image/logo.png", fit: BoxFit.cover)),
              ),
            ),
            SizedBox(
              height: 3,
            ),
            Expanded(
              child: Text(
                text.length > 10 ? ' '+text.substring(0,10)+'...':' '+text,
                style: TextStyle(
                    color: Color(0xFFE1E1E1),
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    fontFamily: 'source-sans-pro-regular'),
              ),
            )
          ],
        ),
      ),
    );
  }
}
