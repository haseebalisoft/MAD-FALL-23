import 'package:coco/utility/colors.dart';
import 'package:coco/viewController/appNetworkImage.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:story_view/story_view.dart';
import 'package:video_player/video_player.dart';
import 'package:path/path.dart' as p;
import '../appConst.dart';
import '../model/storyModel/allStoryModel.dart';
import '../../controller/storyController.dart' as MyStoryController;
import '../view/Client/bottomNagivation/buttom_nav.dart';
import '../view/freelancer/bottomNavigationBar/becameFreelanceBottomNavigation.dart';
import 'alartController.dart';


class StoryInsta extends StatefulWidget {
  final List<Story>? allStoryModel;
  final String? user_name;
  final String? user_img;
  final bool? isThisOwnStory;

  StoryInsta({this.allStoryModel, this.user_name, this.user_img, this.isThisOwnStory});
  @override
  _StoryInstaState createState() => _StoryInstaState();
}

class _StoryInstaState extends State<StoryInsta> {
  final storyController = StoryController();
  late VideoPlayerController _videoPlayerController;




  List<StoryItem> storyItems = [];

  List<bool> storyLike = [];
  List<int> storyLikeCOunt = [];
  int currentIndex = 0;
  int currentStoryLike = 0;




  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    setStory();

    print("story list === ${widget.allStoryModel!.length}");
    print("story === ${widget.allStoryModel!}");
    for(var i in widget.allStoryModel!){
      print("story id === ${i.id}");
      print("story like or not === ${i.isLiked}");

    }
    for(var i in widget.allStoryModel!){
      storyLikeCOunt.add(i.like!);
      storyLike.add(i.isLiked!);
    }
    print("storyItems list === ${storyItems.length}");
    storyController.play();
  }

  setStory()async{
    // Check if the extension is in the list of image extensions
    for(var i in widget.allStoryModel!){
      String imageUrl = '${i.image.toString()}';
      var extPath = p.extension(imageUrl);
      if(extPath == ".mp4" || extPath == ".avi" || extPath == ".mkv"  || extPath == ".wmv" || extPath == ".flv" || extPath == ".mov"){
          storyItems.add( StoryItem.pageVideo(
              i.image.toString(),
              caption: "${i.description == null ? "" : i.description}",
              controller: storyController));
      }else{
          storyItems.add(
              StoryItem.pageImage(
              url: i.image.toString(),
              caption: "${i.description ==null ? "" : i.description}",
              controller: storyController));

      }

    }
  }



  //list of like
  int storyPage = 0;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      child: SafeArea(
        child: Scaffold(
          body: Stack(
            children: [
              StoryView(
                indicatorColor: AppColors.mainColor,
                storyItems: storyItems,
                onStoryShow: (s) {
                  currentIndex  = storyItems.indexOf(s);

                  Future.delayed(Duration.zero, () {
                    updateState();
                  });

                 print("Current story index: $currentIndex");




                 // if(storyItems.length -1 ==  currentIndex) {
                 //    return;
                 //    print("Current story index inside condition : $currentIndex");
                 // }
                 //
                 //
                 // currentIndex++;
                 // updateState();




                },
                onComplete: () {
                  print("complete a story");
                  currentIndex = 0;
                  Future.delayed(Duration.zero, () {
                    updateState();
                  });

                  print("Current story index completed: $currentIndex");
                  //Get.back();
                },
                progressPosition: ProgressPosition.top,
                repeat: true,
                controller: storyController,

              ),
              Container(
                margin: EdgeInsets.only(left: 20, right: 20, top: 30, bottom: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                   Row(
                     children: [
                       Container(
                         width: 50, height: 50,
                         decoration: BoxDecoration(
                             color: Colors.grey,
                             borderRadius: BorderRadius.circular(100)
                         ),
                         child: ClipRRect(
                           borderRadius: BorderRadius.circular(100),
                           child: AppNetworkImage(src: widget.user_img ?? ""),
                         ),
                       ),
                       SizedBox(width: 20,),
                       Text("${widget.user_name ?? 'No name'}",
                         style: TextStyle(
                             fontWeight: FontWeight.w600,
                             color: Colors.white,
                             fontSize: 17
                         ),
                       ),
                     ],
                   ),
                    SizedBox(
                      height: 50, width: 50,
                      child: IconButton(
                        onPressed: () async {
                          SharedPreferences pref = await SharedPreferences.getInstance();

                          debugPrint("role === ${pref.getString("role")}");
                          if(pref.getString("role") == AppConst.FREELANCER_ROLE){
                            Get.offAll( (FreelancerAppBottomNavigation(pageIndex: 0,)));
                          }else if(pref.getString("role") == AppConst.CLIENT_ROLE){
                            Get.offAll(ClientBottomNavigationBar(pageIndex: 0,));
                          }
                        },
                        icon: Icon(Icons.close, color: Colors.white,),
                      ),
                    )
                  ],
                ),
              ),
              Positioned(
                bottom: 100,
                right: 30,
                child: Column(
                  children: [
                    InkWell(onTap:(){
                      setState(() {
                        print("btn index === ${currentIndex}");
                        print("btn index id === ${widget.allStoryModel![currentIndex]!.id}");
                        if(widget.allStoryModel![currentIndex]!.isLiked!){
                          dislikeStory(widget.allStoryModel![currentIndex]!.id!);
                        }else{
                          likeStory(widget.allStoryModel![currentIndex]!.id!);
                        }

                      });
                     },
                        child: Icon(Icons.favorite, color: storyLike[currentIndex] ? Colors.red  : Colors.white, size: 35,)),
                    SizedBox(height: 5,),
                    Text("${storyLikeCOunt[currentIndex]}",
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        color: Colors.white
                      ),
                    )
                  ],
                ),
              ),
              widget.isThisOwnStory! ? Positioned(
                bottom: 50,
                right: 30,
                child: Column(
                  children: [
                    InkWell(onTap:(){
                      setState(() {
                          deleteStory(widget.allStoryModel![currentIndex]!.id!);
                      });
                    },
                        child: Icon(Icons.delete, color: Colors.white, size: 35,)),

                  ],
                ),
              ) : Container(),

            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    storyController.dispose();
    super.dispose();
  }

  void updateState() async{

    setState(() {

    });
  }


  deleteStory(int storyId) async{
    var res = await   MyStoryController.StoryController.deleteStory(story_id:  storyId.toString());

    if(res.statusCode == 200){

      // Navigator.pop(context);
      Get.back();
      SharedPreferences pref = await SharedPreferences.getInstance();

      debugPrint("role === ${pref.getString("role")}");
      if(pref.getString("role") == AppConst.FREELANCER_ROLE){
        Get.offAll( (FreelancerAppBottomNavigation(pageIndex: 0,)));
      }else if(pref.getString("role") == AppConst.CLIENT_ROLE){
        Get.offAll(ClientBottomNavigationBar(pageIndex: 0,));
      }
      Get.snackbar(
        "Deleted!",
        "Your Story has been deleted",
        icon: const Icon(Icons.info, color: Colors.white),
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green,
        titleText: const Text(
          "Deleted!",
          style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.bold
          ),
        ),
        messageText: const Text(
          "Your Story has been deleted",
          style: TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.w400
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 8.0),

      );
    }else if(res.statusCode ==400){
      Get.snackbar(
        "Something wrong happened",
        "This is not your Story",
        icon: const Icon(Icons.error_outline, color: Colors.white),
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        titleText: const Text(
          "Something wrong happened",
          style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.bold
          ),
        ),
        messageText:  Text(
          "This is not your Story",
          style: TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.w400
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 8.0),

      );
    }else{
      Get.snackbar(
        "Something wrong happened",
        "Something wrong happened in the server",
        icon: const Icon(Icons.error_outline, color: Colors.white),
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        titleText: const Text(
          "Something wrong happened",
          style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.bold
          ),
        ),
        messageText:  Text(
          "Something wrong happened in the server",
          style: TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.w400
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 8.0),

      );

    }
  }

  likeStory(int storyId) async{
    setState(() {
      storyLikeCOunt[currentIndex] = storyLikeCOunt[currentIndex] + 1;
      storyLike[currentIndex] = true;
    });

    var res = await   MyStoryController.StoryController.likeStory(story_id:  storyId.toString());

    if(res.statusCode == 200){

      // Navigator.pop(context);
      SharedPreferences pref = await SharedPreferences.getInstance();

      debugPrint("role === ${pref.getString("role")}");
      if(pref.getString("role") == AppConst.FREELANCER_ROLE){
        //Get.offAll( (FreelancerAppBottomNavigation(pageIndex: 0,)));
      }else if(pref.getString("role") == AppConst.CLIENT_ROLE){

       // Get.offAll(ClientBottomNavigationBar(pageIndex: 0,));
      }
      Get.snackbar(
        "Liked!",
        "Story liked successfully",
        icon: const Icon(Icons.info, color: Colors.white),
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green,
        titleText: const Text(
          "Liked!",
          style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.bold
          ),
        ),
        messageText: const Text(
          "Story liked successfully",
          style: TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.w400
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 8.0),

      );
    }
    else{
      setState(() {
        storyLikeCOunt[currentIndex] = storyLikeCOunt[currentIndex] - 1;
        storyLike[currentIndex] = false;
      });


      Get.snackbar(
        "Something wrong happened",
        "Something wrong happened in the server",
        icon: const Icon(Icons.error_outline, color: Colors.white),
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        titleText: const Text(
          "Something wrong happened",
          style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.bold
          ),
        ),
        messageText:  Text(
          "Something wrong happened in the server",
          style: TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.w400
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 8.0),

      );

    }
  }


  dislikeStory(int storyId) async{
    setState(() {
      storyLikeCOunt[currentIndex] = storyLikeCOunt[currentIndex] - 1;
      storyLike[currentIndex] = false;
    });


    var res = await   MyStoryController.StoryController.dislikeStory(story_id:  storyId.toString());

    if(res.statusCode == 200){

      // Navigator.pop(context);
      SharedPreferences pref = await SharedPreferences.getInstance();

      debugPrint("role === ${pref.getString("role")}");
      if(pref.getString("role") == AppConst.FREELANCER_ROLE){
        //Get.offAll( (FreelancerAppBottomNavigation(pageIndex: 0,)));
        // setState(() {
        //   currentStoryLike = currentStoryLike - 1;
        // });
      }else if(pref.getString("role") == AppConst.CLIENT_ROLE){
        //Get.offAll(ClientBottomNavigationBar(pageIndex: 0,));
        // setState(() {
        //   currentStoryLike = currentStoryLike - 1;
        // });
      }
      Get.snackbar(
        "Disiked!",
        "Story disliked successfully",
        icon: const Icon(Icons.info, color: Colors.white),
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green,
        titleText: const Text(
          "Disliked!",
          style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.bold
          ),
        ),
        messageText: const Text(
          "Story disliked successfully",
          style: TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.w400
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 8.0),

      );
    }
    else{
      setState(() {
        storyLikeCOunt[currentIndex] = storyLikeCOunt[currentIndex] + 1;
        storyLike[currentIndex] = true;
      });


      Get.snackbar(
        "Something wrong happened",
        "Something wrong happened in the server",
        icon: const Icon(Icons.error_outline, color: Colors.white),
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        titleText: const Text(
          "Something wrong happened",
          style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.bold
          ),
        ),
        messageText:  Text(
          "Something wrong happened in the server",
          style: TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontFamily: 'Poppins-Bold',
              fontWeight: FontWeight.w400
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 8.0),

      );

    }
  }



}