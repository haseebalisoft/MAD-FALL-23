import 'package:cached_network_image/cached_network_image.dart';
import 'package:coco/utility/colors.dart';
import 'package:flutter/material.dart';

import '../utility/appAssets.dart';

class AppNetworkImage extends StatelessWidget {
  final String src;
  final BoxFit fit;
  final double height;
  final double width;
  const AppNetworkImage({Key? key, required this.src, this.fit = BoxFit.cover, this.height = 200,  this.width = double.infinity } ) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CachedNetworkImage(
      imageUrl: src,
      fit: fit,
      height: height,
      width: width,
      progressIndicatorBuilder: (context, url, downloadProgress) =>
          SizedBox(height: 30, width: 30, child: Center(child: CircularProgressIndicator(color: AppColors.white,),)),
      errorWidget: (context, url, error) => Image.asset(AssetUtils.logoPng),
    );
  }
}
