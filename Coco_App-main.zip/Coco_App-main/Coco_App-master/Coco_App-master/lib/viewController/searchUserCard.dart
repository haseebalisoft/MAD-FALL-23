import 'package:coco/utility/appAssets.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../utility/colors.dart';

class searchUserCard extends StatelessWidget {

  const searchUserCard({
    super.key, required this.name, required this.image, required this.onclick,
  });
  final String name,image;

  final VoidCallback onclick;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(

              padding: EdgeInsets.all(3),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [
                    Color(0xFF00CC83),
                    Color(0xFF53E0DB),
                  ],
                ),
              ),
              child: CircleAvatar(
                radius: 30,
                backgroundColor: Colors.white,
                child: ClipOval(
                  child: FadeInImage(
                    placeholder: AssetImage(AssetUtils.logoPng) as ImageProvider<Object>,
                    image: image != null
                        ? NetworkImage('${image}') as ImageProvider<Object>
                        : AssetImage(AssetUtils.logoPng) as ImageProvider<Object>,
                    fit: BoxFit.cover,
                    width: 60.0,
                    height: 60.0,
                  ),
                ),
              ),

            ),
            SizedBox(width: 7,),
            SizedBox(
              width: MediaQuery.of(context).size.width*0.7,
              child: InkWell(
                onTap: (){
                  onclick();
                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [

                        Text('${name}',style: TextStyle(color: AppColors.white,fontSize: 19,fontFamily: 'SourceSansPro-Semibold'),),
                        SizedBox(
                          height: 20,
                          width: MediaQuery.of(context).size.width*0.6,
                          child: ListView.builder(
                              scrollDirection: Axis.horizontal,
                              itemCount: 5,
                              itemBuilder: (context,index){
                                return  Text(' Photographer,',style: TextStyle(color: AppColors.textgrey,fontSize: 15,fontFamily: 'source-sans-pro-regular'));
                              }),
                        )
                      ],
                    ),


                  ],
                ),
              ),
            ),
            // Spacer(),
            // Spacer(),
            // Spacer(),
            // Spacer(),
            // Spacer(),
            // Spacer()

          ],
        ),
        SizedBox(height: 2.h,)
      ],
    );
  }
}