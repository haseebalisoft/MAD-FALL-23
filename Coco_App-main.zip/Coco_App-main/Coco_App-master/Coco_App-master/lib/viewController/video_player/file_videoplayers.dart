import 'dart:io';

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class FileVideoPlayerWidget extends StatefulWidget {
  final String videoPath; // Replace this with the actual path to your video

  FileVideoPlayerWidget({required this.videoPath});

  @override
  _FileVideoPlayerWidgetState createState() => _FileVideoPlayerWidgetState();
}

class _FileVideoPlayerWidgetState extends State<FileVideoPlayerWidget> {
  late VideoPlayerController _controller;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.file(File(widget.videoPath))
      ..initialize().then((_) {
        _controller.play();
        // Ensure the first frame is shown after the video is initialized
        setState(() {});
      });
  }

   void didChangeAppLifecycleState(AppLifecycleState state) {
    // App state changed before we got the chance to initialize.
    if (_controller == null || !_controller!.value.isInitialized) {
      return;
    }
    if (state == AppLifecycleState.inactive) {
      _controller?.dispose();
    } else if (state == AppLifecycleState.resumed) {
      if (_controller != null) {
        print('muere');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: _controller.value.isInitialized
          ? Stack(
        children: [
          AspectRatio(
            aspectRatio: _controller.value.aspectRatio,
            child: VideoPlayer(_controller),
          ),
          InkWell(
            onTap: (){
              setState(() {
                if (_controller.value.isPlaying) {
                  _controller.pause();
                } else {
                  _controller.play();
                }
              });
            },
            child: Icon(
                _controller.value.isPlaying  ? Icons.pause : _controller.value.isCompleted? Icons.play_arrow : Icons.pause, size: 30,
              ),
          )
        ],
      )
          : Container( margin: EdgeInsets.only(left: 50, right: 50),  child: CircularProgressIndicator()),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}
