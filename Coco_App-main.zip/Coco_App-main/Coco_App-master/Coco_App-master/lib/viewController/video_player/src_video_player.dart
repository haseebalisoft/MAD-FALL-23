import 'dart:io';

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class SrcVideoPlayerWidget extends StatefulWidget {
  final String videoPath; // Replace this with the actual path to your video
  final bool fullAspectRatio;
  SrcVideoPlayerWidget({required this.videoPath, this.fullAspectRatio = false});

  @override
  _SrcVideoPlayerWidgetState createState() => _SrcVideoPlayerWidgetState();
}

class _SrcVideoPlayerWidgetState extends State<SrcVideoPlayerWidget> {
  late VideoPlayerController _controller;

  @override
  void initState() {
    super.initState();

    print("widget.videoPath == ${widget.videoPath}");
    _controller = VideoPlayerController.network(widget.videoPath)
      ..initialize().then((_) {
        // Ensure the first frame is shown after the video is initialized
        setState(() {});
      });
  }


  void didChangeAppLifecycleState(AppLifecycleState state) {
    // App state changed before we got the chance to initialize.
    if (_controller == null || !_controller!.value.isInitialized) {
      return;
    }
    if (state == AppLifecycleState.inactive) {
      _controller?.dispose();
    } else if (state == AppLifecycleState.resumed) {
      if (_controller != null) {
        print('muere');
      }
    }
  }


  @override
  Widget build(BuildContext context) {
    return Center(
      child: _controller.value.isInitialized
          ? Stack(
        children: [
          AspectRatio(
            aspectRatio: widget.fullAspectRatio ? 6/6 : _controller.value.aspectRatio,
            child: ClipRRect( 
                borderRadius: BorderRadius.circular(10),
                child: VideoPlayer(_controller)),
          ),
          IconButton(
            onPressed: () {
              setState(() {
                if (_controller.value.isPlaying) {
                  _controller.pause();
                } else {
                  _controller.play();
                }
              });
            },
            icon: Icon(
              _controller.value.isPlaying ? Icons.pause : Icons.play_arrow,
            ),
          )
        ],
      )
          : CircularProgressIndicator(),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}
