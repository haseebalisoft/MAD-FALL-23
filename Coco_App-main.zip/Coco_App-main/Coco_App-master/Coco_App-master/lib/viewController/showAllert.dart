import 'package:coco/utility/colors.dart';
import 'package:flutter/material.dart';

class AppAllerts{

  //show diloag
  static Future showAlert({required String text, required VoidCallback yesClick, required BuildContext context,})async{
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          content: Text('$text'),
          actions: [
            Container(
              decoration: BoxDecoration(
                color: AppColors.mainColor,
                borderRadius:BorderRadius.circular(5)
              ),
              child: TextButton(
                onPressed: ()=>Navigator.pop(context),
                child: Text("NO",
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
            TextButton(
              onPressed: yesClick,
              child: Text("YES",
                style: TextStyle(color: Colors.black),
              ),
            ),
          ],
        );
      },
    );
  }

}