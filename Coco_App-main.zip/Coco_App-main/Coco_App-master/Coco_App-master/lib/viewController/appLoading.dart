import 'package:coco/utility/colors.dart';
import 'package:flutter/material.dart';

class LoadingOverlay extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black.withOpacity(0.5),
      child: Center(
        child: CircularProgressIndicator(color: AppColors.mainColor,),
      ),
    );
  }
}

void showLoadingOverlay(BuildContext context) {
  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (BuildContext context) {
      return LoadingOverlay();
    },
  );
}

void hideLoadingOverlay(BuildContext context) {
  Navigator.of(context).pop(); // Close the overlay
}

// Example usage:
// showLoadingOverlay(context);
// To hide: hideLoadingOverlay(context);
