import 'dart:io';
import 'dart:typed_data';
import 'package:coco/controller/camera_gallery_controller/cameraGalleryController.dart';
import 'package:coco/model/postModel/PostModel.dart';
import 'package:coco/viewController/appNetworkImage.dart';
import 'package:coco/viewController/videoWIdgets.dart';
import 'package:coco/viewController/video_player/file_videoplayers.dart';
import 'package:coco/viewController/video_player/src_video_player.dart';
import 'package:path/path.dart' as p;
import 'package:coco/appConst.dart';
import 'package:coco/controller/authController.dart';
import 'package:coco/view/freelancer/bottomNavigationBar/becameFreelanceBottomNavigation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../controller/postController.dart';
import '../utility/colors.dart';
import '../view/Client/bottomNagivation/buttom_nav.dart';
import 'alartController.dart';

class UploadPhotosVideos extends StatefulWidget {
  final List? list;
  final dynamic cameraFile;
  final String? title;
  final String? postId;
  final bool? isStory;
  final String? description;
  final List<Images>? image;
  const UploadPhotosVideos({Key? key,  this.list, this.title, this.image, this.postId,  this.description, this.isStory = false, this.cameraFile}) : super(key: key);

  @override
  State<UploadPhotosVideos> createState() => _UploadPhotosVideosState();
}

class _UploadPhotosVideosState extends State<UploadPhotosVideos> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getAllData();
  }


  var cameraFile;
  final discription = TextEditingController();

  final postKey = GlobalKey<FormState>();
  // Get the video file
  List videoFile = [];
  List videoFilePath = [];


  getAllData()async{

    if(widget.cameraFile == null){
      ///============== if camera image or vide is null then check have any list =======//
      for(var i = 0; i<widget.list!.length!; i++){
        videoFile.add(await widget.list![i].file);
      }
      //
      for(var i = 0; i<videoFile.length; i++){
        videoFilePath.add(videoFile[i].path);

        print("this === ${p.extension(videoFile[i].path) }");
      }
    }else{
      ///============ if camera file is have, then assign it into camera file =====//
      cameraFile = await widget.cameraFile;
      videoFilePath.add(await widget.cameraFile); 
    }
    setState(() {});
  }





  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      child: SafeArea(
        child: Scaffold(
          backgroundColor: AppColors.black,
          appBar: AppBar(
            backgroundColor: AppColors.black,
            elevation: 0,
            leading: IconButton(
              onPressed: (){
                Get.back();
                //CameraGalleryController.pickGalleryAndCameraForPost(context: context);
              },
              icon:  Icon(Icons.close, color: AppColors.white,),
            ),
            title:  Text(widget.title!=null? "${widget.title}" : widget!.isStory! ? "New Story" : "New Portfolio" ,
              style: const TextStyle(
                  fontWeight: FontWeight.w600,
                  color: AppColors.white
              ),
            ),
            actions: [
              IconButton(
                onPressed: (){

                  if(discription.text.isEmpty){
                    Get.snackbar(
                      "Description Needed",
                      "Please add description.",
                      icon: const Icon(Icons.error_outline, color: Colors.white),
                      snackPosition: SnackPosition.BOTTOM,
                      backgroundColor: Colors.red,
                      titleText: const Text(
                        "Description Needed",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontFamily: 'Poppins-Bold',
                            fontWeight: FontWeight.bold
                        ),
                      ),
                      messageText:  Text(
                        "Please add description.",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontFamily: 'Poppins-Bold',
                            fontWeight: FontWeight.w400
                        ),
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 8.0),

                    );

                    return;
                  }
                  if(widget.title == "Edit"){
                    _editPortfolio(widget.postId);
                  }else{
                    _uploadPortfolio();
                  }

                  // if(widget.isStory == true){
                  //   _uploadSotry();
                  // }else{
                  //   widget.listImage !=null ?_editPortfolio(widget.postId.toString()) :_uploadPortfolio();
                  // }
                },
                icon: isLoading ? Padding(
                  padding: const EdgeInsets.only(top: 3.0, bottom: 3),
                  child: CircularProgressIndicator(color: AppColors.mainColor, strokeWidth: 1,),
                ) : Icon(Icons.arrow_forward, color: AppColors.mainColor,),

              ),
            ],
          ),
          body: Padding(
            padding: EdgeInsets.all(20),
            child: Form(
              key: postKey,
              child: ListView(
                children: [
                  SizedBox(
                    height: 300,
                    child: cameraFile == null
                        ? widget.image == null
                        ? ListView.builder(
                        shrinkWrap: true,
                        scrollDirection: Axis.horizontal,
                        itemCount: videoFile.length,
                        itemBuilder: (_, index){
                            print("videoFilePath[index] === ${videoFilePath[index]}");
                            return p.extension(videoFile[index].path.toString()) == ".mp4"
                                ? FileVideoPlayerWidget(videoPath: videoFilePath[index])
                               : Container(
                              color: AppColors.black,
                                 margin: EdgeInsets.only(right: 10),
                                 child: ClipRRect(
                                   borderRadius: BorderRadius.circular(5),
                                   child: Image.file(
                                     videoFile[index],
                                     fit: BoxFit.cover,
                                       width:  videoFile.length == 1 ? MediaQuery.of(context).size.width*.90 : MediaQuery.of(context).size.width*.70,
                                   ),
                                 ),
                              );
                          },
                        )
                        : ListView.builder(
                          //shrinkWrap: true,
                          scrollDirection: Axis.horizontal,
                          itemCount: widget.image!.length,
                          itemBuilder: (_, index){
                            return p.extension(widget.image![index]!.image!.toString()) == ".mp4"
                                ? SizedBox(
                                    height: 300,
                                    width: MediaQuery.of(context).size.width*.70,
                                    child:  Stack(
                                      children: [
                                        SrcVideoPlayerWidget(videoPath: widget.image![index]!.image!),
                                        IconButton( icon: Icon(Icons.cancel), color: Colors.red, onPressed: ()=>_deletePostImage(widget.postId, index),),
                                      ],
                                    )
                                    // child: FutureBuilder(
                                    //   future: _initializeVideoPlayerFuture,
                                    //   builder: (context, snapshot) {
                                    //     if (snapshot.hasData) {
                                    //       // If the VideoPlayerController has finished initialization, use
                                    //       // the data it provides to limit the aspect ratio of the video.
                                    //       return
                                    //     } else if(snapshot.connectionState == ConnectionState.waiting){
                                    //       return const Center(child: CircularProgressIndicator());
                                    //     }else {
                                    //       // If the VideoPlayerController is still initializing, show a
                                    //       // loading spinner.
                                    //       return const Center(child: CircularProgressIndicator());
                                    //     }
                                    //   },
                                    // ),
                                  )
                                // FutureBuilder<Uint8List?>(
                            //   future: _loadThumbnail(widget.list[index]),
                            //   builder: (context, snapshot) {
                            //     if (snapshot.connectionState == ConnectionState.waiting) {
                            //       return CircularProgressIndicator();
                            //     } else if (snapshot.hasError || snapshot.data == null) {
                            //       return Icon(Icons.error);
                            //     } else {
                            //       return Container(
                            //         margin: EdgeInsets.only(right: 10),
                            //         child: ClipRRect(
                            //           borderRadius: BorderRadius.circular(5),
                            //           child: Image.memory(
                            //             snapshot.data!,
                            //             fit: BoxFit.cover,
                            //             width: MediaQuery.of(context).size.width*.70,
                            //           ),
                            //         ),
                            //       );
                            //     }
                            //   },
                            // )
                                : p.extension(widget.image![index]!.image!.toString()) != ".mp4" ? Container(
                                  margin: EdgeInsets.only(right: 10),
                                  height: 300,
                                  child: Stack(
                                    children: [
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(5),
                                        child: AppNetworkImage(
                                          src: widget.image![index]!.image!,
                                          fit: BoxFit.fitWidth,
                                          height: 300,
                                          width: MediaQuery.of(context).size.width*.70,
                                        ),
                                      ),
                                      IconButton( icon: Icon(Icons.cancel), color: AppColors.white, onPressed: ()=>_deletePostImage(widget.postId, index),),
                                    ],
                                  ),
                                ):Center();
                          },
                        )
                        :  p.extension(cameraFile.path.toString()) == ".mp4"
                        ? FileVideoPlayerWidget(videoPath: cameraFile!.path)
                        : Container(
                          margin: EdgeInsets.only(right: 10),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(5),
                            child: Image.file(
                              cameraFile!,
                              fit: BoxFit.cover,
                              width:  MediaQuery.of(context).size.width*.90,
                            ),
                          ),
                        ),
                          ),
                  SizedBox(height: 20,),
                  Padding(
                    padding: const EdgeInsets.only(),
                    child: Row(
                      children: const [
                        Text("Description",
                          style: TextStyle(
                              fontSize: 12,
                              color: AppColors.white,
                              fontWeight: FontWeight.bold,

                          ),
                        ),
                        Icon(Icons.star, color: AppColors.mainColor, size: 15,)
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only( top: 10),
                    child: TextFormField(
                      style: TextStyle(
                        color: AppColors.white
                      ),
                      textInputAction: TextInputAction.done,
                      autofocus: true,
                      maxLines: 7,
                      controller: discription,
                      decoration: const InputDecoration(
                          contentPadding: EdgeInsets.all(10),

                          hintText: "Share a bit about your work experience, your projects...",
                      ),
                      validator: (v){
                        if(v!.isEmpty){
                          return "Description must not be empty";
                        }else{
                          return null;
                        }
                      },
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }


bool isLoading = false;
  void _uploadPortfolio() async{
    setState(() =>isLoading=true);
    // SharedPre
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var role = _pref.getString("role");



    // Get the video file
   print("videoFilePath ==== ${videoFilePath}");
    
    if(videoFilePath.isEmpty){
      AlertController.snackbar(context: context, text: "Please select images", bg: Colors.red);
    }else{
      if(postKey.currentState!.validate()){
        var res = await PostController.createPost(dec: discription.text, images: videoFilePath);
        print("response === ${res.statusCode}");
        if(res.statusCode == 200){
          if(role == AppConst.CLIENT_ROLE){
            Get.to(ClientBottomNavigationBar(pageIndex: 4,));
          }else{
            Get.to(FreelancerAppBottomNavigation(pageIndex: 4,));
          }
          AlertController.snackbar(context: context, text: "Post Create was success", bg: Colors.green);
        }else{
          AlertController.snackbar(context: context, text: "Something went wrong with server.", bg: Colors.red);
        }
      }
    }


    setState(() =>isLoading=false);
  }



  bool isDeleting = false;
  _deletePostImage(post_id, index) async{
    setState(() =>isDeleting = true);
    var res = await PostController.deleteImage(post_id: post_id.toString());
    if(res.statusCode == 200){
      setState(() {
        widget.image?.removeAt(index);
      });
      AlertController.snackbar(context: context, text: "Image deleted success.", bg: AppColors.mainColor);
    }else{
      AlertController.snackbar(context: context, text: "Something went wrong with server..", bg: Colors.red);
    }
    setState(() =>isDeleting = false);
  }




  _editPortfolio(post_id) async{
    setState(() =>isLoading = true);
    // SharedPre
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var role = _pref.getString("role");
    var res = await PostController.editPost(post_id: post_id.toString(), description: discription.text);
    print("edit === ${res.statusCode}");
    print("edit === ${res.body}");
    if(res.statusCode == 200){
      if(role == AppConst.CLIENT_ROLE){
        Get.to(ClientBottomNavigationBar(pageIndex: 3,));
      }else{
        Get.to(FreelancerAppBottomNavigation(pageIndex: 3,));
      }
      AlertController.snackbar(context: context, text: "Portfolio edit success.", bg: AppColors.mainColor);
    }else{
      AlertController.snackbar(context: context, text: "Something went wrong with server..", bg: Colors.red);
    }
    setState(() =>isLoading = false);
  }







}
