import 'package:carousel_slider/carousel_slider.dart';
import 'package:coco/appConst.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/viewController/video_player/src_video_player.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import '../model/postModel/PostModel.dart';
import 'appNetworkImage.dart';

class ImageSlider extends StatefulWidget {
  final List<Images> imageUrls;
  final double height;
  const ImageSlider({Key? key, required this.imageUrls, this.height = 200}) : super(key: key);

  @override
  State<ImageSlider> createState() => _ImageSliderState();
}

class _ImageSliderState extends State<ImageSlider> {
  int casoselIndex =0;
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    print("imageUrls === ${widget.imageUrls.length}");
    return Column(

      children: <Widget>[
        CarouselSlider(
          items: widget.imageUrls.map((imageUrl) {
            return  p.extension(imageUrl.image.toString()) != ".mp4"
                ? AppNetworkImage(src: imageUrl.image!, height: widget.height,)
                :SrcVideoPlayerWidget(videoPath: imageUrl.image!);
          }).toList(),
          options: CarouselOptions(
            enableInfiniteScroll: false,
            autoPlay: false,
            enlargeCenterPage: true,
            aspectRatio: 1,
            viewportFraction: 1,
            onPageChanged: (index, reason) {
              setState(() {
                casoselIndex=index;
              });

              print('index ===== $index' );
              print('index ===== $reason' );
              // TODO: Update the indicator based on the current page

            },
          ),
        ),

       //=================== dot ==============//
       widget.imageUrls.length == 1 ? Center(): Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: widget.imageUrls.map((url) {
            int index = widget.imageUrls.indexOf(url);
            print("index === ${index}");
            return Container(
              width: 8.0,
              height: 8.0,
              margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 2.0),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: index == casoselIndex
                    ? AppColors.mainColor : Colors.grey,
              ),
            );
          }).toList(),
        ),
      ],
    );
  }
}
