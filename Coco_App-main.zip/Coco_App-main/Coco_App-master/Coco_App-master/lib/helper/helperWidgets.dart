import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class HelperWidget{

  static void changeSystemUIColor(Color navigationBarColor, Color barColor){
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      systemNavigationBarColor: navigationBarColor,
      statusBarColor: barColor,
    ));
  }



  static InkWell buildSingleServiceList(
      {required String text,
        required Color color,
        required Color borderColor,
        required Color textColor,
        required VoidCallback onClick}) {
    return InkWell(
      onTap: onClick,
      child: Container(

        margin: EdgeInsets.only(right: 10),
        decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(7),
            border: Border.all(width: 1, color: borderColor)
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 7.0, horizontal: 12),
            child: Text(
              text,
              style: TextStyle(color: Colors.white,fontFamily: ' Poppins-Bold',fontSize: 11,fontWeight: FontWeight.bold),
            ),
          ),
        ),
      ),
    );
  }
}