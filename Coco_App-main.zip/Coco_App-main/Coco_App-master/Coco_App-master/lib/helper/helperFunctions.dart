import 'dart:convert';

import 'package:location/location.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HelperFunction{

  // //get let lng
  static Future<LocationData> locationData()async{
    return Location().getLocation();
  }


  static Future<String> getUserRole() async {
    SharedPreferences _pref = await SharedPreferences.getInstance();
    return _pref.getString("role") ?? "";
  }

  static Future<bool> saveUserName(String userName) async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    return pref.setString("userName", userName);
  }

  static Future<bool> saveUserProfilePic(String userProfilePic) async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    return pref.setString("userProfilePic", userProfilePic);
  }

  static Future<bool> saveUserID(String userID) async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    return pref.setString("userID", userID);
  }

  static Future<String?> getUserID() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    return pref.getString("userID");
  }

  static Future<String?> getUserName() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    return pref.getString("userName");
  }

  static Future<String?> getUserProfilePic() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    return pref.getString("userProfilePic");
  }

  static List<int> convertStringToListInt(String? str) {
    if (str == null || str.isEmpty || str == "null") {
      return [];
    } else{
      if (str.endsWith(',]"')) {
        str = str.replaceAll(' ', '');

        str = "${str.substring(0, str.length - 3)}]\"";

        String inputString = jsonDecode(str);
        // Remove square brackets from the string
        String cleanString = inputString.replaceAll(RegExp(r'[\[\]]'), '');

        // Split the string into a list of strings
        List<String> stringList = cleanString.split(',');

        // Convert each string element to an integer
        List<int> intList = stringList.map((String s) => int.parse(s)).toList();

        return intList;

      }

      str = str.substring(1, str.length - 1); // Remove the extra quotes
      return List<int>.from(jsonDecode(str));
    }
  }

  static List<String> convertStringToListString(String? str) {
    if (str == null || str.isEmpty || str == "null") {
      return [];
    } else {
      str = str.substring(1, str.length - 1); // Remove the extra quotes
      // Add double quotes around each string in the list
      str = str.split(',').map((s) => '"${s.trim()}"').join(',');
      // Add square brackets to make it a valid JSON array
      str = '[$str]';
      return List<String>.from(jsonDecode(str));
    }
  }

  static bool isTimeValid(String time) {
    var parts = time.split(':');
    if (parts.length != 2) return false;

    int hour = int.tryParse(parts[0]) ?? -1;
    int minute = int.tryParse(parts[1]) ?? -1;

    return hour >= 0 && hour < 24 && minute >= 0 && minute < 60;
  }

  static bool isOpeningBeforeClosing(String openingTime, String closingTime) {
    var openingParts = openingTime.split(':');
    var closingParts = closingTime.split(':');

    if (openingParts.length != 2 || closingParts.length != 2) return false;

    int openingHour = int.tryParse(openingParts[0]) ?? -1;
    int openingMinute = int.tryParse(openingParts[1]) ?? -1;
    int closingHour = int.tryParse(closingParts[0]) ?? -1;
    int closingMinute = int.tryParse(closingParts[1]) ?? -1;

    if (openingHour < 0 || openingHour >= 24 || openingMinute < 0 || openingMinute >= 60 ||
        closingHour < 0 || closingHour >= 24 || closingMinute < 0 || closingMinute >= 60) {
      return false;
    }

    var openingDateTime = DateTime(1970, 1, 1, openingHour, openingMinute);
    var closingDateTime = DateTime(1970, 1, 1, closingHour, closingMinute);

    return openingDateTime.isBefore(closingDateTime);
  }


  static String removeCountryCode(String countryCode, String phoneNumber) {
    if (phoneNumber.startsWith(countryCode)) {
      return phoneNumber.replaceFirst(countryCode, '');
    } else {
      return phoneNumber;
    }
  }

}