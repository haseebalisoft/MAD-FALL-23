import 'package:flutter/material.dart';

class AppJson{
  static List serviceForHome = [
    {
      "name" : "Aloïs",
      "left" : " 10",
      "collaboration" : "Collaboration",
      "profile" : "asset/image/avatar.png",
      "isCollaboration" : false,
      "category" : "Photographer",
    },
    {
      "name" : "Mathéo",
      "left" : " 50",
      "collaboration" : "Collaboration",

      "profile" : "asset/image/avatar.png",
      "isCollaboration" : false,
      "category" : "Photographer",

    },
    {
      "name" : "Raphaël",
      "left" : " 10",
      "collaboration" : "Collaboration",

      "profile" : "asset/image/avatar.png",
      "isCollaboration" : false,
      "category" : "Photographer",

    },
    {
      "name" : "Éliott",
      "left" : " 45",
      "collaboration" : "Collaboration",

      "profile" : "asset/image/avatar.png",
      "ratting" : "4.5",
      "category" : "Photographer",
    "isCollaboration" : true,
    },
    {
      "name" : "Lyam",
      "left" : " 50",
      "collaboration" : "Collaboration",

      "profile" : "asset/image/avatar.png",
      "ratting" : "4.3",
      "category" : "Vide Editor",
      "isCollaboration" : false,
    },
    {
      "name" : "Mylan",
      "left" : " 15",
      "collaboration" : "Collaboration",

      "profile" : "asset/image/avatar.png",
      "ratting" : "4.1",
      "category" : "Photographer",
      "isCollaboration" : true,
    },
    {
      "name" : "Gabriel",
      "left" : " 44",
      "collaboration" : "Collaboration",

      "profile" : "asset/image/avatar.png",
      "ratting" : "4.9",
      "category" : "Vide Editor",
      "isCollaboration" : false,
    },
  ];


  static List dayTimeList = [
    {
      "day" : "Monday",
      "open": [],
      "close" : false
    },
    {
      "day" : "Tuesday",
      "open": [],
      "close" : false
    },
    {
      "day" : "Wednesday",
      "open": [],
      "close" : false
    },
    {
      "day" : "Thursday",
      "open": [],
      "close" : false
    },
    {
      "day" : "Friday",
      "open": [],
      "close" : false
    },
    {
      "day" : "Saturday",
      "open": [],
      "close" : false
    },
    {
      "day" : "Sunday",
      "open": [],
      "close" : false
    },

  ];
}