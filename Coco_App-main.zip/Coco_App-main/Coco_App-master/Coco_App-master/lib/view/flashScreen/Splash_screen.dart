import 'dart:async';

import 'package:coco/appConst.dart';
import 'package:coco/controller/locationController.dart';
import 'package:coco/view/Client/bottomNagivation/buttom_nav.dart';
import 'package:coco/view/Client/createAccount/profile_info_1.dart';
import 'package:coco/view/Client/createAccount/profile_info_2.dart';
import 'package:coco/view/Client/createAccount/profile_info_3.dart';
import 'package:coco/view/freelancer/CreateAccount/freelancer_profile_info_3.dart';
import 'package:coco/view/freelancer/CreateAccount/freelaner_profile_info_2.dart';
import 'package:coco/view/freelancer/bottomNavigationBar/becameFreelanceBottomNavigation.dart';
import 'package:coco/view/freelancer/search/freelancerSearch.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:onboarding/onboarding.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

import '../../controller/authController.dart';
import '../../helper/helperFunctions.dart';
import '../../utility/appAssets.dart';
import '../auth/role_selector.dart';
import '../auth/sign_in.dart';
import '../freelancer/CreateAccount/freelancer_profile_info_1.dart';
import '../onboarding/onboarding.dart';

class Splash_screen extends StatefulWidget {
  const Splash_screen({super.key});

  @override
  State<Splash_screen> createState() => _Splash_screenState();
}

class _Splash_screenState extends State<Splash_screen> {
  late VideoPlayerController _controller;

  bool _visible = false;

  bool islogin = false;

  bool isLoading = false;
  var onboarding;
  var lat, lng;
  getCheckUserLogedin()async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    setState(() {
      onboarding = _pref.getString("onboarding");
    });
    var token = await AuthController.getLoginToken();

    var role = await AuthController.getRole();
    print("token $token");
    print("token $role");
    print("onboarding  $onboarding");
    if(onboarding != null && onboarding == "1"){
      if(token != "null"){
        var userInfo = await AuthController.getUserInfo();
        if(role != "null"){
          print("role is not null $role");
          if(userInfo.data?.role != null){
            //////////////// ---- if role ==  freelancer
            if (userInfo.data?.role == AppConst.FREELANCER_ROLE) {
              print("userinfo === ${userInfo.data?.userInfo}");
              if(userInfo.data?.userInfo != null){
                if (userInfo.data?.userInfo?.step1Complete == 0) {
                  Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                      builder: (context) =>
                          Freelancer_profile_info_1(userInfo: userInfo,)), (
                      route) => false);
                } else if (userInfo.data?.userInfo?.step2Complete == 0) {
                  Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                      builder: (context) => Freelancer_profile_info_2()), (
                      route) => false);
                } else if (userInfo.data?.userInfo?.step3Complete == 0) {
                  Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                      builder: (context) => Freelancer_profile_info_3()), (
                      route) => false);
                } else {
                  Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                      builder: (context) => FreelancerAppBottomNavigation()), (
                      route) => false);
                }
              }else{
                Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                    builder: (context) =>
                        Freelancer_profile_info_1(userInfo: userInfo,)), (
                    route) => false);
              }
            }

            //////////////// ---- if role ==  client
            if (userInfo.data?.role == AppConst.CLIENT_ROLE) {
              if(userInfo.data?.userInfo != null){
                if (userInfo.data?.userInfo?.step1Complete == 0) {
                  Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                      builder: (context) =>
                          CreateProfileStep1(userInfo: userInfo,)), (
                      route) => false);
                } else if (userInfo.data?.userInfo?.step2Complete == 0) {
                  Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                      builder: (context) => CreateProfileStep2()), (
                      route) => false);
                } else if (userInfo.data?.userInfo?.step3Complete == 0) {
                  Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                      builder: (context) => CreateProfileStep3()), (
                      route) => false);
                } else {
                  Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                      builder: (context) => ClientBottomNavigationBar()), (
                      route) => false);
                }
              }else{
                Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                    builder: (context) =>
                        CreateProfileStep1(userInfo: userInfo,)), (
                    route) => false);
              }

            }
          }else{
            Get.offAll(Role_selector());
          }
        }else{
          print("role is  null");
          Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context)=>Role_selector()), (route) => false);
        }
      }else{
        print("token is null");
        Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context)=>SignInPage()), (route) => false);
      }
    }else{
      Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context)=>OnBoarding()), (route) => false);
    }

  }

  //get current location
  bool isLocationLoading = false;



  getLocationLatLng() async {
    HelperFunction.locationData().then((value) {
      setState(() {
        lat = value.latitude;
        lng = value.longitude;
      });
      updateLatLng();
      print("print lat === $lat");
    });
  }


  @override
  void initState() {
    super.initState();
    getLocationLatLng();

    _controller = VideoPlayerController.asset(AssetUtils.splash_video);
    _controller.initialize().then((value){
      _controller.setLooping(false);
      Timer(Duration(microseconds:0),(){
            setState(() {
              _controller.play();
              _visible = true;
            });
      });
    });

    Future.delayed(Duration(seconds: 3),(){
      getCheckUserLogedin();
    });

  }

  updateLatLng()async{
    var res = await AuthController.updateLatLong(lat: lat, lng: lng);
    print("res.body == ${res.body}");
    print("res.body == ${res.statusCode}");
    if(res.statusCode == 200){
    }
  }


  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    if(_controller !=null){
      _controller.dispose();
    }
  }

  _getVideoBackground() {
    return AnimatedOpacity(
      opacity: _visible ? 1.0 : 0.0,
      duration: Duration(milliseconds: 1000),
      child: VideoPlayer(_controller),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:Stack(
        children: [
          SizedBox.expand(
            child: FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _controller.value.size?.width ?? 0,
                height: _controller.value.size?.height ?? 0,
                child:  _getVideoBackground(),
              ),
            ),
          )

        ],
      )
    );
  }
}
