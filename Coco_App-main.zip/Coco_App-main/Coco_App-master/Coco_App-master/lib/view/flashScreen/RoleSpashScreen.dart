import 'package:coco/appConst.dart';
import 'package:coco/controller/authController.dart';
import 'package:coco/utility/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import '../../utility/appAssets.dart';
import '../client/createAccount/profile_info_1.dart';
import '../freelancer/CreateAccount/freelancer_profile_info_1.dart';

class RoleSpashScreen extends StatefulWidget {
  final String role;
  const RoleSpashScreen({super.key, required this.role});

  @override
  State<RoleSpashScreen> createState() => _RoleSpashScreenState();
}

class _RoleSpashScreenState extends State<RoleSpashScreen> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Container(
      color: Colors.black,
      child: SafeArea(
        child: Scaffold(
          body: SingleChildScrollView(
            child: Container(
              height: size.height,
              width: size.width,
              child: Stack(
                children: [
                  Container(
                    color: Colors.black,
                    height: size.height,
                    width: size.width,
                  ),
                  Container(
                    height: size.height,
                    width: size.width,
                    child: Image.asset(
                      AssetUtils.role_select_img,
                      fit: BoxFit.cover,
                    ),
                  ),

                  Center(
                      child: Container(
                          child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20.0),
                        child: Text('Welcome to coco',textAlign:TextAlign.center,style: TextStyle(fontSize: 42,color: Colors.white,fontFamily: 'Poppins-Bold'),),
                      ),
                      SizedBox(height: 37,),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 38.0),
                        child: Text('Start by creating your profile so Freelancers can find you',textAlign:TextAlign.center,style: TextStyle(color: Colors.white,fontSize: 18,fontFamily: ' Poppins_SemiBold'),),
                      ),
                      SizedBox(height: 20,),
                      SvgPicture.asset(AssetUtils.welcome_image),
                      SizedBox(height: 45,),
                      Padding(
                        padding: const EdgeInsets.only(left: 30, right: 30, bottom: 20),
                        child: SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: AppColors.mainColor),
                                onPressed: () async{
                                  // Get.to(CreateProfileStep1());
                                  var userInfo = await AuthController.getUserInfo();
                                  if(widget.role == AppConst.FREELANCER_ROLE){
                                    Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context)=>Freelancer_profile_info_1(userInfo: userInfo,)), (route) => false);
                                  }
                                  if(widget.role == AppConst.CLIENT_ROLE){
                                   Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context)=> CreateProfileStep1(userInfo: userInfo)), (route) => false);
                                  }
                                },
                                child: Text(
                                  'Let\'s go',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ))),
                      ),
                    ],
                  )))
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}