
import 'dart:developer';

import 'package:coco/controller/authController.dart';
import 'package:coco/model/authModel/equpmentsListModel.dart';
import 'package:coco/view/freelancer/CreateAccount/freelancer_profile_info_1.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:keyboard_dismisser/keyboard_dismisser.dart';
import 'package:sizer/sizer.dart';

import '../../../model/authModel/serviceModle.dart';
import '../../../utility/appAssets.dart';
import '../../../utility/colors.dart';
import '../../../utility/registation_profile_header.dart';
import '../../../viewController/appLoading.dart';
import '../../../viewController/showAllert.dart';
import 'freelancer_profile_info_3.dart';

class Freelancer_profile_info_2 extends StatefulWidget {
  const Freelancer_profile_info_2({super.key});

  @override
  State<Freelancer_profile_info_2> createState() => _Freelancer_profile_info_2State();
}

class _Freelancer_profile_info_2State extends State<Freelancer_profile_info_2> {

  final List _skillList = [
    "Photography",
    "Video Editing",
    "Social Media Management",
    "Copywriter",
    "Community Manager"
  ];

  List<String> _selectedSkill = [];
  List<String> _selectEquipments = [];

  final extraEqupment = TextEditingController();
  final pricePerDay = TextEditingController();
  final website = TextEditingController();

  List _selectedSearchItems = []; //this is empty list.
  //we add items/value when someone tap on search items.

  final GlobalKey<FormState> ClientStep2 = GlobalKey<FormState>();
  TextEditingController price_pe_dayController = TextEditingController();


  var profileImage, name, step1Complete;
  Future<EqupmentsListModel>? getEqupmentsList;
  Future<ServiceModel>? getServiceModel;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getUserInfo();
    getEqupmentsList = AuthController.getEquipmentList();
    getServiceModel = AuthController.getServiceList();
    website.text = 'https://';
  }

  bool isUserDataIsGeting = false;
  var userInfo;
  var userInfoFuture;
  getUserInfo()async{
    setState(() =>isUserDataIsGeting = true);
     userInfoFuture =await AuthController.getUserInfo();
    setState(() {
      profileImage= userInfoFuture?.data?.profileImage;
      name= userInfoFuture?.data?.name;
      step1Complete = userInfoFuture?.data?.userInfo?.step1Complete;
      userInfo = userInfoFuture;
    });
    setState(() =>isUserDataIsGeting = false);

    return userInfoFuture;
  }

  var _selectedValue = "select option";

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return KeyboardDismisser(
      gestures: [GestureType.onTap, GestureType.onPanUpdateDownDirection],
      child: Container(
        color: Colors.black,
        child: SafeArea(
          child: Stack(
            children: [
              Scaffold(

                body: SingleChildScrollView(
                  child: Container(
                    color: Colors.black,
                    child: SingleChildScrollView(
                      child: Form(
                        key: ClientStep2,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            IconButton(
                              onPressed: () =>  Get.to(Freelancer_profile_info_1(userInfo: userInfoFuture)),
                              icon: Icon(
                                Icons.arrow_back,
                                color: AppColors.black,
                              ),
                            ),
                            registation_profile_header(name:'${name??"----"}',following:'0',follower:'0', image: profileImage,),
                            Padding(
                              padding: const EdgeInsets.all(28.0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Step 2 of 3',
                                          style: TextStyle(
                                            fontSize: 13,
                                            color: AppColors.white,
                                            fontFamily: 'Poppins_SemiBold',
                                          )
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 15,
                                  ),
                                  Text('Professional info',
                                      style: TextStyle(
                                          fontSize: 18,
                                          fontFamily: 'Poppins-Bold',
                                          color: Color(0xFF00CC83),
                                         ),),
                                  SizedBox(
                                    height: 25,
                                  ),
                                  Row(
                                    children: [
                                      Text(
                                        'Skills',
                                        style: TextStyle(
                                            fontSize: 12,
                                            color: AppColors.white,
                                            fontFamily: 'Poppins_SemiBold'
                                        ),
                                      ),
                                      SizedBox(
                                        width: 2,
                                      ),
                                      Padding(
                                        padding:
                                        const EdgeInsets.only(bottom: 8.0),
                                        child: CircleAvatar(
                                          radius: 2,
                                          backgroundColor: Color(0xFF00CC83),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Text(
                                    'Select one or multiple skills',
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontFamily: 'Poppins-Light',
                                      color: AppColors.textgrey,
                                    ),
                                  ),
                                  SizedBox(
                                    height: 18,
                                  ),

                                  FutureBuilder<ServiceModel>(
                                      future: getServiceModel,
                                      builder: (context, snapshot) {
                                        if(snapshot.connectionState == ConnectionState.waiting){
                                          return SizedBox(height: 10,);
                                        }else if(snapshot.hasData){
                                          return SizedBox(
                                            height: 100,
                                            child: GridView.builder(
                                              physics: NeverScrollableScrollPhysics(),
                                              shrinkWrap: true,
                                              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                                  crossAxisCount: 3,
                                                  crossAxisSpacing: 5.0,
                                                  mainAxisSpacing: 5.0,
                                                  childAspectRatio: (1 / .25)
                                                //controller: new ScrollController(keepScrollOffset: false),
                                              ),
                                              itemCount: snapshot.data?.data?.length,
                                              itemBuilder: (context, index) {
                                                return InkWell(
                                                  onTap: (){
                                                    setState(() {
                                                      if(_selectedSkill.contains(snapshot.data!.data![index]!.id.toString())){
                                                        _selectedSkill.remove(snapshot.data!.data![index]!.id.toString()!);
                                                      }else{
                                                        _selectedSkill.add(snapshot.data!.data![index]!.id.toString()!);
                                                      }
                                                    });
                                                  },
                                                  child: Container(
                                                    child: Padding(
                                                      padding: const EdgeInsets.symmetric(vertical: 2.0,horizontal:10),
                                                      child: Center(child: Text('${snapshot.data?.data?[index]?.name}',style: TextStyle(fontSize: 10,fontFamily: 'Poppins-Medium', color: _selectedSkill.contains(snapshot.data!.data![index]!.id.toString()!) ? AppColors.white : Colors.black,),)),
                                                    ),
                                                    decoration: BoxDecoration(
                                                        color: _selectedSkill.contains(snapshot.data!.data![index]!.id.toString()!) ? AppColors.mainColor : AppColors.white,
                                                        border: Border.all(
                                                            width: 2,
                                                            color:  _selectedSkill.contains(snapshot.data!.data![index]!.id.toString()!) ? AppColors.mainColor : Color(0xffE8E8E8)
                                                        ),
                                                        borderRadius: BorderRadius.circular(15)
                                                    ),
                                                  ),
                                                );
                                              },
                                            ),
                                          );
                                        }else{
                                          return Center(child: Text("Check your internet"),);
                                        }
                                      }
                                  ),
                                  // SizedBox(
                                  //   height: 18,
                                  // ),
                                  Row(
                                    children: [
                                      Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            children: [
                                              Text(
                                                'Equipments',
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    color: AppColors.white,
                                                    fontFamily: 'Poppins_SemiBold'
                                                ),
                                              ),
                                              SizedBox(
                                                width: 2,
                                              ),
                                              Padding(
                                                padding:
                                                const EdgeInsets.only(bottom: 8.0),
                                                child: CircleAvatar(
                                                  radius: 2,
                                                  backgroundColor: Color(0xFF00CC83),
                                                ),
                                              ),
                                            ],
                                          ),
                                          Text(
                                            'Select one or multiple equipments',
                                            style: TextStyle(
                                                fontSize: 12,
                                                fontFamily: 'Poppins-Light',
                                                color: AppColors.textgrey,),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 18,
                                  ),
                                  FutureBuilder<EqupmentsListModel>(
                                    future: getEqupmentsList,
                                    builder: (context, snapshot) {
                                      if(snapshot.connectionState == ConnectionState.waiting){
                                        return SizedBox(height: 100,);
                                      }else if(snapshot.hasData){
                                        return SizedBox(
                                          height: 100,
                                          child: GridView.builder(
                                            physics: NeverScrollableScrollPhysics(),
                                            shrinkWrap: true,
                                            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                                crossAxisCount: 3,
                                                crossAxisSpacing: 5.0,
                                                mainAxisSpacing: 5.0,
                                                childAspectRatio: (1 / .25)
                                              //controller: new ScrollController(keepScrollOffset: false),
                                            ),
                                            itemCount: snapshot.data?.data?.length,
                                            itemBuilder: (context, index) {
                                              return InkWell(
                                                onTap: (){
                                                  setState(() {
                                                    if(_selectEquipments.contains(snapshot.data!.data![index]!.id.toString()!)){
                                                      _selectEquipments.remove(snapshot.data!.data![index]!.id.toString()!);
                                                    }else{
                                                      _selectEquipments.add(snapshot.data!.data![index]!.id.toString()!);
                                                    }
                                                  });
                                                },
                                                child: Container(
                                                  child: Padding(
                                                    padding: const EdgeInsets.symmetric(vertical: 2.0,horizontal:10),
                                                    child: Center(child: Text('${snapshot.data?.data?[index]?.name}',style: TextStyle(fontSize: 10,fontFamily: 'Poppins-Medium',color: _selectEquipments.contains(snapshot.data!.data![index]!.id.toString()!) ? Colors.white : Colors.black),)),
                                                  ),
                                                  decoration: BoxDecoration(
                                                      color: _selectEquipments.contains(snapshot.data!.data![index]!.id.toString()!) ? AppColors.mainColor : Colors.white,
                                                      border: Border.all(
                                                          width: 2,
                                                          color:  _selectEquipments.contains(snapshot.data!.data![index]!.id.toString()!) ? AppColors.mainColor : Color(0xffE8E8E8)
                                                      ),
                                                      borderRadius: BorderRadius.circular(15)
                                                  ),
                                                ),
                                              );
                                            },
                                          ),
                                        );
                                      }else{
                                        return const Center(child: Text("Check internet connection"),);
                                      }
                                    }
                                  ),
                                  // SizedBox(
                                  //   height: 18,
                                  // ),
                                 SingleChildScrollView(
                                   child:  Row(
                                     children: [
                                       Column(
                                         mainAxisAlignment: MainAxisAlignment.start,
                                         crossAxisAlignment: CrossAxisAlignment.start,
                                         children: [
                                           // Row(
                                           //   children: [
                                           //     Text(
                                           //       'Website',
                                           //     ),
                                           //     SizedBox(
                                           //       width: 2,
                                           //     ),
                                           //   ],
                                           // ),
                                           // Text(
                                           //   'Freelancer will view your website',
                                           //   style: TextStyle(
                                           //       fontSize: 12,
                                           //       fontFamily: 'Poppins-Light',
                                           //       color: Color(0xFFA1A1A1)),
                                           // ),
                                         ],
                                       ),
                                     ],
                                   ),
                                 ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  TextFormField(
                                    style: TextStyle(
                                        fontSize: 14,
                                      color: AppColors.white,
                                    ),
                                    maxLines: 4,
                                    controller: extraEqupment,
                                    decoration: const InputDecoration(

                                        hintText: ('You can list the specific or technical information of your equipments'),
                                      ),
                                  ),
                                  SizedBox(
                                    height: 18,
                                  ),
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: const [
                                          Text(
                                            "Personal Website",
                                            style: TextStyle(
                                                fontSize: 12,
                                                color: AppColors.white,
                                                fontFamily: 'Poppins_SemiBold'
                                            ),
                                          ),
                                          SizedBox(
                                            width: 2,
                                          ),
                                          // Padding(
                                          //   padding:
                                          //   EdgeInsets.only(bottom: 8.0),
                                          //   child: CircleAvatar(
                                          //     radius: 2,
                                          //     backgroundColor: Color(0xFF00CC83),
                                          //   ),
                                          // ),
                                        ],
                                      ),
                                      SizedBox(height: 5,),
                                      const Text(
                                        'You can list the specific or technical information of your equipments',
                                        style: TextStyle(
                                            fontSize: 12,
                                            fontFamily: 'Poppins-Light',
                                            color: Color(0xFFA1A1A1)),
                                      ),
                                      SizedBox(height: 5,),

                                      TextFormField(
                                        style: TextStyle(
                                            fontSize: 14,
                                          color: AppColors.white,
                                        ),
                                        controller: website,
                                        keyboardType: TextInputType.url,

                                        decoration: const InputDecoration(

                                            hintText: ('https://'),
                                        )
                                      ),
                                    ],
                                  ),
                                    SizedBox(
                                    height: 18,
                                  ),



                                  ///TODO: Price and collaboration
                                  Row(
                                    children: const [
                                      Text(
                                        'Remuneration type',
                                        style: TextStyle(
                                            fontSize: 12,
                                            color: AppColors.white,
                                            fontFamily: 'Poppins_SemiBold'
                                        ),
                                      ),
                                      SizedBox(
                                        width: 2,
                                      ),
                                      Padding(
                                        padding:
                                        EdgeInsets.only(bottom: 8.0),
                                        child: CircleAvatar(
                                          radius: 2,
                                          backgroundColor: Color(0xFF00CC83),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Column(
                                    children: <Widget>[
                                      Row(
                                        children: <Widget>[
                                          Radio(
                                            value: 'price',
                                            fillColor: MaterialStateColor.resolveWith((states) => AppColors.white),

                                            activeColor: AppColors.mainColor,
                                            focusColor:AppColors.white,
                                            groupValue: _selectedValue,
                                            onChanged: (value) {
                                              setState(() {
                                                _selectedValue = value!;
                                                pricePerDay.clear();
                                              });
                                            },
                                          ),
                                          Text('Price per hour',style: TextStyle(color: AppColors.white),),
                                        ],
                                      ),
                                      Row(
                                        children: <Widget>[
                                          Radio(
                                            fillColor: MaterialStateColor.resolveWith((states) => AppColors.white),
                                            activeColor: AppColors.mainColor,
                                            focusColor:AppColors.white,
                                            value: 'collaborate',
                                            groupValue: _selectedValue,
                                            onChanged: (value) {
                                              setState(() {
                                                _selectedValue = value!;
                                                pricePerDay.text = _selectedValue;
                                              });
                                            },
                                          ),
                                          Text('Searching for collaboration',style: TextStyle(color: AppColors.white),),
                                        ],
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 18,
                                  ),
                                  _selectedValue == "price" ?  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: const [
                                          Text(
                                            'Price per hour',
                                            style: TextStyle(
                                                fontSize: 12,
                                                color: AppColors.white,
                                                fontFamily: 'Poppins_SemiBold'
                                            ),
                                          ),
                                          SizedBox(
                                            width: 2,
                                          ),
                                          Padding(
                                            padding:
                                            EdgeInsets.only(bottom: 8.0),
                                            child: CircleAvatar(
                                              radius: 2,
                                              backgroundColor: Color(0xFF00CC83),
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(height: 5,),
                                      const Text(
                                        'Set your daily or hourly price',
                                        style: TextStyle(
                                            fontSize: 12,
                                            fontFamily: 'Poppins-Light',

                                          color: AppColors.textgrey,)
                                      ),
                                      SizedBox(height: 5,),

                                      TextFormField(
                                        style: TextStyle(
                                          fontSize: 14,
                                          color: AppColors.white,
                                        ),
                                        controller: pricePerDay,
                                        keyboardType: TextInputType.number  ,
                                        validator: (String? value) {
                                          if (value?.isEmpty ?? true) {
                                            return 'Please Enter your day price';
                                          }
                                        },
                                        decoration: const InputDecoration(

                                            hintText: ('Your price per day/hour'),
                                           ),
                                      ),
                                    ],
                                  ) : Center(),
                                  _selectedValue == "collaborate" ?  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: const [
                                          Text(
                                            'Collaborate',
                                            style: TextStyle(
                                                fontSize: 12,
                                                color: AppColors.white,
                                                fontFamily: 'Poppins_SemiBold'
                                            ),
                                          ),
                                          SizedBox(
                                            width: 2,
                                          ),
                                          Padding(
                                            padding:
                                            EdgeInsets.only(bottom: 8.0),
                                            child: CircleAvatar(
                                              radius: 2,
                                              backgroundColor: Color(0xFF00CC83),
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(height: 5,),
                                      const Text(
                                        'I want to Collaborate',
                                        style: TextStyle(
                                            fontSize: 12,
                                            fontFamily: 'Poppins-Light',
                                            color: Color(0xFFA1A1A1)),
                                      ),
                                      SizedBox(height: 5,),
                                    ],
                                  ) : Center(),
                                  SizedBox(
                                    height: 10.h,
                                  ),

                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                bottomNavigationBar:    Container(
                  color: Colors.black,
                  padding: EdgeInsets.all(20),
                  width: double.infinity,
                  child: ElevatedButton(
                      style: OutlinedButton.styleFrom(
                        backgroundColor: Color(0xFF00CC83),
                      ),
                      onPressed: () {
                        _createFreelancerProfileCreateStepTow();
                        // Get.to(() => Freelancer_profile_info_3());
                      },
                      child: isLoading ? const CircularProgressIndicator(strokeWidth: 1, color: Colors.white,) : Text(
                        'Continue',
                        style: TextStyle(color: Colors.white),
                      )),
                ),
              ),
              isUserDataIsGeting ? LoadingOverlay():Center()
            ],
          ),
        ),
      ),
    );
  }

  ///TODO: need to work here , api change need
  bool isLoading = false;
  void _createFreelancerProfileCreateStepTow() async{
    print("dafadsf");
    List<String> extraEquipments = extraEqupment.text.split(",");
    print("extraEquipments === ${extraEquipments}");
    print("extraEquipments === ${pricePerDay.text}");
    setState(() =>isLoading = true);
    if(ClientStep2.currentState!.validate()){
      var res = await AuthController.freelacnerProfileStepTwo(
        serviceList: _selectedSkill.toString(),
        equipmentsList: _selectEquipments.toString(),
        extraEquipments: extraEquipments.toString(), ///TODO: need to work here , api change need
        pricePerDay: pricePerDay.text,
          website: website.text
      );
      if(res.statusCode == 200){
        var userInfo = AuthController.getUserInfo();
        AlertController.snackbar(context: context, text: "Step 2 is done.", bg: Colors.green);
        Get.to(Freelancer_profile_info_3());
      }else{
        AlertController.snackbar(context: context, text: "Something went wrong", bg: Colors.red);
      }
    }

    setState(() =>isLoading = false);
  }
}
