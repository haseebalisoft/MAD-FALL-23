import 'package:coco/utility/colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class FreelancerAddSocialMediaLink extends StatefulWidget {
  final String listType;
  const FreelancerAddSocialMediaLink({Key? key, required this.listType}) : super(key: key);

  @override
  State<FreelancerAddSocialMediaLink> createState() => _FreelancerAddSocialMediaLinkState();
}

class _FreelancerAddSocialMediaLinkState extends State<FreelancerAddSocialMediaLink> {
  final GlobalKey<FormState> _Social = GlobalKey<FormState>();


  TextEditingController _socialController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    _socialController.text = 'https://';
    return Container(
      color: AppColors.black,
      child: SafeArea(
        child: Scaffold(
          backgroundColor: AppColors.black,
          appBar: AppBar(
            leading: IconButton(
              onPressed: ()=>Get.back(),
              icon: Icon(Icons.arrow_back, color: AppColors.white,),
            ),
            title: Text("${widget.listType}",
              style: TextStyle(
                  color: AppColors.mainColor,
                  fontSize: 15,
                  fontFamily: 'Poppins-Bold'
              ),
            ),
            backgroundColor: AppColors.black,
            elevation: 0,
          ),
          body: SingleChildScrollView(
            padding: EdgeInsets.all(20),
            child: Form(
              key: _Social,
              child: Column(
                children: [
                  TextFormField(
                    style: TextStyle(
                      color: AppColors.white
                    ),
                    controller: _socialController,
                    validator: (String? value) {
                      if (value?.isEmpty ?? true) {
                        return 'Please Enter your ${widget.listType} link';
                      }
                    },
                    decoration: InputDecoration(

                        hintText: "https://${widget.listType}.com"
                    ),
                  ),


                ],
              ),
            ),
          ),
          bottomNavigationBar:  InkWell(
            onTap: (){
              if (!_Social.currentState!.validate()) {
                return;
              }
              Navigator.pop(context, {
                "key": "${widget.listType}",
                "value":_socialController.text,
              });
            },
            child: Container(
              margin: EdgeInsets.only(left: 30,right: 30,bottom: 20),
              width: double.infinity,
              height: 46,
              decoration: BoxDecoration(
                color: AppColors.mainColor,
                borderRadius: BorderRadius.circular(5),

              ),
              child: Center(child: Text('save',style: TextStyle(color: AppColors.white),),),
            ),
          ),

        ),
      ),
    );
  }
}
