import 'package:coco/controller/authController.dart';
import 'package:coco/model/authModel/userInfoModel.dart';
import 'package:coco/view/auth/role_selector.dart';
import 'package:coco/view/profile/widget/uploadCoverImage.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:coco/viewController/showAllert.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:intl_phone_number_input/intl_phone_number_input.dart';
import 'package:keyboard_dismisser/keyboard_dismisser.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';

import '../../../model/authModel/equpmentsListModel.dart';
import '../../../utility/appAssets.dart';
import '../../../utility/colors.dart';
import '../../../utility/registation_profile_header.dart';
import 'freelaner_profile_info_2.dart';

class Freelancer_profile_info_1 extends StatefulWidget {
  final UserInformation userInfo;
  const Freelancer_profile_info_1({super.key, required this.userInfo});

  @override
  State<Freelancer_profile_info_1> createState() => _Freelancer_profile_info_1State();
}

class _Freelancer_profile_info_1State extends State<Freelancer_profile_info_1> {
  final GlobalKey<FormState> _freelancerStep1 = GlobalKey<FormState>();
  final name = TextEditingController();
  final description = TextEditingController();
  final phone = TextEditingController();
  final email = TextEditingController();
  String nameText = "";

  String phone_country_code = "";
  String phone_number = "";
  String phone_iso = "";

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    storeExistingData();
    getPhn();
  }
  

  storeExistingData()async{
    setState(() {
      phone.text = widget.userInfo.data!.phone!;
      email.text = widget.userInfo.data!.email!;
      widget.userInfo.data!.name!.isNotEmpty ? name.text =  widget.userInfo.data!.name! : null;
      widget.userInfo.data!.userInfo!.description!.isNotEmpty ? description.text =  widget.userInfo.data!.userInfo!.description! : null;
    });
  }

  getPhn() async{
    SharedPreferences pref =await SharedPreferences.getInstance();
    setState(() {
      phone_country_code = pref.getString("signUpPhnNumCountryCode").toString();
      phone_number = pref.getString("signUpPhnNum").toString();
      phone_iso = pref.getString("signUpPhnNumISO").toString();
    });
  }

  @override
  Widget build(BuildContext context) {
    return KeyboardDismisser(
      gestures: [GestureType.onTap, GestureType.onPanUpdateDownDirection],
      child: Container(
        color: Colors.black,
        child: SafeArea(
          child: Scaffold(

            body: Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
              color: Colors.black,
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    SizedBox(
                      height: 5.h,
                    ),
                    registation_profile_header(name:'${widget.userInfo.data!.name != null ? widget.userInfo.data!.name! : nameText.isNotEmpty? nameText : "Full Name"}',following:'0',follower:'0'),
                    Padding(
                      padding: const EdgeInsets.all(28.0),
                      child: Form(
                        key: _freelancerStep1,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Text(
                                  'Step 1 of 3',
                                  style: TextStyle(
                                      fontSize: 13,
                                      color: AppColors.white,
                                      fontFamily: 'Poppins_SemiBold'
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 12,
                            ),
                            Text('Personal info',
                                style: TextStyle(
                                    fontSize: 18,
                                    color: Color(0xFF00CC83),
                                    fontFamily: 'Poppins-Bold'
                                )),
                            SizedBox(
                              height: 22,
                            ),
                            Row(
                              children: [
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          'Display name',
                                          style: TextStyle(
                                            color: AppColors.white,
                                            fontSize: 12,
                                              fontFamily: 'Poppins_SemiBold'
                                          ),
                                        ),
                                        SizedBox(
                                          width: 2,
                                        ),
                                        Padding(
                                          padding:
                                          const EdgeInsets.only(bottom: 8.0),
                                          child: CircleAvatar(
                                            radius: 2,
                                            backgroundColor: Color(0xFF00CC83),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Text(
                                      'Name customers will see on your profile',
                                      style: TextStyle(
                                          fontSize: 10,
                                          fontFamily: 'Poppins-Light',
                                          color: Color(0xFFA1A1A1)),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 18,
                            ),
                            TextFormField(

                              style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.white
                              ),
                              controller: name,
                              onChanged: (v){
                                setState(() {
                                  nameText = v;
                                });
                              },
                              validator: (String? value) {
                                if (value?.isEmpty ?? true) {
                                  return 'Please Enter your Display name';
                                }
                              },

                              decoration: InputDecoration(

                                  hintText: ('Type your display name'),

                              ),
                            ),
                            SizedBox(
                              height: 18,
                            ),
                            Row(
                              children: [
                                Text(
                                  'Description',
                                  style: TextStyle(
                                      fontSize: 12,
                                      color: AppColors.white,
                                      fontFamily: 'Poppins_SemiBold'
                                  ),
                                ),
                                SizedBox(
                                  width: 3,
                                ),
                                // Row(
                                //   children: [
                                //     Padding(
                                //       padding: const EdgeInsets.only(bottom: 8.0),
                                //       child: CircleAvatar(
                                //         radius: 2,
                                //         backgroundColor: Color(0xFF00CC83),
                                //       ),
                                //     ),
                                //   ],
                                // )
                              ],
                            ),
                            SizedBox(
                              height: 7,
                            ),
                            Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                TextFormField(
                                  style: TextStyle(
                                      fontSize: 14,
                                      color: Colors.white
                                  ),
                                  controller: description,
                                  textInputAction: TextInputAction.done,
                                  maxLines: 4,
                                  decoration: InputDecoration(

                                      hintText: 'Share a bit about your work experience, your projects...',

                                     ),
                                ),
                                Text(
                                  'min:150',
                                  style: TextStyle(color: AppColors.textgrey,
                                        fontSize: 10,
                                        fontFamily: 'Poppins_Light'
                                    ),
                                  ),

                              ],
                            ),
                            SizedBox(
                              height: 15,
                            ),
                            SizedBox(
                              height: 7,
                            ),
                             Row(
                              children: [
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          'Phone number',
                                          style: TextStyle(
                                              fontSize: 12,
                                              fontFamily: 'Poppins_SemiBold',
                                            color: AppColors.white
                                          ),
                                        ),
                                        SizedBox(
                                          width: 2,
                                        ),
                                        Padding(
                                          padding:
                                          EdgeInsets.only(bottom: 8.0),
                                          child: CircleAvatar(
                                            radius: 2,
                                            backgroundColor: Color(0xFF00CC83),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Text(
                                      'Customers will call you on this number',
                                      style: TextStyle(
                                          fontSize: 10,
                                          fontFamily: 'Poppins-Light',
                                          color: Color(0xFFA1A1A1)),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 18,
                            ),


                            InternationalPhoneNumberInput(
                              selectorTextStyle: TextStyle(
                                color: Colors.white,
                              ),
                              initialValue: PhoneNumber(
                                  dialCode: phone_country_code,
                                  phoneNumber: phone_number,
                                  isoCode: phone_iso

                              ),

                              onInputChanged: (PhoneNumber number) {
                                print(number.phoneNumber);
                              },
                              autoValidateMode: AutovalidateMode.onUserInteraction, // Changed to validate on user interaction
                              searchBoxDecoration: InputDecoration(
                                  fillColor: Colors.grey.shade400,
                                  filled: true,
                                  hintText: "Search",
                                  helperStyle: TextStyle(color: Colors.black, fontWeight: FontWeight.normal)
                              ),
                              hintText:'Phone Number',
                              locale:'US',
                              textStyle: TextStyle(
                                  fontSize: 14,
                                  color: AppColors.white
                              ),
                              inputDecoration : InputDecoration(
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide.none
                                ),
                                fillColor: AppColors.formColorUp,
                                hintText: 'Phone Number',
                                hintStyle: const TextStyle(
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12,
                                    color: AppColors.textgrey),
                              ),
                              selectorConfig: const SelectorConfig(
                                selectorType: PhoneInputSelectorType.BOTTOM_SHEET,
                                setSelectorButtonAsPrefixIcon: true,
                                leadingPadding: 10,
                                showFlags: true,
                                useEmoji: true,
                              ),
                              ignoreBlank: true,
                              countrySelectorScrollControlled:true,
                              textFieldController: phone, // Make sure 'phone' has a valid initial value
                              formatInput: true,
                              keyboardType:
                              TextInputType.numberWithOptions(signed: true, decimal: true),
                              onSaved: (PhoneNumber number) {
                                print('On Saved: $number');
                              },
                            ),

                            SizedBox(
                              height: 10,
                            ),


                            Row(
                              children: [
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          'Email',
                                          style: TextStyle(
                                              fontSize: 12,
                                              color: AppColors.white,
                                              fontFamily: 'Poppins_SemiBold'
                                          ),
                                        ),
                                        SizedBox(
                                          width: 2,
                                        ),
                                        Padding(
                                          padding:
                                          const EdgeInsets.only(bottom: 8.0),
                                          child: CircleAvatar(
                                            radius: 2,
                                            backgroundColor: Color(0xFF00CC83),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Text(
                                      'Customers will contact you on this mail',
                                      style: TextStyle(
                                          fontSize: 10,
                                          fontFamily: 'Poppins-Light',
                                          color: AppColors.textgrey),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 18,
                            ),
                            TextFormField(
                              style: TextStyle(
                                  fontSize: 14,
                                color: Colors.white
                              ),
                              controller: email,
                              readOnly: true,
                              enabled: false,
                              validator: (String? value) {
                                if (value?.isEmpty ?? true) {
                                  return 'Please Enter your email';
                                }
                              },
                              decoration: InputDecoration(


                                  hintText: ('Enter email address'),
                              ),
                            ),

                            SizedBox(
                              height: 20,
                            ),
                            ///////Method////
                            UploadCoverImage(
                              isEdit:  false,
                              placeholder: "https://i0.wp.com/thinkfirstcommunication.com/wp-content/uploads/2022/05/placeholder-1-1.png?fit=1200%2C800&ssl=1",
                            ),

                            SizedBox(
                              height: 20.h,
                            ),

                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            bottomNavigationBar:  Container(
              decoration: BoxDecoration(
                color: Colors.black
              ),
              padding: EdgeInsets.all(20),
              width: double.infinity,
              child: ElevatedButton(
                  style: OutlinedButton.styleFrom(
                    backgroundColor: Color(0xFF00CC83),
                  ),
                 // onPressed: ()=>print("click"),
                  onPressed: (){
                    _freelancerProfileCreatStoepOne();
                    print("ok");
                  },
                  child: isLoading?CircularProgressIndicator(strokeWidth: 1, color: Colors.white,) : Text(
                    'Continue',
                    style: TextStyle(color: Colors.white,fontSize: 13),
                  )),
            ),
          ),
        ),
      ),
    );
  }

  bool isLoading = false;
  void _freelancerProfileCreatStoepOne() async{
    print("click me");
    setState(() =>isLoading=true);
    if (_freelancerStep1.currentState!.validate()) {
        var res = await AuthController.freelacnerProfileStepOne(
          name: name.text,
          phone: phone.text,
          email: email.text,
          description: description.text
        );
        print("response ==== ${res.body}");
        print("response ==== ${res.statusCode}");
        if(res.statusCode == 200){
          /////////// get user information again
          var userInfo = await AuthController.getUserInfo();
          print("user info ==== ${userInfo.data!.userInfo!.step1Complete}");
          AlertController.snackbar(context: context, text: "First step complete.", bg: Colors.green);
          Get.to(Freelancer_profile_info_2());
        }else{
          print("error");
        }
    }
    setState(() =>isLoading=false);

  }
}
