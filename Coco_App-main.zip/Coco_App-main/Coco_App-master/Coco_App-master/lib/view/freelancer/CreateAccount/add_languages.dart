import 'package:coco/controller/authController.dart';
import 'package:coco/model/authModel/languesModel.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/view/freelancer/profile/UserEditProfile.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:keyboard_dismisser/keyboard_dismisser.dart';

import '../bottomNavigationBar/becameFreelanceBottomNavigation.dart';

class AddLanguage extends StatefulWidget {
  final bool ? isupdate;
  const AddLanguage({Key? key, this.isupdate}) : super(key: key);

  @override
  State<AddLanguage> createState() => _AddLanguageState();
}

class _AddLanguageState extends State<AddLanguage> {
  final GlobalKey<FormState> _Social = GlobalKey<FormState>();

  Future<LanguesModel>? languages;


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    languages = AuthController.getLanguages();
  }

  List<bool> checkedStates = [];
   List<String> selectedLanguages = [];

  @override
  Widget build(BuildContext context) {
    return KeyboardDismisser(
      gestures: [GestureType.onTap, GestureType.onPanUpdateDownDirection],
      child: Container(
        color: AppColors.black,
        child: SafeArea(
          child: Scaffold(
            backgroundColor: AppColors.black,
            appBar: AppBar(
              leading: IconButton(
                onPressed: ()=>Get.back(),
                icon: Icon(Icons.arrow_back, color: AppColors.white,),
              ),
              title: Text(
                "language",
                style: TextStyle(
                    color: AppColors.mainColor,
                    fontSize: 15,
                    fontFamily: 'Poppins-Bold'
                ),
              ),
              backgroundColor: AppColors.black,
              elevation: 0,
            ),
            body: Padding(
              padding: EdgeInsets.all(20),
              child: FutureBuilder<LanguesModel>(
                future: languages,
                builder: (_, snapshot){
                  if(snapshot.connectionState == ConnectionState.waiting){
                    return Center(child: CircularProgressIndicator(color: AppColors.mainColor,),);
                  } else if(snapshot.hasData){
                    return snapshot.data!.data!.length == 0
                        ? Center(child: Text("No language added.",style: TextStyle(color: AppColors.white),),)
                        : ListView.builder(
                        itemCount: snapshot.data!.data!.length,
                        itemBuilder: (_, index){
                          return CheckboxListTile(
                            checkColor:AppColors.white,
                            activeColor:AppColors.mainColor,
                            shape: const CircleBorder(),
                            checkboxShape:RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(15)
                            ),
                            title: Text("${snapshot.data!.data![index]!.name}",style: TextStyle(color: AppColors.white),),
                            value: checkedStates[index],
                            onChanged: (value) {
                              setState(() {
                                checkedStates[index]=value!;
                                if(selectedLanguages.contains("${snapshot.data!.data![index]!.id.toString()}")){
                                  selectedLanguages.remove("${snapshot.data!.data![index]!.id.toString()}");
                                } else {
                                  selectedLanguages.add("${snapshot.data!.data![index]!.id.toString()}");
                                }
                              });
                              print("checkedStates == ${checkedStates[index]}");
                              print("value == $value");
                            },
                          );
                        }
                    );
                  } else {
                    return Center(child: Text("Please check your internet connection.",style: TextStyle(color: AppColors.white),),);
                  }
                },
              ),
            ),
            bottomNavigationBar: InkWell(
              onTap: (){
                addLanguages();
              },
              child: Container(
                margin: EdgeInsets.only(left: 30,right: 30,bottom: 20),
                width: double.infinity,
                height: 46,
                decoration: BoxDecoration(
                  color: AppColors.mainColor,
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Center( child: isLoading? CircularProgressIndicator(color: Colors.white,) :  Text('Save & Continue',style: TextStyle(color: AppColors.white),),),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // Widget build(BuildContext context) {
  //   return KeyboardDismisser(
  //     gestures: [GestureType.onTap, GestureType.onPanUpdateDownDirection],
  //     child: Container(
  //       color: AppColors.black,
  //       child: SafeArea(
  //         child: Scaffold(
  //           backgroundColor: AppColors.black,
  //           appBar: AppBar(
  //             leading: IconButton(
  //               onPressed: ()=>Get.back(),
  //               icon: Icon(Icons.arrow_back, color: AppColors.white,),
  //             ),
  //             title: Text("language",
  //               style: TextStyle(
  //                   color: AppColors.mainColor,
  //                   fontSize: 15,
  //                   fontFamily: 'Poppins-Bold'
  //               ),
  //             ),
  //             backgroundColor: AppColors.black,
  //             elevation: 0,
  //           ),
  //           body: Padding(
  //             padding: EdgeInsets.all(20),
  //             child: FutureBuilder<LanguesModel>(
  //               future: languages,
  //               builder: (_, snapshot){
  //                 if(snapshot.connectionState == ConnectionState.waiting){
  //                   return Center(child: CircularProgressIndicator(color: AppColors.mainColor,),);
  //                 }else if(snapshot.hasData){
  //                   return snapshot.data!.data!.length == 0
  //                       ?Center(child: Text("No language added.",style: TextStyle(color: AppColors.white),),)
  //                       : Column(
  //                     children: [
  //                   ListView.builder(
  //                   itemCount: snapshot.data!.data!.length,
  //                       itemBuilder: (_, index){
  //                         // checkedStates.clear();
  //                         for(var i=0;i<snapshot.data!.data!.length; i++){
  //                           checkedStates.add(false);
  //                         }
  //                         return CheckboxListTile(
  //                           checkColor:AppColors.white,
  //
  //                           activeColor:AppColors.mainColor,
  //                           shape: const CircleBorder(),
  //                           checkboxShape:RoundedRectangleBorder(
  //                               borderRadius: BorderRadius.circular(15)),
  //                           title: Text("${snapshot.data!.data![index]!.name}",style: TextStyle(color: AppColors.white),),
  //                           value: checkedStates[index],
  //                           onChanged: (value) {
  //                             setState(() {
  //                               checkedStates[index]=value!;
  //                               if(selectedLanguages.contains("${snapshot.data!.data![index]!.id.toString()}")){
  //                                 selectedLanguages.remove("${snapshot.data!.data![index]!.id.toString()}");
  //                               }else{
  //                                 selectedLanguages.add("${snapshot.data!.data![index]!.id.toString()}");
  //                               }
  //                             });
  //                             print("checkedStates == ${checkedStates[index]}");
  //                             print("value == $value");
  //                           },
  //                         );
  //                       }
  //                   )
  //                     ]
  //                   );
  //
  //
  //
  //                 }else{
  //                   return Center(child: Text("Please check your internet connection.",style: TextStyle(color: AppColors.white),),);
  //                 }
  //               },
  //             ),
  //           ),
  //           bottomNavigationBar:  InkWell(
  //             onTap: (){
  //               addLanguages();
  //             },
  //             child: Container(
  //               margin: EdgeInsets.only(left: 30,right: 30,bottom: 20),
  //               width: double.infinity,
  //               height: 46,
  //               decoration: BoxDecoration(
  //                 color: AppColors.mainColor,
  //                 borderRadius: BorderRadius.circular(5),
  //               ),
  //               child: Center( child: isLoading? CircularProgressIndicator(color: Colors.white,) :  Text('Save & Continue',style: TextStyle(color: AppColors.white),),),
  //             ),
  //           ),
  //
  //         ),
  //       ),
  //     ),
  //   );
  // }

  bool isLoading = false;
  void addLanguages() async{

    print('selected language============== ${selectedLanguages.runtimeType}');


      // if(selectedLanguages.length > 0){
        setState(() =>isLoading = true);
        var res = await AuthController.addLanguages(language_id: selectedLanguages.toString());
        if(res.status == true){
          if(widget.isupdate==true){
            Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context)=>UserEditProfile()), (route) => false);
          }else{
            Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context)=>FreelancerAppBottomNavigation()), (route) => false);
          }

        }else{
          AlertController.snackbar(context: context, text: "Something went wrong", bg: Colors.red);
        }
      // }else{
      //   AlertController.snackbar(context: context, text: "Please selected your languages.", bg: Colors.red);
      // }
  }
}
