import 'package:flutter/material.dart';

class Freelancer_profile_info extends StatefulWidget {
  const Freelancer_profile_info({super.key});

  @override
  State<Freelancer_profile_info> createState() =>
      _Freelancer_profile_infoState();
}

class _Freelancer_profile_infoState extends State<Freelancer_profile_info> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
