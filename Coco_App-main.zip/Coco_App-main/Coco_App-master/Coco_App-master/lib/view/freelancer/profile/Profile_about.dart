import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AboutMeSection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    // Replace this with your About Me content
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Services',
            style: TextStyle(color: Color(0xff00CC83), fontSize: 15,
            fontFamily: 'SourceSansPro-Semibold'
            ),
          ),
          Container(
            height: 35,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: 10,
              itemBuilder: (_, index){
                return Container(
                  margin: EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(50),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.2),
                        spreadRadius: 1,
                        blurRadius: 2,
                        offset: Offset(1, 1), // changes position of shadow
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20.0, vertical: 5),
                    child: Text('photography',style: TextStyle(
                        fontFamily: 'Poppins-Medium',
                        fontSize: 11
                    ),),
                  ),
                );
              },
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Text(
            'Equipment',
            style: TextStyle(color: Color(0xff00CC83), fontSize: 15,
                fontFamily: 'SourceSansPro-Semibold'
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 18.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  decoration: BoxDecoration(
                    color: Color(0xff4AC07C),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  height: 85,
                  width: size.width*.27,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20.0, vertical: 5),
                    child: Padding(
                      padding: const EdgeInsets.only(top: 6, bottom: 6),
                      child: Column(
                        children: [
                          Image.asset(
                            'asset/image/video_cam.png',
                            height: 43,
                            width: 60,
                            fit: BoxFit.contain,
                          ),
                          SizedBox(height: 2,),
                          Text("Video Cam",
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                              color: Colors.white,
                              fontSize: 12
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),

                Container(
                  decoration: BoxDecoration(
                    color: Color(0xff4AC07C),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  height: 85,
                  width: size.width*.27,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20.0, vertical: 5),
                    child: Padding(
                      padding: const EdgeInsets.only(top: 6, bottom: 6),
                      child: Column(
                        children: [
                          Image.asset(
                            'asset/image/dslr.png',
                            height: 43,
                            width: 68,
                            fit: BoxFit.cover,
                          ),
                          SizedBox(height: 2,),
                          Text("DSLR",
                            style: TextStyle(
                                fontWeight: FontWeight.w600,
                                color: Colors.white,
                                fontSize: 12
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),

                Container(
                  decoration: BoxDecoration(
                    color: Color(0xff4AC07C),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  height: 85,
                  width: size.width*.27,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20.0, vertical: 5),
                    child: Padding(
                      padding: const EdgeInsets.only(top: 6, bottom: 6),

                      child: Column(
                        children: [
                          Image.asset(
                            'asset/image/drone.png',
                            height: 38,
                            width: 105,
                            fit: BoxFit.contain,
                          ),
                          SizedBox(height: 4,),
                          Text("Drone",
                            style: TextStyle(
                                fontWeight: FontWeight.w600,
                                color: Colors.white,
                                fontSize: 12
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              style: OutlinedButton.styleFrom(
                side: BorderSide(width: 1.5, color: Color(0xff4AC07C)),
              ),
              onPressed: () {
               // Get.to(Equipments());
              },
              child: Text(
                '+View full equipment list here',
                style: TextStyle(
                  color: Color(0xff4AC07C),
                ),
              ),
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Text(
            'Location',
            style: TextStyle(color: Color(0xff00CC83), fontSize: 15,
                fontFamily: 'SourceSansPro-Semibold'
            ),
          ),
          SizedBox(
            height: 2,
          ),
          Text(
            'Bali, indonesia',
            style: TextStyle(fontSize: 16,
            fontFamily: 'source-sans-pro-regular'
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Text(
            'Spoken languages',
            style: TextStyle(color: Color(0xff00CC83), fontSize: 15,
                fontFamily: 'SourceSansPro-Semibold'
            ),
          ),
          SizedBox(
            height: 2,
          ),
          Text(
            'English, French, German',
            style: TextStyle(fontSize: 16,
                fontFamily: 'source-sans-pro-regular'
            ),
          ),
          SizedBox(
            height: 30,
          ),
          Text(
            'Social media',
            style: TextStyle(color: Color(0xff00CC83), fontSize: 15,
                fontFamily: 'SourceSansPro-Semibold'
            ),
          ),
          SizedBox(
            height: 5,
          ),
          Row(
            children: [
              Image.asset(
                'asset/image/insta.png',
                width: 45,
                height: 45,
              ),
              SizedBox(
                width: 20,
              ),
              Image.asset(
                'asset/image/youtube.png',
                width: 45,
                height: 45,
              ),
              SizedBox(
                width: 20,
              ),
              Image.asset(
                'asset/image/bain.png',
                width: 45,
                height: 45,
              ),
              SizedBox(
                width: 20,
              ),
              Image.asset(
                'asset/image/linkdin.png',
                width: 45,
                height: 45,
              ),
            ],
          ),
          SizedBox(height: 20,)
        ],
      ),
    );
  }
}

