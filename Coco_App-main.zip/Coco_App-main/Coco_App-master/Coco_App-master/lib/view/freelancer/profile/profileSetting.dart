import 'package:coco/utility/appAssets.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/view/profile/account.dart';
import 'package:coco/view/profile/pushNotification.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ClientProfileSetting extends StatefulWidget {
  const ClientProfileSetting({Key? key}) : super(key: key);

  @override
  State<ClientProfileSetting> createState() => _ClientProfileSettingState();
}

class _ClientProfileSettingState extends State<ClientProfileSetting> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Container(
      color: AppColors.mainColor,
      child: SafeArea(
        child: Scaffold(
          backgroundColor: Color(0xfff7f7f7),
          body: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(

                  width: size.width,
                  padding: EdgeInsets.only(top: 30, left: 20, bottom: 30, right: 20),
                  decoration: BoxDecoration(
                    color: AppColors.mainColor,
                  ),
                  child: Row(
                    children: [
                      SizedBox(
                        height: 60,
                        width: 60,
                        child: Container(
                          decoration: BoxDecoration(
                              border: Border.all(width: 1, color: Colors.cyanAccent),
                              borderRadius: BorderRadius.circular(100)
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(100),
                            child: Image.asset(AssetUtils.nav_avatar, fit: BoxFit.cover,),
                          ),
                        ),
                      ),
                      SizedBox(width: 10,),
                      Text("User Name",
                        style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: AppColors.white,
                            fontSize: 18
                        ),
                      )
                    ],
                  ),

                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(20),
                      child: Text("Setting",
                        style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: Colors.black
                        ),
                      ),
                    ),
                    buildSingleMenu(
                        text: "Push Notification",
                        onClick: ()=>Get.to(PushNotificationSetting(), transition: Transition.rightToLeft)
                    ),
                    buildSingleMenu(
                        text: "Account",
                        onClick: ()=>Get.to(AccountSetting(name: '', email: '',),  transition: Transition.rightToLeft)
                    ),
                    buildSingleMenu(
                        text: "Publish Alert",
                        onClick: (){}
                    ),
                    Padding(
                      padding: const EdgeInsets.all(20),
                      child: Text("Logic",
                        style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: Colors.black
                        ),
                      ),
                    ),
                    buildSingleMenu(
                        text: "Teams & Conditions",
                        onClick: (){}
                    ),
                    buildSingleMenu(
                        text: "Privacy Policy",
                        onClick: (){}
                    ),
                  ],
                ),
              ],
            ),
          ),
          bottomNavigationBar: Container(
            margin: EdgeInsets.only(left: 40, bottom: 30, right: 40),
            height: 40,
            decoration: BoxDecoration(
              color: AppColors.mainColor,
              borderRadius: BorderRadius.circular(100),
            ),
            child: Center(
              child: Text("Invite Friend",
                style: TextStyle(
                    fontWeight: FontWeight.w600,
                    color: AppColors.white,
                    fontSize: 16
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  InkWell buildSingleMenu({
    required VoidCallback onClick,
    required String text,
  }) {
    return InkWell(
      onTap: onClick,
      child: Container(
        padding: EdgeInsets.only(left: 10, right: 10),

        decoration: BoxDecoration(
          border: Border(
              bottom: BorderSide(width: 1, color: Colors.grey.shade200)
          ),
          color: AppColors.white,
          //borderRadius: BorderRadius.circular(5)
        ),
        child: ListTile(
          title: Text("$text",
            style: TextStyle(
              color: AppColors.black,
            ),
          ),
          trailing: Icon(Icons.arrow_forward_ios, size: 20, color: AppColors.black,),
        ),
      ),
    );
  }
}
