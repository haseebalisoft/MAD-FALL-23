// import 'package:coco/utility/appAssets.dart';
// import 'package:coco/view/Client/Posts/UserPosts.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
//
//
// class ProfileProtfolio extends StatelessWidget {
//
//
//   List image = [
//     AssetUtils.profile_post_1,
//     AssetUtils.profile_post_2,
//     AssetUtils.profile_post_3,
//     AssetUtils.profile_post_4,
//     AssetUtils.profile_post_5,
//     AssetUtils.profile_post_6,
//     AssetUtils.profile_post_7,
//     AssetUtils.profile_post_8,
//     AssetUtils.profile_post_9,
//     AssetUtils.profile_post_10,
//   ];
//
//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: SizedBox(
//           child: GridView.builder(
//             shrinkWrap: true,
//             itemCount: image.length,
//             gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
//                 crossAxisCount: 2,
//               mainAxisExtent: 300,
//               mainAxisSpacing: 20,
//                 crossAxisSpacing: 20,
//             ),
//             physics: NeverScrollableScrollPhysics(),
//             itemBuilder: (BuildContext context, int index) {
//               return buildSinglePortfolio(
//                 onClick: ()=>Get.to(Users_Posts()),
//                 imagePath: "${image[index]}"
//               );
//             },
//           ),
//         ),
//     );
//   }
//
//   InkWell buildSinglePortfolio({
//   required VoidCallback onClick,
//   required String imagePath,
// }) {
//     return InkWell(
//       onTap: onClick,
//         child: ClipRRect(
//           borderRadius: BorderRadius.circular(10),
//           child: Image.asset(imagePath, fit: BoxFit.cover,),
//         ),
//       );
//   }
// }
