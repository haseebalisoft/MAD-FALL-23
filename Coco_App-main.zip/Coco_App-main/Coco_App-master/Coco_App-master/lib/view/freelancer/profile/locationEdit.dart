import 'dart:convert';

import 'package:coco/controller/authController.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';

class LocationEdit extends StatefulWidget {
  final String? p_Country, p_State, p_city, p_zipcode, p_address, p_CountryId;
  LocationEdit(
      {super.key,
      this.p_Country,
      this.p_State,
      this.p_city,
      this.p_zipcode,
      this.p_CountryId,
      this.p_address});

  @override
  State<LocationEdit> createState() => _LocationEditState();
}

class _LocationEditState extends State<LocationEdit> {
  Future? getCountryFuture;
  Future? getStateFuture;
  Future? getCityFuture;
  bool isCountry = false;
  bool isAllCity = false;
  final List<String> items = [];
  var selectedCountry;
  var selectedState;
  var selectedCity;

  TextEditingController _country = TextEditingController();
  TextEditingController _countryId = TextEditingController();
  TextEditingController _zipcode = TextEditingController();
  TextEditingController _city = TextEditingController();
  TextEditingController _cityId = TextEditingController();
  TextEditingController _state = TextEditingController();
  TextEditingController _stateId = TextEditingController();
  TextEditingController _address = TextEditingController();

  var selectCity, selectState, selectCountry;

  Future getAllCountryInitially() async {
    setState(() => isCountry = true);
    return await AuthController.getAllCountrys();
  }

  Future getAllCity(id) async {
    setState(() => isAllCity = true);
    return await AuthController.getAllCity(id);
  }

  Future getAllState(id) async {
    return await AuthController.getAllState(id);
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getCountryFuture = getAllCountryInitially();
    _focusNode = FocusNode();
    _country.text = widget.p_CountryId!;
    _state.text = widget.p_State!;
    _city.text = widget.p_city!;
  }

  FocusNode? _focusNode;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.black,
      child: Scaffold(
        backgroundColor: AppColors.black,
        appBar: AppBar(
          leading: BackButton(
            color: Colors.white,
          ),
          elevation: 0,
          title: Text(
            'Location',
            style: TextStyle(color: AppColors.white),
          ),
          backgroundColor: AppColors.black,
        ),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10.0),
          child: Column(
            children: [
              SizedBox(
                height: 2.h,
              ),
              Row(
                children: [
                  SizedBox(
                    width: 2.w,
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            'Country',
                            style: TextStyle(
                                fontSize: 12, fontFamily: 'Poppins_SemiBold',color: AppColors.white),
                          ),
                          SizedBox(
                            width: 2,
                          ),
                          Padding(
                            padding: EdgeInsets.only(bottom: 8.0),
                            child: CircleAvatar(
                              radius: 2,
                              backgroundColor: AppColors.mainColor,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
              SizedBox(
                height: 5,
              ),
              TextFormField(
                style: TextStyle(fontSize: 14,
                color: AppColors.white
                ),
                onTap: () => openCountryList(),
                readOnly: true,
                controller: _country,
                validator: (String? value) {
                  if (value?.isEmpty ?? true) {
                    return 'Please Enter your Country';
                  }
                },
                decoration: InputDecoration(

                    hintText: ('Choose a country'),
                 ),
              ),
              SizedBox(
                height: 5,
              ),
              TextFormField(
                style: TextStyle(fontSize: 14,
                color: AppColors.white),
                controller: _state,
                readOnly: true,
                onTap: () {
                  if (_country.text.isNotEmpty) {
                    print("_countryId.toString() ${_countryId.text}");
                    getStateFuture = getAllState(_countryId.text);
                    openState(getAllState(_countryId.text));
                  } else {
                    AlertController.snackbar(
                        context: context,
                        text: "Please Select Country.",
                        bg: Colors.red);
                  }
                },
                // validator: (String? value) {
                //   if (value?.isEmpty ?? true) {
                //     return 'Please Enter your State Address';
                //   }
                // },
                decoration: InputDecoration(

                    hintText: ('State'),
                  ),
              ),
              SizedBox(
                height: 5,
              ),
              TextFormField(
                style: TextStyle(fontSize: 14,
                color: AppColors.white
                ),
                controller: _city,
                readOnly: true,
                onTap: () {
                  if (_state.text.isNotEmpty) {
                    openCity();
                  } else {
                    AlertController.snackbar(
                        context: context,
                        text: "Please Select State.",
                        bg: Colors.red);
                  }
                },
                // validator: (String? value) {
                //   if (value?.isEmpty ?? true) {
                //     return 'Please Enter your city';
                //   }
                // },
                decoration: const InputDecoration(

                    hintText: ('Choose a city'),
                 ),
              ),
              SizedBox(
                height: 5,
              ),
              TextFormField(
                style: TextStyle(fontSize: 14,
                   color: AppColors.white
                ),
                controller: _zipcode,
                validator: (String? value) {
                  if (value?.isEmpty ?? true) {
                    return 'Please Enter your Zipcode';
                  }
                },
                decoration: InputDecoration(
                    hintText: ('Zip code'),
                  ),
              ),
              SizedBox(
                height: 5,
              ),
              SizedBox(
                height: 5,
              ),
              TextFormField(
                style: TextStyle(fontSize: 14,
                  color:  AppColors.white
                ),
                focusNode: _focusNode,
                controller: _address,
                // validator: (String? value) {
                //   if (value?.isEmpty ?? true) {
                //     return 'Please Enter your address';
                //   }
                // },
                decoration: InputDecoration(
                    hintText: ('Address'),
                  ),
              ),
              SizedBox(
                height: 15,
              ),
              SizedBox(
                width: 100.w,
                child: ElevatedButton(
                  onPressed: ()async {
                    clientUp();
                  },
                  child: Text('Update'),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  ////////////////////////////////////////////////////////////////////////////////////////////
  /////////////////////////================================///////////////////////////////////
  final searchCountryController = TextEditingController();
  final searchStateController = TextEditingController();
  final searchCityController = TextEditingController();
  ////////////////////////////////////
  /////////Country search //////////
  List countryList = [];
  List searchCountryList = [];
  openCountryList() async {
    setState(() {});
    // getAllCountryInitially();
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Align(
            alignment: Alignment.bottomRight,
            child: IconButton(
              onPressed: () {
                //countryList.clear();
                searchCountryList.clear();
                searchCountryController.clear();
                Get.back();
              },
              icon: Icon(Icons.close),
            ),
          ),
          insetPadding: const EdgeInsets.all(0),
          content: StatefulBuilder(builder: (context, setState) {
            return SizedBox(
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              child: Column(
                children: [
                  TextFormField(
                    controller: searchCountryController,
                    onChanged: (value) {
                      //////// if the role is freelnacer then we store data only searchBusinessList
                      setState(() {
                        searchCountryList.clear();
                        for (var i = 0; i < countryList.length; i++) {
                          if (countryList[i]["name"]
                              .toLowerCase()
                              .contains(value.toLowerCase())) {
                            searchCountryList?.add(countryList[i]);
                          }
                          print("searchCountryList == ${searchCountryList}");
                        }
                      });
                    },
                    decoration: const InputDecoration(
                        fillColor: Color(0xFFF8F8F8),
                        hintText: ('Search country'),
                        hintStyle: TextStyle(
                            fontFamily: 'Poppins-Light', fontSize: 14)),
                  ),
                  FutureBuilder(
                      future: getCountryFuture,
                      builder: (context, AsyncSnapshot<dynamic> snapshot) {
                        print("snapshot ==== ${snapshot.data}");
                        if (snapshot.connectionState ==
                            ConnectionState.waiting) {
                          return const Center(
                            child: CircularProgressIndicator(
                              strokeWidth: 1,
                              color: Colors.black,
                            ),
                          );
                        } else if (snapshot.hasData) {
                          countryList = snapshot.data;
                          return Expanded(
                            // width: MediaQuery.of(context).size.width,
                            child: searchCountryList.isEmpty
                                ? ListView.builder(
                                    shrinkWrap: true,
                                    itemCount: snapshot.data.length,
                                    itemBuilder: (_, index) {
                                      items.add(snapshot.data[index]["name"]);
                                      return ListTile(
                                        onTap: () {
                                          setState(() {
                                            _countryId.text = snapshot
                                                .data[index]["id"]
                                                .toString();
                                            _country.text =
                                                snapshot.data[index]["name"];
                                            _stateId.clear();
                                            _state.clear();
                                            _city.clear();
                                            _cityId.clear();
                                            searchCountryList.clear();
                                            searchCountryController.clear();
                                          });
                                          Get.back();
                                        },
                                        title: Text(
                                            "${snapshot.data[index]["name"]}"),
                                      );
                                    },
                                  )
                                : ListView.builder(
                                    shrinkWrap: true,
                                    itemCount: searchCountryList.length,
                                    itemBuilder: (_, index) {
                                      items.add(snapshot.data[index]["name"]);
                                      return ListTile(
                                        onTap: () {
                                          setState(() {
                                            _countryId.text =
                                                searchCountryList[index]["id"]
                                                    .toString();
                                            _country.text = searchCountryList[index]["name"];
                                            selectCountry = searchCountryList[index]["id"];
                                            _stateId.clear();
                                            _state.clear();
                                            _city.clear();
                                            _cityId.clear();
                                            searchCountryController.clear();
                                            searchCountryList.clear();
                                          });
                                          Get.back();
                                        },
                                        title: Text(
                                            "${searchCountryList[index]["name"]}"),
                                      );
                                    },
                                  ),
                            // child: Text("dafasd"),
                          );
                        } else {
                          return Center(
                            child: Text("No Country found"),
                          );
                        }
                      }),
                ],
              ),
            );
          }),
          actions: [
            TextButton(
              onPressed: () => Get.back(),
              child: Text("Close"),
            )
          ],
        );
      },
    );
  }

  //////////// open country list ////////////
  List stateList = [];
  List searchStateList = [];
  openState(future) async {
    // getAllCountryInitially();
    getStateFuture = getAllState(_countryId.text);
    print("_countryId === ${_countryId}");
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Align(
            alignment: Alignment.bottomRight,
            child: IconButton(
              onPressed: () {
                setState(() {
                  searchStateList.clear();
                  searchStateController.clear();
                });
                Get.back();
              },
              icon: Icon(Icons.close),
            ),
          ),
          insetPadding: EdgeInsets.all(0),
          content: StatefulBuilder(builder: (context, setState) {
            return SizedBox(
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              child: Column(
                children: [
                  TextFormField(
                    controller: searchStateController,
                    onChanged: (value) {
                      //////// if the role is freelancer then we store data only searchBusinessList
                      setState(() {
                        searchStateList.clear();
                        for (var i = 0; i < stateList.length; i++) {
                          if (stateList[i]["name"]
                              .toLowerCase()
                              .contains(value.toLowerCase())) {
                            searchStateList?.add(stateList[i]);
                          }
                        }
                      });
                    },
                    decoration: const InputDecoration(
                        fillColor: Color(0xFFF8F8F8),
                        hintText: ('Search state'),
                        hintStyle: TextStyle(
                            fontFamily: 'Poppins-Light', fontSize: 14)),
                  ),
                  FutureBuilder(
                      future: getStateFuture,
                      builder: (context, AsyncSnapshot<dynamic> snapshot) {
                        print("snapshot ==== ${snapshot.data}");
                        if (snapshot.connectionState ==
                            ConnectionState.waiting) {
                          return Center(
                            child: CircularProgressIndicator(
                              strokeWidth: 1,
                              color: Colors.black,
                            ),
                          );
                        } else if (snapshot.hasData) {
                          stateList = snapshot.data;
                          return StatefulBuilder(builder: (context, setState) {
                            return Expanded(
                              child: searchStateList.isEmpty
                                  ? ListView.builder(
                                      shrinkWrap: true,
                                      itemCount: snapshot.data.length,
                                      itemBuilder: (_, index) {
                                        return ListTile(
                                          onTap: () {
                                            setState(() {
                                              _stateId.text = snapshot
                                                  .data[index]["id"]
                                                  .toString();
                                              _state.text = snapshot.data[index]["name"];
                                              selectState = snapshot.data[index]["id"];
                                              searchStateList.clear();
                                              searchStateController.clear();
                                            });
                                            Get.back();
                                            print(
                                                "selectedCountry === ${selectedCountry}");
                                          },
                                          title: Text(
                                              "${snapshot.data[index]["name"]}"),
                                        );
                                      },
                                    )
                                  : ListView.builder(
                                      shrinkWrap: true,
                                      itemCount: searchStateList.length,
                                      itemBuilder: (_, index) {
                                        return ListTile(
                                          onTap: () {
                                            setState(() {
                                              _stateId.text =
                                                  searchStateList[index]["id"]
                                                      .toString();
                                              _state.text = searchStateList[index]["name"];
                                              searchStateList.clear();
                                              searchStateController.clear();
                                            });
                                            Get.back();
                                            print(
                                                "selectedCountry === ${selectedCountry}");
                                          },
                                          title: Text(
                                              "${searchStateList[index]["name"]}"),
                                        );
                                      },
                                    ),
                              // child: Text("dafasd"),
                            );
                          });
                        } else if (snapshot.hasError) {
                          print("shanpshot error ==== ${snapshot.hasError}");
                          return Text("error");
                        } else {
                          return Center(
                            child: Text("No State found"),
                          );
                        }
                      }),
                ],
              ),
            );
          }),
          actions: [
            TextButton(
              onPressed: () => Get.back(),
              child: Text("Close"),
            )
          ],
        );
      },
    );
  }

  //////////// open country list ////////////
  List cityList = [];
  List searchCityList = [];
  //////////// open country list ////////////
  openCity() async {
    // getAllCountryInitially();
    getCityFuture = getAllCity(_stateId.text);

    print("_stateId === ${_stateId.text}");
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Align(
            alignment: Alignment.bottomRight,
            child: IconButton(
              onPressed: () {
                setState(() {
                  searchCityList.clear();
                  searchCityController.clear();

                });
                Get.back();
              },
              icon: Icon(Icons.close),
            ),
          ),
          insetPadding: EdgeInsets.all(0),
          content: StatefulBuilder(builder: (context, setState) {
            return SizedBox(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
              child: Column(
                children: [
                  TextFormField(
                    controller: searchCityController,
                    onChanged: (value) {
                      //////// if the role is freelnacer then we store data only searchBusinessList
                      setState(() {
                        searchCityList.clear();
                        for (var i = 0; i < cityList.length; i++) {
                          if (cityList[i]["name"]
                              .toLowerCase()
                              .contains(value.toLowerCase())) {
                            searchCityList?.add(cityList[i]);
                          }
                        }
                      });
                    },
                    decoration: const InputDecoration(
                        fillColor: Color(0xFFF8F8F8),
                        hintText: ('Search city'),
                        hintStyle: TextStyle(
                            fontFamily: 'Poppins-Light', fontSize: 14)),
                  ),
                  FutureBuilder(
                      future: getCityFuture,
                      builder: (context, AsyncSnapshot<dynamic> snapshot) {
                        print("snapshot ==== ${snapshot.data}");
                        if (snapshot.connectionState ==
                            ConnectionState.waiting) {
                          return Center(
                            child: CircularProgressIndicator(
                              strokeWidth: 1,
                              color: Colors.black,
                            ),
                          );
                        } else if (snapshot.hasData) {
                          cityList = snapshot.data;
                          return StatefulBuilder(builder: (context, setState) {
                            return snapshot.data.length == 0
                                ? const Center(
                                    child: Text("No City Found"),
                                  )
                                : Expanded(
                                    child: searchCityList.isEmpty
                                        ? ListView.builder(
                                            shrinkWrap: true,
                                            itemCount: snapshot.data.length,
                                            itemBuilder: (_, index) {
                                              return ListTile(
                                                onTap: () {
                                                  setState(() {
                                                    _cityId.text = snapshot
                                                        .data[index]["id"]
                                                        .toString();
                                                    _city.text = snapshot
                                                        .data[index]["name"];
                                                    selectCity = searchCityList[index]!['id'];
                                                    searchCityList.clear();
                                                    searchCityController
                                                        .clear();
                                                  });
                                                  Get.back();
                                                  print(
                                                      "selectedCountry === ${selectedCountry}");
                                                },
                                                title: Text(
                                                    "${snapshot.data[index]["name"]}"),
                                              );
                                            },
                                          )
                                        : ListView.builder(
                                            shrinkWrap: true,
                                            itemCount: searchCityList.length,
                                            itemBuilder: (_, index) {
                                              return ListTile(
                                                onTap: () {
                                                  setState(() {
                                                    _cityId.text =
                                                        searchCityList[index]
                                                                ["id"]
                                                            .toString();
                                                    _city.text = searchCityList[index]!["name"];
                                                    selectCity = searchCityList[index]!['id'];
                                                    searchCityList.clear();
                                                    searchCityController
                                                        .clear();
                                                  });
                                                  Get.back();
                                                  print(
                                                      "selectedCountry === ${selectedCountry}");
                                                },
                                                title: Text(
                                                    "${searchCityList[index]["name"]}"),
                                              );
                                            },
                                          ),
                                  );
                          });
                        } else {
                          return Center(
                            child: Text("No City found"),
                          );
                        }
                      }),
                ],
              ),
            );
          }),
          actions: [
            TextButton(
              onPressed: () => Get.back(),
              child: Text("Close"),
            )
          ],
        );
      },
    );
  }


  void clientUp() async{
      try{
        var res = await AuthController.CLIENT_PROFILEUP(
          zipcode: _zipcode.text,
          city: _cityId.text,
          state: _stateId.text,
          address: _address.text,
          country: _countryId.text,
        );
        var data = jsonDecode(res.body);
        if(res.statusCode == 200){
          AlertController.snackbar(context: context, text: "Location Update", bg: Colors.green);
          // Navigator.pop(context, MaterialPageRoute(builder: (context)=>CreateProfileStep2()));
          Get.back();
        }else{
          print("location update ${res.body}");
          print("location update ${res.statusCode}");
          AlertController.snackbar(context: context, text: "${data["message"]}", bg: Colors.red);
        }
      }catch(e){
        print("location update $e");
      }
  }


/////////////////////////================================///////////////////////////////////
// //////////////////////////////////////////////////////////////////////////////////////////
}
