import 'package:coco/utility/colors.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:sticky_headers/sticky_headers/widget.dart';
import '../../../utility/appAssets.dart';
import '../../profile/profileTonInfo.dart';
import '../../Client/profile/profileSetting.dart';
import '../../client/profile//Profile_about.dart';
import '../../client/profile//profile_protfolio.dart';
import '../../profile/followingFollower.dart';
import '../bottomNavigationBar/becameFreelanceBottomNavigation.dart';

class FreelacerProfile extends StatefulWidget {
  const FreelacerProfile({super.key});

  @override
  State<FreelacerProfile> createState() => _FreelacerProfileState();
}

class _FreelacerProfileState extends State<FreelacerProfile>
    with SingleTickerProviderStateMixin {
  late TabController tabController;

  bool isFollow = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    tabController = TabController(length: 2, vsync: this);
  }

  bool isAboutMe = false;
  bool isPortfolioTab = true;

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        elevation: 0, backgroundColor: Colors.white,
        leading: IconButton(
            onPressed: () {
              Get.back();
            },
            icon: const Icon(Icons.arrow_back_outlined, color: AppColors.black,)),
        actions: [
          IconButton(
            onPressed: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>FreelancerAppBottomNavigation(pageIndex: 6,))),
            icon: Icon(Icons.settings, color: AppColors.black,),
          ),
          SizedBox(width: 10,)
        ],
      ),
      body: SafeArea(
        child: Container(
          color: Colors.white,
          child: ListView(
            //crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Column(
                children: [

                  /////////////// this information comes from clientProfileInformation widget ///////////////
                  SizedBox(height: 100, child: ProfileTopInformation()),
                  /////////////// this information comes from clientProfileInformation widget ///////////////
                  SizedBox(
                    height: 15,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                            width: MediaQuery.of(context).size.width / 2.3,
                            child: ElevatedButton(
                                onPressed: () {},
                                child: Text('Edit Profile',
                                    style: TextStyle(
                                      fontSize: 12,
                                        fontFamily: 'Poppins_SemiBold'),),),),
                        SizedBox(
                          width: 5,
                        ),
                        SizedBox(
                            width: MediaQuery.of(context).size.width / 2.3,
                            child: ElevatedButton(
                                style: OutlinedButton.styleFrom(
                                  backgroundColor: Color(0xFF00CC83),
                                ),
                                onPressed: ()=>ShowContactInfo(),
                                child: Text(
                                  'Favorite',
                                  style:
                                  TextStyle(
                                      fontSize: 12,
                                      fontFamily: 'Poppins_SemiBold'),
                                ))),
                      ],
                    ),
                  ),
                ],
              ),
              ProfileProtfolio(),
              // StickyHeader(
              //     header: Container(
              //         padding: EdgeInsets.only(top: 20, bottom: 20),
              //         color: Colors.white,
              //         child: Row(
              //           mainAxisAlignment: MainAxisAlignment.center,
              //           children: [
              //             // InkWell(
              //             //   onTap: (){
              //             //     setState(() {
              //             //       isPortfolioTab = true;
              //             //       isAboutMe = false;
              //             //     });
              //             //   },
              //             //   child: Container(
              //             //     width: size.width*.45,
              //             //     padding: EdgeInsets.only(bottom: 10),
              //             //     height: 30,
              //             //     decoration: BoxDecoration(
              //             //         border: isPortfolioTab ? const Border(
              //             //             bottom: BorderSide(width: 2, color: AppColors.mainColor)
              //             //         ):Border(bottom: BorderSide.none)
              //             //     ),
              //             //     child: Center(
              //             //       child: Text("Portfolio",
              //             //         style: TextStyle(
              //             //           fontFamily: 'source-sans-pro-regular',
              //             //             fontSize: 14,
              //             //             fontWeight: FontWeight.w600,
              //             //             color:isPortfolioTab ? AppColors.mainColor : Colors.black
              //             //         ),
              //             //       ),
              //             //     ),
              //             //   ),
              //             // ),
              //             SizedBox(width: 10,),
              //             // InkWell(
              //             //   onTap: (){
              //             //     setState(() {
              //             //       isPortfolioTab = false;
              //             //       isAboutMe = true;
              //             //     });
              //             //   },
              //             //   child: Container(
              //             //     width: size.width*.45,
              //             //     height: 30,
              //             //     padding: EdgeInsets.only(bottom: 10),
              //             //     decoration: BoxDecoration(
              //             //         border: isAboutMe ? Border(
              //             //             bottom: BorderSide(width: 2, color: AppColors.mainColor)
              //             //         ): Border(bottom: BorderSide.none)
              //             //     ),
              //             //     child: Center(child: Text("About Me",
              //             //
              //             //       style: TextStyle(
              //             //           fontFamily: 'source-sans-pro-regular',
              //             //           fontSize: 14,
              //             //           fontWeight: FontWeight.w600,
              //             //           color:isAboutMe ? AppColors.mainColor : Colors.black
              //             //       ),
              //             //
              //             //     )),
              //             //   ),
              //             // )
              //           ],
              //         )
              //     ),
              //     content: isPortfolioTab
              //         ?
              //         : AboutMeSection()
              // ),
            ],
          ),
        ),
      ),

    );
  }
  //
  // ProfileProtfolio(),
  // AboutMeSection(),
  ShowContactInfo() async{
    showModalBottomSheet(
        context: context,
        shape: RoundedRectangleBorder(		//the rounded corner is created here
          borderRadius: BorderRadius.circular(20.0),
        ),
        builder: (context) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Container(
                margin: EdgeInsets.only(top: 10),
                height: 2, width: 100,
                color: Colors.grey.shade500,
              ),
              SizedBox(height: 20,),
              ListTile(
                leading: Container(
                  height: 40, width: 40,
                  padding: EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(100),
                    color: AppColors.mainColor,
                  ),
                  child: Icon(Icons.call, color: AppColors.white,),
                ),
                title: new Text('Call Me',
                  style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w600
                  ),
                ),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: Container(
                  height: 40, width: 40,
                  padding: EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(100),
                    color: AppColors.mainColor,
                  ),
                  child: Icon(Icons.email_outlined, color: AppColors.white,),
                ),
                title: new Text('Send me a mail',
                  style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w600
                  ),
                ),

                onTap: () {
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: Container(
                  height: 40, width: 40,
                  padding: EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(100),
                    color: AppColors.mainColor,
                  ),
                  child: Icon(Icons.call, color: AppColors.white,),
                ),
                title: Row(
                  children: [
                    new Text('Contact via',
                      style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w600
                      ),
                    ),
                    SizedBox(width: 20,),
                    Row(
                      children: [
                        InkWell(
                          onTap: (){},
                          child: Container(
                            height: 35, width: 35,
                            //padding: EdgeInsets.all(10),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                color: AppColors.white,
                                border: Border.all(width: 1, color: AppColors.mainColor)
                            ),
                            child: Center(child: FaIcon(FontAwesomeIcons.instagram, color: AppColors.mainColor, size: 20,)),
                          ),
                        ),
                        SizedBox(width: 20,),
                        InkWell(
                          onTap: (){},
                          child: Container(
                            height: 35, width: 35,
                            //padding: EdgeInsets.all(10),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                color: AppColors.white,
                                border: Border.all(width: 1, color: AppColors.mainColor)
                            ),
                            child: Center(child: FaIcon(FontAwesomeIcons.linkedin, color: AppColors.mainColor, size: 20,)),
                          ),
                        ),
                      ],
                    )
                  ],
                ),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
              SizedBox(height: 40,),
            ],
          );
        });
  }
}

