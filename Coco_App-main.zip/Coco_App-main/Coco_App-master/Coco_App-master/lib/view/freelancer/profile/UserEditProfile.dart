import 'dart:convert';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:coco/appConst.dart';
import 'package:coco/controller/authController.dart';
import 'package:coco/model/authModel/businessHoursModel.dart';
import 'package:coco/model/authModel/singleUserInfo.dart';
import 'package:coco/model/userProfile/ClientProfileInfo.dart';
import 'package:coco/model/userProfile/FreelancerProfileModel.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/view/Client/createAccount/editDayTime.dart';
import 'package:coco/view/Client/createAccount/profile_info_3.dart';
import 'package:coco/view/freelancer/CreateAccount/add_languages.dart';
import 'package:coco/view/freelancer/bottomNavigationBar/becameFreelanceBottomNavigation.dart';
import 'package:coco/view/profile/myProfile.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:coco/viewController/appNetworkImage.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../controller/storyController.dart';
import '../../../controller/user_edit_controller.dart';
import '../../../model/storyModel/allStoryModel.dart';
import '../../client/bottomNagivation/buttom_nav.dart';
import 'locationEdit.dart';

class UserEditProfile extends StatefulWidget {
  const UserEditProfile({super.key});

  @override
  State<UserEditProfile> createState() => _UserEditProfileState();
}

class _UserEditProfileState extends State<UserEditProfile> {
  bool email = false;
  bool username = false;
  bool description = false;
  bool phone = false;
  FocusNode? _focusNode;



  final UserEditController userEditController = Get.put(UserEditController());

  //Country related panel veriables
  final List<String> items=[];
  final List<String> allCountry= [];
  List allState = [];
  List allCity = [];
  var selectedCountry;
  var selectedState;
  var selectedCity;
  TextEditingController CountrySearchController = TextEditingController();
  Future? getCountryFuture;
  Future? getStateFuture;
  Future? getCityFuture;
  bool isCountry = false;
  bool isAllCity = false;
  Future getAllCountryInitially()async{
    setState(() =>isCountry = true);
    return await AuthController.getAllCountrys();
  }
  Future getAllCity(id)async{
    setState(() =>isAllCity = true);
    return await AuthController.getAllCity(id);
  }
  Future getAllState(id)async{
    return await AuthController.getAllState(id);
  }

  ////////////////////////////////////////////////////////////////////////////////////////////
  /////////////////////////================================///////////////////////////////////
  final searchCountryController = TextEditingController();
  final searchStateController = TextEditingController();
  final searchCityController = TextEditingController();
  ////////////////////////////////////
  /////////Country search //////////
  List countryList = [];
  List searchCountryList = [];
  openCountryList()async{
    setState(() {});
    // getAllCountryInitially();
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: AppColors.black,
          title: Align(
            alignment: Alignment.bottomRight,
            child: IconButton(onPressed: (){
              //countryList.clear();
              searchCountryList.clear();
              searchCountryController.clear();
              Get.back();
            }, icon: Icon(Icons.close,color: AppColors.white,),),
          ),
          insetPadding: const EdgeInsets.all(0),
          content: StatefulBuilder(

              builder: (context, setState) {
                return SizedBox(
                  height: MediaQuery.of(context).size.height,
                  width: MediaQuery.of(context).size.width,
                  child: Column(
                    children: [

                      TextFormField(
                        style: TextStyle(
                          color: AppColors.white,
                        ),
                        controller: searchCountryController,
                        onChanged: (value){
                          //////// if the role is freelnacer then we store data only searchBusinessList
                          setState(() {
                            searchCountryList.clear();
                            for (var i = 0; i<countryList.length; i++) {
                              if (countryList[i]["name"].toLowerCase().contains(value.toLowerCase())) {
                                searchCountryList?.add(countryList[i]);
                              }
                              print("searchCountryList == ${searchCountryList}");
                            }
                          });
                        },
                        decoration: const InputDecoration(

                          hintText: ('Search country'),
                        ),
                      ),
                      FutureBuilder(
                          future: getCountryFuture,
                          builder: (context,AsyncSnapshot<dynamic> snapshot) {
                            print("snapshot ==== ${snapshot.data}");
                            if(snapshot.connectionState == ConnectionState.waiting){
                              return const Center(child: CircularProgressIndicator(strokeWidth: 1, color: Colors.white,),);
                            }else if(snapshot.hasData){
                              countryList = snapshot.data;
                              return Expanded(
                                // width: MediaQuery.of(context).size.width,
                                child:searchCountryList.isEmpty
                                    ? ListView.builder(
                                  shrinkWrap: true,
                                  itemCount: snapshot.data.length,
                                  itemBuilder: (_, index){
                                    items.add(snapshot.data[index]["name"]);
                                    return ListTile(
                                      onTap: (){
                                        setState(() {
                                          userEditController.countryId.value.text = snapshot.data[index]["id"].toString();
                                          userEditController.country.value.text = snapshot.data[index]["name"];
                                          userEditController.stateId.value.clear();
                                          userEditController.state.value.clear();
                                          userEditController.city.value.clear();
                                          userEditController.cityId.value.clear();
                                          searchCountryList.clear();
                                          searchCountryController.clear();
                                        });
                                        Get.back();
                                      },
                                      title: Text("${snapshot.data[index]["name"]}",style: TextStyle(color: AppColors.white),),
                                    );
                                  },
                                )
                                    :  ListView.builder(
                                  shrinkWrap: true,
                                  itemCount: searchCountryList.length,
                                  itemBuilder: (_, index){
                                    items.add(snapshot.data[index]["name"]);
                                    return ListTile(
                                      onTap: (){
                                        setState(() {
                                          userEditController.countryId.value.text = searchCountryList[index]["id"].toString();
                                          userEditController.country.value.text = searchCountryList[index]["name"];
                                          userEditController.stateId.value.clear();
                                          userEditController.state.value.clear();
                                          userEditController.city.value.clear();
                                          userEditController.cityId.value.clear();
                                          searchCountryController.clear();
                                          searchCountryList.clear();
                                        });
                                        Get.back();
                                      },
                                      title: Text("${searchCountryList[index]["name"]}",style: TextStyle(color: AppColors.white),),
                                    );
                                  },
                                ),
                                // child: Text("dafasd"),
                              );
                            }else{
                              return Center(child: Text("No Country found",style: TextStyle(color:AppColors.white),),);
                            }
                          }
                      ),
                    ],
                  ),
                );
              }
          ),
          actions: [
            TextButton(
              onPressed: ()=>Get.back(),
              child: Text("Close",style: TextStyle(color: AppColors.mainColor),),
            )
          ],
        );
      },
    );
  }

  //////////// open country list ////////////
  List stateList = [];
  List searchStateList = [];
  openState(future)async{
    // getAllCountryInitially();
    getStateFuture = getAllState(userEditController.countryId.value.text);
    print("userEditController.countryId.value === ${userEditController.countryId.value}");
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor:  AppColors.black,
          title: Align(
            alignment: Alignment.bottomRight,
            child: IconButton(onPressed: (){
              setState(() {
                searchStateList.clear();
                searchStateController.clear();
              });
              Get.back();
            }, icon: Icon(Icons.close,color: AppColors.white,),),
          ),
          insetPadding: EdgeInsets.all(0),
          content: StatefulBuilder(
              builder: (context, setState) {
                return SizedBox(
                  height: MediaQuery.of(context).size.height,
                  width: MediaQuery.of(context).size.width,
                  child: Column(
                    children: [
                      TextFormField(
                        style: TextStyle(
                          color: AppColors.white,
                        ),
                        controller: searchStateController,
                        onChanged: (value){
                          //////// if the role is freelnacer then we store data only searchBusinessList
                          setState(() {
                            searchStateList.clear();
                            for (var i = 0; i<stateList.length; i++) {
                              if (stateList[i]["name"].toLowerCase().contains(value.toLowerCase())) {
                                searchStateList?.add(stateList[i]);
                              }
                            }
                          });
                        },
                        decoration: const InputDecoration(
                          hintText: ('Search state'),
                        ),
                      ),
                      FutureBuilder(
                          future: getStateFuture,
                          builder: (context,AsyncSnapshot<dynamic> snapshot) {
                            print("snapshot ==== ${snapshot.data}");
                            if(snapshot.connectionState == ConnectionState.waiting){
                              return Center(child: CircularProgressIndicator(strokeWidth: 1, color: Colors.white,),);
                            }else if(snapshot.hasData){
                              stateList = snapshot.data;
                              return  StatefulBuilder(
                                  builder: (context, setState) {
                                    return Expanded(
                                      child: searchStateList.isEmpty
                                          ? ListView.builder(
                                        shrinkWrap: true,
                                        itemCount: snapshot.data.length,
                                        itemBuilder: (_, index){
                                          return ListTile(
                                            onTap: (){
                                              setState(() {
                                                userEditController.stateId.value.text = snapshot.data[index]["id"].toString();
                                                userEditController.state.value.text = snapshot.data[index]["name"];
                                                searchStateList.clear();
                                                searchStateController.clear();
                                              });
                                              Get.back();
                                              print("selectedCountry === ${selectedCountry}");
                                            },
                                            title: Text("${snapshot.data[index]["name"]}", style: TextStyle(
                                              color: AppColors.white,
                                            ),),
                                          );
                                        },
                                      )
                                          : ListView.builder(
                                        shrinkWrap: true,
                                        itemCount: searchStateList.length,
                                        itemBuilder: (_, index){
                                          return ListTile(
                                            onTap: (){
                                              setState(() {
                                                userEditController.stateId.value.text = searchStateList[index]["id"].toString();
                                                userEditController.state.value.text = searchStateList[index]["name"];
                                                searchStateList.clear();
                                                searchStateController.clear();
                                              });
                                              Get.back();
                                              print("selectedCountry === ${selectedCountry}");
                                            },
                                            title: Text("${searchStateList[index]["name"]}",style: TextStyle(color: AppColors.white),),
                                          );
                                        },
                                      ),
                                      // child: Text("dafasd"),
                                    );
                                  }
                              );
                            }else if(snapshot.hasError){
                              print("shanpshot error ==== ${snapshot.hasError}");
                              return Text("error");
                            }else{
                              return Center(child: Text("No State found", style: TextStyle(
                                color: AppColors.white,
                              ),),);
                            }
                          }
                      ),
                    ],
                  ),
                );
              }
          ),
          actions: [
            TextButton(
              onPressed: ()=>Get.back(),
              child: Text("Close", style: TextStyle(
                color: AppColors.mainColor,
              ),),
            )
          ],
        );
      },
    );
  }


  //////////// open country list ////////////
  List cityList = [];
  List searchCityList = [];
  //////////// open country list ////////////
  openCity()async{
    // getAllCountryInitially();
    getCityFuture = getAllCity(userEditController.stateId.value.text);

    print("userEditController.stateId.value === ${userEditController.stateId.value.text}");
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: AppColors.black,
          title: Align(
            alignment: Alignment.bottomRight,
            child: IconButton(onPressed: (){
              setState(() {
                searchCityList.clear();
                searchCityController.clear();
              });
              Get.back();
            }, icon: Icon(Icons.close,color: AppColors.white,),),
          ),
          insetPadding: EdgeInsets.all(0),
          content: StatefulBuilder(
              builder: (context, setState) {
                return SizedBox(
                  width: MediaQuery.of(context).size.width,
                  height:MediaQuery.of(context).size.height,
                  child: Column(
                    children: [
                      TextFormField(
                        controller: searchCityController,
                        onChanged: (value){
                          //////// if the role is freelnacer then we store data only searchBusinessList
                          setState(() {
                            searchCityList.clear();
                            for (var i = 0; i<cityList.length; i++) {
                              if (cityList[i]["name"].toLowerCase().contains(value.toLowerCase())) {
                                searchCityList?.add(cityList[i]);
                              }
                            }
                          });
                        },
                        decoration: const InputDecoration(

                          hintText: ('Search city'),
                        ),
                      ),
                      FutureBuilder(
                          future: getCityFuture,
                          builder: (context,AsyncSnapshot<dynamic> snapshot) {
                            print("snapshot ==== ${snapshot.data}");
                            if(snapshot.connectionState == ConnectionState.waiting){
                              return Center(child: CircularProgressIndicator(strokeWidth: 1, color: Colors.white,),);
                            }else if(snapshot.hasData){
                              cityList = snapshot.data;
                              return  StatefulBuilder(
                                  builder: (context, setState) {
                                    return snapshot.data.length == 0
                                        ? const Center(child: Text("No City Found", style: TextStyle(
                                      color: AppColors.white,
                                    ),),)
                                        : Expanded(
                                      child: searchCityList.isEmpty
                                          ? ListView.builder(
                                        shrinkWrap: true,
                                        itemCount: snapshot.data.length,
                                        itemBuilder: (_, index){
                                          return ListTile(
                                            onTap: (){
                                              setState(() {
                                                userEditController.cityId.value.text = snapshot.data[index]["id"].toString();
                                                userEditController.city.value.text = snapshot.data[index]["name"];
                                                searchCityList.clear();
                                                searchCityController.clear();
                                              });
                                              Get.back();
                                              print("selectedCountry === ${selectedCountry}");
                                            },
                                            title: Text("${snapshot.data[index]["name"]}", style: TextStyle(
                                              color: AppColors.white,
                                            ),),
                                          );
                                        },
                                      )
                                          : ListView.builder(
                                        shrinkWrap: true,
                                        itemCount: searchCityList.length,
                                        itemBuilder: (_, index){
                                          return ListTile(
                                            onTap: (){
                                              setState(() {
                                                userEditController.cityId.value.text = searchCityList[index]["id"].toString();
                                                userEditController.city.value.text = searchCityList[index]["name"];
                                                searchCityList.clear();
                                                searchCityController.clear();
                                              });
                                              Get.back();
                                              print("selectedCountry === ${selectedCountry}");
                                            },
                                            title: Text("${searchCityList[index]["name"]}", style: TextStyle(
                                              color: AppColors.white,
                                            ),),
                                          );
                                        },
                                      ),
                                    );
                                  }
                              );
                            }else{
                              return Center(child: Text("No City found", style: TextStyle(
                                color: AppColors.white,
                              ),),);
                            }
                          }
                      ),
                    ],
                  ),
                );
              }
          ),
          actions: [
            TextButton(
              onPressed: ()=>Get.back(),
              child: Text("Close", style: TextStyle(
                color: AppColors.mainColor,
              ),),
            )
          ],
        );
      },
    );
  }
  /////////////////////////================================///////////////////////////////////
  // //////////////////////////////////////////////////////////////////////////////////////////


  List<Map<String, dynamic>> hours = [];
  Future<BusinessHoursModel> getBusinessHoursFuture()async{
    var res = await AuthController.getBusinessHours();
    for(var i in res.data!){
      print("hours == $i");
      setState(() {
        hours.add({
          "day" : i.day,
          "open" : i.open
        });
      });
    }

    List<String> day_order = [
      'Saturday',
      'Sunday',
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
    ];

    hours.sort((a, b) => day_order.indexOf(a['day']).compareTo(day_order.indexOf(b['day'])));

    print("hours dffffffffffgg== $hours");
    return res;
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _focusNode = FocusNode();
    getCountryFuture = getAllCountryInitially();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      getBusinessHoursFuture();
      //getUserFuture = AuthController.freelancerProfileInfo();
      userEditController.getData();
      getStoryChecker();
    });
  }

  // Future<SingleUserInfoModel>? getUserFuture()async{
  //   SharedPreferences _prefs = await SharedPreferences.getInstance();
  //   var user_id = _prefs.getString("user_id");
  //   return AuthController.getSingleUserInfo(user_id.toString());
  // }
  // Future<FreelancerEditProfileModel>?getUserFuture;
  Future<AllStoryModel>? _getAllStory;

  bool haveStory = false;

  getStoryChecker() async {
    SharedPreferences _pre = await SharedPreferences.getInstance();
    UserStory userStories;
    _getAllStory = StoryController.getStroyList();
    _getAllStory?.then((value) {
      for (var i in value!.userStories!) {
        if (i.id.toString() == _pre.getString("user_id")) {
          setState(() {
            haveStory = true;
          });
        }
      }
    });
  }

  @override
  void dispose() {
    _focusNode?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Obx(() =>
      Scaffold(
        backgroundColor: AppColors.black,
        body: SafeArea(
          child: userEditController.isLoading.value
              ? const Center(
                  child: CircularProgressIndicator(
                      color: AppColors.mainColor
                  )
                )
              :
               SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            IconButton(
                              onPressed: () {
                                // Get.back();
                                Navigator.pop(context);
                                // Get.to(MyProfile());
                                userEditController.role ==
                                    AppConst.FREELANCER_ROLE ? Get.to(FreelancerAppBottomNavigation(pageIndex: 4,)): Get.to(ClientBottomNavigationBar(pageIndex: 3,));
                              },
                              icon: Icon(Icons.clear,color: AppColors.white,),),
                            IconButton(
                                onPressed: () {
                                  //Get.back();
                                  _updateprofile();
                                },
                                icon: Icon(Icons.arrow_forward_outlined,
                                  color: Colors.green, size: 30,)
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 15,
                        ),
                        Center(
                          child: Column(
                            children: [
                              Container(
                                height: 120,
                                width: 120,
                                decoration: BoxDecoration(
                                  // color: AppColors.mainColor,

                                  gradient: haveStory ? LinearGradient(colors: [
                                    Color(0xFF00CC83),
                                    Color(0xFF53E0DB),
                                  ]) : null,
                                  shape: BoxShape.circle,
                                ),
                                child: Center(
                                  child: CircleAvatar(
                                      backgroundColor: Colors.white,
                                      radius: 55,
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(100),
                                        child: Container(

                                        child: _cropProfile == null
                                        ? AppNetworkImage(src: userEditController.getUserInfo.value?.data!.user!.profileImage ?? "",)
                                            : Image.file(
                                          _cropProfile!, // provide the path to your fallback image
                                        fit: BoxFit.cover, // adjust the BoxFit as needed
                                      ),
                                  ),
                                ),
                                  ),


                                ),
                              ),
                              SizedBox(
                                height: 7,
                              ),
                              InkWell(
                                onTap: () {

                                },
                                child: InkWell(
                                  onTap: (){
                                    _pickImage(ImageSource.gallery, "profile");
                                  },
                                  child: Text(
                                    'Change Photo',
                                    style: TextStyle(fontWeight: FontWeight.bold,color: AppColors.white),
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Username',
                              style: TextStyle(color: Color(0xff00CC83),
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold),
                            ),
                            SizedBox(
                              height: 6,
                            ),
                            InkWell(
                              onTap: () {
                                setState(() {
                                  username = !username;
                                  email = false;
                                  description = false;
                                  phone = false;
                                });
                              },


                              child: username ? TextFormField(
                                style: TextStyle(color: AppColors.white),
                                controller: userEditController.usernameController.value,
                                autofocus: true,
                                decoration: InputDecoration(
                                    contentPadding: EdgeInsets.zero,
                                    hintText: '${userEditController.getUserInfo.value?.data!.user!.name ?? userEditController.getUserInfo.value?.data!.user!.userName!}',
                                  fillColor: AppColors.black

                                ),
                              ) : Text(
                                userEditController.getUserInfo.value?.data!.user!.name ??  userEditController.getUserInfo.value?.data!.user!.userName! ?? "",
                                style: TextStyle(
                                    color: AppColors.white, fontSize: 16),
                              ),
                            ),
                             Divider(),
                          ],
                        ),

                        SizedBox(
                          height: 10,
                        ),

                        Text(
                          'Description',
                          style: TextStyle(color: Color(0xff00CC83),
                              fontSize: 15,
                              fontWeight: FontWeight.bold),
                        ),
                        SizedBox(
                          height: 6,
                        ),
                        InkWell(
                          onTap: () {
                            setState(() {
                              username = false;
                              email = false;
                              description = !description;
                              phone = false;
                            });
                          },
                          child: description ? TextFormField(
                            style: TextStyle(
                              color: AppColors.white
                            ),
                            autofocus: true,
                            controller: userEditController.DescriptionController.value,
                            decoration: InputDecoration(
                              fillColor: AppColors.black,
                                contentPadding: EdgeInsets.zero,
                                hintText: '${userEditController.getUserInfo.value?.data!.userInfo
                                    ?.description!}',
                                hintStyle: TextStyle(
                                    color: AppColors.white, fontSize: 16
                                )
                            ),
                          ) : Text(
                            "${userEditController.getUserInfo.value?.data!.userInfo!.description}",
                            style: TextStyle(color: AppColors.white,
                                fontSize: 16),
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Divider(),

                        userEditController.getUserInfo.value?.data?.user?.role != AppConst.CLIENT_ROLE ?
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'Skills',
                                  style: TextStyle(color: Color(0xff00CC83),
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold),
                                ),
                                IconButton(onPressed: () {
                                  userEditController.getUserInfo.value!.data!.serviceName!.clear();

                                  if(userEditController.showSkillEditPanel.value){
                                    for(int i = 0; i < userEditController.selectedSkill.length; i++){
                                      for(int j = 0; j < userEditController.getServiceModel.value!.data!.length; j++){
                                        if(userEditController.selectedSkill[i] == userEditController.getServiceModel.value!.data![j].id.toString()){
                                          userEditController.getUserInfo.value!.data!.serviceName!.add(userEditController.getServiceModel.value!.data![j].name!);
                                          break;
                                        }
                                      }
                                    }

                                    print("userEditController.selectedSkill => ${userEditController.selectedSkill}");
                                    print("userEditController.getUserInfo.value!.data!.serviceName => ${userEditController.getUserInfo.value!.data!.serviceName}");

                                    userEditController.showSkillEditPanel.value = false;
                                  }
                                  else{
                                    userEditController.showSkillEditPanel.value = true;
                                  }
                                }, icon: Icon(
                                  Icons.edit, color: AppColors.mainColor,))
                              ],
                            ),

                            Visibility(
                                visible: !userEditController.showSkillEditPanel.value,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    SizedBox(
                                      height: 6,
                                    ),
                                    Container(
                                      width: MediaQuery.of(context).size.width,
                                      child: Wrap(
                                        spacing: 15, // Spacing between items
                                        runSpacing: 10, // Spacing between lines
                                        children: userEditController.getUserInfo.value?.data?.serviceName?.map((serviceName) {
                                          return Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.circular(20),
                                              color: Colors.white,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.grey.withOpacity(0.2),
                                                  spreadRadius: 5,
                                                  blurRadius: 7,
                                                  offset: Offset(0, 3), // changes position of shadow
                                                ),
                                              ],
                                            ),
                                            child: Padding(
                                              padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 6),
                                              child: Text(
                                                '$serviceName',
                                                style: TextStyle(
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 11,
                                                ),
                                              ),
                                            ),
                                          );
                                        })?.toList() ?? [],
                                      ),
                                    )

                                  ],
                                )
                            ),

                            // Text(
                            //   "${userEditController.getUserInfo.value?.data!.userInfo!.description}",
                            //   style: TextStyle(color: Color(0xff676767),fontSize: 16),
                            // ),

                            Visibility(
                               visible: userEditController.showSkillEditPanel.value,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Select one or multiple skills',
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontFamily: 'Poppins-Light',
                                        color: AppColors.textgrey,
                                      ),
                                    ),
                                    SizedBox(
                                      height: 18,
                                    ),
                                    GridView.builder(
                                      physics: NeverScrollableScrollPhysics(),
                                      shrinkWrap: true,
                                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                        crossAxisCount: 3,
                                        crossAxisSpacing: 5.0,
                                        mainAxisSpacing: 5.0,
                                        childAspectRatio: (1 / .25),
                                      ),
                                      itemCount: userEditController.getServiceModel.value?.data?.length,
                                      itemBuilder: (context, index) {
                                        return GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              final id = userEditController.getServiceModel.value?.data?[index].id.toString();
                                              if (userEditController.selectedSkill.contains(id)) {
                                                userEditController.selectedSkill.remove(id);
                                              } else {
                                                userEditController.selectedSkill.add(id!);
                                              }
                                            });
                                          },
                                          child: Container(
                                            decoration: BoxDecoration(
                                              color: userEditController.selectedSkill.contains(userEditController.getServiceModel.value?.data?[index].id.toString()) ? AppColors.mainColor : AppColors.white,
                                              border: Border.all(
                                                width: 2,
                                                color: userEditController.selectedSkill.contains(userEditController.getServiceModel.value?.data?[index].id.toString()) ? AppColors.mainColor : Color(0xffE8E8E8),
                                              ),
                                              borderRadius: BorderRadius.circular(15),
                                            ),
                                            child: Padding(
                                              padding: const EdgeInsets.symmetric(vertical: 2.0, horizontal: 10),
                                              child: Center(
                                                child: Text(
                                                  '${userEditController.getServiceModel.value?.data?[index].name}',
                                                  style: TextStyle(
                                                    fontSize: 10,
                                                    fontFamily: 'Poppins-Medium',
                                                    color: userEditController.selectedSkill.contains(userEditController.getServiceModel.value?.data?[index].id.toString()) ? AppColors.white : Colors.black,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        );
                                      },
                                    )
                                  ]
                                )

                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Divider(),
                            SizedBox(
                              height: 10,
                            ),
                          ],
                        ) : SizedBox(height: 0,),

                        userEditController.getUserInfo.value?.data?.user?.role != AppConst.CLIENT_ROLE ?
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'Equipments',
                                  style: TextStyle(color: Color(0xff00CC83),
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold),
                                ),
                                IconButton(onPressed: () {
                                  userEditController.getUserInfo.value!.data!.equipmentsName!.clear();

                                  if(userEditController.showEquipmentEditPanel.value){
                                    for(int i = 0; i < userEditController.selectEquipments.length; i++){
                                      for(int j = 0; j < userEditController.getEqupmentsList.value!.data!.length; j++){
                                        if(userEditController.selectEquipments[i] == userEditController.getEqupmentsList.value!.data![j].id.toString()){
                                          userEditController.getUserInfo.value!.data!.equipmentsName!.add(userEditController.getEqupmentsList.value!.data![j].name!);
                                          break;
                                        }
                                      }
                                    }

                                    print("userEditController.selectEquipments => ${userEditController.selectEquipments}");
                                    print("userEditController.getUserInfo.value!.data!.equipmentsName => ${userEditController.getUserInfo.value!.data!.equipmentsName}");

                                    userEditController.showEquipmentEditPanel.value = false;
                                  }
                                  else{
                                    userEditController.showEquipmentEditPanel.value = true;
                                  }
                                }, icon: Icon(
                                  Icons.edit, color: AppColors.mainColor,))
                              ],
                            ),

                            Visibility(
                                visible: !userEditController.showEquipmentEditPanel.value,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    SizedBox(
                                      height: 6,
                                    ),
                                    Container(
                                      width: MediaQuery.of(context).size.width,
                                      child: Wrap(
                                        spacing: 15, // Spacing between items
                                        runSpacing: 10, // Spacing between lines
                                        children: userEditController.getUserInfo.value?.data?.equipmentsName?.map((equipmentName) {
                                          return Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.circular(20),
                                              color: Colors.white,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.grey.withOpacity(0.2),
                                                  spreadRadius: 5,
                                                  blurRadius: 7,
                                                  offset: Offset(0, 3), // changes position of shadow
                                                ),
                                              ],
                                            ),
                                            child: Padding(
                                              padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 6),
                                              child: Text(
                                                '$equipmentName',
                                                style: TextStyle(
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 11,
                                                ),
                                              ),
                                            ),
                                          );
                                        }).toList() ?? [],
                                      ),
                                    )

                                  ],
                                )
                            ),

                            // Text(
                            //   "${userEditController.getUserInfo.value?.data!.userInfo!.description}",
                            //   style: TextStyle(color: Color(0xff676767),fontSize: 16),
                            // ),

                            Visibility(
                                visible: userEditController.showEquipmentEditPanel.value,
                                child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Select one or multiple skills',
                                        style: TextStyle(
                                          fontSize: 12,
                                          fontFamily: 'Poppins-Light',
                                          color: AppColors.textgrey,
                                        ),
                                      ),
                                      SizedBox(
                                        height: 18,
                                      ),
                                      GridView.builder(
                                        physics: NeverScrollableScrollPhysics(),
                                        shrinkWrap: true,
                                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                          crossAxisCount: 3,
                                          crossAxisSpacing: 5.0,
                                          mainAxisSpacing: 5.0,
                                          childAspectRatio: (1 / .25),
                                        ),
                                        itemCount: userEditController.getEqupmentsList.value?.data?.length,
                                        itemBuilder: (context, index) {
                                          return GestureDetector(
                                            onTap: () {
                                              setState(() {
                                                final id = userEditController.getEqupmentsList.value?.data?[index].id.toString();
                                                if (userEditController.selectEquipments.contains(id)) {
                                                  userEditController.selectEquipments.remove(id);
                                                } else {
                                                  userEditController.selectEquipments.add(id!);
                                                }
                                              });
                                            },
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: userEditController.selectEquipments.contains(userEditController.getEqupmentsList.value?.data?[index].id.toString()) ? AppColors.mainColor : AppColors.white,
                                                border: Border.all(
                                                  width: 2,
                                                  color: userEditController.selectEquipments.contains(userEditController.getEqupmentsList.value?.data?[index].id.toString()) ? AppColors.mainColor : Color(0xffE8E8E8),
                                                ),
                                                borderRadius: BorderRadius.circular(15),
                                              ),
                                              child: Padding(
                                                padding: const EdgeInsets.symmetric(vertical: 2.0, horizontal: 10),
                                                child: Center(
                                                  child: Text(
                                                    '${userEditController.getEqupmentsList.value?.data?[index].name}',
                                                    style: TextStyle(
                                                      fontSize: 10,
                                                      fontFamily: 'Poppins-Medium',
                                                      color: userEditController.selectEquipments.contains(userEditController.getEqupmentsList.value?.data?[index].id.toString()) ? AppColors.white : Colors.black,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          );
                                        },
                                      )
                                    ]
                                )

                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Divider(),
                            SizedBox(
                              height: 10,
                            ),
                          ],
                        ) : SizedBox(height: 0,),

                        userEditController.getUserInfo.value?.data?.user?.role != AppConst.CLIENT_ROLE ?
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'Extra Equipments',
                                  style: TextStyle(color: Color(0xff00CC83),
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold),
                                ),
                                IconButton(onPressed: () {

                                  if (userEditController.showExtraEquipmentEditPanel.value) {

                                    userEditController.writtenExtraEquipments = userEditController.extraEquipmentsController.value.text.split(',');

                                    userEditController.showExtraEquipmentEditPanel.value = false;
                                  }
                                  else{
                                    userEditController.showExtraEquipmentEditPanel.value = true;
                                  }
                                }, icon: Icon(
                                  Icons.edit, color: AppColors.mainColor,))
                              ],
                            ),

                            Visibility(
                                visible: !userEditController.showExtraEquipmentEditPanel.value,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    SizedBox(
                                      height: 6,
                                    ),
                                   Text(
                                     userEditController.extraEquipmentsController.value.text,
                                     style: TextStyle(
                                       color: AppColors.white,
                                       fontSize: 16
                                     ),
                                   )
                                  ],
                                )
                            ),

                            Visibility(
                                visible: userEditController.showExtraEquipmentEditPanel.value,
                                child: TextFormField(
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: AppColors.white,
                                  ),
                                  maxLines: 4,
                                  controller: userEditController.extraEquipmentsController.value,
                                  decoration: const InputDecoration(

                                    hintText: ('You can list the specific or technical information of your equipments'),
                                  ),
                                ),


                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Divider(),
                            SizedBox(
                              height: 10,
                            ),
                          ],
                        ) : SizedBox(height: 0,),

                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'Personal Website',
                                  style: TextStyle(color: Color(0xff00CC83),
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold),
                                ),
                                IconButton(onPressed: () {

                                  if (userEditController.showPersonalWebsiteEditingPanel.value) {


                                    userEditController.showPersonalWebsiteEditingPanel.value = false;
                                  }
                                  else{
                                    userEditController.showPersonalWebsiteEditingPanel.value = true;
                                  }
                                }, icon: Icon(
                                  Icons.edit, color: AppColors.mainColor,))
                              ],
                            ),

                            Visibility(
                                visible: !userEditController.showPersonalWebsiteEditingPanel.value,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    SizedBox(
                                      height: 6,
                                    ),
                                    Text(
                                      userEditController.personalWebController.value.text,
                                      style: TextStyle(
                                          color: AppColors.white,
                                          fontSize: 16
                                      ),
                                    )
                                  ],
                                )
                            ),

                            Visibility(
                              visible: userEditController.showPersonalWebsiteEditingPanel.value,
                              child: TextFormField(
                                style: TextStyle(
                                  fontSize: 14,
                                  color: AppColors.white,
                                ),
                                maxLines: 4,
                                controller: userEditController.personalWebController.value,
                              ),


                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Divider(),
                            SizedBox(
                              height: 10,
                            ),
                          ],
                        ),

                        userEditController.getUserInfo.value?.data?.user?.role != AppConst.CLIENT_ROLE ?
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: const [
                                Text(
                                  'Remuneration type',
                                  style: TextStyle(color: Color(0xff00CC83),
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold),
                                ),
                                SizedBox(
                                  width: 2,
                                ),
                                Padding(
                                  padding:
                                  EdgeInsets.only(bottom: 8.0),
                                  child: CircleAvatar(
                                    radius: 2,
                                    backgroundColor: Color(0xFF00CC83),
                                  ),
                                ),
                              ],
                            ),
                            Column(
                              children: <Widget>[
                                Row(
                                  children: <Widget>[
                                    Radio(
                                      value: 'price',
                                      fillColor: MaterialStateColor.resolveWith((states) => AppColors.white),

                                      activeColor: AppColors.mainColor,
                                      focusColor:AppColors.white,
                                      groupValue: userEditController.selectedValue.value,
                                      onChanged: (value) {
                                        setState(() {
                                          userEditController.selectedValue.value = value!;
                                          userEditController.pricePerDay.value.clear();
                                        });
                                      },
                                    ),
                                    Text('Price per hour',style: TextStyle(color: AppColors.white),),
                                  ],
                                ),
                                Row(
                                  children: <Widget>[
                                    Radio(
                                      fillColor: MaterialStateColor.resolveWith((states) => AppColors.white),
                                      activeColor: AppColors.mainColor,
                                      focusColor:AppColors.white,
                                      value: 'collaborate',
                                      groupValue: userEditController.selectedValue.value,
                                      onChanged: (value) {
                                        setState(() {
                                          userEditController.selectedValue.value = value!;
                                          userEditController.pricePerDay.value.text = userEditController.selectedValue.value;
                                        });
                                      },
                                    ),
                                    Text('Searching for collaboration',style: TextStyle(color: AppColors.white),),
                                  ],
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 18,
                            ),
                            userEditController.selectedValue == "price" ?  Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: const [
                                    Text(
                                      'Price per hour',
                                      style: TextStyle(
                                          fontSize: 12,
                                          color: AppColors.white,
                                          fontFamily: 'Poppins_SemiBold'
                                      ),
                                    ),
                                    SizedBox(
                                      width: 2,
                                    ),
                                    Padding(
                                      padding:
                                      EdgeInsets.only(bottom: 8.0),
                                      child: CircleAvatar(
                                        radius: 2,
                                        backgroundColor: Color(0xFF00CC83),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 5,),
                                const Text(
                                    'Set your daily or hourly price',
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontFamily: 'Poppins-Light',

                                      color: AppColors.textgrey,)
                                ),
                                SizedBox(height: 5,),

                                TextFormField(
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: AppColors.white,
                                  ),
                                  controller: userEditController.pricePerDay.value,
                                  keyboardType: TextInputType.number  ,
                                  validator: (String? value) {
                                    if (value?.isEmpty ?? true) {
                                      return 'Please Enter your day price';
                                    }
                                  },
                                  decoration: const InputDecoration(

                                    hintText: ('Your price per day/hour'),
                                  ),
                                ),
                              ],
                            ) : Center(),
                            userEditController.selectedValue == "collaborate" ?  Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: const [
                                    Text(
                                      'Collaborate',
                                      style: TextStyle(
                                          fontSize: 12,
                                          color: AppColors.white,
                                          fontFamily: 'Poppins_SemiBold'
                                      ),
                                    ),
                                    SizedBox(
                                      width: 2,
                                    ),
                                    Padding(
                                      padding:
                                      EdgeInsets.only(bottom: 8.0),
                                      child: CircleAvatar(
                                        radius: 2,
                                        backgroundColor: Color(0xFF00CC83),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 5,),
                                const Text(
                                  'I want to Collaborate',
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontFamily: 'Poppins-Light',
                                      color: Color(0xFFA1A1A1)),
                                ),
                                SizedBox(height: 5,),
                              ],
                            ) : Center(),
                            SizedBox(
                              height: 10,
                            ),
                          ],
                        ) : SizedBox(height: 0,),

                        userEditController.getUserInfo.value?.data?.user?.role == AppConst.CLIENT_ROLE ?
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Location',
                                    style: TextStyle(color: Color(0xff00CC83),
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold),
                                  ),

                                ],
                              ),

                              Visibility(
                                  visible: !userEditController.showLocationEditingPanel.value,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      SizedBox(
                                        height: 6,
                                      ),
                                      Row(
                                        children: [
                                          Text(
                                            'Country',
                                            style: TextStyle(
                                                fontSize: 12,
                                                color: AppColors.white,
                                                fontFamily: 'Poppins_SemiBold'),
                                          ),
                                          SizedBox(
                                            width: 2,
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(bottom: 8.0),
                                            child: CircleAvatar(
                                              radius: 2,
                                              backgroundColor: AppColors.mainColor,
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(
                                        height: 5,
                                      ),
                                      TextFormField(
                                        style: TextStyle(
                                            fontSize: 14,
                                            color: AppColors.white
                                        ),
                                        onTap: ()=>openCountryList(),
                                        readOnly: true,
                                        controller: userEditController.country.value,
                                        validator: (String? value) {
                                          if (value?.isEmpty ?? true) {
                                            return 'Please Enter your Country';
                                          }
                                        },
                                        decoration: InputDecoration(

                                          hintText: ('Choose a country'),
                                        ),
                                      ),
                                      SizedBox(
                                        height: 5,
                                      ),
                                      TextFormField(
                                        style: TextStyle(
                                            fontSize: 14,
                                            color: AppColors.white
                                        ),
                                        controller: userEditController.state.value,
                                        readOnly: true,
                                        onTap: (){
                                          if(userEditController.country.value.text.isNotEmpty){
                                            print("userEditController.countryId.value.toString() ${userEditController.countryId.value.text}");
                                            getStateFuture = getAllState(userEditController.countryId.value.text);
                                            openState(getAllState(userEditController.countryId.value.text));
                                          }else{
                                            AlertController.snackbar(context: context, text: "Please Select Country.", bg: Colors.red);
                                          }

                                        },
                                        // validator: (String? value) {
                                        //   if (value?.isEmpty ?? true) {
                                        //     return 'Please Enter your State Address';
                                        //   }
                                        // },
                                        decoration: InputDecoration(

                                          hintText: ('State'),
                                        ),
                                      ),
                                      SizedBox(
                                        height: 5,
                                      ),
                                      TextFormField(
                                        style: TextStyle(
                                            fontSize: 14,
                                            color: AppColors.white
                                        ),
                                        controller: userEditController.city.value,
                                        readOnly: true,
                                        onTap: (){
                                          if(userEditController.state.value.text.isNotEmpty){
                                            openCity();
                                          }else{
                                            AlertController.snackbar(context: context, text: "Please Select State.", bg: Colors.red);
                                          }
                                        },
                                        // validator: (String? value) {
                                        //   if (value?.isEmpty ?? true) {
                                        //     return 'Please Enter your city';
                                        //   }
                                        // },
                                        decoration: const InputDecoration(

                                          hintText: ('Choose a city'),
                                        ),
                                      ),
                                      SizedBox(
                                        height: 5,
                                      ),
                                      TextFormField(
                                        style: TextStyle(
                                            fontSize: 14,
                                            color: AppColors.white
                                        ),
                                        controller: userEditController.zipcode.value,
                                        validator: (String? value) {
                                          if (value?.isEmpty ?? true) {
                                            return 'Please Enter your Zipcode';
                                          }
                                        },
                                        decoration: InputDecoration(

                                          hintText: ('Zip code'),
                                        ),
                                      ),
                                      SizedBox(
                                        height: 5,
                                      ),
                                      TextFormField(
                                        style: TextStyle(
                                            fontSize: 14,
                                            color: AppColors.white
                                        ),
                                        focusNode: _focusNode,
                                        controller: userEditController.address.value,
                                        // validator: (String? value) {
                                        //   if (value?.isEmpty ?? true) {
                                        //     return 'Please Enter your address';
                                        //   }
                                        // },
                                        decoration: InputDecoration(

                                          hintText: ('Address'),
                                        ),
                                      ),
                                      SizedBox(
                                        height: 5,
                                      ),

                                    ],
                                  )
                              ),
                              SizedBox(
                                height: 10,
                              ),
                            ],
                          ) : SizedBox(height: 0,),



                        Divider(),
                        SizedBox(
                          height: 10,
                        ),

                        // userEditController.getUserInfo.value?.data?.user?.role == AppConst.CLIENT_ROLE
                        //     ? Column(
                        //   crossAxisAlignment: CrossAxisAlignment.start,
                        //   children: [
                        //
                        //     const Text(
                        //       'Spoken language',
                        //       style: TextStyle(color: Color(0xff00CC83),
                        //           fontSize: 15,
                        //           fontWeight: FontWeight.bold),
                        //     ),
                        //     SizedBox(
                        //       height: 2,
                        //     ),
                        //     Row(
                        //       children: [
                        //         Expanded(
                        //           child: Text(
                        //
                        //             '${userEditController.language}',
                        //             style: TextStyle(fontSize: 15,color: AppColors.white),
                        //           ),
                        //         ),
                        //         SizedBox(width: 30.w,),
                        //         IconButton(onPressed: () {
                        //           Get.to(AddLanguage(isupdate: true,));
                        //         },
                        //             icon: Icon(
                        //               Icons.edit, color: AppColors.mainColor,)),
                        //         // SizedBox(
                        //         //     width: 50,
                        //         //     height: 45,
                        //         //     child: ElevatedButton(
                        //         //         style: OutlinedButton.styleFrom(
                        //         //           backgroundColor: Color(0xFF00CC83),
                        //         //         ),
                        //         //         onPressed: () {
                        //         //           Get.to(AddLanguage(isupdate: true,));
                        //         //         },
                        //         //         child: Text(
                        //         //           'Edit',
                        //         //           style: TextStyle(fontFamily: 'Poppins_SemiBold',fontSize: 12),
                        //         //         )
                        //         //     )),
                        //       ],
                        //     ),
                        //
                        //     Divider(),
                        //     SizedBox(
                        //       height: 10,
                        //     ),
                        //
                        //     Text(
                        //       'Phone number',
                        //       style: TextStyle(color: Color(0xff00CC83),
                        //           fontSize: 15,
                        //           fontWeight: FontWeight.bold),
                        //     ),
                        //     SizedBox(
                        //       height: 6,
                        //     ),
                        //     InkWell(
                        //       onTap: () {
                        //         setState(() {
                        //           username = false;
                        //           email = false;
                        //           description = false;
                        //           phone = !phone;
                        //         });
                        //       },
                        //       child: phone ? TextFormField(
                        //           style: TextStyle(
                        //               color: AppColors.white
                        //           ),
                        //           controller: userEditController.phoneController.value,
                        //           autofocus: true,
                        //           decoration: InputDecoration(
                        //               fillColor: AppColors.black,
                        //               contentPadding: EdgeInsets.zero,
                        //               hintText: userEditController.getUserInfo.value?.data!.user!
                        //                   .phone ?? 'No Phone Found',
                        //               hintStyle: TextStyle(
                        //                   color: AppColors.white, fontSize: 16
                        //               )
                        //           )) : Text(
                        //         "${userEditController.getUserInfo.value?.data!.user!.phone}",
                        //         style: TextStyle(
                        //             color: AppColors.white, fontSize: 16),
                        //       ),
                        //     ),
                        //
                        //     Divider(),
                        //
                        //     SizedBox(
                        //       height: 10,
                        //     ),
                        //     Divider(),
                        //     SizedBox(
                        //       height: 10,
                        //     ),
                        //
                        //     Text(
                        //       'Email',
                        //       style: TextStyle(color: Color(0xff00CC83),
                        //           fontSize: 15,
                        //           fontWeight: FontWeight.bold),
                        //     ),
                        //     SizedBox(
                        //       height: 6,
                        //     ),
                        //     InkWell(
                        //       onTap: () {
                        //         setState(() {
                        //           // username = false;
                        //           // email = !email;
                        //           // description = false;
                        //           // phone = false;
                        //         });
                        //       },
                        //       child: email ?
                        //       TextFormField(
                        //           style: TextStyle(
                        //               color: AppColors.white
                        //           ),
                        //           enabled: true,
                        //           controller: userEditController.EmailController.value,
                        //           autofocus: true,
                        //           decoration: InputDecoration(
                        //               contentPadding: EdgeInsets.zero,
                        //              fillColor: AppColors.black,
                        //               hintStyle: TextStyle(
                        //                   color: AppColors.white, fontSize: 16
                        //               )
                        //           ))
                        //           : Text(
                        //         "${userEditController.getUserInfo.value?.data!.user!.email}",
                        //         style: TextStyle(
                        //             color: AppColors.white, fontSize: 16),
                        //       ),
                        //     ),
                        //     SizedBox(
                        //       height: 10,
                        //     ),
                        //     Divider(),
                        //   ],
                        // )
                        //     : SizedBox(height: 0,),


                        userEditController.getUserInfo.value?.data?.user?.role == AppConst.CLIENT_ROLE
                            ? Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Opening Hour',
                                    style: TextStyle(color: Color(0xff00CC83),
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  IconButton(onPressed: () {
                                    Get.to(EditDayTime(from: "edit",));
                                  },
                                      icon: Icon(
                                        Icons.edit, color: AppColors.mainColor,)),
                                ],
                              ),
                              SizedBox(
                                height: 6,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    width: MediaQuery.of(context).size.width*.60,
                                      child: ListView.builder(
                                          shrinkWrap: true,
                                          physics: NeverScrollableScrollPhysics(),
                                          itemCount: hours.length,
                                          itemBuilder:(_, index){
                                            return Container(
                                              padding: EdgeInsets.only(bottom: 5, top: 5),
                                              decoration: BoxDecoration(
                                                border: Border(
                                                  bottom: BorderSide(width: 1, color: Colors.black)
                                                )
                                              ),
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,

                                                children: [
                                                  Flexible(
                                                    flex: 1, // This takes half of the available space
                                                    child: Text(
                                                      '${hours[index]["day"]}: ',
                                                      style: TextStyle(color: Colors.white),
                                                    ),
                                                  ),
                                                  Flexible(
                                                    flex: 1, // This also takes half of the available space
                                                    child: hours[index]["open"] == "00 "
                                                        ? Text(
                                                      '${"Open 24 hours "}',
                                                      style: TextStyle(
                                                        color: hours[index]["open"] == "Close "
                                                            ? Colors.red
                                                            : hours[index]["open"] == "00 "
                                                            ? AppColors.mainColor
                                                            : Colors.white,
                                                      ),
                                                    )
                                                        : SizedBox(
                                                      width: MediaQuery.of(context).size.width * 0.35,
                                                      child: Text(
                                                        '${hours[index]["open"]}',
                                                        style: TextStyle(
                                                          color: hours[index]["open"] == "Close "
                                                              ? Colors.red
                                                              : hours[index]["open"] == "00 "
                                                              ? AppColors.mainColor
                                                              : Colors.white,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              )


                                            );
                                          }
                                      ),
                                  ),

                                  // SizedBox(
                                  //     width: 50,
                                  //     height: 45,
                                  //     child: ElevatedButton(
                                  //         style: OutlinedButton.styleFrom(
                                  //           backgroundColor: Color(0xFF00CC83),
                                  //         ),
                                  //         onPressed: () {
                                  //           Get.to(LocationEdit(p_Country: userEditController.getUserInfo.value?.data!.location?.country,p_State:userEditController.getUserInfo.value?.data!.location?.state, p_city: userEditController.getUserInfo.value?.data!.location?.city, p_zipcode: '', p_address: userEditController.getUserInfo.value?.data!.location?.city,));
                                  //         },
                                  //         child: Text(
                                  //           'Edit',
                                  //           style: TextStyle(fontFamily: 'Poppins_SemiBold',fontSize: 12),
                                  //         )
                                  //     )),
                                ],
                              ),
                              SizedBox(
                                height: 10,
                              ),


                              Divider(),
                              SizedBox(
                                height: 10,
                              ),
                            ])
                            : SizedBox(height: 0,),

                         Row(
                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
                           children: [
                             Text(
                              'Follow me',
                              style: TextStyle(color: Color(0xff00CC83),
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold),
                        ),
                             IconButton(onPressed: () {
                               userEditController.getUserInfo.value?.data?.user?.role ==
                                   AppConst.CLIENT_ROLE ? Get.to(
                                   CreateProfileStep3(isFromEditingScreen: true,
                                     role: AppConst.CLIENT_ROLE,)) : Get.to(
                                   CreateProfileStep3(isFromEditingScreen: true,
                                     role: AppConst.FREELANCER_ROLE,));
                             },
                                 icon: Icon(
                                   Icons.edit, color: AppColors.mainColor,)),
                           ],
                         ),
                        SizedBox(
                          height: 5,
                        ),
                        SizedBox(
                          height: 50,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              SizedBox(
                                height: 35,
                                child: ListView(
                                  shrinkWrap: true,
                                  scrollDirection: Axis.horizontal,
                                  children: [
                                    userEditController.getUserInfo.value?.data!.user!.social!
                                        .instagram != "null" ? InkWell(
                                      onTap: () {
                                        print("cliecnt inta === ${userEditController.getUserInfo.value?.data!.user!.social!.instagram}");
                                        launchUrl(Uri.parse(
                                            "${userEditController.getUserInfo.value?.data!.user!.social!
                                                .instagram!}"));
                                      },
                                      child: Container(
                                        height: 35,
                                        width: 35,
                                        margin: EdgeInsets.only(right: 20),
                                        //padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(
                                                100),
                                            color: AppColors.white,
                                            border: Border.all(width: 1,
                                                color: AppColors.mainColor)
                                        ),
                                        child: Center(child: FaIcon(
                                          FontAwesomeIcons.instagram,
                                          color: AppColors.mainColor, size: 20,)),
                                      ),
                                    ) : Center(),
                                    userEditController.getUserInfo.value?.data!.user!.social!.facebook !=
                                        "null" ? InkWell(
                                      onTap: () {
                                        print("cliecnt inta === ${userEditController.getUserInfo.value?.data!.user!.social!.facebook}");
                                        launchUrl(Uri.parse(
                                            "${userEditController.getUserInfo.value?.data!.user!.social!
                                                .instagram!}"));
                                      },
                                      child: Container(
                                        height: 35,
                                        width: 35,
                                        margin: EdgeInsets.only(right: 20),
                                        //padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(
                                                100),
                                            color: AppColors.white,
                                            border: Border.all(width: 1,
                                                color: AppColors.mainColor)
                                        ),
                                        child: Center(child: FaIcon(
                                          FontAwesomeIcons.facebook,
                                          color: AppColors.mainColor, size: 20,)),
                                      ),
                                    ) : Center(),

                                    userEditController.getUserInfo.value?.data!.user!.social!.youtube !=
                                        "null" ? InkWell(
                                      onTap: () {
                                        launchUrl(Uri.parse(
                                            "${userEditController.getUserInfo.value?.data!.user!.social!
                                                .youtube!}"));
                                      },
                                      child: Container(
                                        margin: EdgeInsets.only(right: 20),
                                        height: 35,
                                        width: 35,
                                        //padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(
                                                100),
                                            color: AppColors.white,
                                            border: Border.all(width: 1,
                                                color: AppColors.mainColor)
                                        ),
                                        child: Center(child: FaIcon(
                                          FontAwesomeIcons.youtube,
                                          color: AppColors.mainColor, size: 20,)),
                                      ),
                                    ) : Center(),

                                    userEditController.getUserInfo.value?.data!.user!.social!.behance !=
                                        "null" ? InkWell(
                                      onTap: () {
                                        launchUrl(Uri.parse(
                                            "${userEditController.getUserInfo.value?.data!.user!.social!
                                                .behance!}"));
                                      },
                                      child: Container(
                                        margin: EdgeInsets.only(right: 20),
                                        height: 35,
                                        width: 35,
                                        //padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(
                                                100),
                                            color: AppColors.white,
                                            border: Border.all(width: 1,
                                                color: AppColors.mainColor)
                                        ),
                                        child: Center(child: FaIcon(
                                          FontAwesomeIcons.behance,
                                          color: AppColors.mainColor, size: 20,)),
                                      ),
                                    ) : Center(),

                                    userEditController.getUserInfo.value?.data!.user!.social!.tiktok !=
                                        "null" ? InkWell(
                                      onTap: () {
                                        launchUrl(Uri.parse(
                                            "${userEditController.getUserInfo.value?.data!.user!.social!
                                                .tiktok!}"));
                                      },
                                      child: Container(
                                        margin: EdgeInsets.only(right: 20),
                                        height: 35,
                                        width: 35,
                                        //padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(
                                                100),
                                            color: AppColors.white,
                                            border: Border.all(width: 1,
                                                color: AppColors.mainColor)
                                        ),
                                        child: Center(child: FaIcon(
                                          FontAwesomeIcons.tiktok,
                                          color: AppColors.mainColor, size: 20,)),
                                      ),
                                    ) : Center(),

                                    userEditController.getUserInfo.value?.data!.user!.social!.vimeo !=
                                        "null" ? InkWell(
                                      onTap: () {
                                        launchUrl(Uri.parse(
                                            "${userEditController.getUserInfo.value?.data!.user!.social!
                                                .vimeo!}"));
                                      },
                                      child: Container(
                                        margin: EdgeInsets.only(right: 20),
                                        height: 35,
                                        width: 35,
                                        //padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(
                                                100),
                                            color: AppColors.white,
                                            border: Border.all(width: 1,
                                                color: AppColors.mainColor)
                                        ),
                                        child: Center(child: FaIcon(
                                          FontAwesomeIcons.vimeo,
                                          color: AppColors.mainColor, size: 20,)),
                                      ),
                                    ) : Center(),

                                    userEditController.getUserInfo.value?.data!.user!.social!.dribble !=
                                        "null" ? InkWell(
                                      onTap: () {
                                        AuthController.launchUrl(
                                            userEditController.getUserInfo.value?.data!.user!.social!
                                                .dribble!);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.only(right: 20),
                                        height: 35,
                                        width: 35,
                                        //padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(
                                                100),
                                            color: AppColors.white,
                                            border: Border.all(width: 1,
                                                color: AppColors.mainColor)
                                        ),
                                        child: Center(child: FaIcon(
                                          FontAwesomeIcons.dribbble,
                                          color: AppColors.mainColor, size: 20,)),
                                      ),
                                    ) : Center(),
                                  ],
                                ),
                              ),
                              SizedBox(width: 20,),

                              // SizedBox(
                              //     width: 50,
                              //     height: 45,
                              //     child: ElevatedButton(
                              //         style: OutlinedButton.styleFrom(
                              //           backgroundColor: Color(0xFF00CC83),
                              //         ),
                              //         onPressed: () =>userEditController.getUserInfo.value?.data?.user?.role == AppConst.CLIENT_ROLE ? Get.to(CreateProfileStep3(isFromEditingScreen: true, role: AppConst.CLIENT_ROLE ,)) : Get.to(CreateProfileStep3(isFromEditingScreen: true, role: AppConst.FREELANCER_ROLE,)),
                              //         child: Text(
                              //           'Edit',
                              //           style: TextStyle(fontFamily: 'Poppins_SemiBold',fontSize: 12),
                              //         )
                              //     )),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text("Cover Photo",
                              style: TextStyle(color: Color(0xff00CC83),
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold),
                            ),
                            IconButton(onPressed: () {
                              _pickImage(ImageSource.gallery, "cover");
                              }, icon: Icon(
                              Icons.edit, color: AppColors.mainColor,)),
                            // SizedBox(
                            //   width: 50,
                            //   height: 45,
                            //   child: ElevatedButton(
                            //       style: OutlinedButton.styleFrom(
                            //         backgroundColor: Color(0xFF00CC83),
                            //       ),
                            //       onPressed: ()=>chosePhoto(),
                            //       child: Text(
                            //         'Edit',
                            //         style: TextStyle(fontFamily: 'Poppins_SemiBold',fontSize: 12),
                            //       )
                            //   ),
                            // )
                          ],
                        ),
                        SizedBox(
                          height: 10,
                        ),

                        InkWell(
                          onTap: () => _pickImage(ImageSource.gallery, "cover"),
                          child: ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: _cropCover != null
                                  ? Image.file(_cropCover!, width: MediaQuery
                                  .of(context)
                                  .size
                                  .width, height: 400, fit: BoxFit.cover,)
                                  : Container(
                                   //height: 400,
                                  decoration: BoxDecoration(
                                      color: AppColors.black,
                                      // borderRadius: BorderRadius.circular(5),
                                  ),
                                  child: CachedNetworkImage(
                                    imageUrl: userEditController.getUserInfo.value?.data!.user!.coverImage ?? "",
                                    fit: BoxFit.cover,
                                    height: 180,
                                    width: double.infinity,
                                    progressIndicatorBuilder: (context, url, downloadProgress) =>
                                        SizedBox(height: 30, width: 30, child: Center(child: CircularProgressIndicator(color: AppColors.white,),)),
                                    errorWidget: (context, url, error) => Center(child: Text("Cover photo not found", style: TextStyle(color: AppColors.white),)),
                                  )
                              )
                          ),
                        )

                      ],
                    ),
                  )
        ),
      ),
    );
  }


  ////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////// edit profile //////////////////////////
  //final cropKey = GlobalKey<CropState>();

//   late File _lastCropped;
//   _cropImages(originalFile)async{
//
//     final crop = cropKey.currentState;
// // final crop = Crop.of(context);
//     final scale = crop?.scale;
//     final area = crop?.area;
//     if (area == null) {
//       // cannot crop, widget is not setup
//       // ...
//       debugPrint("area is empty $area");
//       return;
//     }
//     debugPrint("area is empty $area");
//
//     debugPrint("permission === ${await ImageCrop.requestPermissions()}");
//
//     final sampleFile = await ImageCrop.sampleImage(
//       file: originalFile,
//       preferredWidth: 800,
//       preferredHeight: 400,
//     );
//
//     final croppedFile = await ImageCrop.cropImage(
//       file: sampleFile,
//       area: area,
//     );
//     setState(() {
//       image = croppedFile;
//     });
//     debugPrint("croppedFile === ${croppedFile}");
//
//
//
//   }



  ////////// chossse images /////////







  ////////// pick profile image////////
  var profileImage;
  var coverImage;
  Future<void> _pickImage(ImageSource type, from) async {
    ImagePicker picker = ImagePicker();
    XFile? pickedFile = await picker.pickImage(source: type);
    if (pickedFile != null) {
      if(from == "profile"){

        setState(() {
          profileImage =  File(pickedFile!.path);
        });
        _cropImage(profileImage, from);
      }else{
        setState(() {
          coverImage =  File(pickedFile!.path);
        });
        _cropImage(coverImage, from);
      }

      // Handle the picked image, e.g., display it in an image widget or upload it
      // to a server.
    }
  }

  File? _cropProfile;
  File? _cropCover;
  Future<void> _cropImage(file, type) async {
    if (file != null) {
      final croppedFile = await ImageCropper().cropImage(
        maxHeight: 400,
        maxWidth: 800,
        aspectRatio: CropAspectRatio(
            ratioX: 1, ratioY: 1
        ),
        sourcePath: file!.path,
        compressFormat: ImageCompressFormat.jpg,
        compressQuality: 100,
        uiSettings: [
          AndroidUiSettings(
              toolbarTitle: 'Profile Photo',
              toolbarColor: Colors.black,
              toolbarWidgetColor: Colors.white,
              initAspectRatio: CropAspectRatioPreset.original,
              lockAspectRatio: false),
          IOSUiSettings(
            title: 'Profile Photo',
          ),
          WebUiSettings(
            context: context,
            presentStyle: CropperPresentStyle.dialog,
            boundary: const CroppieBoundary(
              width: 520,
              height: 520,
            ),
            viewPort: const CroppieViewPort(width: 480, height: 480, type: 'circle'),
            enableExif: true,
            enableZoom: true,
            showZoomer: true,
          ),
        ],
      );
      if (croppedFile != null) {
        setState(() {
          if(type=="profile"){
            _cropProfile = File(croppedFile.path);
            _uploadPortfolio(_cropProfile);
          }else{
            _cropCover = File(croppedFile.path);
            _uploadCoverImage(_cropCover);
          }
        });
      }
    }
  }

  bool isLoading = false;



  void _uploadCoverImage(file) async {
    setState(() => isLoading = true);
    AlertController.snackbar(context: context,
        text: "Cover image uploading....",
        bg: AppColors.mainColor.withOpacity(0.7));
    var res = await AuthController.uploadCoverImage(images: file);

    print("response === ${res.statusCode}");
    print("response === ${res.stream.map((event) => print(event))}");
    if (res.statusCode == 200) {
      AlertController.snackbar(context: context,
          text: "Cover image uploaded success.",
          bg: Colors.green);
    } else {
      AlertController.snackbar(context: context,
          text: "Something went wrong with server.",
          bg: Colors.red);
    }
    setState(() => isLoading = false);
  }

////////////////////////////////////////////////////////////////////////////
//////////////////////////////////// edit profile //////////////////////////


  File? profileimage;

  ////////// pick profile image////////
  Future<void> profilepickImage(ImageSource type) async {
    ImagePicker picker = ImagePicker();
    XFile? pickedFile = await picker.pickImage(source: type);
    if (pickedFile != null) {
      setState(() {
        profileimage = File(pickedFile!.path);
        _uploadPortfolio(profileimage);
      });

      // Handle the picked image, e.g., display it in an image widget or upload it
      // to a server.
    }
  }




  void _updateprofile() async {
    setState(() => isLoading = true);

    print("username === ${userEditController.usernameController.value.text}");
    print("description === ${userEditController.DescriptionController.value.text}");
    print("phonenumber === ${userEditController.phoneController.value.text}");
    print("email === ${userEditController.EmailController.value.text}");

    // Map<String, String> params = {
    //   if (userEditController.usernameController.value.text.isNotEmpty && userEditController.usernameController.value.text != 'No name found') 'username': userEditController.usernameController.value.text,
    //   if (userEditController.DescriptionController.value.text.isNotEmpty) 'description': userEditController.DescriptionController.value.text,
    //   if (userEditController.phoneController.value.text.isNotEmpty && userEditController.phoneController.value.text != 'No phone found') 'phonenumber': userEditController.phoneController.value.text,
    //   if (userEditController.EmailController.value.text.isNotEmpty) 'email': userEditController.EmailController.value.text,
    // };

    print(userEditController.usernameController.value.text);

    print(userEditController.pricePerDay.value.text);
    var res = await AuthController.profileUpdate(

      username: userEditController.usernameController.value.text,
      description: userEditController.DescriptionController.value.text,
      phonenumber: userEditController.phoneController.value.text,
      email: userEditController.EmailController.value.text,
      serviceList: userEditController.selectedSkill.toString(),
      equipmentsList: userEditController.selectEquipments.toString(),
      extraEquipments: userEditController.selectEquipments.toString(),
      pricePerDay: userEditController.pricePerDay.value.text,
      website: userEditController.personalWebController.value.text,
      zipcode: userEditController.zipcode.value.text,
      address: userEditController.address.value.text,
    );
    print("response profile update ==== ${res.body}");
    print("response ==== ${res.statusCode}");
    var data = jsonDecode(res.body);
    if (res.statusCode == 200) {
      SharedPreferences pref = await SharedPreferences.getInstance();
      String? ownUserId = pref.getString("user_id");

      /////////// get user information again
      userEditController.role == AppConst.FREELANCER_ROLE ? Get.to(
          FreelancerAppBottomNavigation(pageIndex: 4,userId:ownUserId)) : Get.to(
          ClientBottomNavigationBar(pageIndex: 3,userId:ownUserId));
    } else {
      AlertController.snackbar(
          context: context, text: "${data["message"]}", bg: Colors.red);
    }
  }




  void _uploadPortfolio(file) async {
    setState(() => isLoading = true);
    AlertController.snackbar(context: context,
        text: "Profile uploading....",
        bg: AppColors.mainColor.withOpacity(0.7));
    var res = await AuthController.uploadProfile(images: file);

    print("response === ${res.statusCode}");
    print("response === ${res.stream.map((event) => print(event))}");
    if (res.statusCode == 200) {
      AlertController.snackbar(context: context,
          text: "Profile uploaded success.",
          bg: Colors.green);
    } else {
      AlertController.snackbar(context: context,
          text: "Something went wrong with server.",
          bg: Colors.red);
    }
    setState(() => isLoading = false);
  }





}
