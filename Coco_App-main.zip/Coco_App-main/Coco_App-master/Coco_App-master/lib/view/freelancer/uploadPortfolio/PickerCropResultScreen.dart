// import 'dart:io';
//
// import 'package:coco/appConst.dart';
// import 'package:coco/controller/authController.dart';
// import 'package:coco/controller/postController.dart';
// import 'package:coco/main.dart';
// import 'package:coco/model/postModel/PostModel.dart';
// import 'package:coco/view/Client/bottomNagivation/buttom_nav.dart';
// import 'package:coco/viewController/alartController.dart';
// import 'package:coco/viewController/appNetworkImage.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
// import '../../../utility/colors.dart';
// import '../bottomNavigationBar/becameFreelanceBottomNavigation.dart';
// import '../profile/freelancerProfile.dart';
//
// class PickerCropResultScreen extends StatefulWidget {
//   const PickerCropResultScreen({super.key, this.cropStream, this.listImage, this.postId, this.description, this.title, this.isStory = false});
//
//   final List<Images>? listImage;
//   final String? postId;
//   final String? description;
//   final String? title;
//   final bool? isStory;
//
//
//   @override
//   State<PickerCropResultScreen> createState() => _PickerCropResultScreenState();
// }
//
// class _PickerCropResultScreenState extends State<PickerCropResultScreen> {
//   final discription = TextEditingController();
//
//   final postKey = GlobalKey<FormState>();
//   List filePath = [];
//
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     print("images ==== ${widget!.cropStream}");
//     discription.text = widget.description ?? "";
//   }
//   List<File> file = [];
//
//   @override
//   Widget build(BuildContext context) {
//     var size = MediaQuery.of(context).size;
//     final height = MediaQuery.of(context).size.height - kToolbarHeight;
//
//     return Scaffold(
//       appBar: AppBar(
//         backgroundColor: Colors.white,
//         elevation: 0,
//         leading: IconButton(
//           onPressed: (){
//             Get.back();
//           },
//           icon:  Icon(Icons.close, color: Colors.black,),
//         ),
//         title:  Text(widget.title!=null? "${widget.title}": 'New Portfolio',
//           style: TextStyle(
//               fontWeight: FontWeight.w600,
//               color: Colors.black
//           ),
//         ),
//         actions: [
//           IconButton(
//             onPressed: (){
//               if(widget.isStory == true){
//                 _uploadSotry();
//               }else{
//                 widget.listImage !=null ?_editPortfolio(widget.postId.toString()) :_uploadPortfolio();
//               }
//             },
//             icon: isLoading || isEditing?Padding(
//               padding: const EdgeInsets.only(top: 3.0, bottom: 3),
//               child: CircularProgressIndicator(color: AppColors.mainColor, strokeWidth: 1,),
//             ) : Icon(Icons.arrow_forward, color: AppColors.mainColor,),
//           ),
//         ],
//       ),
//       body: widget.listImage !=null
//           ? SingleChildScrollView(
//         child: Form(
//           key: postKey,
//           child: Column(
//             children: [
//               SizedBox(
//                 width: size.width,
//                 height: 300,
//                 child: ListView.builder(
//                   shrinkWrap: true,
//                   scrollDirection: Axis.horizontal,
//                   itemCount: widget.listImage!.length,
//                   itemBuilder: (_, index){
//                     return Stack(
//                       children: [
//                         Container(
//                             margin: EdgeInsets.only(right: 10),
//                             width: widget.listImage!.length == 1 ? size.width : size.width*.80,
//                             child: AppNetworkImage(src: widget.listImage![index]!.image!, height: 300, fit: BoxFit.cover,)),
//                         Positioned(
//                             right: 15, top: 5,
//                             child: Container(
//                                 decoration: BoxDecoration(
//                                   borderRadius: BorderRadius.circular(100),
//                                   color: Colors.white
//                                 ),
//                                 child: isDeleting? CircularProgressIndicator(strokeWidth: 1, color: AppColors.mainColor,) : IconButton(onPressed: ()=>_deletePostImage(widget.listImage![index]!.id!, index), icon: Icon(Icons.close, color: Colors.black,))))
//                       ],
//                     );
//                     // return Row(
//                     //   children: [
//                     //     Container(
//                     //         margin: EdgeInsets.only(right: 10),
//                     //         width: size.width*.80,
//                     //         child: Stack(
//                     //           children: [
//                     //             AppNetworkImage(src: widget.listImage![index]!.image!, height: 300, fit: BoxFit.cover,),
//                     //             Positioned(
//                     //                 right: 0, top: 0,
//                     //                 child: IconButton(onPressed: ()=>_deletePostImage(widget.listImage![index]!.id!), icon: Icon(Icons.delete_forever, color: Colors.red,)))
//                     //           ],
//                     //         )),
//                     //     index == widget.listImage!.length-1 ? InkWell(
//                     //      // onTap: ()=>updatePostImageSelect(),
//                     //       child: Container(
//                     //         margin: EdgeInsets.only(right: 10),
//                     //         width: size.width*.80,
//                     //         height: 300,
//                     //         child: IconButton(onPressed: (){}, icon: Icon(Icons.add),),
//                     //       ),
//                     //     ): Center()
//                     //   ],
//                     // );
//                   },
//                 ),
//               ),
//               SizedBox(height: 20,),
//               Padding(
//                 padding: const EdgeInsets.only(left: 20.0, right: 20),
//                 child: Row(
//                   children: [
//                     Text("Description",
//                       style: TextStyle(
//                           fontSize: 12,
//                           fontWeight: FontWeight.bold,
//                           color: Colors.black
//                       ),
//                     ),
//                     Icon(Icons.star, color: AppColors.mainColor, size: 15,)
//                   ],
//                 ),
//               ),
//               Padding(
//                 padding: const EdgeInsets.only(left: 20, right: 20, top: 10),
//                 child: TextFormField(
//                   textInputAction: TextInputAction.done,
//                   autofocus: true,
//                   maxLines: 7,
//                   controller: discription,
//                   decoration: const InputDecoration(
//                       contentPadding: EdgeInsets.all(10),
//                       border: OutlineInputBorder(
//                           borderSide: BorderSide(width: 1, color: Color(0xffE1E1E1))
//                       ),
//                       enabledBorder: OutlineInputBorder(
//                           borderSide: BorderSide(width: 1, color: Color(0xffE1E1E1))
//                       ),
//                       focusedBorder: OutlineInputBorder(
//                           borderSide: BorderSide(width: 1, color: Color(0xffE1E1E1))
//                       ),
//                       hintText: "Share a bit about your work experience, your projects...",
//                       hintStyle: TextStyle(
//                           fontWeight: FontWeight.w200,
//                           fontSize: 10
//                       )
//                   ),
//                   validator: (v){
//                     if(v!.isEmpty){
//                       return "Description must not be empty";
//                     }else{
//                       return null;
//                     }
//                   },
//                 ),
//               )
//             ],
//           ),
//         ),
//       )
//           :  StreamBuilder<InstaAssetsExportDetails>(
//           stream: widget.cropStream,
//           builder: (context, snapshot){
//             file.clear();
//             filePath.clear();
//             for(var i = 0; i < snapshot.data!.croppedFiles.length; i++ ){
//               file.add(snapshot.data!.croppedFiles[i]!);
//               print("this is file === ${file}");
//             }
//             for(var i=0;i<file.length;i++){
//               filePath.add(file[i]!.path);
//             }
//             if(snapshot.connectionState == ConnectionState.waiting){
//               return Center(child: CircularProgressIndicator(strokeWidth: 1, color: Colors.black,),);
//             }else if(snapshot.hasData){
//               return SingleChildScrollView(
//                 child: Form(
//                   key: postKey,
//                   child: Column(
//                     children: [
//                       SizedBox(
//                         width: size.width,
//                         height: 300,
//                         child: ListView.builder(
//                           shrinkWrap: true,
//                           scrollDirection: Axis.horizontal,
//                           itemCount: file.length,
//                           itemBuilder: (_, index){
//                             return Container(
//                                 margin: EdgeInsets.only(right: 10),
//                                 width:  file.length ==1 ? size.width : size.width*.80,
//                                 child: Image.file(file[index], width: size.width, height: 300, fit: BoxFit.cover,));
//                           },
//                         ),
//                       ),
//                       SizedBox(height: 20,),
//                       Padding(
//                         padding: const EdgeInsets.only(left: 20.0, right: 20),
//                         child: Row(
//                           children: [
//                             Text("Description",
//                               style: TextStyle(
//                                   fontSize: 12,
//                                   fontWeight: FontWeight.bold,
//                                   color: Colors.black
//                               ),
//                             ),
//                             Icon(Icons.star, color: AppColors.mainColor, size: 15,)
//                           ],
//                         ),
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.only(left: 20, right: 20, top: 10),
//                         child: TextFormField(
//                           maxLines: 7,
//                           controller: discription,
//                           decoration: const InputDecoration(
//                               contentPadding: EdgeInsets.all(10),
//                               border: OutlineInputBorder(
//                                   borderSide: BorderSide(width: 1, color: Color(0xffE1E1E1))
//                               ),
//                               enabledBorder: OutlineInputBorder(
//                                   borderSide: BorderSide(width: 1, color: Color(0xffE1E1E1))
//                               ),
//                               focusedBorder: OutlineInputBorder(
//                                   borderSide: BorderSide(width: 1, color: Color(0xffE1E1E1))
//                               ),
//                               hintText: "Share a bit about your work experience, your projects...",
//                               hintStyle: TextStyle(
//                                   fontWeight: FontWeight.w200,
//                                   fontSize: 10
//                               )
//                           ),
//                           validator: (v){
//                             if(v!.isEmpty){
//                               return "Description must not be empty";
//                             }else{
//                               return null;
//                             }
//                           },
//                         ),
//                       )
//                     ],
//                   ),
//                 ),
//               );
//             }else{
//               return const Center(
//                 child: Text("No photo selected"),
//               );
//             }
//
//
//           }
//         //     CropResultView(
//         //   selectedAssets: snapshot.data?.selectedAssets ?? [],
//         //   croppedFiles: snapshot.data?.croppedFiles ?? [],
//         //   progress: snapshot.data?.progress,
//         //   heightFiles: height / 2,
//         //   heightAssets: height / 4,
//         // ),
//       ),
//     );
//   }
//
//   bool isLoading = false;
//
//   void _uploadPortfolio() async{
//     setState(() =>isLoading=true);
//     print("filePath ==== ${filePath}");
//     if(filePath.isEmpty){
//       AlertController.snackbar(context: context, text: "Please select images", bg: Colors.red);
//     }else{
//       if(postKey!.currentState!.validate()){
//         var res = await PostController.createPost(dec: discription.text, images: file);
//
//         print("response === ${res.statusCode}");
//         if(res.statusCode == 200){
//           Get.to(ClientBottomNavigationBar(pageIndex: 3,));
//           AlertController.snackbar(context: context, text: "Post Create was success", bg: Colors.green);
//         }else{
//           AlertController.snackbar(context: context, text: "Something went wrong with server.", bg: Colors.red);
//         }
//       }
//     }
//
//
//     setState(() =>isLoading=false);
//   }
//
//
//   void _uploadSotry() async{
//     SharedPreferences _pref = await SharedPreferences.getInstance();
//     var role = _pref.getString("role");
//     setState(() {
//       isLoading=true;
//     });
//     AlertController.snackbar(context: context, text: "Story uploading...", bg: AppColors.mainColor.withOpacity(0.7));
//     var  res = await AuthController.uploadStory(images: file[0], description: discription.text);
//     print("response === ${res.statusCode}");
//
//     if(res.statusCode == 200){
//       AlertController.snackbar(context: context, text: "Story uploaded successfully.", bg: Colors.green);
//       if(role == AppConst.FREELANCER_ROLE){
//         Get.to(FreelancerAppBottomNavigation());
//       }else{
//         Get.to(ClientBottomNavigationBar());
//       }
//     }else{
//       AlertController.snackbar(context: context, text: "Something went wrong with server.", bg: Colors.red);
//     }
//     setState(() {
//       isLoading=false;
//     });
//     if (mounted) {
//       // Perform actions that depend on the widget being active.
//       // Update the state or modify the UI.
//     }
//   }
//
//
//   bool isEditing = false;
//   _editPortfolio(post_id) async{
//     setState(() =>isEditing = true);
//     var res = await PostController.editPost(post_id: post_id.toString(), description: discription.text);
//     print("edit === ${res.statusCode}");
//     print("edit === ${res.body}");
//     if(res.statusCode == 200){
//       Get.to(ClientBottomNavigationBar(pageIndex: 3,));
//       AlertController.snackbar(context: context, text: "Portfolio edit success.", bg: AppColors.mainColor);
//     }else{
//       AlertController.snackbar(context: context, text: "Something went wrong with server..", bg: Colors.red);
//     }
//     setState(() =>isEditing = false);
//   }
//
//   bool isDeleting = false;
//   _deletePostImage(post_id, index) async{
//     setState(() =>isDeleting = true);
//     var res = await PostController.deleteImage(post_id: post_id.toString());
//     if(res.statusCode == 200){
//       setState(() {
//         widget.listImage?.removeAt(index);
//       });
//       AlertController.snackbar(context: context, text: "Image deleted success.", bg: AppColors.mainColor);
//     }else{
//       AlertController.snackbar(context: context, text: "Something went wrong with server..", bg: Colors.red);
//     }
//     setState(() =>isDeleting = false);
//   }
//
//
//
//
//
//
//   ///////////
// ///////////////////////
// //////////////
// ////////////////////
//
//   final _instaAssetsPicker = InstaAssetPicker();
//   final _provider = DefaultAssetPickerProvider(maxAssets: 10);
//   late final ThemeData _pickerTheme =
//   InstaAssetPicker.themeData(Theme.of(context).primaryColor).copyWith(
//     appBarTheme: const AppBarTheme(
//       // backgroundColor: Colors.white,
//       //   elevation: 0,
//       //   centerTitle: false,
//         centerTitle: false,
//         titleTextStyle: TextStyle(color: Colors.white, fontSize: 18)),
//   );
//
//   List<AssetEntity> selectedAssets = <AssetEntity>[];
//   InstaAssetsExportDetails? exportDetails;
//
//   @override
//   void dispose() {
//     _provider.dispose();
//     _instaAssetsPicker.dispose();
//     super.dispose();
//   }
//
//
//
//
// }
