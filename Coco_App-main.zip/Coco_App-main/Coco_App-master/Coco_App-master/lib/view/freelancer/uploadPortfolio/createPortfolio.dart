import 'package:coco/controller/camera_gallery_controller/cameraGalleryController.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../utility/appAssets.dart';
import '../../../utility/colors.dart';
import '../../client/bottomNagivation/buttom_nav.dart';
import '../../client/reels/reels.dart';
import '../../userProfile/Cafe_Edit_profile.dart';
import 'PickerCropResultScreen.dart';
import 'editFreelancerProfile.dart';

class CreateFreelancerPortfolio extends StatefulWidget {
  const CreateFreelancerPortfolio({super.key});

  @override
  State<CreateFreelancerPortfolio> createState() => _CreateFreelancerPortfolioState();
}

class _CreateFreelancerPortfolioState extends State<CreateFreelancerPortfolio> {


  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      body: SafeArea(
        child: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          color: Colors.white,
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 18.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                          onPressed: () {
                            Get.back();
                          },
                          icon: const Icon(Icons.arrow_back_outlined)),
                      const SizedBox(
                        width: 50,
                      )
                    ],
                  ),
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: (){
                        Get.to(Reels());
                      },
                      child:  Container(
                        width: 105,
                        height: 105,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(colors: [
                              Color(0xFF00CC83),
                              Color(0xFF53E0DB),
                            ])),
                        child: Container(
                          margin: EdgeInsets.all(4),
                          child: CircleAvatar(
                            radius: 80,
                            backgroundColor: Color(0xFFF6F6F6),
                            child: CircleAvatar(
                              backgroundColor: Color(0xFF0452D8),
                              radius: 80,
                              child: ClipOval(
                                child: Image.asset(
                                  AssetUtils.profile_avatar,
                                  width: double.infinity,
                                  height: double.infinity,
                                  fit: BoxFit.fill,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      width: 20,
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Mike Peter',
                          style: TextStyle(
                              fontSize: 25,
                              fontFamily: 'Poppins-Bold'),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            InkWell(
                              onTap: () => {}, //this is outside o bottomnavigation, but we need still button navigation
                              child:  Column(
                                children: [
                                  Text(
                                    '0',
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20),
                                  ),
                                  Text(
                                    'Following',
                                    style: TextStyle(
                                        color: Colors.black38,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 13),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(
                              width: 25,
                            ),
                            Container(
                              height: 30,
                              width: 2,
                              color: Colors.black12,
                            ),
                            const SizedBox(
                              width: 25,
                            ),
                            Column(
                              children: [
                                Text(
                                  '0',
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 20),
                                ),
                                Text(
                                  'Followers',
                                  style: TextStyle(
                                      color: Colors.black38,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),

                Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SizedBox(
                          width: MediaQuery.of(context).size.width / 2.3,
                          child: ElevatedButton(
                              onPressed: () {
                                Get.to(EditFreelacnerProfile());
                              },
                              child: Text('Edit Profile',
                                  style: TextStyle(
                                      fontFamily: 'Poppins_SemiBold')))),
                      SizedBox(
                        width: 5,
                      ),
                      SizedBox(
                          width: MediaQuery.of(context).size.width / 2.3,
                          child: ElevatedButton(
                              style: OutlinedButton.styleFrom(
                                backgroundColor: Color(0xFF00CC83),
                              ),
                              onPressed: (){},
                              child: Text(
                                'Favorites',
                                style:
                                TextStyle(fontFamily: 'Poppins_SemiBold'),
                              ))),
                    ],
                  ),
                ),

                const SizedBox(
                  height: 15,
                ),

                InkWell(
                  onTap: ()=> CameraGalleryController.pickGalleryAndCameraForPost(context: context),
                  child: Container(
                    width: size.width*.46,
                    height:280,
                    margin: EdgeInsets.only(left: 20, right: 20),
                    decoration: BoxDecoration(
                        color: Color(0xffF1F1F1),
                        borderRadius: BorderRadius.circular(10)
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Icon(Icons.add, color: Colors.grey.shade300, size: 30,),
                        SizedBox(height: 5,),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 13.0),
                          child: Text("Add a portfolio", textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 12,
                                color: Color(0xffCECECE)
                            ),
                          ),
                        )
                      ],
                    ),

                  ),
                )

              ],
            ),
          ),
        ),
      ),
    );
  }

  showBottomSheet()async{
    showModalBottomSheet(
        context: context,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            topRight: Radius.circular(20),
            topLeft: Radius.circular(20),
          ),
        ),
        builder: (context) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Container(
                margin: EdgeInsets.only(top: 10),
                height: 2, width: 100,
                color: Colors.grey.shade500,
              ),
              SizedBox(height: 30,),
              ListTile(
                leading: Container(
                  height: 40, width: 40,
                  padding: EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(100),
                    color: AppColors.mainColor,
                  ),
                  child: Icon(Icons.photo, color: AppColors.white,),
                ),
                title: new Text('Add a portfolio',
                  style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w600
                  ),
                ),
                onTap: ()=> CameraGalleryController.pickGalleryAndCameraForPost(context: context),

              ),
              ListTile(
                leading: Container(
                  height: 40, width: 40,
                  padding: EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(100),
                    color: AppColors.mainColor,
                  ),
                  child: Icon(Icons.remove_red_eye, color: AppColors.white,),
                ),
                title: new Text('Add a story',
                  style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w600
                  ),
                ),
                onTap: () {
                   CameraGalleryController.pickGalleryAndCameraForPost(context: context);
                },
              ),
              SizedBox(height: 30,),
            ],
          );
        });
  }





}
