import 'package:coco/utility/appAssets.dart';
import 'package:coco/utility/colors.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';

class EditFreelacnerProfile extends StatefulWidget {
  const EditFreelacnerProfile({super.key});

  @override
  State<EditFreelacnerProfile> createState() => _EditFreelacnerProfileState();
}

class _EditFreelacnerProfileState extends State<EditFreelacnerProfile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      onTap: () {
                        Get.back();
                      },
                      child: Icon(Icons.clear),
                    ),
                  ],
                ),
                SizedBox(
                  height: 15,
                ),
                Center(
                  child: Column(
                    children: [
                      Container(
                        width: 105,
                        height: 105,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(colors: [
                              Color(0xFF00CC83),
                              Color(0xFF53E0DB),
                            ])),
                        child: Container(
                          margin: EdgeInsets.all(4),
                          child: CircleAvatar(
                            radius: 80,
                            backgroundColor: Color(0xFFF6F6F6),
                            child: CircleAvatar(
                              backgroundColor: Color(0xFF0452D8),
                              radius: 80,
                              child: ClipOval(
                                child: Image.asset(
                                  AssetUtils.profile_avatar,
                                  width: double.infinity,
                                  height: double.infinity,
                                  fit: BoxFit.fill,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 7,
                      ),
                      Text(
                        'Edit Profile',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                ),
                Text(
                  'username',
                  style: TextStyle(

                    color: AppColors.mainColor,
                    fontSize: 15,
                    fontFamily: 'source-sans-pro-bold',
                    fontWeight: FontWeight.bold,


                  ),
                ),
                SizedBox(
                  height: 6,
                ),
                Text(
                  "Mike Peters",
                  style: TextStyle(
                      color: Color(0xff707070),
                    fontFamily: 'source-sans-pro-regular',
                    fontSize: 16

                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Divider(),
                Text(
                  'Description',
                  style: TextStyle(
                    color: AppColors.mainColor,
                    fontSize: 15,
                    fontFamily: 'source-sans-pro-bold',
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(
                  height: 6,
                ),
                Text(
                  "Professional photogapher with over 10 years of experience",
                  style: TextStyle(
                      color: Color(0xff707070),
                      fontFamily: 'source-sans-pro-regular',
                      fontSize: 16

                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Divider(),
                Text(
                  'Skills',
                  style: TextStyle(
                    color: AppColors.mainColor,
                    fontSize: 15,
                    fontFamily: 'source-sans-pro-bold',
                    fontWeight: FontWeight.bold,

                  ),
                ),
                SizedBox(
                  height: 1,
                ),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10.0, vertical: 15),
                    child: Row(
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(50),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                spreadRadius: 5,
                                blurRadius: 7,
                                offset:
                                    Offset(0, 3), // changes position of shadow
                              ),
                            ],
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20.0, vertical: 5),
                            child: Text(
                              'photography',
                              style: TextStyle(
                                  fontFamily: 'Poppins-Medium', fontSize: 11),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(50),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                spreadRadius: 5,
                                blurRadius: 7,
                                offset:
                                    Offset(0, 3), // changes position of shadow
                              ),
                            ],
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20.0, vertical: 5),
                            child: Text(
                              'photography',
                              style: TextStyle(
                                  fontFamily: 'Poppins-Medium', fontSize: 11),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(50),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                spreadRadius: 5,
                                blurRadius: 7,
                                offset:
                                    Offset(0, 3), // changes position of shadow
                              ),
                            ],
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20.0, vertical: 5),
                            child: Text(
                              'photography',
                              style: TextStyle(
                                  fontFamily: 'Poppins-Medium', fontSize: 11),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(50),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                spreadRadius: 5,
                                blurRadius: 7,
                                offset:
                                    Offset(0, 3), // changes position of shadow
                              ),
                            ],
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20.0, vertical: 5),
                            child: Text(
                              'photography',
                              style: TextStyle(
                                  fontFamily: 'Poppins-Medium', fontSize: 11),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(50),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                spreadRadius: 5,
                                blurRadius: 7,
                                offset:
                                    Offset(0, 3), // changes position of shadow
                              ),
                            ],
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20.0, vertical: 5),
                            child: Text(
                              'photography',
                              style: TextStyle(
                                  fontFamily: 'Poppins-Medium', fontSize: 11),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(50),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                spreadRadius: 5,
                                blurRadius: 7,
                                offset:
                                    Offset(0, 3), // changes position of shadow
                              ),
                            ],
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20.0, vertical: 5),
                            child: Text(
                              'photography',
                              style: TextStyle(
                                  fontFamily: 'Poppins-Medium', fontSize: 11),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(50),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                spreadRadius: 5,
                                blurRadius: 7,
                                offset:
                                    Offset(0, 3), // changes position of shadow
                              ),
                            ],
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20.0, vertical: 5),
                            child: Text(
                              'photography',
                              style: TextStyle(
                                  fontFamily: 'Poppins-Medium', fontSize: 11),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(50),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                spreadRadius: 5,
                                blurRadius: 7,
                                offset:
                                    Offset(0, 3), // changes position of shadow
                              ),
                            ],
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20.0, vertical: 5),
                            child: Text(
                              'photography',
                              style: TextStyle(
                                  fontFamily: 'Poppins-Medium', fontSize: 11),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(50),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                spreadRadius: 5,
                                blurRadius: 7,
                                offset:
                                    Offset(0, 3), // changes position of shadow
                              ),
                            ],
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20.0, vertical: 5),
                            child: Text(
                              'photography',
                              style: TextStyle(
                                  fontFamily: 'Poppins-Medium', fontSize: 11),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(50),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                spreadRadius: 5,
                                blurRadius: 7,
                                offset:
                                    Offset(0, 3), // changes position of shadow
                              ),
                            ],
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20.0, vertical: 5),
                            child: Text(
                              'photography',
                              style: TextStyle(
                                  fontFamily: 'Poppins-Medium', fontSize: 11),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(50),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                spreadRadius: 5,
                                blurRadius: 7,
                                offset:
                                    Offset(0, 3), // changes position of shadow
                              ),
                            ],
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20.0, vertical: 5),
                            child: Text(
                              'photography',
                              style: TextStyle(
                                  fontFamily: 'Poppins-Medium', fontSize: 11),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Divider(),
                SizedBox(
                  height: 10,
                ),
                Text(
                  'Location',
                  style: TextStyle(
                    color: AppColors.mainColor,
                    fontSize: 15,
                    fontFamily: 'source-sans-pro-bold',
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text("Bali, indonesia",   style: TextStyle(
                        color: Color(0xff707070),
                        fontFamily: 'source-sans-pro-regular',
                        fontSize: 16

                    ),)),
                    Spacer(),
                    SizedBox(
                        width: 100,
                        child: ElevatedButton(
                            style: OutlinedButton.styleFrom(
                              backgroundColor: Color(0xFF00CC83),
                            ),
                            onPressed: () {},
                            child: Text(
                              'Edit',
                              style: TextStyle(fontFamily: 'Poppins_SemiBold'),
                            ))),
                  ],
                ),
                Divider(),
                Text(
                  'Spoken languages',
                  style: TextStyle(

                    color: AppColors.mainColor,
                    fontSize: 15,
                    fontFamily: 'source-sans-pro-bold',
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(
                  height: 2,
                ),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        'English, French, German',
                        style: TextStyle(
                            color: Color(0xff707070),
                            fontFamily: 'source-sans-pro-regular',
                            fontSize: 16

                        ),
                      ),
                    ),
                    SizedBox(
                        width: 100,
                        child: ElevatedButton(
                            style: OutlinedButton.styleFrom(
                              backgroundColor: Color(0xFF00CC83),
                            ),
                            onPressed: () {},
                            child: Text(
                              'Edit',
                              style: TextStyle(fontFamily: 'Poppins_SemiBold'),
                            ))),
                  ],
                ),
                Divider(),
                Text(
                  'Phone Number',
                  style: TextStyle(

                    color: AppColors.mainColor,
                    fontSize: 15,
                    fontFamily: 'source-sans-pro-bold',
                    fontWeight: FontWeight.bold,

                  ),
                ),
                SizedBox(
                  height: 6,
                ),
                Text(
                  "+33658952475",
                  style: TextStyle(
                      color: Color(0xff707070),
                      fontFamily: 'source-sans-pro-regular',
                      fontSize: 16

                  ),
                ),
                Divider(),
                Text(
                  'Email',
                  style: TextStyle(

                    color: AppColors.mainColor,
                    fontSize: 15,
                    fontFamily: 'source-sans-pro-bold',
                    fontWeight: FontWeight.bold,

                  ),
                ),
                SizedBox(
                  height: 6,
                ),
                Text(
                  "Mikepeter@gmail.com",
                  style: TextStyle(
                      color: Color(0xff707070),
                      fontFamily: 'source-sans-pro-regular',
                      fontSize: 16

                  ),
                ),
                Divider(),
                Text(
                  'Follow us',
                  style: TextStyle(
                    color: AppColors.mainColor,
                    fontSize: 15,
                    fontFamily: 'source-sans-pro-bold',
                    fontWeight: FontWeight.bold,
                  ),
                ),

                Row(
                  children: [
                    Image.asset(
                      'asset/image/insta.png',
                      width: 35,
                      height: 35,
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Image.asset(
                      'asset/image/youtube.png',
                      width: 35,
                      height: 35,
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Image.asset(
                      'asset/image/bain.png',
                      width: 35,
                      height: 35,
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Image.asset(
                      'asset/image/linkdin.png',
                      width: 35,
                      height: 35,
                    ),
                    Spacer(),
                    SizedBox(
                        width: 100,
                        child: ElevatedButton(
                            style: OutlinedButton.styleFrom(
                              backgroundColor: Color(0xFF00CC83),
                            ),
                            onPressed: () {},
                            child: Text(
                              'Edit',
                              style: TextStyle(fontFamily: 'Poppins_SemiBold'),
                            ))),
                  ],
                ),
                SizedBox(
                  height: 20,
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
