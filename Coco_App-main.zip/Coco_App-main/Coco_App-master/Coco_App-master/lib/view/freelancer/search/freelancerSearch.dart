import 'package:coco/model/authModel/serviceModle.dart';
import 'package:coco/view/freelancer/bottomNavigationBar/becameFreelanceBottomNavigation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';

import '../../../controller/authController.dart';
import '../../../utility/colors.dart';

class FreelancerSearch extends StatefulWidget {
  const FreelancerSearch({super.key});

  @override
  State<FreelancerSearch> createState() => _FreelancerSearchState();
}

class _FreelancerSearchState extends State<FreelancerSearch> {
  List _selectedSearchItems = []; //this is empty list.
  //we add items/value when someone tap on search items.

  //this is Service list
  //show list of service according to this list.
  final List _serviceList = [
    "Restaurant",
    "Accommodation",
    "Bar/Club",
    "Health & wellness",
    "Sports"
  ];

  Future<ServiceModel>? getServiceModel;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getServiceModel = AuthController.getServiceList();

  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      child: SafeArea(
        child: Scaffold(
          body: Container(
            // width: double.infinity,
            // height: double.infinity,
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(color: Colors.black),
            child: Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,

                  children: [
                    InkWell(
                      onTap: () {
                        //Get.back();
                      },
                      child: Icon(Icons.arrow_back, color: Colors.white,),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Expanded(
                      child: Text(
                        'Client business categories',
                        style: TextStyle(
                            color: Colors.white,
                            fontFamily: 'Poppins-Bold',
                            fontSize: 16),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 5.h,
                ),

                FutureBuilder<ServiceModel>(
                  future: getServiceModel,
                  builder: (context, snapshot) {
                    if(snapshot.connectionState == ConnectionState.waiting){
                      return Center(child: CircularProgressIndicator(color: Colors.white,),);
                    }else if(snapshot.hasData){
                      return Expanded(
                        child: ListView.builder(
                          itemCount: snapshot.data?.data?.length,
                          itemBuilder: (_, index) {
                            return Padding(
                              padding: const EdgeInsets.only(
                                  left: 15, right: 15, bottom: 5, top: 10),
                              child: GestureDetector(
                                onTap: () {
                                  setState(() {
                                    if (_selectedSearchItems.contains(snapshot.data?.data?[index]?.id.toString())) {
                                      _selectedSearchItems.remove(snapshot.data?.data?[index]?.id.toString());
                                    } else {
                                      _selectedSearchItems.add(snapshot.data?.data?[index]?.id.toString());
                                    }
                                  });
                                },
                                child: Container(
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5),
                                      color: _selectedSearchItems.contains(snapshot.data?.data?[index]?.id.toString())
                                          ? AppColors.white
                                          : Colors.black,
                                      border: Border.all(
                                          width: 1, color: Color(0xFFA1A1A1))),
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 18.0, vertical: 12),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        SizedBox(
                                          width: 20,
                                          child: _selectedSearchItems.contains(snapshot.data?.data?[index]?.id.toString())
                                              ? Icon(
                                            Icons.check_circle,
                                            size: 18,
                                            color: AppColors.mainColor,
                                          )
                                              : Center(),
                                        ),
                                        Text(
                                          '${snapshot.data?.data?[index]?.name}',
                                          style: TextStyle(
                                              color:
                                              _selectedSearchItems.contains(snapshot.data?.data?[index]?.id.toString())
                                                  ? Colors.black
                                                  : AppColors.white,
                                              fontSize: 13,
                                              fontFamily: 'Poppins-Bold'),
                                        ),
                                        SizedBox(
                                          width: 20,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      );
                    }else{
                      return Center(child: Text("Check your internet connection.",
                        style: TextStyle(
                          color: Colors.white
                        ),
                      ),);
                    }
                  }
                ),
                SizedBox(
                  height: 40,
                ),
               

                //CheckboxListTile
              ],
            ),
          ),
          bottomNavigationBar:  _selectedSearchItems.isNotEmpty
              ? Container(
            color: Colors.black,
            padding: EdgeInsets.all(20),
            width: double.infinity,
            child: ElevatedButton(
                style: OutlinedButton.styleFrom(
                  backgroundColor: Colors.white,
                ),
                onPressed: () async{
                  // Get.to(() => AppBottomNavigationBar());
                  // Get.to(AppBottomNavigationBar());
                  SharedPreferences _prefs = await SharedPreferences.getInstance();
                  _prefs.getString("token") != null
                      ? Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              FreelancerAppBottomNavigation(pageIndex: 0,)))
                      :Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              FreelancerAppBottomNavigation(pageIndex: 5,)));
                  // Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context)=>AppBottomNavigationBar()), (route) => false);
                },
                child: Text(
                  'Continue',
                  style: TextStyle(color: Colors.black, fontSize: 13),
                )),
          )
              : Container(),
        ),
      ),
    );
  }
}
