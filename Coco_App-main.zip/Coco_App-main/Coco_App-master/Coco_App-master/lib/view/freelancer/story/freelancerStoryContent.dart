import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import '../../storys/likeIcon.dart';
import 'freelancerStoryOption.dart';

class FreelancerContentScreen extends StatefulWidget {
  final String? src;

  const FreelancerContentScreen({Key? key, this.src}) : super(key: key);

  @override
  _FreelancerContentScreenState createState() => _FreelancerContentScreenState();
}

class _FreelancerContentScreenState extends State<FreelancerContentScreen> {
  late VideoPlayerController _videoPlayerController;
  ChewieController? _chewieController;
  bool _liked = false;


  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        GestureDetector(
            onDoubleTap: () {
              setState(() {
                _liked = !_liked;
              });
            },
            child: Image.network("${widget.src}", fit: BoxFit.cover, )
        ),
        if (_liked)
          Center(
            child: LikeIcon(),
          ),
        FreelancerSotryOptionsScreen()
      ],
    );
  }
}