import 'package:animator/animator.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../client/bottomNagivation/buttom_nav.dart';

class FreelancerSotryOptionsScreen extends StatefulWidget {

  @override
  State<FreelancerSotryOptionsScreen> createState() => _FreelancerSotryOptionsScreenState();
}

class _FreelancerSotryOptionsScreenState extends State<FreelancerSotryOptionsScreen> {
  bool isLike = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(8.0),
      decoration: BoxDecoration(
          gradient: new LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.transparent,
              Colors.black.withOpacity(0.5)
            ],
          )
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          SizedBox(),
          Padding(
            padding: const EdgeInsets.only(left: 15, right: 15, bottom: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 140),
                    InkWell(
                      onTap: ()=>Get.to(ClientBottomNavigationBar(pageIndex: 7,)),
                      child: Row(
                        children: [
                          CircleAvatar(
                            child: Icon(Icons.person, size: 18),
                            radius: 15,
                          ),
                          SizedBox(width: 6),
                          Text('Coco Stories',
                            style: TextStyle(
                                fontWeight: FontWeight.w600,
                                color: Colors.white,
                                fontSize: 15
                            ),
                          ),
                          SizedBox(width: 10),
                        ],
                      ),
                    ),
                    SizedBox(height:5),
                    Text('Flutter is beautiful and fast 💙❤💛 ,,, More',
                      style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w400,
                          color: Colors.white
                      ),
                    ),
                    SizedBox(height: 5),
                    Text('2 hours ago',
                      style: TextStyle(
                          fontSize: 9,
                          fontWeight: FontWeight.w400,
                          color: Colors.white
                      ),
                    ),
                  ],
                ),
                Column(
                  children: [
                    InkWell(
                      onTap: ()=>setState(()=>isLike =true),
                        child: isLike ? Animator<double>(
                          duration: Duration(milliseconds: 1000),
                          cycles: 0,
                          repeats: 1,
                          tween:  Tween<double>(begin: 10.00, end: 12.0),
                          curve: Curves.elasticIn,
                          builder: (_, animatorState, child)=>Column(
                            children: [
                              Icon(Icons.favorite, color: Colors.red, size: animatorState.value*3,),
                              Text('601k',style: TextStyle(color: Colors.white),),
                            ],
                          ),
                        )
                        : Column(
                          children: [
                            Icon(Icons.favorite, color: Colors.white, size: 30,),
                            Text('601k',style: TextStyle(color: Colors.white),),
                          ],
                        )
                    ),


                    SizedBox(height: 20),
                    Icon(Icons.send, color: Colors.white,),
                    Text('1123',style: TextStyle(color: Colors.white),),

                    SizedBox(height: 50),
                    IconButton(
                      onPressed: ()=>showBottomNavigation(),
                      icon: Icon(Icons.more_horiz, color: Colors.white,),
                    ),
                    SizedBox(height: 20,)

                  ],
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  like() {
  }

  showBottomNavigation() async {

  }
}