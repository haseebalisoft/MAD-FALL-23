import 'dart:io';

import 'package:coco/controller/authController.dart';
import 'package:coco/controller/camera_gallery_controller/cameraGalleryController.dart';
import 'package:coco/controller/locationController.dart';
import 'package:coco/model/authModel/userInfoModel.dart';
import 'package:coco/view/freelancer/search/freelancerSearch.dart';
import 'package:coco/view/profile/followingFollower.dart';
import 'package:coco/view/profile/myProfile.dart';
import 'package:coco/view/profile/profileSetting.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:wechat_assets_picker/wechat_assets_picker.dart';

import '../../../helper/helperFunctions.dart';
import '../../../utility/appAssets.dart';
import '../../../utility/colors.dart';
import '../../../viewController/uploadphotos_videos.dart';
import '../../location/location_map.dart';
import '../../location/not_used_location.dart';
import '../../search/searchFreelancerClientProfile.dart';
import '../../search/searchFreelancerClientProfileNotUsed.dart';
import '../dashboard/dashboard.dart';
import '../profile/UserEditProfile.dart';
import '../profile/freelancerProfile.dart';
import '../uploadPortfolio/PickerCropResultScreen.dart';
import '../uploadPortfolio/createPortfolio.dart';


class FreelancerAppBottomNavigation extends StatefulWidget {
  final String? userId;
  final int pageIndex;
  const FreelancerAppBottomNavigation({super.key,  this.pageIndex = 0, this.userId,});

  @override
  State<FreelancerAppBottomNavigation> createState() => _FreelancerAppBottomNavigationState();
}

class _FreelancerAppBottomNavigationState extends State<FreelancerAppBottomNavigation> {
  late String _role;
  int page_index = 0;
  final List _screens = [
    FreelancerDashboard(),
    SearchFreelancerClientProfile(),
    CreateFreelancerPortfolio(),
    //open bottom sheet
     //showBottomSheet(),
    LocationMap(),
    MyProfile(), //index4
    // CreateFreelancerPortfolio(),//index5
    ProfileSetting(),//index 6
    UserEditProfile(), //index 7
  ];



  showBottomSheet()async{
    showModalBottomSheet(
        context: context,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            topRight: Radius.circular(20),
            topLeft: Radius.circular(20),
          ),
        ),
        builder: (context) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Container(
                margin: EdgeInsets.only(top: 10),
                height: 2, width: 100,
                // color: Colors.grey.shade500,
                color: AppColors.black,
              ),
              SizedBox(height: 30,),
              ListTile(
                leading: Container(
                  height: 40, width: 40,
                  padding: EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(100),
                    color: AppColors.mainColor,
                  ),
                  child: Icon(Icons.photo, color: AppColors.white,),
                ),
                title: new Text('Add a portfolio',
                  style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w600
                  ),
                ),
                onTap: ()=> CameraGalleryController.pickGalleryAndCameraForPost(context: context),

              ),
              ListTile(
                leading: Container(
                  height: 40, width: 40,
                  padding: EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(100),
                    color: AppColors.mainColor,
                  ),
                  child: Icon(Icons.remove_red_eye, color: AppColors.white,),
                ),
                title: new Text('Add a story',
                  style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w600
                  ),
                ), //commit
                onTap: ()=> CameraGalleryController.pickGalleryAndCameraForPost(context: context),
              ),
              SizedBox(height: 30,),
            ],
          );
        });
  }

  bool hometap = false;
  bool searchtap = false;
  bool locationtap = false;
  bool boxtap = false;
  bool istap = true;

  page_index_with_navbar() {


  }

  @override
  void initState() {
    super.initState();
    getLocationLatLng();
    setState(() {
      page_index = widget.pageIndex!;
    });
    page_index_with_navbar();
    getUserInfoFuture = AuthController.getUserInfo();

    print("page_index === ${page_index}");
  }



  getLocationLatLng() async {
    HelperFunction.locationData().then((value) {
      setState(() {
        lat = value.latitude;
        lng = value.longitude;
      });
      updateLatLng();
      print("print lat === $lat");
    });
  }
  var lat, lng;
  updateLatLng()async{
    print("dasfadsfasd");
    var res = await AuthController.updateLatLong(lat: lat.toString(), lng: lng.toString());
    print("res.body == ${res.body}");
    print("res.body == ${res.statusCode}");
    if(res.statusCode == 200){
    }
  }


  Future<UserInformation>? getUserInfoFuture;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[page_index],
      bottomNavigationBar: FutureBuilder<UserInformation>(
          future: getUserInfoFuture,
          builder: (context, snapshot) {
            if(snapshot.connectionState ==ConnectionState.waiting){

              return Container(
                padding: const EdgeInsets.only(top: 5, bottom: 0, ),
                decoration: BoxDecoration(color: AppColors.black, boxShadow: [
                  BoxShadow(
                      color: Color(0xFFA1A1A1).withOpacity(0.5),
                      blurRadius: 20,
                      offset: Offset(5, 10),
                      spreadRadius: 0.1,
                      blurStyle: BlurStyle.normal)
                ]),
                height: Platform.isIOS ? 75 : 61,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      onTap: () {
                        page_index = 0;
                        if (mounted) {
                          setState(() {});
                        }
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Column(
                          children: [
                            SvgPicture.asset(
                              AssetUtils.nav_bar,
                              width: 16,
                            ),
                            SizedBox(
                              height: 2,
                            ),
                            page_index == 0
                                ? CircleAvatar(
                              backgroundColor: Color(0xFF00CC83),
                              radius: 3,
                            )
                                : SizedBox(
                            )
                          ],
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        page_index = 1;
                        if (mounted) {
                          setState(() {});
                        }
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Column(
                          children: [
                            SvgPicture.asset(
                              AssetUtils.nav_search,
                              width: 16,
                            ),
                            SizedBox(
                              height: 2,
                            ),
                            page_index == 1
                                ? CircleAvatar(
                              backgroundColor: Color(0xFF00CC83),
                              radius: 3,
                            )
                                : SizedBox(

                            )
                          ],
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: ()=>CameraGalleryController.pickGalleryAndCameraForPost(context: context),
                      child: Container(
                        height: 24,
                        width: 25,
                        margin: const EdgeInsets.only(bottom:8),
                        // padding: EdgeInsets.all(6),
                        decoration: BoxDecoration(
                            border: Border.all(width: 1.5, color:  AppColors.white),
                            borderRadius: BorderRadius.circular(3)
                        ),
                        child: const Center(child: Icon(Icons.add, size: 18,color:  AppColors.white,)),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        page_index = 3;
                        if (mounted) {
                          setState(() {});
                        }
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Column(
                          children: [
                            SvgPicture.asset(
                              AssetUtils.nav_location,
                              width: 13.5,
                            ),
                            SizedBox(
                              height: 2,
                            ),
                            page_index == 3
                                ? CircleAvatar(
                              backgroundColor: Color(0xFF00CC83),
                              radius: 3,
                            )
                                : SizedBox(

                            )
                          ],
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        page_index = 4;
                        if (mounted) {
                          setState(() {});
                        }
                      },
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 15.0),
                        child: CircleAvatar(
                          radius: 15,
                          child: ClipOval(
                            child: Image.asset(
                              AssetUtils.logoPng,
                              width: double.infinity,
                              height: double.infinity,
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 1,
                    )
                  ],
                ),
              );

            }
            else if(snapshot.hasData){
          return Container(
            padding: const EdgeInsets.only(top: 5, bottom: 0, ),
            decoration: BoxDecoration(color: AppColors.black, boxShadow: [
              BoxShadow(
                  color: Color(0xFFA1A1A1).withOpacity(0.5),
                  blurRadius: 20,
                  offset: Offset(5, 10),
                  spreadRadius: 0.1,
                  blurStyle: BlurStyle.normal)
            ]),
            height: Platform.isIOS ? 75 : 61,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    page_index = 0;
                    if (mounted) {
                      setState(() {});
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Column(
                      children: [
                        SvgPicture.asset(
                          AssetUtils.nav_bar,
                          width: 16,
                        ),
                        SizedBox(
                          height: 2,
                        ),
                        page_index == 0
                            ? CircleAvatar(
                          backgroundColor: Color(0xFF00CC83),
                          radius: 3,
                        )
                            : SizedBox(
                        )
                      ],
                    ),
                  ),
                ),
                InkWell(
                  onTap: () {
                    page_index = 1;
                    if (mounted) {
                      setState(() {});
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Column(
                      children: [
                        SvgPicture.asset(
                          AssetUtils.nav_search,
                          width: 16,
                        ),
                        SizedBox(
                          height: 2,
                        ),
                        page_index == 1
                            ? CircleAvatar(
                          backgroundColor: Color(0xFF00CC83),
                          radius: 3,
                        )
                            : SizedBox(

                        )
                      ],
                    ),
                  ),
                ),
                InkWell(
                  onTap: ()=>CameraGalleryController.pickGalleryAndCameraForPost(context: context),
                  child: Container(
                    height: 24,
                    width: 25,
                    margin: const EdgeInsets.only(bottom:8),
                    // padding: EdgeInsets.all(6),
                    decoration: BoxDecoration(
                        border: Border.all(width: 1.5, color:  AppColors.white),
                        borderRadius: BorderRadius.circular(3)
                    ),
                    child: const Center(child: Icon(Icons.add, size: 18,color:  AppColors.white,)),
                  ),
                ),
                InkWell(
                  onTap: () {
                    page_index = 3;
                    if (mounted) {
                      setState(() {});
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Column(
                      children: [
                        SvgPicture.asset(
                          AssetUtils.nav_location,
                          width: 13.5,
                        ),
                        SizedBox(
                          height: 2,
                        ),
                        page_index == 3
                            ? CircleAvatar(
                          backgroundColor: Color(0xFF00CC83),
                          radius: 3,
                        )
                            : SizedBox(

                        )
                      ],
                    ),
                  ),
                ),
                InkWell(
                  onTap: () {
                    page_index = 4;
                    if (mounted) {
                      setState(() {});
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 15.0),
                    child: CircleAvatar(
                      radius: 15,
                      child: ClipOval(
                        child:  snapshot.data?.data?.profileImage != null ? Image.network(
                          snapshot.data?.data?.profileImage,
                          width: double.infinity,
                          height: double.infinity,
                          fit: BoxFit.cover,
                        ) : Image.asset(
                          AssetUtils.logoPng,
                          fit: BoxFit.cover,
                          width: double.infinity,
                          height: double.infinity,
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 1,
                )
              ],
            ),
          );
        }else{
              return Container(
                margin: EdgeInsets.only(right: 15),
                padding: const EdgeInsets.only(top: 5, bottom: 0, ),
                decoration: BoxDecoration(color: Colors.white, boxShadow: [
                  BoxShadow(
                      color: Color(0xFFA1A1A1).withOpacity(0.5),
                      blurRadius: 20,
                      offset: Offset(5, 10),
                      spreadRadius: 0.1,
                      blurStyle: BlurStyle.normal)
                ]),
                height: Platform.isIOS ? 75 : 61,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      onTap: () {
                        page_index = 0;
                        if (mounted) {
                          setState(() {});
                        }
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Column(
                          children: [
                            SvgPicture.asset(
                              AssetUtils.nav_bar,
                              width: 16,
                            ),
                            SizedBox(
                              height: 2,
                            ),
                            page_index == 0
                                ? CircleAvatar(
                              backgroundColor: Color(0xFF00CC83),
                              radius: 3,
                            )
                                : SizedBox(
                            )
                          ],
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        page_index = 1;
                        if (mounted) {
                          setState(() {});
                        }
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Column(
                          children: [
                            SvgPicture.asset(
                              AssetUtils.nav_search,
                              width: 16,
                            ),
                            SizedBox(
                              height: 2,
                            ),
                            page_index == 1
                                ? CircleAvatar(
                              backgroundColor: Color(0xFF00CC83),
                              radius: 3,
                            )
                                : SizedBox(

                            )
                          ],
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: ()=>CameraGalleryController.pickGalleryAndCameraForPost(context: context),
                      child: Container(
                        height: 24,
                        width: 25,
                        margin: const EdgeInsets.only(bottom:8),
                        // padding: EdgeInsets.all(6),
                        decoration: BoxDecoration(
                            border: Border.all(width: 1.5, color: Colors.white),
                            borderRadius: BorderRadius.circular(3)
                        ),
                        child: const Center(child: Icon(Icons.add, size: 18,color: AppColors.white,)),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        page_index = 3;
                        if (mounted) {
                          setState(() {});
                        }
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Column(
                          children: [
                            SvgPicture.asset(
                              AssetUtils.nav_location,
                              width: 13.5,
                            ),
                            SizedBox(
                              height: 2,
                            ),
                            page_index == 3
                                ? CircleAvatar(
                              backgroundColor: Color(0xFF00CC83),
                              radius: 3,
                            )
                                : SizedBox(

                            )
                          ],
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        page_index = 4;
                        if (mounted) {
                          setState(() {});
                        }
                      },
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 15.0),
                        child: CircleAvatar(
                          radius: 15,
                          child: ClipOval(
                            child: Image.asset(
                              fit: BoxFit.cover,
                              AssetUtils.logoPng,
                              width: double.infinity,
                              height: double.infinity,
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 1,
                    )
                  ],
                ),
              );
            }

          }
      ),
    );
  }







}
