import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:coco/appConfig.dart';
import 'package:coco/helper/helperFunctions.dart';
import 'package:coco/view/favoriteList/faveriotList.dart';
import 'package:get/get.dart';
import 'package:path/path.dart' as p;
import 'package:coco/controller/postController.dart';
import 'package:coco/model/postModel/PostModel.dart';
import 'package:coco/model/postModel/commentListModel.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/view/shareApp.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:coco/viewController/appNetworkImage.dart';
import 'package:coco/viewController/imageSlider.dart';
import 'package:coco/viewController/likeAnimation.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';
import '../Client/bottomNagivation/buttom_nav.dart';
import 'on_click_option_widget.dart';
import 'package:http/http.dart' as http;


class SinglePost extends StatefulWidget {
  final String userName;
  final String? userImage;
  final Datum singlePost;
  final bool? isLiked;
  final bool? isFav;
  const SinglePost({Key? key, required this.userName,  this.userImage, required this.singlePost, required this.isLiked, required this.isFav }) : super(key: key);

  @override
  State<SinglePost> createState() => _SinglePostState();
}

class _SinglePostState extends State<SinglePost> {
  bool isPressed = false;

  int? likeCount;

  bool showBookmarkLoading = false;

  final comment = TextEditingController();

  bool isComment = false;
  bool userReplay = false;
  bool showFullText = false;

  String profilePic = "";
  
  
  //list of like ture 
  List isLikeList =[];
  bool bookmark = false;


  void toggleText() {
    setState(() {
      showFullText = !showFullText;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    likeCount = widget.singlePost!.like!;
    getCommentFuture = PostController.commentList(post_id: widget.singlePost!.post!.id.toString());;
    getUserId();
    likeFav();

    print("user  image : ${widget.userImage}");
  }

  likeFav(){
    setState(() {
      print("widget.isLiked == ${widget.isLiked}");
      isLike = widget.isLiked!;
      isLikeList.contains(widget.singlePost!.post!.id.toString());

      bookmark = widget.isFav!;

      print("isLike == ${isLike}");
    });
  }

  Future<SinglePostCommentListModel>? getCommentFuture;

  var userid;
  getUserId()async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    setState(() {
      userid = _pref.getString("user_id");
    });


    print("user id === ${userid}");
    print("user id === ${ widget.singlePost!.userData![0]!.id.toString()}");
  }



  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              InkWell(
                onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientBottomNavigationBar(pageIndex: 6, userId: widget.singlePost!.userData![0]!.id.toString()))),
                child: Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 8),
                      child: CircleAvatar(
                        child: ClipOval(
                            child: widget.userImage != null ? AppNetworkImage(src: widget!.userImage!) : Image.asset("asset/image/logo.png", fit: BoxFit.cover)
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 13,
                    ),
                    Text(
                      '${widget.singlePost.userData?[0].name ?? widget.singlePost.userData?[0].userName}',
                      style: const TextStyle(color: Colors.white,
                          fontFamily: ' Roboto-Bold',
                          fontSize: 16,
                          fontWeight: FontWeight.bold
                      ),
                    ),
                  ],
                ),
              ),
              Spacer(),
              widget.singlePost!.userData![0]!.id.toString() != userid ? Center() :   IconButton(
               onPressed: () {
                  Navigator.of(context).push(PageRouteBuilder(
                      opaque: false,
                      pageBuilder: (BuildContext context, _, __) =>
                          showAlertDialogg(postId:"${widget.singlePost!.post!.id}", images: widget.singlePost!.image!, description: widget.singlePost!.post!.description, userName: "${widget.userName}",)));
                },
                icon: Icon(Icons.more_horiz),
                color: Colors.grey,
              )
            ],
          ),
          SizedBox(
            height: 10,
          ),
          InkWell(
              onDoubleTap: () {
                if(isLike == true){
                  _postUnList(widget.singlePost!.post!.id.toString());
                  return;
                }else{
                  _postList(widget.singlePost!.post!.id.toString());
                  return;
                }
                setState(() {});
              },
               child: Stack(
                 children: [

                   /////////=========== image slider widget=============//
                   ImageSlider(imageUrls: widget.singlePost!.image!, height: 400,),

                  isLiking? Container(
                     height:  widget.singlePost!.image!.length >1 ? 415 : 400,
                     decoration: BoxDecoration(
                       color: Colors.black.withOpacity(0.4)
                     ),
                     child: Center(
                       child: LikeAnimation(),
                     ),
                   ): Center()
                 ],
               ),
          ),
      //child: AppNetworkImage(src: "${widget.singlePost!.image!.isEmpty?"https://upload.wikimedia.org/wikipedia/commons/thumb/6/65/No-Image-Placeholder.svg/1665px-No-Image-Placeholder.svg.png" :widget.singlePost!.image![0]!.image}")),
          Row(
            children: [
              IconButton(
                  onPressed: () {
                    if(isLike == true){
                      _postUnList(widget.singlePost!.post!.id.toString());
                      return;
                    }else{
                      _postList(widget.singlePost!.post!.id.toString());
                      return;
                    }
                    setState(() {});
                  },
                  icon: Icon(
                   Icons.favorite,
      // Color(0xff7e7e7e)
                    color: isLike ? Colors.red : AppColors.white,
                  )),
              FutureBuilder<SinglePostCommentListModel>(
                  future: getCommentFuture,
                  builder: (context, snapshot) {
                    if(snapshot.connectionState == ConnectionState.waiting){
                      return Center();
                    }else if(snapshot.hasData){
                      return IconButton(
                        onPressed: (){
                          setState(() {
                            getCommentFuture = PostController.commentList(post_id: widget.singlePost!.post!.id.toString()); //get comment future
                            openCommentBox(snapshot.data!.data!); //pass the data
                            setState(() {}); //state change

                          });
                        },
                        icon: FaIcon(FontAwesomeIcons.comment,color: AppColors.white,),
                        color: Color(0xff7e7e7e),
                      );
                    }else{
                      return Center();
                    }
                  }
              ),
              IconButton(
                onPressed: () async{

                  //ShareApp.createDynamicLink(link: "${widget.singlePost!.image![0].image}", text: "${widget.singlePost!.userData![0]!.name}: ${widget.singlePost!.post!.description} \n ${widget.singlePost!.like} Likes ", context: context);
                  Share.share("${widget.singlePost!.userData![0]!.name}: ${widget.singlePost!.post!.description} \n ${widget.singlePost!.like} Likes \n${widget.singlePost!.image![0].image} ", );
                },
                icon: FaIcon(FontAwesomeIcons.paperPlane,color: AppColors.white,),
                color: Color(0xff7e7e7e),
              ),
              // SizedBox(width: 50.w,),
              Expanded(child: Container()),

              showBookmarkLoading ? Container(
                margin: EdgeInsets.only(right: 10),
                height: 20,
                width: 20,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: AppColors.white,
                )
              )
                  :  IconButton(
                onPressed: () {
                  setState(() {
                    // bookmark = !bookmark;
                    // Get.to(FavList());
                    showBookmarkLoading = true;
                    print("bookmark == ${bookmark}");
                    print("--------------------------------");
                    if(bookmark == true) {
                      print("bookmark == ${bookmark}");
                      postRemoveFromFav(widget.singlePost!.post!.id.toString());
                      return;
                    }
                    else if(bookmark == false){
                      print("bookmark == ${bookmark}");

                      postAddToFav(widget.singlePost!.post!.id.toString());
                      return;
                    }
                  });

                },
                icon:bookmark ? FaIcon(FontAwesomeIcons.solidBookmark,color: Colors.white,) : FaIcon(FontAwesomeIcons.bookmark,color: AppColors.white,),
                color: Color(0xff7e7e7e),
              ),


            ],
          ),
          isComment ? Container(
            margin: EdgeInsets.only(bottom: 8),
            child: SizedBox(
              height: 7.5.h,
              child: TextField(
                style: TextStyle(color: Colors.white),
                controller: comment,
                decoration: InputDecoration(
                    fillColor: Color(0xff5D5D5D5A),
                    filled: true,
                    // contentPadding: EdgeInsets.only(left: 20, right: 20, top: -50, bottom: 10),
                    hintText: "Comment here....",
                    labelStyle: TextStyle(
                      fontWeight:FontWeight.w400,
                      fontSize: 12,
                      color: Colors.white,


                    ),
                    hintStyle: TextStyle(
                      fontWeight:FontWeight.w400,
                      fontSize: 12,
                      color: AppColors.white
                    ),
                    suffix: IconButton(icon: Icon(Icons.send,color: AppColors.white,), color: AppColors.black, onPressed: (){


                      setState(() {
                        _commentOnPost(widget.singlePost!.post!.id.toString());
                      });
                      setState(() {

                      });
                    },)
                ),
              ),
            ),
          ) : Center(),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${likeCount} likes',
                  style: TextStyle(color: Colors.white, fontSize: 13,
                    fontFamily: 'Roboto-Medium',

                  ),
                ),
                SizedBox(height: 6,),
                InkWell(
                  onTap: (){

                    setState(() {
                      toggleText();
                    });
                  },
                  child: Text.rich(
                    TextSpan(
                      text: '${widget.singlePost!.userData![0]!.name ?? widget.singlePost!.userData![0]!.userName}  ',
                      style:
                      TextStyle(fontSize: 13, color: Colors.white,
                           fontWeight: FontWeight.w600
                      ),
                      children: [
                        TextSpan(
                          text: showFullText ? widget.singlePost!.post!.description : '${widget.singlePost!.post!.description!.length > 50 ? widget.singlePost!.post!.description!.substring(0, 30)+' ...more' : widget.singlePost!.post!.description}',
                          style: TextStyle(color: AppColors.white,
                              fontFamily: 'Roboto-Regular',
                              fontWeight: FontWeight.w400,
                              fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 7,
                ),
                FutureBuilder<SinglePostCommentListModel>(
                  future: getCommentFuture,
                  builder: (context, snapshot) {
                    if(snapshot.connectionState == ConnectionState.waiting){
                      return Center();
                    }else if(snapshot.hasData){
                      return InkWell(
                        onTap: (){
                          getCommentFuture = PostController.commentList(post_id: widget.singlePost!.post!.id.toString()); //get comment future
                          openCommentBox(snapshot.data!.data!); //pass the data
                          setState(() {}); //state change
                        },
                        child: Text('View all ${snapshot.data!.data!.length} comments',
                            style: TextStyle(
                                color: AppColors.white.withOpacity(0.75),
                                fontFamily: 'Roboto-Regular',
                                fontSize: 12.5
                            )),
                      );
                    }else{
                      return Center();
                    }
                  }
                ),
                SizedBox(
                  height: 5,
                ),
                Text('${widget.singlePost!.postTime}',
                    style: TextStyle(
                        color: Color(0xff7e7e7e),
                        fontFamily: 'Roboto-Regular',
                        fontSize: 12
                    )),
                SizedBox(
                  height: 20,
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  getProfilePic()async{
    SharedPreferences pref = await SharedPreferences.getInstance();
    setState(() {
      profilePic = pref.getString("userProfilePic") ?? "";
    });
  }

  //list of comment show and hide
  List commentId = [];
  openCommentBox(List<CommentList> list){
    print("list == ${list}");
    commentId.clear();

    for(var i in list){
      //store all comment hide yes in to this list
      if(i.hide == "yes"){
        commentId.add(i.id.toString());
      }
    }

    print("Tahmid Alavi Ishmam");
    print("commentId init === $commentId");
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            topRight: Radius.circular(30),
            topLeft: Radius.circular(30)
          )
        ),
        builder: (context) {
          print("comment box data ${list.length}");

          //Get profile  pic from shared preference

          getProfilePic();
          ScrollController _scrollController = ScrollController();

          return StatefulBuilder(
            builder: (context, setState) {
              return NotificationListener<ScrollNotification>(
                onNotification: (scrollNotification) {
                  if (scrollNotification is ScrollEndNotification &&
                      _scrollController.position.pixels == 0.0) {
                    // Scrolled to the top
                    if (_scrollController.position.maxScrollExtent == 264.03333333333325) {
                      // At the bottom, close the bottom sheet
                      //Navigator.pop(context);
                    }
                  }
                  return false;
                },
                child: Scaffold(
                  backgroundColor: Colors.transparent,
                  bottomSheet: Container(
                    height: 90.h,
                    padding: EdgeInsets.only(top: 10),
                    decoration: BoxDecoration(
                     borderRadius: BorderRadius.only(topLeft: Radius.circular(20),topRight: Radius.circular(20)),
                      color: Colors.grey.shade900
                    ),
                    child: list.isNotEmpty  
                        ? Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min, // Set MainAxisSize.min here
                      children: [
                        Center(
                          child: Container(
                            height: 5,
                            width: 50,
                            decoration: BoxDecoration(
                              color: Colors.grey.withOpacity(0.3),
                              borderRadius: BorderRadius.circular(10)
                            ),
                          ),
                        ),
                        SizedBox(height: 30,),
                        Center(
                          child: Text('Comments',
                            style: TextStyle(color: Colors.white,fontWeight: FontWeight.w600,fontSize: 13),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        SizedBox(height: 20,),
                        Center(
                          child: Container(
                            height: 1,
                            width: MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(
                                color: Colors.grey.withOpacity(0.3),
                                borderRadius: BorderRadius.circular(10)
                            ),
                          ),
                        ),

                        Padding(
                          padding: const EdgeInsets.only(left: 15, right: 15, top: 15, bottom: 5),
                          child: Text('View all ${list.length} comments',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontFamily: 'Roboto-Regular',
                                  fontSize: 12
                              )),
                        ),
                        Expanded(
                          child: ListView.builder(
                              controller: _scrollController,
                              itemCount: list.length,
                              itemBuilder: (_,index){
                                return Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 5.0,horizontal: 5),
                                  child: ListTile(
                                    leading: SizedBox(
                                      height: 32,
                                      width: 32,
                                      child: InkWell(
                                          onTap: (){
                                            Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientBottomNavigationBar(pageIndex: 6, userId:list[index].commentUser?.id )));
                                          },
                                          child: CachedNetworkImage(
                                              imageUrl: list[index]?.commentUser?.profileImage ?? '', // Provide the URL here
                                              imageBuilder: (context, imageProvider) => ClipRRect(
                                                borderRadius: BorderRadius.circular(45),
                                                child: Image(
                                                  image: imageProvider,
                                                  fit: BoxFit.cover,
                                                  height: 30,
                                                  width: 30,
                                                ),
                                              ),
                                              placeholder: (context, url) => Center(child: CircularProgressIndicator(color: AppColors.mainColor)),
                                              errorWidget: (context, url, error) => ClipOval(
                                                child: Image.asset(
                                                  "asset/image/logo.png",
                                                  fit: BoxFit.cover,
                                                  height: 30,
                                                  width: 30,
                                                ),
                                              )
                                          )


                                      ),
                                    ),
                                    title: Text('${list[index]!.commentUser?.name ?? list[index]!.commentUser?.userName}',
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w700,
                                        color: Colors.grey.shade200
                                      ),
                                    ),
                                    subtitle: Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text("${list[index]!.comments }",
                                          style: TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight.w500,
                                              color: Colors.white
                                          ),
                                        ),
                                        SizedBox(height: 5,),
                                        Text("${list[index]!.time}",
                                          style: TextStyle(
                                            fontSize: 8,
                                            fontWeight: FontWeight.w300,
                                            color: Colors.white
                                        ),),
                                        SizedBox(height: 7,),
                                        widget.singlePost!.userData![0]!.id.toString() == userid.toString() ?  Row(
                                          children: [
                                            // InkWell(
                                            //     onTap: (){
                                            //       setState(() {
                                            //         userReplay = !userReplay;
                                            //       });
                                            //     },
                                            //     child: Text('Replay',style: TextStyle(color: Colors.blueAccent,fontSize: 12),)),
                                            // SizedBox(width: 10,),
                                            InkWell(
                                                onTap: ()async{
                                                  setState(() {
                                                    print("commentId before === $commentId");
                                                    if(commentId.contains(list[index].id.toString())){
                                                      commentId.remove(list[index].id.toString());
                                                    }else{
                                                      commentId.add(list[index].id.toString());
                                                    }
                                                    print("commentId after === $commentId");

                                                  });
                                                  await PostController.hidePostComment(list[index]!.id.toString());
                                                  getCommentFuture = PostController.commentList(post_id: widget.singlePost!.post!.id.toString());;
                                                  setState((){

                                                  });
                                                },
                                                child: commentId.contains(list[index].id.toString())
                                                    ? Row(
                                                  children: [
                                                    Text('Unhide',style: TextStyle(color: Colors.amber,fontSize: 12),),
                                                    SizedBox(width: 5,),
                                                    Icon(Icons.visibility, color: Colors.amber, size: 15,)
                                                  ],
                                                )
                                                    : Row(
                                                  children: [
                                                    Text('Hide',style: TextStyle(color: Colors.red,fontSize: 12),),
                                                    SizedBox(width: 5,),
                                                    Icon(Icons.visibility_off, color: Colors.red, size: 15,)
                                                  ],
                                                )
                                            ),
                                          ],
                                        ) :Center()

                                      ],
                                    ),
                                  ),
                                );
                          }),
                        ),
                        Center(
                          child: Container(
                            height: 1,
                            width: MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(
                                color: Colors.grey.withOpacity(0.3),
                                borderRadius: BorderRadius.circular(10)
                            ),
                          ),
                        ),
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            children: <String>[
                              '❤️', '😍', '😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '😊', '😇',
                            ].map((String emoji) {
                              return GestureDetector(
                                onTap: () {
                                  _addEmojiToComment(emoji);
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                    emoji,
                                    style: TextStyle(fontSize: 24),
                                  ),
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                        Center(
                          child: Container(
                            height: 1,
                            width: MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(
                                color: Colors.grey.withOpacity(0.3),
                                borderRadius: BorderRadius.circular(10)
                            ),
                          ),
                        ),
                        Container(
                              height: 45,
                              // margin: EdgeInsets.only(bottom: 8),
                              child: Row(
                                children: [
                                  const SizedBox(width: 5)  ,
                                  ClipOval(
                                      child: AppNetworkImage(src: profilePic, height: 30, width: 30,)),
                                  const SizedBox(width: 10)  ,
                                  Flexible(
                                    child: Container(
                                      padding: EdgeInsets.all(0),
                                      child: TextFormField(
                                        autofocus: true,
                                        cursorColor: AppColors.mainColor,
                                        style: TextStyle(
                                            fontSize: 15,
                                            color: Colors.white
                                        ),
                                        controller: comment,
                                        decoration: InputDecoration(
                                            contentPadding: EdgeInsets.zero,
                                            fillColor: Colors.transparent,
                                            border: OutlineInputBorder(
                                              borderSide: BorderSide.none,
                                            ),
                                            enabledBorder: OutlineInputBorder(
                                              borderSide: BorderSide.none,
                                            ),
                                            focusedBorder: OutlineInputBorder(
                                              borderSide: BorderSide.none,
                                            )
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 5)  ,
                                   isCommentLoading
                                    ? Container(
                                    height: 30,
                                    width: 30,
                                    decoration: BoxDecoration(
                                        color: AppColors.mainColor,
                                        borderRadius: BorderRadius.circular(5)
                                    ),
                                    child: const Center(
                                      child: SizedBox(
                                        height: 20,
                                        width: 20,
                                        child: CircularProgressIndicator(
                                          valueColor: AlwaysStoppedAnimation<Color>(AppColors.white),
                                          strokeWidth: 4,
                                        ),
                                      ),
                                    ),
                                  )
                                    :InkWell(
                                    onTap: (){

                                      setState(() {
                                        _commentOnPost(widget.singlePost!.post!.id.toString());
                                        Navigator.pop(context);
                                      });
                                      setState(() {

                                      });
                                    },
                                    child: Container(
                                      height: 30,
                                      width: 30,
                                      decoration: BoxDecoration(
                                          color: AppColors.mainColor,
                                          borderRadius: BorderRadius.circular(5)
                                      ),
                                      child: Center(
                                        child: Icon(Icons.send,color: Colors.white,size: 15,),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 5)  ,

                                ],
                              ),
                            ) ,
                      ],
                    )
                        : Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min, // Set MainAxisSize.min here
                      children: [
                        Center(
                          child: Container(
                            height: 5,
                            width: 50,
                            decoration: BoxDecoration(
                                color: Colors.grey.withOpacity(0.3),
                                borderRadius: BorderRadius.circular(10)
                            ),
                          ),
                        ),
                        SizedBox(height: 30,),
                        Center(
                          child: Text('Comments',
                            style: TextStyle(color: Colors.white,fontWeight: FontWeight.w600,fontSize: 13),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        SizedBox(height: 20,),
                        Center(
                          child: Container(
                            height: 1,
                            width: MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(
                                color: Colors.grey.withOpacity(0.3),
                                borderRadius: BorderRadius.circular(10)
                            ),
                          ),
                        ),

                        Padding(
                          padding: const EdgeInsets.only(left: 15, right: 15, top: 15, bottom: 5),
                          child: Text('',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontFamily: 'Roboto-Regular',
                                  fontSize: 12
                              )),
                        ),
                        Expanded(
                          child: ListView.builder(
                              controller: _scrollController,
                              itemCount: list.length,
                              itemBuilder: (_,index){
                                return Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 5.0,horizontal: 5),
                                  child: ListTile(
                                    leading: InkWell(
                                        onTap: (){
                                          Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientBottomNavigationBar(pageIndex: 6, userId:list[index].commentUser?.id )));
                                        },
                                        child: ClipRRect(borderRadius: BorderRadius.circular(45), child: Image.network(list[index]!.commentUser!.profileImage!,fit: BoxFit.cover,height: 30,width: 30,))),
                                    title: Text('${list[index]!.commentUser?.name}',
                                      style: TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w700,
                                          color: Colors.grey.shade200
                                      ),
                                    ),
                                    subtitle: Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text("${list[index]!.comments }",
                                          style: TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight.w500,
                                              color: Colors.white
                                          ),
                                        ),
                                        SizedBox(height: 5,),
                                        Text("${list[index]!.time}",
                                          style: TextStyle(
                                              fontSize: 8,
                                              fontWeight: FontWeight.w300,
                                              color: Colors.white
                                          ),),
                                        SizedBox(height: 7,),
                                        widget.singlePost!.userData![0]!.id.toString() == userid.toString() ?  Row(
                                          children: [
                                            InkWell(
                                                onTap: ()async{
                                                  setState(() {
                                                    print("commentId before === $commentId");
                                                    if(commentId.contains(list[index].id.toString())){
                                                      commentId.remove(list[index].id.toString());
                                                    }else{
                                                      commentId.add(list[index].id.toString());
                                                    }
                                                    print("commentId after === $commentId");

                                                  });
                                                  await PostController.hidePostComment(list[index]!.id.toString());
                                                  getCommentFuture = PostController.commentList(post_id: widget.singlePost!.post!.id.toString());;
                                                  setState((){

                                                  });
                                                },
                                                child: commentId.contains(list[index].id.toString())
                                                    ? Row(
                                                  children: [
                                                    Text('Unhide',style: TextStyle(color: Colors.amber,fontSize: 12),),
                                                    SizedBox(width: 5,),
                                                    Icon(Icons.visibility, color: Colors.amber, size: 15,)
                                                  ],
                                                )
                                                    : Row(
                                                  children: [
                                                    Text('Hide',style: TextStyle(color: Colors.red,fontSize: 12),),
                                                    SizedBox(width: 5,),
                                                    Icon(Icons.visibility_off, color: Colors.red, size: 15,)
                                                  ],
                                                )
                                            ),
                                          ],
                                        ) :Center()

                                      ],
                                    ),
                                  ),
                                );
                              }),
                        ),
                        Center(
                          child: Container(
                            height: 1,
                            width: MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(
                                color: Colors.grey.withOpacity(0.3),
                                borderRadius: BorderRadius.circular(10)
                            ),
                          ),
                        ),
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            children: <String>[
                              '❤️', '😍', '😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '😊', '😇',
                            ].map((String emoji) {
                              return GestureDetector(
                                onTap: () {
                                  _addEmojiToComment(emoji);
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                    emoji,
                                    style: TextStyle(fontSize: 24),
                                  ),
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                        Center(
                          child: Container(
                            height: 1,
                            width: MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(
                                color: Colors.grey.withOpacity(0.3),
                                borderRadius: BorderRadius.circular(10)
                            ),
                          ),
                        ),
                        Container(
                          height: 45,
                          // margin: EdgeInsets.only(bottom: 8),
                          child: Row(
                            children: [
                              const SizedBox(width: 5)  ,
                              ClipOval(
                                  child: AppNetworkImage(src: profilePic, height: 30, width: 30,)),
                              const SizedBox(width: 10)  ,
                              Flexible(
                                child: Container(
                                  padding: EdgeInsets.all(0),
                                  child: TextFormField(
                                    autofocus: true,
                                    cursorColor: AppColors.mainColor,
                                    style: TextStyle(
                                        fontSize: 15,
                                        color: Colors.white
                                    ),
                                    controller: comment,
                                    decoration: InputDecoration(
                                        contentPadding: EdgeInsets.zero,
                                        fillColor: Colors.transparent,
                                        border: OutlineInputBorder(
                                          borderSide: BorderSide.none,
                                        ),
                                        enabledBorder: OutlineInputBorder(
                                          borderSide: BorderSide.none,
                                        ),
                                        focusedBorder: OutlineInputBorder(
                                          borderSide: BorderSide.none,
                                        )
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 5)  ,
                              isCommentLoading
                                  ? Container(
                                height: 30,
                                width: 30,
                                decoration: BoxDecoration(
                                    color: AppColors.mainColor,
                                    borderRadius: BorderRadius.circular(5)
                                ),
                                child: const Center(
                                  child: SizedBox(
                                    height: 20,
                                    width: 20,
                                    child: CircularProgressIndicator(
                                      valueColor: AlwaysStoppedAnimation<Color>(AppColors.white),
                                      strokeWidth: 4,
                                    ),
                                  ),
                                ),
                              )
                                  :InkWell(
                                onTap: (){
                                  setState(() {
                                    _commentOnPost(widget.singlePost!.post!.id.toString());
                                    Navigator.pop(context);

                                  });
                                  setState(() {

                                  });
                                },
                                child: Container(
                                  height: 30,
                                  width: 30,
                                  decoration: BoxDecoration(
                                      color: AppColors.mainColor,
                                      borderRadius: BorderRadius.circular(5)
                                  ),
                                  child: Center(
                                    child: Icon(Icons.send,color: Colors.white,size: 15,),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 5)  ,

                            ],
                          ),
                        ) ,
                      ],
                    )
                  ),
                ),
              );
            }
          );


          // return Container(
          //   height: MediaQuery.of(context).size.height*.90,
          //   width:  MediaQuery.of(context).size.width,
          //   decoration: BoxDecoration(
          //     borderRadius: BorderRadius.circular(40)
          //   ),
          //   child: list.length > 0 ? ListView.builder(
          //     itemCount: list.length,
          //     itemBuilder: (_, index){
          //       return ListTile(
          //         leading: ClipRRect(borderRadius: BorderRadius.circular(100), child: AppNetworkImage(src: list[index]!.commentUser!.profileImage!,)),
          //         title: Text('${list[index]!.commentUser?.name}'),
          //         subtitle: Text("${list[index]!.comments}"),
          //       );
          //     },
          //   ) : Center(child: Text("No comment "),)
          // );
        });
  }





///////////////////////////////////////#######################/////////////////////////////////
  bool isLiking = false;
  bool isLike = false;
  _postList(post_id)async{
    setState(() =>isLiking = true);
    await PostController.likePost(post_id: post_id);
    setState(() {
      isLike = true;
      isLikeList.add(post_id);
      likeCount = (likeCount!+1)!;
    });
    print("like this post id: ${isLike}");

    setState(() {
      isPressed ? isPressed = false : isPressed = true;
    });
    setState(() =>isLiking = false);
  }
  ///////////unlike///////
  _postUnList(post_id)async{
    setState(() =>isLiking = true);
    await PostController.unLikePost(post_id: post_id);
    setState(() {
      isLike = false;
      isLikeList.remove(post_id);
      likeCount = (likeCount!-1)!;
    });
    print("like this post id: ${isLike}");

    setState(() {
      isPressed ? isPressed = false : isPressed = true;
    });
    setState(() =>isLiking = false);
  }

  bool isCommentLoading = false;
  _commentOnPost(post_id) async{
    setState(() =>isCommentLoading = true);
    var res = await PostController.addComment(post_id: post_id.toString(), comment: comment.text);
    print("comment ==== ${post_id}");
    print("comment ==== ${res.body}");
    if(res.statusCode == 200){
      //once comment is done, then isComment FALSE, and hide input//
      setState(() {
        isComment = false;
        comment.clear();
        getCommentFuture = PostController.commentList(post_id: widget.singlePost!.post!.id.toString());
      });

      print("data === ${res.body}");
      print("data === ${res.statusCode}");
      //-------------------------------------------------------//
      AlertController.snackbar(context: context, text: "Comment added.", bg: AppColors.mainColor);
    }else{
      AlertController.snackbar(context: context, text: "Something went wrong with server", bg: Colors.red);
    }
    setState(() =>isCommentLoading = false);
  }


  void _addEmojiToComment(String emoji) {
    final currentText = comment.text;
    final selection = comment.selection;

    // Insert the emoji at the current cursor position
    final newText = currentText.replaceRange(
      selection.baseOffset,
      selection.extentOffset,
      emoji,
    );

    // Update the text and move the cursor to the end
    comment.value = TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(offset: newText.length),
    );
  }
///////////////////////////////////////#######################/////////////////////////////////

 postAddToFav(post_id) async{
   SharedPreferences pref = await SharedPreferences.getInstance();
   var token = pref.getString("token");

   print(AppConfig.POST_FAVORITE);
   var respose = await http.post(Uri.parse(AppConfig.POST_FAVORITE),
       headers: {
         "Authorization" : "Bearer $token",
         "Accept" : "application/json"
       },
        body: {
          "post_id" : post_id.toString()
        }
   );

    print("response === ${respose.body}");
    print("response === ${respose.statusCode}");
    if(respose.statusCode == 200){
      setState(() {
        showBookmarkLoading = false;
        bookmark = true;
      });
    }else{
      setState(() {
        showBookmarkLoading = false;

        bookmark = false;
      });
    }
 }

 postRemoveFromFav(post_id) async{
   SharedPreferences pref = await SharedPreferences.getInstance();
   var token = pref.getString("token");

   print(AppConfig.POST_UNFAVORITE);
   var respose = await http.post(Uri.parse(AppConfig.POST_UNFAVORITE),
       headers: {
         "Authorization" : "Bearer $token",
         "Accept" : "application/json"
       },
       body: {
         "post_id" : post_id.toString()
       }
   );

   print("response === ${respose.body}");
   print("response === ${respose.statusCode}");
   if(respose.statusCode == 200){
     setState(() {
       showBookmarkLoading = false;

       bookmark = false;
     });
   }else{
     setState(() {
       showBookmarkLoading = false;
       bookmark = true;
     });
   }
 }
}
