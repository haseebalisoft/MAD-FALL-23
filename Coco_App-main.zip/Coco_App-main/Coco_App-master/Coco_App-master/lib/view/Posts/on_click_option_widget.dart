import 'package:coco/controller/postController.dart';
import 'package:coco/model/postModel/PostModel.dart';
import 'package:coco/view/freelancer/uploadPortfolio/PickerCropResultScreen.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../utility/colors.dart';
import '../../viewController/uploadphotos_videos.dart';
import 'UserPosts.dart';

class showAlertDialogg extends StatefulWidget {
  final String postId;
  final String? userName;
  final String? description;
  final List<Images>? images;
  const showAlertDialogg({super.key, required this.postId, this.images, this.description, this.userName});

  @override
  State<showAlertDialogg> createState() => _showAlertDialoggState();
}

class _showAlertDialoggState extends State<showAlertDialogg> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: Column(
            children: [
              Row(
                children: [
                  Spacer(),
                  IconButton(
                    onPressed: () {
                      Get.back();
                    },
                    icon: Icon(Icons.clear,size: 40,),
                    color: Colors.white,
                  )
                ],
              ),
              Spacer(),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 28.0),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                      style: OutlinedButton.styleFrom(
                        backgroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                      ),
                      onPressed: ()=>Get.to(UploadPhotosVideos(image: widget.images, postId: widget.postId, description: widget.description, title: "Edit")),
                      child: Text(
                        'Edit Portfolio',
                        style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 15),
                      )),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 28.0),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(

                      style: OutlinedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                        backgroundColor: AppColors.mainColor,
                      ),
                      onPressed: ()=> _deletePost(),
                      child: isLoading
                          ? Center(child: CircularProgressIndicator(strokeWidth: 1, color: Colors.white,),)
                          : Text(
                        'Delete',
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 15),
                      )),
                ),
              ),
              Spacer(),
            ],
          ),
        ),
      ),
      backgroundColor: Colors.black.withOpacity(0.85),
    );
  }

  bool isLoading = false;

  _deletePost() async{
    setState(() =>isLoading = true);
    var res = await PostController.deletePost(post_id: '${widget.postId}');
    print("delete post res === ${res.body}");
    print("delete post res === ${res.statusCode}");
    if(res.statusCode == 200){
      AlertController.snackbar(context: context, text: "Post was delete", bg: Colors.green);
      setState(() {
      });
      Get.to(Users_Posts(userName: widget.userName!, userImage: ""));
    }else{
      AlertController.snackbar(context: context, text: "Something went wrong with server.", bg: Colors.red);
    }
    setState(() =>isLoading = false);
  }
}
