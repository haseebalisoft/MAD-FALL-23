import 'package:flutter/material.dart';

class SliderWithDotIndicator extends StatefulWidget {
  final List imageUrls;
  const SliderWithDotIndicator({required this.imageUrls});
  @override
  _SliderWithDotIndicatorState createState() => _SliderWithDotIndicatorState();
}

class _SliderWithDotIndicatorState extends State<SliderWithDotIndicator> {
  final PageController _pageController = PageController();
  int _currentPage = 0;


  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Slider with Dot Indicator'),
      ),
      body: Column(
        children: [
          Expanded(
            child: PageView.builder(
              controller: _pageController,
              itemCount: widget.imageUrls.length,
              itemBuilder: (context, index) {
                return Image.network(
                  widget.imageUrls[index].image,
                  fit: BoxFit.cover,
                );
              },
              onPageChanged: (int index) {
                setState(() {
                  _currentPage = index;
                });
              },
            ),
          ),
          SizedBox(height: 20.0),
          buildDotIndicator(),
        ],
      ),
    );
  }

  Widget buildDotIndicator() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List<Widget>.generate(widget.imageUrls.length, (int index) {
        return Container(
          width: 10.0,
          height: 10.0,
          margin: EdgeInsets.symmetric(horizontal: 5.0),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _currentPage == index ? Colors.blue : Colors.grey,
          ),
        );
      }),
    );
  }
}
