import 'package:coco/utility/colors.dart';
import 'package:coco/view/auth/role_selector.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';

import '../../utility/appAssets.dart';
import '../../viewController/signupTopBar.dart';


class otp_verified_screen extends StatefulWidget {
  const otp_verified_screen({super.key});

  @override
  State<otp_verified_screen> createState() => _otp_verified_screenState();
}

class _otp_verified_screenState extends State<otp_verified_screen> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Container(
      color: Colors.black,
      child: SafeArea(
        child: Scaffold(
          backgroundColor: Colors.black,
          body: Center(
            child: Container(
              color: Colors.black,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // SignUpTopBar(size: size,),
                    Padding(
                      padding: const EdgeInsets.only(left: 40, right: 40, top: 50),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          SizedBox(
                            height: 20,
                          ),
                          Padding(
                            padding: const EdgeInsets.all(28.0),
                            child: Center(
                              child: SvgPicture.asset(AssetUtils.sign),
                            ),
                          ),
                          SizedBox(
                            height: 30,
                          ),
                          Center(
                              child: Text(
                            'Code Verified',
                            style: TextStyle(
                              color: AppColors.white,
                              fontSize: 19,
                              fontFamily: 'Poppins-Bold',),
                          )),
                          SizedBox(
                            height: 30.h,
                          ),
                          SizedBox(
                              width: double.infinity,
                              child: ElevatedButton(
                                  onPressed: () {
                                    Get.to(Role_selector());
                                  },
                                  child: Text('Continue'))),

                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
