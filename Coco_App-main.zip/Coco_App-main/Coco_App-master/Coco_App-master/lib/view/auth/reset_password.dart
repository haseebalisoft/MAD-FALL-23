import 'dart:convert';
import 'dart:io';

import 'package:coco/controller/authController.dart';
import 'package:coco/controller/locationController.dart';
import 'package:coco/view/auth/pin_varification.dart';
import 'package:coco/view/auth/role_selector.dart';
import 'package:coco/view/auth/sign_in.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:faker/faker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:intl_phone_number_input/intl_phone_number_input.dart';
import 'package:location/location.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';
import '../../controller/auth/reset_password_controller.dart';
import '../../helper/helperFunctions.dart';
import '../../utility/colors.dart';
import '../../viewController/prograssLoading.dart';
import '../../viewController/signupTopBar.dart';

class ResetPassword extends StatefulWidget {
  final String email;
  const ResetPassword({super.key, required this.email});

  @override
  State<ResetPassword> createState() => _ResetPasswordState();
}

class _ResetPasswordState extends State<ResetPassword> {



  ResetPasswordController resetPasswordController = Get.put(ResetPasswordController());

  final password = TextEditingController();
  final confirmPassword = TextEditingController();

  late bool passwordVisible;
  late bool confirmPasswordVisible;

  int passwordLength = 0;


  @override
  void initState() {
    super.initState();
    passwordVisible = true;
    confirmPasswordVisible = true;
  }




  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Obx(() =>
        resetPasswordController.isLoading.value
            ? const Center(
          child: CircularProgressIndicator(
            color: AppColors.mainColor,
          ),
        ) :
      Container(
        color: Colors.black,
        child: Scaffold(
          backgroundColor: Colors.black,
          body: AnnotatedRegion<SystemUiOverlayStyle>(
            value: SystemUiOverlayStyle.dark.copyWith(
              statusBarColor: Colors.transparent, // Set the status bar color
              statusBarIconBrightness: Brightness.light, // Set the status bar text color
            ),
            child: Container(
              height: size.height,
              width: size.width,
              child: ListView(
                children: [
                  SizedBox(height: 5.h,),
                  SignUpTopBar(size: size),
                  Padding(
                    padding:
                    const EdgeInsets.only(left: 37, right: 37, top: 50),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        SizedBox(
                          height: 20,
                        ),

                        SizedBox(
                          height: 7,
                        ),
                        TextFormField(
                          style: TextStyle(
                              color: AppColors.white,
                              fontSize: 14
                          ),
                          controller: password,
                          onChanged: (v){
                            setState(() {
                              passwordLength = v.length;
                            });
                          },
                          decoration: InputDecoration(
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide.none
                              ),
                              enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide.none
                              ),
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide.none
                              ),
                              hintStyle: TextStyle(
                                  fontWeight: FontWeight.w400,
                                  fontSize: 12,
                                  color: AppColors.textgrey),
                              fillColor: AppColors.formColorUp,
                              hintText: 'Password',
                              suffixIcon: IconButton(
                                icon: Icon(
                                  // Based on passwordVisible state choose the icon
                                  passwordVisible
                                      ? Icons.visibility_off
                                      : Icons.visibility,
                                  color: AppColors.textgrey,
                                  size: 18,
                                ),
                                onPressed: () {
                                  // Update the state i.e. toogle the state of passwordVisible variable
                                  setState(() {
                                    passwordVisible = !passwordVisible;
                                  });
                                },
                              ),
                              prefixIcon: Icon(
                                Icons.lock,
                                size: 20,
                                color: AppColors.mainColor,
                              )),
                          obscureText: passwordVisible,
                          validator: (v){
                            if(v!.isEmpty){
                              return "Password must not be empty";
                            }else if(v!.length < 6){
                              return "Password must be 6 character";
                            }else{
                              return null;
                            }
                          },
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        TextFormField(
                          style: TextStyle(
                              color: AppColors.white,
                              fontSize: 14
                          ),
                          controller: confirmPassword,
                          onChanged: (v){
                            setState(() {
                            });
                          },
                          decoration: InputDecoration(
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide.none
                              ),
                              enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide.none
                              ),
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide.none
                              ),
                              hintStyle: TextStyle(
                                  fontWeight: FontWeight.w400,
                                  fontSize: 12,
                                  color: AppColors.textgrey),



                              fillColor: AppColors.formColorUp,
                              hintText: 'Confirm Password',
                              suffixIcon: IconButton(
                                icon: Icon(
                                  // Based on passwordVisible state choose the icon
                                  confirmPasswordVisible
                                      ? Icons.visibility_off
                                      : Icons.visibility,
                                  color: AppColors.textgrey,
                                  size: 18,
                                ),
                                onPressed: () {
                                  // Update the state i.e. toogle the state of confirmPasswordVisible variable
                                  setState(() {
                                    confirmPasswordVisible = !confirmPasswordVisible;
                                  });
                                },
                              ),
                              prefixIcon: Icon(
                                Icons.lock,
                                size: 20,
                                color: AppColors.mainColor,
                              )),
                          obscureText: confirmPasswordVisible,
                          validator: (v){
                            if(v!.isEmpty){
                              return "Password must not be empty";
                            }else if(v!.length < 6){
                              return "Password must be 6 character";
                            }else{
                              return null;
                            }
                          },
                        ),
                        SizedBox(
                          height: password.text == confirmPassword.text ? 10 : 5,
                        ),
                        password.text == confirmPassword.text
                            ? SizedBox()
                        :  const Padding(
                          padding: EdgeInsets.only(left: 8.0, right: 8.0),
                          child: Text(
                            'Password does not match.',
                            style: TextStyle(
                                color: Colors.red,
                                fontSize: 12
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 8,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Icon(
                                passwordLength < 6 ? Icons.info_outline : Icons.check_circle,
                                color: passwordLength < 6 ? AppColors.textgrey : Colors.green,
                                size: 12,
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              Text(
                                'Password must be 6 characters long.',
                                style: TextStyle(
                                    color: passwordLength < 6 ? AppColors.textgrey : Colors.green
                                    ,
                                    fontSize: 12
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 15,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(bottom: 2.0),
                          child: SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed: (){
                                if(passwordLength < 6){
                                  SnackBar snackBar = SnackBar(content: Text('Password must be 6 characters long.'), backgroundColor: Colors.red,);
                                  ScaffoldMessenger.of(context).showSnackBar(snackBar);
                                  return;
                                }

                                if(password.text != confirmPassword.text){
                                  SnackBar snackBar = SnackBar(content: Text('Password does not match.'), backgroundColor: Colors.red,);
                                  ScaffoldMessenger.of(context).showSnackBar(snackBar);
                                  return;
                                }

                                resetPasswordController.resetPassword(widget.email, password.text, context);
                              },
                              child: Text(
                                'Reset Password',
                                style: TextStyle(
                                    fontSize: 14, fontFamily: 'Poppins-Bold'),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 6.h,
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }



/////////////////////////////////////////////////////////
///////////////////// signup method /////////////////////
}
