import 'package:coco/controller/authController.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/view/auth/otp_varified_screen.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:sizer/sizer.dart';
import '../../controller/auth/forgot_password_otp_controller.dart';
import '../../viewController/prograssLoading.dart';
import '../../viewController/signupTopBar.dart';

class ForgotPasswordOtp extends StatefulWidget {
  final String email;
  const ForgotPasswordOtp({super.key, required this.email});

  @override
  State<ForgotPasswordOtp> createState() => _ForgotPasswordOtpState();
}

class _ForgotPasswordOtpState extends State<ForgotPasswordOtp> {


  ForgotPasswordOtpController forgotPasswordOtpController = Get.put(ForgotPasswordOtpController());
  String otp = "";


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // otpSendingFuture = otpSendTest();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return SafeArea(
      child: Obx(() =>
          forgotPasswordOtpController.isLoading.value
              ? const Center(
            child: CircularProgressIndicator(
              color: AppColors.mainColor,
            ),
          )
           : Container(
          color: Colors.black,
          child: Scaffold(
            backgroundColor: Colors.black,
            body: Container(
              color: Colors.black,
              child: SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child: Column(

                  children: [
                    SizedBox(height: 4.h,),
                    SignUpTopBar(size: size),
                    Padding(
                      padding: const EdgeInsets.all(25.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(
                            height: 60,
                          ),
                          const Text(
                            'Verification code',
                            style: TextStyle(
                                fontSize: 19, fontFamily: 'Poppins-Bold'),
                          ),
                          SizedBox(height: 5,),
                          const Text(
                            'Please enter the verification code you have received by email',
                            style:
                            TextStyle(fontSize: 12, color: AppColors.textgrey,
                                fontFamily:'Poppins-Light'
                            ),
                          ),
                          SizedBox(
                            height: 6.h,
                          ),

                          PinCodeTextField(
                            length: 6,
                            obscureText: false,
                            animationType: AnimationType.fade,
                            keyboardType: TextInputType.number,
                            pinTheme: PinTheme(
                              shape: PinCodeFieldShape.box,
                              borderRadius: BorderRadius.circular(5),
                              fieldHeight: 62,
                              fieldWidth: 48,
                              activeFillColor: Colors.white,
                              inactiveFillColor: Color(0xffEDEDED),
                              inactiveColor:Color(0xffEDEDED).withOpacity(0.61),
                              activeColor: Colors.black,
                              selectedFillColor: Colors.white,
                              selectedColor: AppColors.black,
                            ),
                            animationDuration: Duration(milliseconds: 300),
                            backgroundColor: Colors.black,
                            enableActiveFill: true,
                            cursorColor: Colors.black,
                            validator: (String? value) {
                              if (value?.isEmpty ?? true) {
                                return 'Enter OTP here';
                              }
                            },
                            onCompleted: (v) {
                              print("Completed $v");
                              otp = v;

                            },
                            onChanged: (value) {

                            },
                            beforeTextPaste: (text) {
                              print("Allowing to paste $text");
                              //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
                              //but you can show anything you want here, like your pop up saying wrong paste format or etc
                              return true;
                            },
                            appContext: context,
                          ),
                          SizedBox(
                            height: 20.h,
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                                style: ButtonStyle(
                                    backgroundColor:  MaterialStateProperty.all(AppColors.mainColor)
                                ),
                                onPressed: () {
                                  if(otp.isEmpty){
                                    SnackBar snackBar = SnackBar(content: Text('Please enter OTP'), backgroundColor: Colors.red,);
                                    ScaffoldMessenger.of(context).showSnackBar(snackBar);
                                    return;
                                  }
                                  if(otp.length < 6){
                                    SnackBar snackBar = SnackBar(content: Text('Please enter valid OTP'), backgroundColor: Colors.red,);
                                    ScaffoldMessenger.of(context).showSnackBar(snackBar);
                                    return;
                                  }

                                  forgotPasswordOtpController.resetTokenVerify(widget.email, otp, context);

                                },
                                child: Text('Validate',  style: TextStyle(
                                    fontSize: 14, fontFamily: 'Poppins-Bold'),)),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                                style: ButtonStyle(
                                    backgroundColor:  MaterialStateProperty.all(Colors.transparent)
                                ),
                                onPressed: () {
                                  forgotPasswordOtpController.sendEmail(widget.email, context);
                                },
                                child: Text('Resend OTP',  style: TextStyle(
                                    fontSize: 14, fontFamily: 'Poppins-Bold', color: Colors.white.withOpacity(0.6)),)),
                          ),

                          // SizedBox(
                          //   height: 20.h,
                          // ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
