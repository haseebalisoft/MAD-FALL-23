import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../utility/appAssets.dart';
import '../../utility/colors.dart';
import '../client/bottomNagivation/buttom_nav.dart';
import '../freelancer/bottomNavigationBar/becameFreelanceBottomNavigation.dart';

class SignInRoleSelect extends StatelessWidget {
  const SignInRoleSelect({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        color: Colors.black,
        child: Scaffold(
          body: Stack(
            children: [
              SizedBox(
                  height: double.infinity,
                  width: double.infinity,
                  child: Container(
                    color: Colors.black,
                  )),

              SizedBox(
                height: double.infinity,
                width: double.infinity,
                child: Image.asset(
                  AssetUtils.role_select_img,
                  fit: BoxFit.cover,
                ),
              ),
              Row(
                children: [
                  IconButton(
                      onPressed: () {
                        Get.back();
                      },
                      icon: Icon(
                        Icons.arrow_back,
                        color: Colors.white,
                      )),
                  SizedBox(
                    width: 50,
                  )
                ],
              ),
              Center(
                child: Padding(
                  padding: const EdgeInsets.all(18.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const Text(
                        'Which Profile',
                        style: TextStyle(
                            fontSize: 30,
                            fontFamily: 'Poppins-Bold',
                            color: Colors.white),
                      ),
                      const Text(
                        'Wanna Check?',
                        style: TextStyle(
                            fontSize: 30,
                            fontFamily: 'Poppins-Bold',
                            color: Colors.white),
                      ),
                      SizedBox(
                        height: 39,
                      ),
                      Text(
                        'Select which role profile you wanna check',
                        style: TextStyle(color: AppColors.textgrey, fontSize: 12),
                      ),
                      SizedBox(
                        height: 30,
                      ),
                      SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                  backgroundColor: Color(0xff4AC07C)),
                              onPressed: () {
                                // Get.to(CreateProfileStep1());
                                Get.to(ClientBottomNavigationBar(pageIndex: 4,));
                              },
                              child: Text(
                                'Hire a freelancer',
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ))),
                      SizedBox(
                        height: 15,
                      ),
                      SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.white,
                              ),
                              onPressed: () {

                                Get.to(FreelancerAppBottomNavigation(pageIndex: 5,));

                              },
                              child: Text(
                                'Become a Freelancer',
                                style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold),
                              ))),
                      SizedBox(
                        height: 70,
                      )
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
