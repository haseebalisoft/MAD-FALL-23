import 'dart:convert';
import 'dart:io';

import 'package:coco/controller/authController.dart';
import 'package:coco/controller/locationController.dart';
import 'package:coco/view/auth/pin_varification.dart';
import 'package:coco/view/auth/role_selector.dart';
import 'package:coco/view/auth/sign_in.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:faker/faker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:intl_phone_number_input/intl_phone_number_input.dart';
import 'package:location/location.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';
import '../../helper/helperFunctions.dart';
import '../../utility/colors.dart';
import '../../viewController/prograssLoading.dart';
import '../../viewController/signupTopBar.dart';

class Sign_up extends StatefulWidget {
  const Sign_up({super.key});

  @override
  State<Sign_up> createState() => _Sign_upState();
}

class _Sign_upState extends State<Sign_up> {

final signUpFormKey = GlobalKey<FormState>();

////// get location
  Location location =  Location();
  late LocationData _locationData;
  var lat, lng;
  var errorText;

  bool isGoogleLogin = false;

  String phone_country_code = "";
  String phone_number = "";

  String phone_iso_code = "";


//
  final userName = TextEditingController();
  final email = TextEditingController();
  final phone = TextEditingController();
  final password = TextEditingController();

  var phontErrorText;

  late bool _passwordVisible;
  @override
  void initState() {
    _passwordVisible = true;
    getLocationLatLng();
  }

  //bool isGoogleLogin = false;
  ///// store coundty code
  storeCountryCode(code)async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    setState(() {
      _pref.setString("isoCode", code);
    });
  }

  //get current location
  bool isLocationLoading = false;
  getLocationLatLng()async{
    setState(() =>isLocationLoading = true);
    HelperFunction.locationData().then((value){
      setState(() {
        lat = value.latitude;
        lng = value.longitude;
      });
      print("print lat === $lat");
    });
    setState(() =>isLocationLoading = false);

  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Container(
      color: Colors.black,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: AnnotatedRegion<SystemUiOverlayStyle>(
          value: SystemUiOverlayStyle.dark.copyWith(
            statusBarColor: Colors.transparent, // Set the status bar color
            statusBarIconBrightness: Brightness.light, // Set the status bar text color
          ),
          child: Container(
            height: size.height,
            width: size.width,
            child: Form(
              key: signUpFormKey,
              child: ListView(
                children: [
                  SizedBox(height: 4.h,),
                  SignUpTopBar(size: size),
                  Padding(
                    padding:
                        const EdgeInsets.only(left: 37, right: 37, top: 50),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: 7,
                        ),
                        Text(
                          'Sign Up',
                          style: TextStyle(
                              fontSize: 12,
                              color: AppColors.white,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Poppins-Bold'),
                        ),
                        isLocationLoading ? ProgressLoading() : Center(),
                        errorText!=null ?Padding(
                          padding: EdgeInsets.all(10),
                          child: Center(child: Text("$errorText",
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.red,
                              fontWeight: FontWeight.bold
                            )
                          )),
                        ): Center(),
                        SizedBox(
                          height: 10,
                        ),
                        TextFormField(
                          style: TextStyle(
                              color: AppColors.white,
                              fontSize: 14
                          ),
                          controller: userName,
                         onTap: (){

                         },
                          onChanged: (v){
                            setState(() {
                              userNameError = "";
                            });
                          },
                          decoration:  InputDecoration(
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide.none
                              ),
                              enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide.none
                              ),
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide.none
                              ),
                              fillColor: AppColors.formColorUp,
                              hintText: 'Username',
                              hintStyle: TextStyle(
                                  fontWeight: FontWeight.w400,
                                  fontSize: 12,
                                  color: AppColors.textgrey),
                              prefixIcon: Icon(
                                Icons.person,
                                color: AppColors.mainColor,
                                size: 20,
                              )),
                          validator: (v){
                            if(v!.isEmpty){
                              return "Username must not be empty";
                            } else if(v!.length < 6){
                              return "Username must be 6 character";
                            }else{
                              return null;
                            }
                          },
                        ),
                        SizedBox(height: 5,),
                        userNameError.isNotEmpty
                            ? Text("${userNameError}",
                          style: TextStyle(
                            color: Colors.red,
                            fontStyle: FontStyle.italic,
                          ),
                        ): Center(),
                        SizedBox(
                          height: 7,
                        ),
                        TextFormField(
                          style: TextStyle(
                              color: AppColors.white,
                              fontSize: 14
                          ),
                          controller: email,
                          onChanged: (v){
                           setState(() {
                             emailError = "";
                           });
                          },
                          decoration:  InputDecoration(
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide.none
                              ),
                              enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide.none
                              ),
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide.none
                              ),
                              hintStyle: TextStyle(
                                  fontWeight: FontWeight.w400,
                                  fontSize: 12,
                                  color: AppColors.textgrey),

                              fillColor: AppColors.formColorUp,
                              hintText: 'Email',
                              prefixIcon: Icon(
                                Icons.email,
                                size: 20,
                                color: AppColors.mainColor,
                              )),
                          validator: (v){
                            if(v!.isEmpty){
                              return "Email must not be empty";
                            }else{
                              return null;
                            }
                          },
                        ),
                        SizedBox(height: 5,),
                        emailError.isNotEmpty ?
                             Text("${emailError}",
                          style: TextStyle(
                            color: Colors.red,
                            fontStyle: FontStyle.italic,
                          ),
                        ) : Center(),
                        SizedBox(
                          height: 7,
                        ),

                        // InternationalPhoneNumberInput(
                        //   onInputChanged: (PhoneNumber number) {
                        //     print(number.phoneNumber);
                        //   },
                        //   onInputValidated: (bool value) {
                        //     print(value);
                        //   },
                        //   selectorConfig: SelectorConfig(
                        //
                        //     selectorType: PhoneInputSelectorType.BOTTOM_SHEET,
                        //     showFlags : true,
                        //     useEmoji : false,
                        //     backgroundColor : AppColors.white,
                        //   ),
                        //   ignoreBlank: false,
                        //   autoValidateMode: AutovalidateMode.disabled,
                        //   selectorTextStyle: TextStyle(color: Colors.black),
                        //
                        //   textFieldController: phone,
                        //   formatInput: true,
                        //   keyboardType:
                        //   TextInputType.numberWithOptions(signed: true, decimal: true),
                        //   inputBorder: OutlineInputBorder(),
                        //   onSaved: (PhoneNumber number) {
                        //     print('On Saved: $number');
                        //   },
                        // ),




                        InternationalPhoneNumberInput(
                            selectorTextStyle: TextStyle(
                              color: Colors.white,
                            ),

                          onInputChanged: (PhoneNumber number) {
                            storeCountryCode(number.isoCode.toString()); //store the country code
                            print(number.dialCode);
                            print(number.phoneNumber);
                            phone_country_code = number.dialCode.toString();
                            phone_number = number.phoneNumber.toString();
                            phone_iso_code = number.isoCode.toString();
                            phoneError = "";

                          },
                          autoValidateMode: AutovalidateMode.always,
                            searchBoxDecoration: InputDecoration(
                                border: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    color: Colors.red, // Change the color to something more visible
                                    width: 2.0, // Increase the border width
                                  ),
                                ),
                              fillColor: Colors.white,
                              filled: true,
                              hintText: "Search123",
                              helperStyle: TextStyle(color: Colors.black, fontWeight: FontWeight.normal)
                            ),
                          hintText:'Phone Number',
                          locale:'US',
                          textStyle: TextStyle(
                            fontSize: 14,
                            color: AppColors.white
                          ),
                          // errorMessage : 'Invalid phone number',
                          inputDecoration : InputDecoration(
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide.none,
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide.none,
                            ),
                            fillColor: AppColors.formColorUp,
                            hintText: 'Phone Number',
                            hintStyle: const TextStyle(
                                fontWeight: FontWeight.w400,
                                fontSize: 12,
                                color: AppColors.textgrey),
                          ),
                          selectorConfig: const SelectorConfig(
                            selectorType: PhoneInputSelectorType.BOTTOM_SHEET,
                            setSelectorButtonAsPrefixIcon: true,
                            leadingPadding: 10,
                            showFlags: true,
                              useEmoji: true,
                          ),
                          ignoreBlank: true,
                          // autoValidateMode: Auto validateMode.always,
                          countrySelectorScrollControlled: true,
                          textFieldController: phone,
                          formatInput: true,
                          keyboardType: TextInputType.numberWithOptions(signed: true, decimal: true),
                          onSaved: (PhoneNumber number) {
                            print('On Saved: $number');
                          },

                        ),

                        SizedBox(height: 0,),

                        // IntlPhoneField(
                        //
                        //   controller: phone,
                        //     showDropdownIcon:true,
                        //   decoration: const InputDecoration(
                        //     hintStyle: TextStyle(fontSize: 12),
                        //     fillColor: AppColors.formColor,
                        //     hintText: 'Phone Number',
                        //   ),
                        //   initialCountryCode: 'AFG',
                        //   style: TextStyle(fontSize: 14),
                        //   onChanged: (phone) {
                        //     print(phone.completeNumber);
                        //   },
                        // ),

                        // TextFormField(
                        //   controller: phone,
                        //   decoration: const InputDecoration(
                        //       hintStyle: TextStyle(fontSize: 12),
                        //       fillColor: AppColors.formColor,
                        //       hintText: 'Phone Number',
                        //       prefixIcon: Icon(
                        //         Icons.phone,
                        //         size: 20,
                        //         color: Colors.black,
                        //       )),
                        //   validator: (v){
                        //     if(v!.isEmpty){
                        //       return "Phone Number must not be empty";
                        //     }else{
                        //       return null;
                        //     }
                        //   },
                        // ),
                        SizedBox(height: 5,),
                        phoneError.isNotEmpty ?
                        Text("${phoneError}",
                          style: TextStyle(
                            color: Colors.red,
                            fontStyle: FontStyle.italic,
                          ),
                        ) : Center(),
                        SizedBox(
                          height: 7,
                        ),
                        TextFormField(
                          style: TextStyle(
                              color: AppColors.white,
                              fontSize: 14
                          ),
                          controller: password,
                          onChanged: (v){
                          },
                          decoration: InputDecoration(
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide.none
                              ),
                              enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide.none
                              ),
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide.none
                              ),
                            hintStyle: TextStyle(
                                fontWeight: FontWeight.w400,
                                fontSize: 12,
                                color: AppColors.textgrey),



                              fillColor: AppColors.formColorUp,
                              hintText: 'Password',
                            suffixIcon: IconButton(
                              icon: Icon(
                                // Based on passwordVisible state choose the icon
                                _passwordVisible
                                    ? Icons.visibility_off
                                    : Icons.visibility,
                                color: AppColors.textgrey,
                                size: 18,
                              ),
                              onPressed: () {
                                // Update the state i.e. toogle the state of passwordVisible variable
                                setState(() {
                                  _passwordVisible = !_passwordVisible;
                                });
                              },
                            ),
                              prefixIcon: Icon(
                                Icons.lock,
                                size: 20,
                                color: AppColors.mainColor,
                              )),
                          obscureText: _passwordVisible,
                          validator: (v){
                            if(v!.isEmpty){
                              return "Password must not be empty";
                            }else if(v!.length < 6){
                              return "Password must be 6 character";
                            }else{
                              return null;
                            }
                          },
                        ),
                        SizedBox(
                          height: 27,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(bottom: 2.0),
                          child: SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed: (){
                                _checkUser();
                              },
                              child: isLoading?CircularProgressIndicator(color: Colors.white, strokeWidth: 1,): Text(
                                'Continue',
                                style: TextStyle(
                                    fontSize: 14, fontFamily: 'Poppins-Bold'),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 6.h,
                        ),

                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Center(
                              child: Text(
                            'You already have an account?',
                            style: TextStyle(
                                color: Color(0xff918F8F),
                                fontSize: 12,
                                fontWeight: FontWeight.w400),
                          )),
                        ),
                        SizedBox(
                          height: 0,
                        ),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () =>Get.to(SignInPage()),
                            child: Text(
                              'Sign in',
                              style: TextStyle(
                                  fontSize: 14, fontFamily: 'Poppins-Bold'),
                            ),
                          ),
                        ),

                        SizedBox(height: 3.h,)

                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }


  //////////////////////////////////////////
  ///////////////////// signup method /////////////////////
  bool isLoading = false;
  String emailError = "", phoneError = "", userNameError = "";
  _checkUser() async{
    setState(()=>isLoading = true);

    // final faker = Faker();
    // email.text = faker.internet.email();
    // userName.text = faker.internet.userName();
    // password.text = "123456";
    // print(signUpFormKey!.currentState!.validate());

    // final faker = Faker();
    // email.text = faker.internet.email();
    // userName.text = faker.internet.userName();
    // password.text = "123456";
    // print(signUpFormKey!.currentState!.validate());
    //
    // if(signUpFormKey!.currentState!.validate()) {
    //
    //   String phone_number_without_country_code = HelperFunction.removeCountryCode(phone_country_code, phone_number);
    //   var res = await AuthController.checkExitingUser(
    //     email: email.text,
    //     userName: userName.text,
    //     phone: phone.text,
    //   );
    //   var data = jsonDecode(res.body);
    //   print("phone ===== --- ${data}");
    //   if (res.statusCode == 200) {
    //     SharedPreferences prefs = await SharedPreferences.getInstance();
    //
    //     await prefs.setString("signUpPhnNumCountryCode", phone_country_code);
    //     await prefs.setString("signUpPhnNum", phone_number);
    //     await prefs.setString("signUpPhnNumISO", phone_iso_code);
    //     await prefs.setString("signUpPhnNumWithoutCountryCode", phone_number_without_country_code);
    //
    //     Get.to(Pin_varification(
    //       userName: userName.text,
    //       phone: phone.text,
    //       email: email.text,
    //       password: password.text,
    //       lat: lat,
    //       lng: lng,
    //     ));
    //   }
    // }

    ////////////////////////////////////////////////////////////////
    if(signUpFormKey!.currentState!.validate()){
      print("phone.text, ==== ${phone.text}");
      String phone_number_without_country_code = HelperFunction.removeCountryCode(phone_country_code, phone_number);

      var res = await AuthController.checkExitingUser(
          email: email.text,
          userName: userName.text,
          phone: phone.text,
      );
      var data = jsonDecode(res.body);
      print("phone ===== --- ${data}");
      if(res.statusCode == 200){

            SharedPreferences prefs = await SharedPreferences.getInstance();

            await prefs.setString("signUpPhnNumCountryCode", phone_country_code);
            await prefs.setString("signUpPhnNum", phone_number);
            await prefs.setString("signUpPhnNumISO", phone_iso_code);
            await prefs.setString("signUpPhnNumWithoutCountryCode", phone_number_without_country_code);

        Get.to(Pin_varification(
          userName: userName.text,
          phone: phone.text,
          email: email.text,
          password: password.text,
          lat: lat, lng: lng,
        ));
      }else{
        if(data["errors"]["phone"] != null ){
          setState(() {
            print("phone error === ${data["errors"]["phone"][0]}");
            phoneError = data["errors"]["phone"][0];
          });
        }
        if(data["errors"]["email"] != null ){
          setState(() {
            emailError = data["errors"]["email"][0];
          });
        }
        if(data["errors"]["user_name"] != null ){
          setState(() {
            userNameError = data["errors"]["user_name"][0];
          });
        }
      }
    }


    setState(()=>isLoading = false);
  }

  void _googleSignUp() async{
    //await AuthController.signOut();
    final UserCredential? user = await AuthController.googleAuth();

    print("user?.user?.phoneNumber == ${user?.user?.phoneNumber}");


    final signup = await  AuthController.signup(
        email: user!.user!.email!,
        password: '--',
        user_name: user.user!.email!,
        phone: "000000000", ///TODO: in api, check the phone validation then replace it user?.user?.phoneNumber
        lat: lat.toString(),
        lng: lng.toString()
    );

    print("signup user === ${signup.body}");
    print("signup user === ${signup.statusCode}");
    if(signup.statusCode == 201){
      Get.offAll(Role_selector());
    }else{
      AlertController.snackbar(context: context, text: "Something went wrong when creating Account with google.", bg: Colors.red);
    }
  }
/////////////////////////////////////////////////////////
///////////////////// signup method /////////////////////
}
