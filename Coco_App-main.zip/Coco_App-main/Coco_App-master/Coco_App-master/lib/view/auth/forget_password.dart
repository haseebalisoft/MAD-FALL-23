import 'package:coco/controller/auth/forgot_password_controller.dart';
import 'package:coco/utility/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';
import 'package:get/get.dart';
class Forget_password extends StatefulWidget {
  const Forget_password({super.key});

  @override
  State<Forget_password> createState() => _Forget_passwordState();
}

class _Forget_passwordState extends State<Forget_password> {

  TextEditingController emailController = TextEditingController();
  late ForgotPasswordController forgotPasswordController = Get.put(ForgotPasswordController());


  @override
  void initState() {
    super.initState();


  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Obx(() =>
          forgotPasswordController.isLoading.value
              ? const Center(
                    child: CircularProgressIndicator(
                      color: AppColors.mainColor,
                   )
                )
              :
          Container(
            color: Colors.black,
          child: AnnotatedRegion<SystemUiOverlayStyle>(
            value: SystemUiOverlayStyle.dark.copyWith(
            statusBarColor: Colors.black, // Set the status bar color
            statusBarIconBrightness: Brightness.light, // Set the status bar text color
          ),
          child: Column(
          children: [
          Container(
          width: double.infinity,
            height: 150,
            decoration: BoxDecoration(),
            child: Row(
              children: [
                IconButton(
                  onPressed: (){
                    Get.back();
                  },
                  icon: Icon(Icons.arrow_back),
                  color: Colors.white,
                ),
                Text(
                  'Forgot password',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontFamily: 'Poppins-Bold'
                  ),
                ),
              ],
            ),
          ),
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.05),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(85),
                  ),
                ),
                child: Container(
                  //color: Colors.black.withOpacity(0.90),
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage('asset/image/forgot_pass_bg.png'),  // Verify the path
                      fit: BoxFit.cover,
                    ),
                  ),
                  child: Column(
                    children: [
                      SizedBox(
                        height: 116,
                      ),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.all(30.0),
                          child: ListView(
                            children: [
                              TextFormField(
                                controller: emailController,
                                keyboardType: TextInputType.emailAddress,
                                cursorColor: AppColors.mainColor,
                                decoration: InputDecoration(
                                    fillColor: Color(0xffF2F2F2),
                                    hintText: 'Email',
                                    prefixIcon: Icon(
                                      Icons.email,
                                      color:Color(0xff898989),
                                    )),
                              ),
                              SizedBox(
                                height: 11,
                              ),
                              Text(
                                'Your password reset otp will be sent to your email address.',
                                style: TextStyle(
                                    color: Color(0xff918F8F), fontSize: 12),
                              ),
                              SizedBox(
                                height: 14.1.h,
                              ),
                              SizedBox(
                                  width: double.infinity,
                                  child: ElevatedButton(
                                      onPressed: () {
                                        if(emailController.text.isEmpty){
                                          SnackBar snackBar = SnackBar(content: Text('Please enter email'), backgroundColor: Colors.red,);
                                          ScaffoldMessenger.of(context).showSnackBar(snackBar);
                                          return;
                                        }
                                        if(!GetUtils.isEmail(emailController.text)){
                                          SnackBar snackBar = SnackBar(content: Text('Please enter valid email'), backgroundColor: Colors.red,);
                                          ScaffoldMessenger.of(context).showSnackBar(snackBar);
                                          return;
                                        }
                                        forgotPasswordController.sendEmail(emailController.text);

                                      },
                                      child: Text('Validate')))
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            )
            ],
          ),
          ),
      ),
        ),
    )
    );
  }
}
