import 'package:coco/controller/authController.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/view/auth/otp_varified_screen.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:sizer/sizer.dart';
import '../../viewController/prograssLoading.dart';
import '../../viewController/signupTopBar.dart';

class Pin_varification extends StatefulWidget {
  final String userName;
  final String email;
  final String phone;
  final String password;
  final double lat;
  final double lng;
  const Pin_varification({super.key, required this.userName, required this.email, required this.phone, required this.password, required this.lat, required this.lng});

  @override
  State<Pin_varification> createState() => _Pin_varificationState();
}

class _Pin_varificationState extends State<Pin_varification> {
  bool isvarified = true;
  var OTP;



  ///////////////// ------- send otp ---------/////////////
  bool isOtpSending = false;
  bool isOtpSend = false;
  Future? otpSendingFuture;
  otpSend()async{
    setState(() =>isOtpSending = true);
    var res = await AuthController.emailOtpSend(email: widget.email);
    print("res.body == ${res.body}");
    if(res.statusCode == 200){
      setState(() =>isOtpSend= true);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("OTP has been send."),
        backgroundColor: Colors.green,
        duration: Duration(milliseconds: 3000),
      ));
    }else{
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("OTP not send. Something went wrong with server."),
        backgroundColor: Colors.red,
        duration: Duration(milliseconds: 3000),
      ));
      Get.back();
    }
    setState(() =>isOtpSending = false);
  }
  otpSendTest() async {
    setState(() => isOtpSending = true);

    // Simulating the absence of API call for testing purposes
    // var res = await AuthController.emailOtpSend(email: widget.email);
    // Commenting out the API call and print statement
    // print("res.body == ${res.body}");

    // Simulating a successful response
    // if (res.statusCode == 200) {
    setState(() => isOtpSend = true);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text("OTP has been sent."),
      backgroundColor: Colors.green,
      duration: Duration(milliseconds: 3000),
    ));
    // } else {
    // Simulating a failure response
    // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    //   content: Text("OTP not sent. Something went wrong with the server."),
    //   backgroundColor: Colors.red,
    //   duration: Duration(milliseconds: 3000),
    // ));
    // Get.back();
    // }

    setState(() => isOtpSending = false);
  }

  ///////////////// ------- send otp ---------/////////////



  ///////////////// ------- Verify otp ---------/////////////
  bool isLoading = false;
  bool isSignup = false;
  verifyOtp()async{
    setState(() =>isLoading = true);
    if(OTP.toString().length >4){
      var res = await AuthController.emailOTPMatch(OTP: OTP, email: widget.email);
      if(res.statusCode == 200){

        ScaffoldMessenger.of(context).showSnackBar( const SnackBar(
          content: Text("Email Verification Success. Creating account..."),
          backgroundColor: Colors.green,
          duration: Duration(milliseconds: 500),
        ));

        //after otp verification
        ///////// user should be signup ====////////
        setState(()=>isSignup = true );
        var singUpRes = await AuthController.signup(
            email: widget.email,
            password: widget.password,
            user_name: widget.userName,
            phone: widget.phone,
            lat: widget.lat.toString(),
            lng: widget.lng.toString()
        );
        print("signup data ===== ${singUpRes.statusCode}");
        print("signup data ===== ${singUpRes.body}");
        if(singUpRes.statusCode == 201){
          ScaffoldMessenger.of(context).showSnackBar( const SnackBar(
            content: Text("Account create success. Your are get to go."),backgroundColor: Colors.green, duration: Duration(milliseconds: 3000),
          ));
          Get.offAll(otp_verified_screen());
        }else{
          setState(()=>isvarified = false );
          ScaffoldMessenger.of(context).showSnackBar( const SnackBar(
            content: Text("Something went wrong while create account."),backgroundColor: Colors.red, duration: Duration(milliseconds: 3000),
          ));
        }
        setState(()=>isSignup = false );
        setState(()=>isvarified = false );

      }else{
        setState(()=>isvarified = false );
        ScaffoldMessenger.of(context).showSnackBar( SnackBar(
          content: Text("Enter a valid verification code."),backgroundColor: Colors.red, duration: Duration(milliseconds: 3000),
        ));
      }
    }else{
      AlertController.snackbar(context: context, text: 'please type valid otp', bg: Colors.red);
    }

    setState(() =>isLoading = false);
  }

  verifyOtpTest()async{
    setState(() =>isLoading = true);


        ScaffoldMessenger.of(context).showSnackBar( const SnackBar(
          content: Text("Email Verification Success. Creating account..."),
          backgroundColor: Colors.green,
          duration: Duration(milliseconds: 500),
        ));

        //after otp verification
        ///////// user should be signup ====////////
        setState(()=>isSignup = true );
        var singUpRes = await AuthController.signup(
            email: widget.email,
            password: widget.password,
            user_name: widget.userName,
            phone: widget.phone,
            lat: widget.lat.toString(),
            lng: widget.lng.toString()
        );
        print("signup data ===== ${singUpRes.statusCode}");
        print("signup data ===== ${singUpRes.body}");
        if(singUpRes.statusCode == 201){
          ScaffoldMessenger.of(context).showSnackBar( const SnackBar(
            content: Text("Account create success. Your are get to go."),backgroundColor: Colors.green, duration: Duration(milliseconds: 3000),
          ));
          Get.offAll(otp_verified_screen());
        }
        else{
          setState(()=>isvarified = false );
          ScaffoldMessenger.of(context).showSnackBar( const SnackBar(
            content: Text("Something went wrong while create account."),backgroundColor: Colors.red, duration: Duration(milliseconds: 3000),
          ));
        }
        setState(()=>isSignup = false );
        setState(()=>isvarified = false );



    setState(() =>isLoading = false);
  }




  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    otpSendingFuture = otpSend();
   // otpSendingFuture = otpSendTest();
  }



  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return SafeArea(
      child: Container(
        color: Colors.black,
        child: Scaffold(
          backgroundColor: Colors.black,
          body: Container(
            color: Colors.black,
            child: SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Column(

                children: [
                  SizedBox(height: 4.h,),
                  SignUpTopBar(size: size),
                  Padding(
                    padding: const EdgeInsets.all(25.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(
                          height: 60,
                        ),
                        const Text(
                          'Verification code',
                          style: TextStyle(
                              fontSize: 19, fontFamily: 'Poppins-Bold'),
                        ),
                        SizedBox(height: 5,),
                        const Text(
                          'Please enter the verification code you have received by email',
                          style:
                              TextStyle(fontSize: 12, color: AppColors.textgrey,
                              fontFamily:'Poppins-Light'
                              ),
                        ),
                        isOtpSending || isSignup ? ProgressLoading() : Center(),
                        SizedBox(
                          height: 6.h,
                        ),
                        Form(
                          child: PinCodeTextField(
                            length: 5,
                            obscureText: false,
                            animationType: AnimationType.fade,
                            keyboardType: TextInputType.number,
                            pinTheme: PinTheme(
                              shape: PinCodeFieldShape.box,
                              borderRadius: BorderRadius.circular(5),
                              fieldHeight: 66,
                              fieldWidth: 58,
                              activeFillColor: Colors.white,
                              inactiveFillColor: Color(0xffEDEDED),
                              inactiveColor:Color(0xffEDEDED).withOpacity(0.61),
                              activeColor: Colors.black,
                              selectedFillColor: Colors.white,
                              selectedColor: AppColors.black,
                            ),
                            animationDuration: Duration(milliseconds: 300),
                            backgroundColor: Colors.black,
                            enableActiveFill: true,
                            cursorColor: Colors.black,
                            validator: (String? value) {
                              if (value?.isEmpty ?? true) {
                                return 'Enter OTP here';
                              }
                            },
                            onCompleted: (v) {
                              print("Completed $v");
                              setState(() {
                                OTP = v;
                              });
                            },
                            onChanged: (value) {
                              print(value);
                              setState(() {});
                            },
                            beforeTextPaste: (text) {
                              print("Allowing to paste $text");
                              //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
                              //but you can show anything you want here, like your pop up saying wrong paste format or etc
                              return true;
                            },
                            appContext: context,
                          ),
                        ),
                        SizedBox(
                          height: 20.h,
                        ),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                              style: ButtonStyle(
                                backgroundColor: isOtpSending ? MaterialStateProperty.all(AppColors.mainColor) : MaterialStateProperty.all(AppColors.mainColor)
                              ),
                              onPressed: () {
                                verifyOtp();
                              },
                              child: isLoading ? CircularProgressIndicator(strokeWidth: 1, color: Colors.white,) : Text('Validate',  style: TextStyle(
                                  fontSize: 14, fontFamily: 'Poppins-Bold'),)),
                        ),
                        // SizedBox(
                        //   height: 20.h,
                        // ),
                        Center(child: TextButton(onPressed: ()=>otpSendingFuture = otpSend(), child: Text("Resend OTP",style: TextStyle(color: AppColors.textgrey),))),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
