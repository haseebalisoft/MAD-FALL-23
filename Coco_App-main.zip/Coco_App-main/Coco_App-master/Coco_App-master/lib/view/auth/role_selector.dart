import 'dart:convert';

import 'package:coco/appConst.dart';
import 'package:coco/utility/colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../controller/authController.dart';
import '../../utility/appAssets.dart';
import '../flashScreen/RoleSpashScreen.dart';

class Role_selector extends StatefulWidget {
  final String? token;
  const Role_selector({super.key, this.token});

  @override
  State<Role_selector> createState() => _Role_selectorState();
}

class _Role_selectorState extends State<Role_selector> {

  bool freelancerVisibility = true;
  bool clientVisibility = true;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        color: Colors.black,
        child: Scaffold(
          body: Stack(
            children: [
              SizedBox(
                  height: double.infinity,
                  width: double.infinity,
                  child: Container(
                    color: Colors.black,
                  )),

              SizedBox(
                height: double.infinity,
                width: double.infinity,
                child: Image.asset(
                  AssetUtils.role_select_img,
                  fit: BoxFit.cover,
                ),
              ),
              Row(
                children: [
                  IconButton(
                      onPressed: () {
                        Get.back();
                      },
                      icon: Icon(
                        Icons.arrow_back,
                        color: Colors.white,
                      )),
                  SizedBox(
                    width: 50,
                  )
                ],
              ),
              Center(
                child: Padding(
                  padding: const EdgeInsets.all(18.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const Text(
                        'Freelancer',
                        style: TextStyle(
                            fontSize: 39,
                            fontFamily: 'Poppins-Bold',
                            color: Colors.white),
                      ),
                      const Text(
                        ' On demand',
                        style: TextStyle(
                            fontSize: 39,
                            fontFamily: 'Poppins-Bold',
                            color: Colors.white),
                      ),
                      SizedBox(
                        height: 39,
                      ),
                      Text(
                        'What you are looking for?',
                        style: TextStyle(color: AppColors.textgrey, fontSize: 12),
                      ),
                      SizedBox(
                        height: 30,
                      ),
                       Visibility(
                         visible: clientVisibility,
                         child: SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Color(0xff4AC07C)),
                                onPressed: (){
                                  _roleSelection(role: AppConst.CLIENT_ROLE);
                                },
                                child: isLoading ? CircularProgressIndicator(strokeWidth: 1, color: Colors.white,) :  Column(
                                  children: [
                                    Text(
                                      'Business owner',
                                      style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),
                                    ),
                                    Text('Looking for freelancers',style: TextStyle(fontSize: 11,fontFamily: 'Poppins-Light'),)
                                  ],
                                ))
                      ),
                       ),
                      SizedBox(
                        height: 15,
                      ),
                      Visibility(
                        visible: freelancerVisibility,
                        child: SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.white,
                                ),
                                onPressed: (){
                                  _roleSelection(role: AppConst.FREELANCER_ROLE);
                                },
                                child: isLoading ? CircularProgressIndicator(strokeWidth: 1, color: Colors.black,) : Column(
                                  children: [
                                    Text(
                                      'Freelancer',
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                        fontSize: 15
                                      ),
                                    ),
                                    Text('Looking for business owners',style: TextStyle(fontSize: 11,fontFamily: 'Poppins-Light', color: Colors.black),)
                                  ],
                                ))
                        ),
                      ),
                      SizedBox(
                        height: 70,
                      )
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  bool isLoading = false;
  _roleSelection({required String role})async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var token = _pref.getString("token");
    setState((){
      ///////////// if select freelancer then the client is disable //////////
      if(role == AppConst.FREELANCER_ROLE){
        clientVisibility = false;
      }
      ///////////// if select client then the freelancer is disable //////////
      if(role == AppConst.CLIENT_ROLE){
        freelancerVisibility = false;
      }
      isLoading = true;
    });
    var res = await AuthController.selectRole(role: role, token: widget.token??"$token");
    print("res === ${res.body}");
    print("res === ${res.statusCode}");
    if(res.statusCode == 200){
      var data = jsonDecode(res.body)["data"];
      //hid user data;
      _pref.setString("role", data["role"]);
      var userInfo = await AuthController.getUserInfo();
      print("userInfo.data.email ${userInfo.data!.email}");
      Navigator.push(context, MaterialPageRoute(builder: (context)=>RoleSpashScreen(role: data["role"],)));
    }else{
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("Something went wrong."),
        backgroundColor: Colors.red,
        duration: Duration(milliseconds: 3000),
      ));
    }
    setState(() => isLoading = false);
  }
}
