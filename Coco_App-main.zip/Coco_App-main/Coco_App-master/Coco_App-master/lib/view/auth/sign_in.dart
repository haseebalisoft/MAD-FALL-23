import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:coco/appConst.dart';
import 'package:coco/view/auth/role_selector.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:coco/controller/authController.dart';
import 'package:coco/view/Client/bottomNagivation/buttom_nav.dart';
import 'package:coco/view/auth/sign_up.dart';
import 'package:coco/view/freelancer/bottomNavigationBar/becameFreelanceBottomNavigation.dart';
import 'package:coco/viewController/signupTopBar.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:location/location.dart';
import 'package:sizer/sizer.dart';

import '../../controller/locationController.dart';
import '../../helper/helperFunctions.dart';
import '../../utility/colors.dart';
import '../../viewController/appLoading.dart';
import '../Client/createAccount/profile_info_1.dart';
import '../Client/createAccount/profile_info_2.dart';
import '../Client/createAccount/profile_info_3.dart';
import '../freelancer/CreateAccount/freelancer_profile_info_1.dart';
import '../freelancer/CreateAccount/freelancer_profile_info_3.dart';
import '../freelancer/CreateAccount/freelaner_profile_info_2.dart';
import 'forget_password.dart';
import 'otp_varified_screen.dart';

class SignInPage extends StatefulWidget {
  const SignInPage({super.key});

  @override
  State<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  final email = TextEditingController();
  final password = TextEditingController();
////// get location
  Location location =  Location();
  late LocationData _locationData;
  var lat, lng;
  var errorText;
  //firebase ini
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn googleSignIn = GoogleSignIn();
  final fromKey = GlobalKey<FormState>();

  //

  bool isGoogleLogin = false;

  //login .......
  bool isLoading = false;

  _login() async {
    //email.text = 'tutu@tutu.com';
    // email.text = 'testbussiness@gmail.com';
    //
    //
    // password.text = '123456';

    setState(() => isLoading = true);
    if (fromKey.currentState!.validate()) {
      var res = await AuthController.login(
          email: email.text, password: password.text);
      print("status ==== ${res.statusCode}");
      print("login body ==== ${res.body}");
      if (res.statusCode == 200) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text("Login success."),
            backgroundColor: Colors.green,
            duration: Duration(milliseconds: 3000),
          ));
        }
        var userInfo = await AuthController.getUserInfo();
        if (userInfo.data!.role!.isNotEmpty) {
          //////////////// ---- if role ==  freelancer
          if (userInfo.data!.role == AppConst.FREELANCER_ROLE) {
            if (userInfo.data!.userInfo!.step1Complete == 0) {
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                  builder: (context) =>
                      Freelancer_profile_info_1(userInfo: userInfo,)), (
                  route) => false);
            } else if (userInfo.data!.userInfo!.step2Complete == 0) {
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                  builder: (context) => Freelancer_profile_info_2()), (
                  route) => false);
            } else if (userInfo.data!.userInfo!.step2Complete == 0) {
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                  builder: (context) => Freelancer_profile_info_3()), (
                  route) => false);
            } else {
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                  builder: (context) => FreelancerAppBottomNavigation()), (
                  route) => false);
            }
          }
          //////////////// ---- if role ==  client
          if (userInfo.data!.role == AppConst.CLIENT_ROLE) {
            if (userInfo.data!.userInfo?.step1Complete == 0) {
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                  builder: (context) =>
                      CreateProfileStep1(userInfo: userInfo,)), (
                  route) => false);
            } else if (userInfo.data!.userInfo?.step2Complete == 0) {
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                  builder: (context) => CreateProfileStep2()), (
                  route) => false);
            } else if (userInfo.data!.userInfo?.step2Complete == 0) {
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                  builder: (context) => CreateProfileStep3()), (
                  route) => false);
            } else {
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                  builder: (context) => ClientBottomNavigationBar()), (
                  route) => false);
            }
          }
        } else {
          Get.offAll(Role_selector());
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text("Login Failed."),
          backgroundColor: Colors.red,
          duration: Duration(milliseconds: 3000),
        ));
      }
    }
    setState(() => isLoading = false);
  }

  //get current location
  bool isLocationLoading = false;

  getLocationLatLng() async {
    setState(() => isLocationLoading = true);
    HelperFunction.locationData().then((value) {
      setState(() {
        lat = value.latitude;
        lng = value.longitude;
      });
      print("print lat === $lat");
    });
    setState(() => isLocationLoading = false);
  }

  ///
  late bool _passwordVisible;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _passwordVisible = true;

    getLocationLatLng();
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery
        .of(context)
        .size;
    return Container(
      color: Colors.black,
      child: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.dark.copyWith(
          statusBarColor: Colors.transparent, // Set the status bar color
          statusBarIconBrightness: Brightness.light, // Set the status bar text color
        ),
        child: Stack(
          children: [
            Scaffold(
              backgroundColor: Colors.black,

              body: Container(
                height: size.height,
                color: Colors.black,
                child: Form(
                  key: fromKey,
                  child: ListView(
                    children: [
                      SizedBox(height: 4.h,),
                      SignUpTopBar(size: size),
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 25.0, right: 25, top: 48),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // const Text(
                            //   'Welcome to coco app',
                            //   style: TextStyle(
                            //       fontSize: 21, fontFamily: 'Poppins-Bold'),
                            // ),
                            // SizedBox(
                            //   height: 2,
                            // ),
                            const Text(
                              'Sign in',
                              style: TextStyle(
                                  fontSize: 12,
                                  color: AppColors.white,
                                  fontWeight: FontWeight.w600),
                            ),
                            SizedBox(
                              height: size.height * .02,
                            ),
                            TextFormField(
                              style: TextStyle(
                                color: AppColors.white,
                                fontSize: 14
                              ),
                              controller: email,

                              decoration:  InputDecoration(
                                  border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide.none
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide.none
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide.none
                                  ),
                                  hintText: 'Email or username',
                                  fillColor: AppColors.formColorUp,
                                  hintStyle: TextStyle(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 12,
                                      color: AppColors.textgrey),
                                  prefixIcon: Icon(
                                    Icons.person,
                                    color: AppColors.mainColor,
                                  )),
                              validator: (v) {
                                if (v!.isEmpty) {
                                  return "Email must not be empty.";
                                } else {
                                  return null;
                                }
                              },
                            ),
                            const SizedBox(
                              height: 16,
                            ),
                            TextFormField(
                              style: TextStyle(
                                  color: AppColors.white,
                                  fontSize: 14
                              ),
                              controller: password,
                              decoration: InputDecoration(
                                  hintText: 'Password',
                                  fillColor: AppColors.formColorUp,
                                  border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide.none
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide.none
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide.none
                                  ),
                                  hintStyle: TextStyle(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 12,
                                      color: AppColors.textgrey ),
                                  suffixIcon: IconButton(
                                    icon: Icon(
                                      // Based on passwordVisible state choose the icon
                                      _passwordVisible
                                          ? Icons.visibility_off
                                          : Icons.visibility,
                                      color: AppColors.textgrey,
                                      size: 18,
                                    ),
                                    onPressed: () {
                                      // Update the state i.e. toogle the state of passwordVisible variable
                                      setState(() {
                                        _passwordVisible = !_passwordVisible;
                                      });
                                    },
                                  ),
                                  prefixIcon: Icon(
                                    Icons.lock,
                                    color:AppColors.mainColor,
                                  )),
                              obscureText: _passwordVisible,
                              validator: (v) {
                                if (v!.isEmpty) {
                                  return "Password must not be empty.";
                                } else {
                                  return null;
                                }
                              },
                            ),
                            SizedBox(
                              height: 2.h,
                            ),
                            SizedBox(
                                width: double.infinity,
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: AppColors.mainColor
                                  ),
                                    onPressed: () => _login(),
                                    child: isLoading
                                        ? CircularProgressIndicator(
                                      strokeWidth: 1,
                                      color: AppColors.white,
                                    )
                                        : Text('Continue'))),
                            Center(
                              child: Column(
                                children: [
                                  SizedBox(
                                    height: 1.h,
                                  ),
                                  TextButton(
                                      onPressed: () {
                                        Get.to(() => const Forget_password());
                                      },
                                      child: const Text(
                                        'Forgot Password?',
                                        style: TextStyle(
                                            fontSize: 12,
                                            color:AppColors.textgrey,
                                            fontWeight: FontWeight.w400),
                                      )),
                                  SizedBox(
                                    height: 1.h,
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                     Container(
                                       height: 1,
                                       width: 30.w,
                                       decoration: BoxDecoration(
                                           color: AppColors.textgrey,
                                         borderRadius: BorderRadius.circular(10)
                                       ),
                                     ),
                                      SizedBox(width: 5.w,),
                                      Text('Or',style: TextStyle(color: AppColors.white,fontSize: 15,fontWeight: FontWeight.bold),),
                                      SizedBox(width: 5.w,),
                                      Container(
                                        height: 1,
                                        width: 30.w,
                                        decoration: BoxDecoration(
                                            color: AppColors.textgrey,
                                            borderRadius: BorderRadius.circular(10)
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 2.h,),
                                  // const Text(
                                  //   'or Sign in via',
                                  //   style: TextStyle(
                                  //     fontWeight: FontWeight.bold,
                                  //     fontSize: 14,
                                  //   ),
                                  // ),
                                  // SizedBox(
                                  //   height: 1.h,
                                  // ),
                                  Container(
                                    decoration: BoxDecoration(
                                       color: AppColors.white,
                                      borderRadius: BorderRadius.circular(5)
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.0,),
                                      child: Center(

                                        //google sign in
                                        child: InkWell(
                                          onTap: () async {
                                            //signInWithGoogle();

                                            _googleLogin();

                                          },
                                          child: isGoogleLogin
                                              ? CircularProgressIndicator(
                                            strokeWidth: 1,
                                            color: AppColors.mainColor,)
                                              : Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment.center,
                                            children: [
                                              Image.asset(
                                                'asset/image/google.png',
                                                width: 30,
                                              ),
                                              const SizedBox(
                                                width: 20,
                                              ),
                                              const Text('Sign in with Google',style: TextStyle(fontWeight: FontWeight.bold),),



                                            ],
                                          ),
                                        ),

                                        ///
                                        ///
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 2.h,),
                                Platform.isIOS ?
                                  Container(
                                    decoration: BoxDecoration(
                                       color: AppColors.white,
                                      borderRadius: BorderRadius.circular(5)
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.0,),
                                      child: Center(

                                        //google sign in
                                        child: InkWell(
                                          onTap: () async {
                                            //signInWithGoogle();

                                            _googleLogin();

                                          },
                                          child: isGoogleLogin
                                              ? CircularProgressIndicator(
                                            strokeWidth: 1,
                                            color: AppColors.mainColor,)
                                              : Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment.center,
                                            children: [
                                              Image.asset(
                                                'asset/image/iphone.png',
                                                width: 30,
                                              ),
                                              const SizedBox(
                                                width: 20,
                                              ),
                                              const Text('Sign in with Apple',style: TextStyle(fontWeight: FontWeight.bold)),



                                            ],
                                          ),
                                        ),

                                        ///
                                        ///
                                      ),
                                    ),
                                  ) : SizedBox(height: 0,),
                                  SizedBox(height: 1.h),
                                  Text(
                                    'Don\'t have an acount yet?',
                                    style: TextStyle(color: AppColors.textgrey),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  SizedBox(
                                    width: double.infinity,
                                    child: ElevatedButton(
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: AppColors.mainColor
                                      ),
                                      onPressed: () {
                                        Get.to(const Sign_up());
                                      },
                                      child: const Text('Sign up'),
                                    ),
                                  ),
                                   SizedBox(
                                    height: 2.h,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
            isGoogleLogin ? LoadingOverlay() : Center()
          ],
        ),
      ),
    );
  }


  void _googleLogin() async {
    setState(() => isGoogleLogin = true);
    //await AuthController.signOut();
    Random random = new Random();
    int randomNumber = random.nextInt(999999999);
    int rendomUserCode = random.nextInt(100);
    final UserCredential? user = await AuthController.googleAuth();
    if(user == null){
      setState(() => isGoogleLogin = false);
    }

    String name = user!.user!.displayName!.trim().toLowerCase();
    final userName = name.replaceAll(RegExp(r' '), '_');


    ///////login with google
    print("user ==== ${user?.user?.email}");
    final response = await AuthController.loginWithGoogleAPI(
      email: user!.user!.email!,
    );


    print("user ==== ${response.body}");
    print("user ==== ${response.statusCode}");

    if (response.statusCode == 200) {
      setState(() => isGoogleLogin = false);
      var userInfo = await AuthController.getUserInfo();
      print("userInfo.data?.userInfo? === ${userInfo.data?.userInfo}");
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("Login success."),
        backgroundColor: Colors.green,
        duration: Duration(milliseconds: 3000),
      ));
      if (userInfo.data?.role != null) {
        print("userInfo.data?.userInfo? === ${userInfo.data?.userInfo}");
        //////////////// ---- if role ==  freelancer
        if (userInfo.data?.role == AppConst.FREELANCER_ROLE) {
          if(userInfo.data?.userInfo != null){
            if (userInfo.data?.userInfo?.step1Complete == 0) {
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                  builder: (context) =>
                      Freelancer_profile_info_1(userInfo: userInfo,)), (
                  route) => false);
            } else if (userInfo.data?.userInfo?.step2Complete == 0) {
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                  builder: (context) => Freelancer_profile_info_2()), (
                  route) => false);
            } else if (userInfo.data?.userInfo?.step3Complete == 0) {
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                  builder: (context) => Freelancer_profile_info_3()), (
                  route) => false);
            } else {
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                  builder: (context) => FreelancerAppBottomNavigation()), (
                  route) => false);
            }
          }else{
            Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                builder: (context) =>
                    Freelancer_profile_info_1(userInfo: userInfo,)), (
                route) => false);
          }
        }

        //////////////// ---- if role ==  client
        if (userInfo.data?.role == AppConst.CLIENT_ROLE) {
          if(userInfo.data?.userInfo != null){
            if (userInfo.data?.userInfo?.step1Complete == 0) {
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                  builder: (context) =>
                      CreateProfileStep1(userInfo: userInfo,)), (
                  route) => false);
            } else if (userInfo.data?.userInfo?.step2Complete == 0) {
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                  builder: (context) => CreateProfileStep2()), (
                  route) => false);
            } else if (userInfo.data?.userInfo?.step2Complete == 0) {
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                  builder: (context) => CreateProfileStep3()), (
                  route) => false);
            } else {
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                  builder: (context) => ClientBottomNavigationBar()), (
                  route) => false);
            }
          }else{
            Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                builder: (context) =>
                    CreateProfileStep1(userInfo: userInfo,)), (
                route) => false);
          }

        }
      } else {
        Get.offAll(Role_selector(token: jsonDecode(response.body)["data"]["token"],));
      }
    } else if(response.statusCode == 422){
      setState(() => isGoogleLogin = false);
      ///////// user should be signup ====////////
      var singUpRes = await AuthController.signup(
          email: user!.user!.email!,
          password: "--",
          user_name: "${userName+rendomUserCode.toString()}",
          phone: "$randomNumber",
          lat: lat.toString(),
          lng: lng.toString()
      );
      print("signup data ===== ${singUpRes.statusCode}");
      print("signup data ===== ${singUpRes.body}");
      if(singUpRes.statusCode == 201){
        setState(() => isGoogleLogin = false);
        ScaffoldMessenger.of(context).showSnackBar( const SnackBar(
          content: Text("Account create success. Your are get to go."),backgroundColor: Colors.green, duration: Duration(milliseconds: 3000),
        ));
        Get.offAll(otp_verified_screen());
      }else if(singUpRes.statusCode == 500) {
        setState(() => isGoogleLogin = false);
      }else{
        setState(() => isGoogleLogin = false);
        ScaffoldMessenger.of(context).showSnackBar( const SnackBar(
          content: Text("Something went wrong while create account."),backgroundColor: Colors.red, duration: Duration(milliseconds: 3000),
        ));
      }
    } else {
      setState(() => isGoogleLogin = false);
      AlertController.snackbar(context: context,
          text: "${jsonDecode(response.body)["message"]}",
          bg: Colors.red);
    }
    setState(() => isGoogleLogin = false);
  }
//
// Future<UserCredential?> signInWithGoogle() async {
//   final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
//
//   String name = googleUser!
//       .displayName!
//       .trim()
//       .toLowerCase();
//   final userName = name.replaceAll(
//       RegExp(r' '), '_');
//
//   if (googleUser == null) {
//     final signup =
//     await  AuthController.signup(
//         email:
//         googleUser!.email!,
//         password: ' ',
//         user_name: userName,
//         phone: googleUser!.phoneNumber!,
//         lat: lat,
//         lng: lng);
//
//     print("signup === ${signup.body}");
//     if(signup.statusCode == 200){
//       Get.to(Role_selector());
//     }else{
//       AlertController.snackbar(context: context, text: "Google Login Faild", bg: Colors.red);
//     }
//   }
//
//   final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
//
//   final OAuthCredential credential = GoogleAuthProvider.credential(
//     accessToken: googleAuth.accessToken,
//     idToken: googleAuth.idToken,
//   );
//
//   return await FirebaseAuth.instance.signInWithCredential(credential);
// }
}