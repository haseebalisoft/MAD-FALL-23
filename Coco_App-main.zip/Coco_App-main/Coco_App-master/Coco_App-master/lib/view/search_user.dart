import 'package:coco/controller/UserSearch.dart';
import 'package:coco/under_dev.dart';
import 'package:coco/utility/colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';

import '../model/searchUserModel/searchUserModel.dart';
import '../viewController/searchUserCard.dart';
import 'Client/bottomNagivation/buttom_nav.dart';

class SearchUser extends StatefulWidget {
  const SearchUser({Key? key}) : super(key: key);

  @override
  State<SearchUser> createState() => _SearchUserState();
}

class _SearchUserState extends State<SearchUser> {
  TextEditingController searchByUserName = TextEditingController();
  Future<SearchUserModel>? userSearch;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    searchByUserName.clear();
  }

  searUserData(String name){
    userSearch = UserSearchController.userSearch(name);
    return userSearch;
  }


  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.black,
      child: SafeArea(
        child: Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            backgroundColor: AppColors.black,
            elevation: 0,
              leading: BackButton(),
            title:   SizedBox(
              width: double.infinity,
              child: TextFormField(
                onChanged: (text){
                  setState(() {
                    searUserData(text);
                  });
                },
                autofocus: true,
                controller: searchByUserName,
                style: TextStyle(color: Colors.white),
                decoration:  InputDecoration(
                    fillColor: Color(0xff5D5D5D5A),
                    filled: true,
                    contentPadding: EdgeInsets.only(left: 15, right: 15),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(100)
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(width: 1,color: AppColors.formColorUp),
                        borderRadius: BorderRadius.circular(100)
                    ),
                    focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(width: 1,color: AppColors.formColorUp),
                        borderRadius: BorderRadius.circular(100)
                    ),
                    hintText: "Search",
                    hintStyle:TextStyle(fontWeight: FontWeight.w400, color: Colors.grey),
                    prefixIcon: Icon(Icons.search, color: Colors.grey)
                ),
              ),
            )
          ),
          body:Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 3.h,),
               Text('Recent',style: TextStyle(color: AppColors.mainColor,fontSize: 17,fontWeight: FontWeight.w600),),
                SizedBox(height: 2.h,),
                 FutureBuilder<SearchUserModel>(
                future: userSearch,
                builder: (context, snapshot){
                  print('seach dataaaaa ${snapshot.data?.data}');
                  if(snapshot.connectionState == ConnectionState.waiting){
                    return Container(
                      padding: EdgeInsets.only(left: 20, right: 20),
                      height: 30,
                      //  child: CircularProgressIndicator(color: Colors.white,),
                      //     child: ListView.builder(
                      //   itemCount: 20,
                      //   scrollDirection: Axis.horizontal,
                      //   itemBuilder: (_, index) {
                      //     return Shimmer.fromColors(
                      //       highlightColor: Colors.grey.shade300,
                      //       baseColor: Colors.white,
                      //       child: Container(
                      //         height: 30,
                      //         width: 130,
                      //         margin: EdgeInsets.only(right: 10),
                      //         decoration: BoxDecoration(
                      //             borderRadius: BorderRadius.circular(100),
                      //             color: Colors.white
                      //         ),
                      //       ),
                      //     );
                      //   },
                      // )
                    );
                  }else if(snapshot.hasData){
                    // print(snapshot.data?.data);
                    return Expanded(
                      child: ListView.builder(
                          itemCount: snapshot.data!.data!.length,
                          itemBuilder: (context,index){
                            return searchUserCard(name: '${snapshot.data!.data![index].name}', image: '${snapshot.data!.data![index].profileImage}', onclick: () { Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientBottomNavigationBar(pageIndex: 6, userId:snapshot.data!.data![index]?.id ))); },);
                          }),
                    );
                  }else{
                    return Center(child: Text("Something went wrong"),);
                  }

                }

                 )],
            ),
          ),
        ),
      ),
    );
  }
}


