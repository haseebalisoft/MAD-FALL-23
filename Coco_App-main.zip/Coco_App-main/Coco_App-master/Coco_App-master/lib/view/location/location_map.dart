import 'package:cached_network_image/cached_network_image.dart';
import 'package:coco/controller/serviceController.dart';
import 'package:coco/utility/colors.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:url_launcher/url_launcher_string.dart';

import '../../appConst.dart';
import '../../controller/locationController.dart';
import '../../helper/helperWidgets.dart';
import '../../model/authModel/allBusinessTypeModel.dart';
import '../../model/authModel/allUserList.dart';
import '../../model/authModel/serviceModle.dart';
import '../../model/service/serviceModel.dart';
import '../Client/bottomNagivation/buttom_nav.dart';
import '../freelancer/bottomNavigationBar/becameFreelanceBottomNavigation.dart';

class LocationMap extends StatefulWidget {
  const LocationMap({Key? key}) : super(key: key);

  @override
  State<LocationMap> createState() => _LocationMapState();
}

class _LocationMapState extends State<LocationMap> {
  final LocationController locationController = Get.put(LocationController());
  @override
  void initState() {
    super.initState();
    proceedWithAllFunctions();
  }

  proceedWithAllFunctions() async {
    await locationController.getAllBusinessType();
  }

  @override
  Widget build(BuildContext context) {
    return Obx(()=>
        Scaffold(
           appBar: AppBar(
             automaticallyImplyLeading: false,
             backgroundColor: AppColors.black,
             title:  locationController.getBusinessType.value == null && locationController.getServices.value == null
                 ? Row()
                 : Row(
               children: [
                 SizedBox(
                   width: 50,
                   height: 50,
                   child: IconButton(
                     onPressed: (){
                       locationController.role == AppConst.CLIENT_ROLE
                           ?  Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientBottomNavigationBar()))
                           :  Navigator.push(context, MaterialPageRoute(builder: (context)=>FreelancerAppBottomNavigation()));
                     },
                     icon: Icon(Icons.arrow_back, color: Colors.white,),
                   ),
                 ),
                 Expanded(
                   child: Container(
                     padding: EdgeInsets.only(left: 10),
                     height: 37,
                     child:
                     locationController.role.value == AppConst.CLIENT_ROLE
                         ? ListView.builder(
                       itemCount: locationController.getServices.value!.data!.length,
                       scrollDirection: Axis.horizontal,
                       itemBuilder: (_, index) {
                         return HelperWidget.buildSingleServiceList(
                             text: "${locationController.getServices.value!.data![index].name}",
                             color: locationController.service.contains(index.toString())
                                 ? AppColors.mainColor
                                 :  Colors.grey.shade900,
                             borderColor: locationController.service.contains(index.toString())
                                 ? AppColors.mainColor
                                 :  Colors.grey.shade600,
                             textColor: locationController.service.contains(index.toString())
                                 ? Colors.black
                                 : Colors.white,
                             onClick: () {
                               setState(() {
                                 // locationController.service.clear(); //first we clear all
                                 // locationController.service.add(locationController.getServices.value!.data![index].id.toString()); //then add the unick index
                                 // locationController.getUserByIDWithRole();
                                 locationController.filterByServiceClick(index);
                               });
                             });
                       },
                     )
                         :

                     ListView.builder(
                       itemCount: locationController.getBusinessType.value!.data!.length,
                       scrollDirection: Axis.horizontal,
                       itemBuilder: (_, index) {
                         return HelperWidget.buildSingleServiceList(
                             text: "${locationController.getBusinessType.value!.data![index].name}",
                             color: locationController.service.contains(index.toString())
                                 ? AppColors.mainColor
                                 :  Colors.grey.shade900,
                             borderColor: locationController.service.contains(index.toString())
                                 ? AppColors.mainColor
                                 :  Colors.grey.shade600,
                             textColor: locationController.service.contains(index.toString())
                                 ? Colors.black
                                 : Colors.white,
                             onClick: () {
                               setState(() {
                                 locationController.filterByServiceClick(index);
                               });
                             });
                       },
                     ),
                   ),
                 )
               ],
             ),
           )
          ,
            body: Container(
              //padding: EdgeInsets.only(left: 20, right: 20),
              color: AppColors.black,
              child:  Center(
                child: locationController.isLoading.value == true || locationController.getAllUser.value == null
                  ? CircularProgressIndicator( color: AppColors.white,)
                  :  GoogleMap(
                          mapToolbarEnabled: false,
                          initialCameraPosition: CameraPosition(
                            target: LatLng(locationController.lat.value, locationController.lng.value),
                            zoom: 12,
                          ),
                          markers: {
                            Marker(
                              markerId: MarkerId('Own'),
                              position: LatLng(locationController.lat.value, locationController.lng.value),
                              icon: locationController.ownMarkerIcon.value,
                            ),
                            for(int i = 0; i < locationController.getAllUser.value!.data!.length; i++)
                              Marker(
                                markerId: MarkerId(locationController.getAllUser.value!.data![i].id.toString()),
                                position: LatLng(locationController.getAllUser.value!.data![i].latitude!, locationController.getAllUser.value!.data![i].longitude!),
                                icon: locationController.otherMarkerIcon.value,
                                onTap: (){
                                  showModalBottomSheet(
                                    context: context,
                                    backgroundColor: Colors.transparent,
                                    builder: (context) {
                                      return Material(
                                        elevation: 20.0,
                                        color: Colors.transparent,
                                        shadowColor: Colors.white,
                                        child: ClipRRect(
                                          borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(20.0),
                                            topRight: Radius.circular(20.0),
                                          ),
                                          child: Container(
                                            color: AppColors.white,
                                            height: 250,
                                            child: Column(
                                              children: [
                                                Center(
                                                  child: Container(
                                                    margin: EdgeInsets.only(top: 8.0),
                                                    width: 150.0,
                                                    height: 4.0,
                                                    decoration: BoxDecoration(
                                                      color: AppColors.mainColor,
                                                      borderRadius: BorderRadius.all(Radius.circular(2.0)),
                                                    ),
                                                  ),
                                                ),

                                        Padding(
                                            padding: EdgeInsets.only(left: 25.0, right: 25.0, top: 10.0),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  width: 70.0,
                                                  height: 70.0,
                                                  decoration: BoxDecoration(
                                                    shape: BoxShape.circle,
                                                    border: Border.all(
                                                      color: AppColors.mainColor,  // Border color
                                                      width: 3.0,           // Border width
                                                    ),
                                                  ),
                                                  child: ClipOval(
                                                    child: CachedNetworkImage(
                                                      imageUrl: "${locationController.getAllUser.value!.data![i].profileImage}",
                                                      placeholder: (context, url) => const CircularProgressIndicator(
                                                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),  // White color
                                                      ),
                                                      errorWidget: (context, url, error) => Image.asset(
                                                        'asset/image/logo.png',  // Replace with your error image asset path
                                                        fit: BoxFit.cover,
                                                      ),
                                                      fit: BoxFit.cover,
                                                    ),
                                                  ),
                                                ),
                                                Expanded(
                                                  child: Padding(
                                                    padding: const EdgeInsets.only(left: 10, right: 10),
                                                    child: Text(
                                                      "${locationController.getAllUser.value!.data![i].name ?? locationController.getAllUser.value!.data![i].userName}",
                                                      overflow: TextOverflow.ellipsis,
                                                      style: const TextStyle(
                                                        fontSize: 16.0,
                                                        color: Colors.black,
                                                        fontWeight: FontWeight.bold,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                InkWell(
                                                  onTap: () {
                                                    // Replace '1234567890' with the phone number you want to dial
                                                    launchUrlString('tel:${locationController.getAllUser.value!.data![i].phone}');
                                                  },
                                                  child: Image.asset(
                                                    'asset/image/phone_circle.png',  // Replace with your image asset path
                                                    width: 35.0,
                                                    height: 35.0,
                                                  ),
                                                )

                                              ],
                                            ),
                                            SizedBox(height: 20.0),
                                            Container(
                                              width: double.infinity,
                                              child: ElevatedButton(
                                                onPressed: () {
                                                  // Put your button press functionality here
                                                  Navigator.pop(context);
                                                  locationController.role == AppConst.CLIENT_ROLE
                                                      ?  Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientBottomNavigationBar(pageIndex: 6, userId: locationController.getAllUser.value!.data![i].id.toString())))
                                                      :  Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientBottomNavigationBar(pageIndex: 6, userId: locationController.getAllUser.value!.data![i].id.toString())));
                                                },
                                                style: ElevatedButton.styleFrom(
                                                  backgroundColor: AppColors.mainColor, // background color
                                                  foregroundColor: Colors.white, // text color
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius: BorderRadius.circular(20.0),
                                                  ),
                                                ),
                                                child: Text('View profile'),
                                              ),
                                            ),
                                            SizedBox(height: 10),  // Add some space between the buttons
                                            Container(
                                              width: double.infinity,
                                              child: ElevatedButton(
                                                onPressed: () async {
                                                  // Define the latitude and longitude of the start and end points
                                                  double startLat = double.parse(locationController.lat.value.toString());
                                                  double startLng = double.parse(locationController.lng.value.toString());
                                                  double endLat = double.parse(locationController.getAllUser.value!.data![i].latitude.toString());
                                                  double endLng = double.parse(locationController.getAllUser.value!.data![i].longitude.toString());

                                                  // Construct the URL for the directions
                                                  String url = 'https://www.google.com/maps/dir/?api=1&origin=$startLat,$startLng&destination=$endLat,$endLng&travelmode=driving';

                                                  // Open the URL in the default browser
                                                  try{
                                                    await launchUrl(Uri.parse(url));
                                                  }
                                                  catch(e){
                                                    rethrow;
                                                  }

                                                  // } else {
                                                  //
                                                  //   Fluttertoast.showToast(
                                                  //       msg: "Could not launch $url, startLat: $startLat, startLng: $startLng, endLat: $endLat, endLng: $endLng",
                                                  //       toastLength: Toast.LENGTH_SHORT,
                                                  //       gravity: ToastGravity.CENTER,
                                                  //       backgroundColor: Colors.red,
                                                  //       textColor: Colors.white,
                                                  //       fontSize: 16.0);
                                                  // }
                                                },
                                                style: ElevatedButton.styleFrom(
                                                  backgroundColor: AppColors.mainColor, // background color
                                                  foregroundColor: Colors.white, // text color
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius: BorderRadius.circular(20.0),
                                                  ),
                                                ),
                                                child: Text('View Directions'),
                                              ),
                                            ),

                                          ],
                                        )

                                        ),


                                                // Text("Name: ${locationController.getAllUser.value!.data![i].name}"),
                                                // Text("Email: ${locationController.getAllUser.value!.data![i].email}"),
                                                // Text("Phone: ${locationController.getAllUser.value!.data![i].phone}"),
                                                // Text("User Name: ${locationController.getAllUser.value!.data![i].userName}"),
                                                // Text("Role: ${locationController.getAllUser.value!.data![i].role}"),
                                              ],
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  );


                                },
                              ),
                          },
                       )
              ),
          ),
    )
    );
  }
}