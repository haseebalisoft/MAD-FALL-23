// import 'package:coco/controller/serviceController.dart';
// import 'package:coco/utility/colors.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:google_maps_flutter/google_maps_flutter.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
// import '../../appConst.dart';
// import '../../model/authModel/allBusinessTypeModel.dart';
// import '../../model/authModel/allUserList.dart';
// import '../../model/authModel/serviceModle.dart';
// import '../../model/service/serviceModel.dart';
//
// class NotUsedLocationMap extends StatefulWidget {
//   const NotUsedLocationMap({Key? key}) : super(key: key);
//
//   @override
//   State<NotUsedLocationMap> createState() => _NotUsedLocationMapState();
// }
//
// class _NotUsedLocationMapState extends State<NotUsedLocationMap> {
//
//   List serviceList = [];
//   List service = [];
//
//   Future<AllUserModel>? getAllUser;
//   Future<ServiceDataModel>? getAllSearchUsers;
//   Future<ServiceDataModel>? getAllSearchByBusinessTypeUser;
//   Future<ServiceModel>? getServices;
//   Future<AllBusnissType>? getBusinessType;
//   //current user role
//   var role;
//   getUserByIDWithRole()async{
//     SharedPreferences _pref = await SharedPreferences.getInstance();
//     setState(() {
//       role = _pref.getString("role");
//     });
//     // if(role == AppConst.CLIENT_ROLE) {
//     //   getAllSearchUsers = ServiceController.getUserByServiceId(service[0].toString());
//     //   return;
//     // }
//     // if( role == AppConst.FREELANCER_ROLE){
//     //   getAllSearchUsers =  ServiceController.getUserByBusinessTypeId(service[0].toString());
//     //   return;
//     // }
//   }
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       color: AppColors.mainColor,
//       child: SafeArea(
//         child: Scaffold(
//           body: Stack(
//             children: [
//               GoogleMap(
//                 initialCameraPosition: CameraPosition(
//                   target: LatLng(0,0),
//                 zoom: 15,
//               ),
//                 myLocationEnabled: true,
//                 myLocationButtonEnabled: true,
//                 zoomControlsEnabled: true,
//                 zoomGesturesEnabled: true,
//                 trafficEnabled: true,
//                 compassEnabled: true,
//                 mapType: MapType.normal,
//                 buildingsEnabled: true,
//               ),
//               Positioned(
//                 left: 20, top: 20, right: 20,
//                 child:Row(
//                   children: [
//                     IconButton(
//                       icon: Icon(Icons.arrow_back),
//                       onPressed: ()=>Get.back(),
//                     ),
//                     SizedBox(width: 5,),
//                     /////// service///////////
//                     ///////////////////////////
//                     role == AppConst.CLIENT_ROLE
//                         ? FutureBuilder<ServiceModel>(
//                         future: getServices,
//                         builder: (context, snapshot) {
//                           if(snapshot.connectionState == ConnectionState.waiting){
//                             return Container(
//                               padding: EdgeInsets.only(left: 20, right: 20),
//                               height: 30,
//                               //  child: CircularProgressIndicator(color: Colors.white,),
//                               //     child: ListView.builder(
//                               //   itemCount: 20,
//                               //   scrollDirection: Axis.horizontal,
//                               //   itemBuilder: (_, index) {
//                               //     return Shimmer.fromColors(
//                               //       highlightColor: Colors.grey.shade300,
//                               //       baseColor: Colors.white,
//                               //       child: Container(
//                               //         height: 30,
//                               //         width: 130,
//                               //         margin: EdgeInsets.only(right: 10),
//                               //         decoration: BoxDecoration(
//                               //             borderRadius: BorderRadius.circular(100),
//                               //             color: Colors.white
//                               //         ),
//                               //       ),
//                               //     );
//                               //   },
//                               // )
//                             );
//                           } else if(snapshot.hasData){
//                             return   Expanded(
//                               child: Container(
//                                 padding: EdgeInsets.only(left: 20, right: 20),
//                                 height: 37,
//                                 child: ListView.builder(
//                                   itemCount: snapshot.data!.data!.length,
//                                   scrollDirection: Axis.horizontal,
//                                   itemBuilder: (_, index) {
//                                     return buildSingleServiceList(
//                                         text: "${snapshot.data!.data![index]!.name}",
//                                         color: service.contains(index.toString())
//                                             ? AppColors.mainColor
//                                             :  Colors.grey.shade900,
//                                         borderColor: service.contains(index.toString())
//                                             ? AppColors.mainColor
//                                             :  Colors.grey.shade600,
//                                         textColor: service.contains(index.toString())
//                                             ? Colors.black
//                                             : Colors.white,
//                                         onClick: () {
//                                           setState(() {
//                                             service.clear(); //first we clear all
//                                             service.add(index.toString()); //then add the unick index
//                                             getUserByIDWithRole();
//                                           });
//                                         });
//                                   },
//                                 ),
//                               ),
//                             );
//                           }else{
//                             return Center(child: Text("Something went wrong"),);
//                           }
//                         }
//                     )
//                         : FutureBuilder<AllBusnissType>(
//                         future: getBusinessType,
//                         builder: (context, snapshot) {
//                           if(snapshot.connectionState == ConnectionState.waiting){
//                             return Container(
//                               padding: EdgeInsets.only(left: 20, right: 20),
//                               height: 30,
//                               // child: CircularProgressIndicator(color: Colors.white,),
//                               // child: ListView.builder(
//                               //   itemCount: 20,
//                               //   scrollDirection: Axis.horizontal,
//                               //   itemBuilder: (_, index) {
//                               //     return Shimmer.fromColors(
//                               //       highlightColor: Colors.grey.shade300,
//                               //       baseColor: Colors.white,
//                               //       child: Container(
//                               //         height: 30,
//                               //         width: 130,
//                               //         margin: EdgeInsets.only(right: 10),
//                               //         decoration: BoxDecoration(
//                               //             borderRadius: BorderRadius.circular(100),
//                               //             color: Colors.white
//                               //         ),
//                               //       ),
//                               //     );
//                               //   },
//                               // )
//                             );
//                           } else if(snapshot.hasData){
//                             return   Expanded(
//                               child: Container(
//                                 padding: EdgeInsets.only(left: 20, right: 20),
//                                 height: 37,
//                                 child: ListView.builder(
//                                   itemCount: snapshot.data!.data!.length,
//                                   scrollDirection: Axis.horizontal,
//                                   itemBuilder: (_, index) {
//                                     return buildSingleServiceList(
//                                         text: "${snapshot.data!.data![index]!.name}",
//                                         color: service.contains(index.toString())
//                                             ? AppColors.mainColor
//                                             :  Colors.grey.shade900,
//                                         borderColor: service.contains(index.toString())
//                                             ? AppColors.mainColor
//                                             :  Colors.grey.shade600,
//                                         textColor: service.contains(index.toString())
//                                             ? Colors.black
//                                             : Colors.white,
//                                         onClick: () {
//                                           setState(() {
//                                             service.clear(); //first we clear all
//                                             service.add(index.toString()); //then add the unick index
//                                             getUserByIDWithRole();
//                                           });
//                                         });
//                                   },
//                                 ),
//                               ),
//                             );
//                           }else{
//                             return Center(child: Text("Something went wrong"),);
//                           }
//                         }
//                     ),
//
//                   ],
//                 )
//
//
//               )
//             ],
//           )
//         ),
//       ),
//     );
//   }
//
//
//   InkWell buildSingleServiceList(
//       {required String text,
//         required Color color,
//         required Color borderColor,
//         required Color textColor,
//         required VoidCallback onClick}) {
//     return InkWell(
//       onTap: onClick,
//       child: Container(
//
//         margin: EdgeInsets.only(right: 10),
//         decoration: BoxDecoration(
//             color: color,
//             borderRadius: BorderRadius.circular(7),
//             border: Border.all(width: 1, color: borderColor)
//         ),
//         child: Center(
//           child: Padding(
//             padding: const EdgeInsets.symmetric(vertical: 7.0, horizontal: 12),
//             child: Text(
//               text,
//               style: TextStyle(color: Colors.white,fontFamily: ' Poppins-Bold',fontSize: 11,fontWeight: FontWeight.bold),
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
