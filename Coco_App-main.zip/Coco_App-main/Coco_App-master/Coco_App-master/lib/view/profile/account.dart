import 'package:coco/utility/colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';

import '../../controller/authController.dart';


class AccountSetting extends StatefulWidget {
  final String name,email;
  const AccountSetting({Key? key, required this.name, required this.email}) : super(key: key);

  @override
  State<AccountSetting> createState() => _AccountSettingState();
}

class _AccountSettingState extends State<AccountSetting> {
  bool isFollowers = true;
  bool isAppUpdate = false;

  final fullName = TextEditingController();
  final email = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    email.text = widget.email;
    fullName.text = widget.name;
    print('user email ==== ${widget.email}');
    print('user name ==== ${widget.name}');

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          onPressed: ()=>Get.back(),
          icon: Icon(Icons.arrow_back, color: Colors.white,),
        ),
        title: Text("Account Setting",
          style: TextStyle(
              fontSize: 18,
              color: Colors.white
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.only(top: 20),

        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
             Text('Full name',style: TextStyle(
               fontSize: 18,
               color: AppColors.mainColor,
               fontFamily: 'Poppins-Bold'
             ),),
              Text(widget.name,style: TextStyle(
                color: AppColors.white,
                fontSize: 16
              ),),
              SizedBox(height: 5,),
              Divider(),
              Text('Email',style: TextStyle(
                  fontSize: 18,
                  color: AppColors.mainColor,
                  fontFamily: 'Poppins-Bold'
              ),),
              Text(widget.email,style: TextStyle(
                  color: AppColors.white,
                  fontSize: 16
              ),),
              SizedBox(height: 25.h,),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(onPressed: () async {
                  await AuthController.signOut();

                },

                  style:ElevatedButton.styleFrom(
                    backgroundColor: AppColors.mainColor
                  ),
                  child: Text('Logout'),),
              )
            ],
          ),
        ),
      ),
    );
  }
}
