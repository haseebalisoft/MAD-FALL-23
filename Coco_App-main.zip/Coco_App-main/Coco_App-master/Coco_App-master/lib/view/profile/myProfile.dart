import 'dart:convert';

import 'package:coco/model/authModel/userInfoModel.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/view/Client/bottomNagivation/buttom_nav.dart';
import 'package:coco/view/freelancer/bottomNavigationBar/becameFreelanceBottomNavigation.dart';
import 'package:coco/view/profile/profileRoleButtonFuture.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../appConst.dart';
import '../../controller/authController.dart';
import '../../utility/topbarmassage.dart';
import 'profileTonInfo.dart';
import '../Client/profile/profile_protfolio.dart';

class MyProfile extends StatefulWidget {
  final String ? ProfileUserId;
  const MyProfile({super.key, this.ProfileUserId});

  @override
  State<MyProfile> createState() => _MyProfileState();
}

class _MyProfileState extends State<MyProfile>
    with SingleTickerProviderStateMixin {
  late TabController tabController;

  late UserInformation _userInformation;

  bool isfollow = false;

  String alertMsg = "";
  bool isPublishAlert = false;


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    tabController = TabController(length: 2, vsync: this);
    getRole();
    getAlertDetails();
  }


  bool isAboutMe = false;
  bool isPortfolioTab = true;

  var role;
  getRole()async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
   setState(() {
     role = _pref.getString("role");
   });
  }


  getAlertDetails() async {
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var id = _pref.getString("user_id");
    var res = await AuthController.publishAlert(id);
    if(res.statusCode == 200){
      if(jsonDecode(res.body)["data"] != null ){
        setState(() {
          alertMsg = jsonDecode(res.body)["data"]["alert_msg"];
          isPublishAlert = jsonDecode(res.body)["data"]["status"] == "yes" ? true : false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Container(
      color: Colors.transparent,
      child: Scaffold(
        backgroundColor: AppColors.black,
        // appBar: AppBar(
        //   elevation: 0, backgroundColor: AppColors.black,
        //   leading: IconButton(
        //       onPressed: () {
        //         //////// if your role client, go to client bottom navigation else freelacnerbootomnavigation
        //         role == AppConst.CLIENT_ROLE ?   Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientBottomNavigationBar())):  Navigator.push(context, MaterialPageRoute(builder: (context)=>FreelancerAppBottomNavigation()));
        //       },
        //       icon: const Icon(Icons.arrow_back_outlined, color: AppColors.white,)),
        //   actions: [
        //     IconButton(
        //       onPressed: ()=>role == AppConst.FREELANCER_ROLE
        //           ? Navigator.push(context, MaterialPageRoute(builder: (context)=> FreelancerAppBottomNavigation(pageIndex: 5,)))
        //           : Navigator.push(context, MaterialPageRoute(builder: (context)=> ClientBottomNavigationBar(pageIndex: 5,))),
        //       icon: const Icon(Icons.settings, color: AppColors.white,),
        //     ),
        //     const SizedBox(width: 10,)
        //   ],
        // ),
        body: ListView(
          //crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            isPublishAlert
                ? AppTopBarMassage(massage: '${alertMsg}',)
                : Container(),
            isPublishAlert
            ? const SizedBox(height: 2,)
            : Container(),

            Container(
              color: AppColors.black,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    onPressed: () {
                      //////// if your role client, go to client bottom navigation else freelacnerbootomnavigation
                      role == AppConst.CLIENT_ROLE ? Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientBottomNavigationBar())): Navigator.push(context, MaterialPageRoute(builder: (context)=>FreelancerAppBottomNavigation()));
                    },
                    icon: const Icon(Icons.arrow_back_outlined, color: AppColors.white,),
                  ),
                  IconButton(
                    onPressed: ()=>role == AppConst.FREELANCER_ROLE
                        ? Navigator.push(context, MaterialPageRoute(builder: (context)=> FreelancerAppBottomNavigation(pageIndex: 5,)))
                        : Navigator.push(context, MaterialPageRoute(builder: (context)=> ClientBottomNavigationBar(pageIndex: 5,))),
                    icon: const Icon(Icons.settings, color: AppColors.white,),
                  ),
                ],
              ),
            ),

           SizedBox(height: 100, child: ProfileTopInformation()),
            /////////////// this information comes from clientProfileInformation widget ///////////////
            const SizedBox(height: 10,),


            ProfileRoleButton(),

            ProfileProtfolio(postUserId:widget.ProfileUserId),
          ],
        ),

      ),
    );
  }

}


