import 'dart:io';

import 'package:coco/controller/authController.dart';
import 'package:coco/main.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/view/freelancer/bottomNavigationBar/becameFreelanceBottomNavigation.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

class StoryUpload extends StatefulWidget {
  const StoryUpload({Key? key}) : super(key: key);

  @override
  State<StoryUpload> createState() => _StoryUploadState();
}

class _StoryUploadState extends State<StoryUpload> {

  final des = TextEditingController();

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Container(
      color: Colors.white,
      child: SafeArea(
        child: Scaffold(
          appBar: AppBar(
            leading: IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.black,),
              onPressed: ()=>Get.back(),
            ),
            title: Text("Upload story",
              style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 18,
                color: Colors.black
              ),
            ),
            backgroundColor: Colors.white,
            elevation: 0,
            actions: [
             isLoading
                 ?Padding(
                   padding: const EdgeInsets.all(10.0),
                   child: CircularProgressIndicator(strokeWidth: 1, color: AppColors.mainColor,),
                 )
                 : Row(
                children: [
                  TextButton(
                      onPressed:()=>image != null ? _uploadPortfolio(image) : null,
                      child: Text("Upload Story",
                        style: TextStyle(
                          color: image != null ? AppColors.mainColor : Colors.grey,
                        ),
                      )
                  ),
                  Icon(Icons.arrow_forward, color: AppColors.mainColor, size: 20,),
                  SizedBox(width: 10,)
                ],
              )
            ],
          ),
          body: SingleChildScrollView(
            padding: EdgeInsets.all(20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                InkWell(
                  onTap: ()=>chosePhoto(),
                  child: Container(
                    height: size.height*.50,
                    width: size.width,
                    decoration: BoxDecoration(
                      border: Border.all(width: 1, color: Colors.grey.shade300),
                      borderRadius: BorderRadius.circular(5)
                    ),
                    child: image!=null
                        ?Image.file(image!, fit: BoxFit.cover,)
                        : Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: const [
                        Icon(Icons.cloud_upload,color: AppColors.mainColor, size: 100,),
                        SizedBox(height: 10,),
                        Text("Upload image",
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w600
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                SizedBox(height: 20,),
                Text("Description",
                  style: TextStyle(
                      fontWeight: FontWeight.w500,
                      fontSize: 13
                  ),
                ),
                SizedBox(height: 10,),
                TextFormField(
                  maxLines: 7,
                  controller: des,
                  decoration: InputDecoration(
                      contentPadding: EdgeInsets.all(10),
                      border: OutlineInputBorder(
                          borderSide: BorderSide(width: 1, color: Color(0xffE1E1E1))
                      ),
                      enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(width: 1, color: Color(0xffE1E1E1))
                      ),
                      focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(width: 1, color: Color(0xffE1E1E1))
                      ),
                      hintText: "Share a bit about your work experience, your projects...",
                      hintStyle: TextStyle(
                          fontWeight: FontWeight.w200,
                          fontSize: 10
                      )
                  ),
                  validator: (v){
                    if(v!.isEmpty){
                      return "Description must not be empty";
                    }else{
                      return null;
                    }
                  },
                )
              ],
            ),
          ),
        ),
      ),
    );
  }



  bool isLoading = false;
  ////////// chossse images /////////
  void chosePhoto()async{
    showModalBottomSheet(
        context: context,
        builder: (context) {
          return Padding(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                SizedBox(height: 20,),
                Text("Choose Image", style: TextStyle(color: AppColors.black, fontSize: 15, fontWeight: FontWeight.w600),),
                SizedBox(height: 30,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () {
                        _pickImage(ImageSource.camera); Navigator.pop(context);
                      },
                      child: Column(
                        children: [
                          Icon(Icons.camera_alt, color: AppColors.mainColor, size: 30,),
                          SizedBox(height: 10,),
                          Text("Take Photo", style: TextStyle(color: AppColors.mainColor),),
                        ],
                      ),
                    ),

                    SizedBox(width: 50,),
                    InkWell(
                      onTap: () {
                        _pickImage(ImageSource.gallery); Navigator.pop(context);
                      },
                      child: Column(
                        children: const [
                          Icon(Icons.photo, color: Colors.blueAccent, size: 30,),
                          SizedBox(height: 10,),
                          Text("Choose from Gallery", style: TextStyle(color: Colors.blueAccent),),
                        ],
                      ),
                    )
                  ],
                ),
                SizedBox(height: 20,),
              ],
            ),
          );
        });
  }

  //////// pick images ///////////

  File? image;
  ////////// pick profile image////////
  Future<void> _pickImage(ImageSource type) async {
    ImagePicker picker = ImagePicker();
    XFile? pickedFile = await picker.pickImage(source: type);
    if (pickedFile != null) {
     setState(() {
       image =  File(pickedFile!.path);
     });
      // Handle the picked image, e.g., display it in an image widget or upload it
      // to a server.
    }
  }

  ///////// upload image ///////////
  void _uploadPortfolio(file) async{
   setState(() {
     isLoading=true;
   });
   AlertController.snackbar(context: context, text: "Story uploading...", bg: AppColors.mainColor.withOpacity(0.7));
   var  res = await AuthController.uploadStory(images: file, description: des.text);
    print("response === ${res.statusCode}");

    if(res.statusCode == 200){
      AlertController.snackbar(context: context, text: "Story uploaded successfully.", bg: Colors.green);
      Get.to(FreelancerAppBottomNavigation());
    }else{
      AlertController.snackbar(context: context, text: "Something went wrong with server.", bg: Colors.red);
    }
    setState(() {
      isLoading=false;
    });
    if (mounted) {
      // Perform actions that depend on the widget being active.
      // Update the state or modify the UI.
    }
  }




}
