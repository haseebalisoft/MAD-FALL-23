import 'package:coco/utility/colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../client/bottomNagivation/buttom_nav.dart';

class Language_Select extends StatefulWidget {
  const Language_Select({super.key});

  @override
  State<Language_Select> createState() => _Language_SelectState();
}

class _Language_SelectState extends State<Language_Select> {
  bool isselected = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
          child: Column(
            children: [
              SizedBox(height: 10,),
              Row(
                children: [
                  IconButton(onPressed: (){
                    Get.back();
                  }, icon: Icon(Icons.arrow_back)),
                  Text('Langues',style: TextStyle(color: AppColors.mainColor,fontWeight: FontWeight.bold,fontSize: 18),)
                ],
              ),

              SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 28.0),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Checkbox(value: isselected,  onChanged: (bool? value) {
                            isselected = value!;
                            setState(() {
                            });
                          }),
                          Text('English',style: TextStyle(fontWeight: FontWeight.bold),)
                        ],
                      ),
                      Row(
                        children: [
                          Checkbox(
                            value: isselected,
                            onChanged: (bool? value) {
                              isselected = value!;
                              setState(() {});
                            },
                          ),
                          Text(
                            '英语',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Checkbox(
                            value: isselected,
                            onChanged: (bool? value) {
                              isselected = value!;
                              setState(() {});
                            },
                          ),
                          Text(
                            'Español',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Checkbox(
                            value: isselected,
                            onChanged: (bool? value) {
                              isselected = value!;
                              setState(() {});
                            },
                          ),
                          Text(
                            'हिंदी',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Checkbox(
                            value: isselected,
                            onChanged: (bool? value) {
                              isselected = value!;
                              setState(() {});
                            },
                          ),
                          Text(
                            'العربية',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Checkbox(
                            value: isselected,
                            onChanged: (bool? value) {
                              isselected = value!;
                              setState(() {});
                            },
                          ),
                          Text(
                            'Français',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Checkbox(
                            value: isselected,
                            onChanged: (bool? value) {
                              isselected = value!;
                              setState(() {});
                            },
                          ),
                          Text(
                            'Русский',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Checkbox(
                            value: isselected,
                            onChanged: (bool? value) {
                              isselected = value!;
                              setState(() {});
                            },
                          ),
                          Text(
                            'বাংলা',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Checkbox(
                            value: isselected,
                            onChanged: (bool? value) {
                              isselected = value!;
                              setState(() {});
                            },
                          ),
                          Text(
                            'Português',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Checkbox(
                            value: isselected,
                            onChanged: (bool? value) {
                              isselected = value!;
                              setState(() {});
                            },
                          ),
                          Text(
                            'اردو',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Checkbox(
                            value: isselected,
                            onChanged: (bool? value) {
                              isselected = value!;
                              setState(() {});
                            },
                          ),
                          Text(
                            'Bahasa Indonesia',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Checkbox(
                            value: isselected,
                            onChanged: (bool? value) {
                              isselected = value!;
                              setState(() {});
                            },
                          ),
                          Text(
                            'Deutsch',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Checkbox(
                            value: isselected,
                            onChanged: (bool? value) {
                              isselected = value!;
                              setState(() {});
                            },
                          ),
                          Text(
                            '日本語',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
          //           Row(
          //             children: [
          //               Checkbox(
          //                 value: isselected,
          //                 onChanged: (bool? value) {
          //                   isselected = value!;
          //                   setState(() {});
          //                 },
          //               ),
          //               Text(
          //                 'ਪੰਜਾਬੀ',
          //                 style: TextStyle(fontWeight: FontWeight.bold),
          //               ),
          //             ],
          //           ),
          //           Row(
          //             children: [
          //               Checkbox(
          //                 value: isselected,
          //                 onChanged: (bool? value) {
          //                   isselected = value!;
          //                   setState(() {});
          //                 },
          //               ),
          //               Text(
          //                 '한국어',
          //                 style: TextStyle(fontWeight: FontWeight.bold),
          //               ),
          //             ],
          //           ),
          //           Row(
          //             children: [
          //               Checkbox(
          //                 value: isselected,
          //                 onChanged: (bool? value) {
          //                   isselected = value!;
          //                   setState(() {});
          //                 },
          //               ),
          //               Text(
          //                 'Italiano',
          //                 style: TextStyle(fontWeight: FontWeight.bold),
          //               ),
          //             ],
          //           ),
          //           Row(
          //             children: [
          //               Checkbox(
          //                 value: isselected,
          //                 onChanged: (bool? value) {
          //                   isselected = value!;
          //                   setState(() {});
          //                 },
          //               ),
          //               Text(
          //                 'Türkçe',
          //                 style: TextStyle(fontWeight: FontWeight.bold),
          //               ),
          //             ],
          //           ),
          //           Row(
          //             children: [
          //               Checkbox(
          //                 value: isselected,
          //                 onChanged: (bool? value) {
          //                   isselected = value!;
          //                   setState(() {});
          //                 },
          //               ),
          //               Text(
          //                 'Tiếng Việt',
          //                 style: TextStyle(fontWeight: FontWeight.bold),
          //               ),
          //             ],
          //           ),
          //           Row(
          //             children: [
          //               Checkbox(
          //                 value: isselected,
          //                 onChanged: (bool? value) {
          //                   isselected = value!;
          //                   setState(() {});
          //                 },
          //               ),
          //               Text(
          //                 'தமிழ்',
          //                 style: TextStyle(fontWeight: FontWeight.bold),
          //               ),
          //             ],
          //           ),
          //            Row(
          //   children: [
          //       Checkbox(
          //         value: isselected,
          //         onChanged: (bool? value) {
          //           isselected = value!;
          //           setState(() {});
          //         },
          //       ),
          //       Text(
          //         'فارسی',
          //
          //         style: TextStyle(fontWeight: FontWeight.bold),
          //       ),
          //   ],
          // )

                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                        style: OutlinedButton.styleFrom(
                          backgroundColor: Color(0xFF00CC83),
                        ),
                        onPressed: () {
                          Get.to(() => ClientBottomNavigationBar());
                        },
                        child: Text(
                          'Save',
                          style: TextStyle(fontFamily: 'Poppins_SemiBold'),
                        ))),
              ),
            ],
          ),

        ),
    );
  }
}
