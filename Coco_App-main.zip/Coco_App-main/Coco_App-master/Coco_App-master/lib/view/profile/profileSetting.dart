import 'package:coco/controller/authController.dart';
import 'package:coco/controller/postController.dart';
import 'package:coco/under_dev.dart';
import 'package:coco/utility/appAssets.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/view/profile/account.dart';
import 'package:coco/view/profile/profileSetting/terms_conditions.dart';
import 'package:coco/view/profile/pushNotification.dart';
import 'package:coco/viewController/appNetworkImage.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shimmer/shimmer.dart';

import '../../model/authModel/userInfoModel.dart';
import 'profileSetting/privacy_policy.dart';
import 'publish_allert.dart';

class ProfileSetting extends StatefulWidget {
  const ProfileSetting({Key? key}) : super(key: key);

  @override
  State<ProfileSetting> createState() => _ProfileSettingState();
}

class _ProfileSettingState extends State<ProfileSetting> {

  Future<UserInformation>? getUserInfoFuture;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getUserInfoFuture = AuthController.getUserInfo();
  }

  late String name,email;

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Container(
      color: AppColors.mainColor,
      child: SafeArea(
        child: Scaffold(
          backgroundColor: AppColors.black,
          body: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                FutureBuilder<UserInformation>(
                  future: getUserInfoFuture,
                  builder: (context, snapshot) {
                    if(snapshot.connectionState == ConnectionState.waiting){
                      return Container(
                        width: size.width,
                        padding: EdgeInsets.only(top: 30, left: 20, bottom: 30, right: 20),
                        decoration: BoxDecoration(
                          color: AppColors.mainColor,
                        ),
                        child: Row(
                          children: [
                            Shimmer.fromColors(
                              highlightColor:AppColors.black,
                              baseColor: AppColors.black,
                              child: Container(
                                height: 60,
                                width: 60,
                                decoration: BoxDecoration(borderRadius: BorderRadius.circular(100), color: AppColors.black),
                              ),
                            ),
                            SizedBox(width: 10,),
                            Container(
                              width: 200,
                              height: 30,
                              decoration: BoxDecoration(borderRadius: BorderRadius.circular(100), color: AppColors.black),
                            )
                          ],
                        ),

                      );
                    }else if(snapshot.hasData){
                      name = snapshot.data!.data!.name ?? ''; // Use the null-aware operator
                      email = snapshot.data!.data!.email ?? ''; // Use the null-aware operator
                     return Container(
                       width: size.width,
                       padding: EdgeInsets.only(top: 30, left: 20, bottom: 30, right: 20),
                       decoration: BoxDecoration(
                         color: AppColors.mainColor,
                       ),
                       child: Row(
                         children: [
                           SizedBox(
                             height: 60, width: 60,
                             child: Container(
                               decoration: BoxDecoration(
                                 borderRadius: BorderRadius.circular(100),
                                 border: Border.all(width: 1, color: Colors.lightBlueAccent)
                               ),
                               child: ClipRRect(
                                 borderRadius: BorderRadius.circular(100),
                                 child: AppNetworkImage(src: snapshot.data?.data?.profileImage?? AssetUtils.logoPng,),
                               ),
                             )
                           ),
                           SizedBox(width: 10,),
                           Text("${snapshot.data?.data?.name ?? snapshot.data?.data?.userName ?? 'No Name Found'}",
                            style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w600,
                              color: Colors.white
                            ),
                           )
                         ],
                       ),

                     );
                    }else{
                      return const Center(child: Text("Please check you internet connection."),);
                    }
                  }
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(20),
                      child: Text("Settings",
                        style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: Colors.black
                        ),
                      ),
                    ),
                    buildSingleMenu(
                      text: "Push Notification",
                      onClick: ()=>Get.to(PushNotificationSetting(), transition: Transition.rightToLeft)
                    ),
                    buildSingleMenu(
                        text: "Account",
                        onClick: ()=>Get.to(AccountSetting(name: name, email: email,),  transition: Transition.rightToLeft)
                    ),
                    buildSingleMenu(
                        text: "Publish Alert",
                      onClick: ()=>Get.to(PublishAllert()),
                    ),
                    // Padding(
                    //   padding: const EdgeInsets.all(20),
                    //   child: Text("Logic",
                    //     style: TextStyle(
                    //         fontSize: 18,
                    //         fontWeight: FontWeight.w600,
                    //         color: Colors.black
                    //     ),
                    //   ),
                    // ),
                    buildSingleMenu(
                        text: "Terms and conditions",
                        onClick: ()=>Get.to(TermsConditions()),
                    ),
                    buildSingleMenu(
                        text: "Privacy Policy",
                      onClick: ()=>Get.to(PrivacyPolicy()),
                    ),
                    buildSingleMenu(
                        text: "Logout",
                        onClick: ()async{
                          await AuthController.signOut();
                        }
                    ),
                  ],
                ),
              ],
            ),
          ),
          bottomNavigationBar: InkWell(
            onTap: ()async{
              Share.share("Find On Demand Freelancer In Bali \nhttps://play.google.com/store/apps/details?id=com.newellmediallc.live.coco \n", );
            },
            child: Container(
              margin: EdgeInsets.only(left: 40, bottom: 30, right: 40),
              height: 40,
              decoration: BoxDecoration(
                color: AppColors.mainColor,
                borderRadius: BorderRadius.circular(100),
              ),
              child: Center(
                child: Text("Invite Friend",
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    color: AppColors.white,
                    fontSize: 16
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  InkWell buildSingleMenu({
  required VoidCallback onClick,
  required String text,
}) {
    return InkWell(
                    onTap: onClick,
                    child: Container(
                      padding: EdgeInsets.only(left: 10, right: 10),

                      decoration: BoxDecoration(
                        border: Border(
                          bottom: BorderSide(width: 1, color: AppColors.textgrey.withOpacity(0.5))
                        ),
                          color: AppColors.black,
                          //borderRadius: BorderRadius.circular(5)
                      ),
                      child: ListTile(
                        title: Text("$text",
                          style: TextStyle(
                            color: AppColors.white,
                          ),
                        ),
                        trailing: Icon(Icons.arrow_forward_ios, size: 20, color: AppColors.white,),
                      ),
                    ),
                  );
  }
}
