import 'dart:convert';
import 'dart:io';

import 'package:coco/appConst.dart';
import 'package:coco/controller/authController.dart';
import 'package:coco/controller/camera_gallery_controller/cameraGalleryController.dart';
import 'package:coco/model/authModel/userInfoModel.dart';
import 'package:coco/utility/appAssets.dart';
import 'package:coco/view/client/bottomNagivation/buttom_nav.dart';
import 'package:coco/view/freelancer/bottomNavigationBar/becameFreelanceBottomNavigation.dart';
import 'package:coco/view/freelancer/uploadPortfolio/PickerCropResultScreen.dart';
import 'package:coco/view/storys/story.dart';
import 'package:coco/viewController/StoryViewinsta.dart';
import 'package:coco/viewController/appNetworkImage.dart';
import 'package:coco/viewController/uploadVideoPreviews.dart';
import 'package:coco/viewController/viewController.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shimmer/shimmer.dart';
import 'package:sizer/sizer.dart';
import 'package:wechat_assets_picker/wechat_assets_picker.dart';

import '../../controller/profileToInfoController.dart';
import '../../controller/storyController.dart';
import '../../model/publish_alert_model.dart';
import '../../model/storyModel/allStoryModel.dart';
import '../../utility/colors.dart';
import '../../viewController/alartController.dart';
import '../../viewController/uploadphotos_videos.dart';
import '../profile_favorite.dart';
import 'story_upload_preview.dart';


class ProfileTopInformation extends StatefulWidget {
  const ProfileTopInformation({
    super.key,
  });

  @override
  State<ProfileTopInformation> createState() => _ProfileTopInformationState();
}

class _ProfileTopInformationState extends State<ProfileTopInformation> {

  final des = TextEditingController();

  Future<UserInformation>? getUserInfoFuture;
  Future<PublishAlertModel>? getUserAlertFuture;

  Future<AllStoryModel>? _getAllStory;
  List<Story> myStory = [];

  bool isFavCountLoading = true;
  int userID = 0;



  ProfileToInfoController controller = Get.put(ProfileToInfoController());

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getUserInfoFuture = AuthController.getUserInfo();
    //getUserAlertFuture = AuthController.getPublishAlert();

    getStoryChecker();
    getFavoriteNumber();
  }

  bool haveStory = false;

  getStoryChecker() async {
    SharedPreferences _pre = await SharedPreferences.getInstance();
    UserStory userStories;
    _getAllStory = StoryController.getStroyList();
    _getAllStory?.then((value) {
      for (var i in value!.userStories!) {
        if (i.id.toString() == _pre.getString("user_id")) {
          setState(() {
            haveStory = true;
          });
          for (var j in i!.stories!) {
            myStory.add(j);
          }
        }
      }
    });
  }


  getFavoriteNumber() async {
    setState(() {
      isFavCountLoading = true;
    });
    await controller.getFetchUserFavCount();

    setState(() {
      isFavCountLoading = false;
    });
  }




  @override
  Widget build(BuildContext context) {
    return FutureBuilder<UserInformation>(
        future: getUserInfoFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.grey.shade200
                  ),
                  // child: Center(child: CircularProgressIndicator(color: Colors.white,),),
                ),
                SizedBox(
                  width: 20,
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Shimmer.fromColors(
                        child: Container(width: 100, height: 20,),
                        baseColor: Colors.white,
                        highlightColor: Colors.grey.shade200
                    ),

                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        InkWell(
                          //onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientBottomNavigationBar(pageIndex: 4, userId: "1", ))),//this is outside o bottomnavigation, but we need still button navigation
                          child: Column(
                            children: [
                              Text(
                                '--',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.white,
                                    fontFamily: "arial-bold",
                                    fontSize: 17),
                              ),
                              Text(
                                'Followers',
                                style: TextStyle(
                                    color: AppColors.textgrey,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 10.w,
                        ),
                        Container(
                          height: 30,
                          width: 2,
                          color: Colors.black12,
                        ),
                        SizedBox(
                          width: 10.w,
                        ),
                        Column(
                          children: [
                            Text(
                              '--',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontFamily: "arial-bold",
                                  color: AppColors.white,
                                  fontSize: 17),
                            ),
                            Text(
                              'Following',
                              style: TextStyle(
                                  color: AppColors.textgrey,
                                  fontWeight: FontWeight.w400,
                                  fontSize: 12),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            );
          }
          else if (snapshot.hasData) {
            return Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                InkWell(
                  onTap: () {

                  },
                  child: Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: haveStory ? LinearGradient(colors: [
                          Color(0xFF00CC83),
                          Color(0xFF53E0DB),
                        ]) : const LinearGradient(colors: [
                          Colors.white,
                          Colors.white
                        ])),
                    child: Stack(
                      children: [
                        InkWell(
                          onTap: () =>
                          haveStory ? Get.to(StoryInsta(
                              allStoryModel: myStory,
                              user_name: snapshot.data!.data!.name!)) : null,
                          child: Container(
                            margin: EdgeInsets.all(5),
                            child: CircleAvatar(
                              radius: 100,
                              child: ClipOval(
                                child: snapshot.data?.data?.profileImage !=
                                    null
                                    ? AppNetworkImage(
                                  src: snapshot.data!.data!.profileImage!,
                                  width: 100,
                                  height: 100,
                                  fit: BoxFit.cover,)
                                    : Image.asset(
                                  AssetUtils.logoPng,
                                  width: double.infinity,
                                  height: double.infinity,
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          right: 0, bottom: 0,
                          child: InkWell(
                            onTap: () =>
                                CameraGalleryController
                                    .pickGalleryAndCameraForStory(
                                    context: context, from: "profile"),
                            // onTap: ()=>ViewController.chosePhoto(
                            //     context: context,
                            //     leftButton: (){
                            //       _uploadPost();
                            //       Get.back();
                            //     } ,
                            //     rightButton: (){
                            //       Get.back();
                            //       Get.to(UploadVideoPreviews(), transition: Transition.downToUp);
                            //     }
                            // ),
                            child: Container(
                              width: 30,
                              height: 30,
                              decoration: BoxDecoration(
                                  color: Colors.blue,
                                  borderRadius: BorderRadius.circular(100)
                              ),
                              child: Center(child: Icon(
                                Icons.add, color: Colors.white,),),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  width: 20,
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: MediaQuery
                          .of(context)
                          .size
                          .width * 0.5,
                      child: Text(
                        snapshot.data?.data?.name ?? snapshot.data?.data?.userName ?? "No Name Found",
                        style: TextStyle(
                            fontSize: 20,
                            color: AppColors.white,
                            fontFamily: 'Poppins-Bold'
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 0,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        InkWell(
                          onTap: () =>
                              Navigator.push(context, MaterialPageRoute(
                                  builder: (context) =>
                                      ClientBottomNavigationBar(pageIndex: 4,
                                          userId: snapshot.data?.data?.id
                                              .toString()))),
                          //this is outside o bottomnavigation, but we need still button navigation
                          child: Column(
                            children: [
                              Text(
                                '${snapshot.data!.data!.followers!.length}',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.white,
                                    fontFamily: "arial-bold",
                                    fontSize: 17),
                              ),
                              Text(
                                'Followers',
                                style: TextStyle(
                                    color: AppColors.textgrey,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 5.w,
                        ),
                        InkWell(
                          onTap: () =>
                              Navigator.push(context, MaterialPageRoute(
                                  builder: (context) =>
                                      ClientBottomNavigationBar(pageIndex: 4,
                                        userId: snapshot.data?.data?.id.toString(),
                                          pageInderForFollowing: 1,))

                              ),
                          //this is outside o bottomnavigation, but we need still button navigation


                          child: Column(
                            children: [
                              Text(
                                '${snapshot.data!.data!.following!.length}',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.white,
                                    fontFamily: "arial-bold",
                                    fontSize: 17),
                              ),
                              Text(
                                'Following',
                                style: TextStyle(
                                    color: AppColors.textgrey,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 5.w,
                        ),
                        InkWell(
                          child: Column(
                            children: [
                              isFavCountLoading
                                  ? Container(
                                width: 15, // Customize the width as needed
                                height: 15, // Customize the height as needed
                                child: CircularProgressIndicator(
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                      AppColors.mainColor),
                                ),
                              )
                                  :
                              Obx(() {
                                return InkWell(
                                  onTap: () {
                                    Get.to(ProfileFavorite(), transition: Transition.rightToLeft);
                                  },
                                  child: Text(
                                    '${controller.favCount}',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: AppColors.white,
                                      fontFamily: "arial-bold",
                                      fontSize: 17,
                                    ),
                                  ),
                                );
                              }),
                              Text(
                                'Favorite',
                                style: TextStyle(
                                  color: AppColors.textgrey,
                                  fontWeight: FontWeight.w400,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            );
          } else {
            return Center(child: Text("Error: ${snapshot.error}"),);
          }
        }
    );
  }


  File? image;

  ////////// pick profile image////////
  Future<void> _pickImage(ImageSource type) async {
    ImagePicker picker = ImagePicker();
    XFile? pickedFile = await picker.pickImage(source: type);
    if (pickedFile != null) {
      image = File(pickedFile!.path);
      // _uploadPortfolio(image);
      // Handle the picked image, e.g., display it in an image widget or upload it
      // to a server.
    }
  }


  void chosePhoto() async {
    showModalBottomSheet(
        context: context,
        builder: (context) {
          return Padding(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                SizedBox(height: 20,),
                Text("Choose Image", style: TextStyle(color: AppColors.black,
                    fontSize: 15,
                    fontWeight: FontWeight.w600),),
                SizedBox(height: 30,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () {
                        _pickImage(ImageSource.camera);
                        Navigator.pop(context);
                      },
                      child: Column(
                        children: [
                          Icon(Icons.camera_alt, color: AppColors.mainColor,
                            size: 30,),
                          SizedBox(height: 10,),
                          Text("Take Photo", style: TextStyle(color: AppColors
                              .mainColor),),
                        ],
                      ),
                    ),

                    SizedBox(width: 50,),
                    InkWell(
                      onTap: () {
                        _pickImage(ImageSource.gallery);
                        Navigator.pop(context);
                      },
                      child: Column(
                        children: const [
                          Icon(
                            Icons.photo, color: Colors.blueAccent, size: 30,),
                          SizedBox(height: 10,),
                          Text("Choose from Gallery",
                            style: TextStyle(color: Colors.blueAccent),),
                        ],
                      ),
                    )
                  ],
                ),
                SizedBox(height: 20,),
              ],
            ),
          );
        });
  }


  ///= =============------ use set here isStory = true =========//
  List<AssetEntity> videos = [];

  Future<void> _pickVideos() async {
    List<AssetEntity>? result = await AssetPicker.pickAssets(
      context,
      pickerConfig: AssetPickerConfig(
          requestType: RequestType.all,
          filterOptions: PMFilter.defaultValue(),
          maxAssets: 1
      ),
    );

    if (result != null) {
      setState(() {
        videos = List.from(result);
      });
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) =>
            UploadPhotosVideos(
              list: videos, isStory: true,),
      ),
    );
  }

// void showOptionForProfile()async{
//   showModalBottomSheet(
//       context: context,
//       builder: (context) {
//         return Column(
//           mainAxisSize: MainAxisSize.min,
//           children: <Widget>[
//             ListTile(
//               leading: new Icon(Icons.edit),
//               title: const Text('Edit Profile'),
//               onTap: () {
//                 // selectTypeForUploadProfile("profile");
//                 Future.delayed(Duration(milliseconds: 100), () {
//                   // 5s over, navigate to a new page
//                   chosePhoto();
//                 });
//                 print("dsfdasf");
//                 Navigator.pop(context);
//               },
//             ),
//             ListTile(
//               leading: new Icon(Icons.add),
//               title: const Text('Add Store'),
//               onTap: () {
//                 // selectTypeForUploadProfile("profile");
//                 Get.to(StoryUpload());
//                 //Navigator.pop(context);
//               },
//             ),
//             SizedBox(height: 20,),
//           ],
//         );
//       });
// }


}
