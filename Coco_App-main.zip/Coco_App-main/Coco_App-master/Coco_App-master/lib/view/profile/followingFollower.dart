import 'dart:convert';

import 'package:coco/controller/authController.dart';
import 'package:coco/controller/followUnFollowList.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/view/Client/profile/freelancerProfileDetails.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:coco/viewController/appLoading.dart';
import 'package:coco/viewController/appNetworkImage.dart';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../appConst.dart';
import '../../controller/followingFollowerController.dart';
import '../../model/authModel/singleUserInfo.dart';
import '../../model/authModel/userInfoModel.dart';
import '../Client/bottomNagivation/buttom_nav.dart';
import '../freelancer/bottomNavigationBar/becameFreelanceBottomNavigation.dart';

class FollowingFollowers extends StatefulWidget {
  final String? userId;
  final bool? ownFollowList;

  final int initPage;

  const FollowingFollowers(
      {super.key, this.userId, this.ownFollowList, this.initPage = 0});

  @override
  State<FollowingFollowers> createState() => _FollowingFollowersState();
}

class _FollowingFollowersState extends State<FollowingFollowers>
    with SingleTickerProviderStateMixin {
  late TabController tabController;
  Future<SingleUserInfoModel>? singleUserFollowFollowingFuture;

  final FollowingFollowerController followingFollowerController = Get.put(
      FollowingFollowerController());


  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    followingFollowerController.getgetFollowFollowingList(widget.userId!);
    tabController =
        TabController(length: 2, vsync: this, initialIndex: widget.initPage);
  }


  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      child: Obx(() {
        return Scaffold(
            backgroundColor: Colors.black,
            appBar: AppBar(
              backgroundColor: Colors.black,
              elevation: 0,
              leading: IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.arrow_back, color: Colors.white,),
              ),
            ),
            body: followingFollowerController.isLoading.value
                ? Center(child: CircularProgressIndicator( color: Colors.white,),)
                : Column(
              children: [
                TabBar(
                    controller: tabController,
                    labelColor: Colors.white,
                    dividerColor: AppColors.mainColor,
                    unselectedLabelColor: Colors.grey,
                    indicatorColor: AppColors.mainColor,
                    tabs: [
                      Tab(
                        icon: Text(
                          "${followingFollowerController.followersList.length}",
                          style: TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: 20
                          ),
                        ),
                        child: Text("Followers",
                          style: TextStyle(
                              fontWeight: FontWeight.w400,
                              fontSize: 14
                          ),
                        ),
                      ),
                      Tab(
                        icon: Text(
                          "${followingFollowerController.followingList.length}",
                          style: TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: 20
                          ),
                        ),
                        child: Text("Following",
                          style: TextStyle(
                              fontWeight: FontWeight.w400,
                              fontSize: 14
                          ),
                        ),
                      ),

                      // Padding(
                      //   padding: const EdgeInsets.all(10.0),
                      //   child: Text('Protfolio',),
                      // ),
                      // Padding(
                      //   padding: const EdgeInsets.all(10.0),
                      //   child: Text('About me',),
                      // ),
                    ]),
                Expanded(
                  child: TabBarView(
                    controller: tabController,
                    children: [
                      // Text('data'),
                      // Text('data'),
                      buildFollowersList(),
                      buildFollowingList(),

                    ],
                  ),
                )
              ],
            )
        );
      }),
    );
  }

  Column buildFollowingList() {
    return Column(
      children: [
        SizedBox(height: 20,),
        Container(
          margin: EdgeInsets.only(left: 20, right: 20),
          child: TextFormField(
              onChanged: (v) {
                followingSearch(v, followingFollowerController.followingList);
              },
              decoration: InputDecoration(
                  contentPadding: EdgeInsets.only(left: 10, right: 10),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(100),
                    borderSide: BorderSide.none,
                  ),
                  fillColor: Colors.grey.shade200,
                  filled: true,
                  hintText: "Search",
                  hintStyle: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.normal
                  ),
                  prefixIcon: Icon(Icons.search, color: Colors.grey,)
              )
          ),
        ),
        SizedBox(height: 20,),
        followingFollowerController.followingList.isNotEmpty ? Expanded(
          child: followingFollowerController.searchFollowingList.isNotEmpty
              ? ListView.builder(
            itemCount: followingFollowerController.searchFollowingList.length,
            itemBuilder: (_, index) {
              return singleUser(
                  onTab: () => _followUnfollow(
                      followingFollowerController.searchFollowingList[index]
                          ?.id.toString()),
                  userId: followingFollowerController
                      .searchFollowingList[index]!.id.toString(),
                  text: "Unfollow",
                  bgButton: AppColors.mainColor,
                  name: followingFollowerController.searchFollowingList[index]!
                      .name!,
                  profile: followingFollowerController
                      .searchFollowingList[index]?.profileImage.toString()
              );
            },
          )
              : ListView.builder(
            itemCount: followingFollowerController.followingList.length,
            itemBuilder: (_, index) {
              return singleUser(
                  onTab: () => _followUnfollow(
                      followingFollowerController.followingList[index]?.id
                          .toString()),
                  userId: followingFollowerController.followingList[index]!.id
                      .toString(),
                  text: "Unfollow",
                  bgButton: AppColors.mainColor,
                  name: followingFollowerController.followingList[index]
                      ?.name ?? "",
                  profile: followingFollowerController.followingList[index]
                      ?.profileImage.toString()
              );
            },
          ),
        ) : Padding(padding: EdgeInsets.only(top: 100),
          child: Text("You don't have any Follower."),)
      ],
    );
  }


  Column buildFollowersList() {
    return Column(
      children: [
        SizedBox(height: 20,),
        Container(
          margin: EdgeInsets.only(left: 20, right: 20),
          child: TextFormField(
              onChanged: (v) {
                followersSearch(v, followingFollowerController.followersList);
              },
              decoration: InputDecoration(
                  contentPadding: EdgeInsets.only(left: 10, right: 10),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(100),
                    borderSide: BorderSide.none,
                  ),
                  fillColor: Colors.grey.shade200,
                  filled: true,
                  hintText: "Search",
                  prefixIcon: Icon(Icons.search, color: Colors.grey,)
              )
          ),
        ),
        SizedBox(height: 20,),
        followingFollowerController.followersList.isNotEmpty ? Expanded(
          child: followingFollowerController.searchFollowersList.isNotEmpty
              ? ListView.builder(
            itemCount: followingFollowerController.searchFollowersList.length,
            itemBuilder: (_, index) {
              return singleUser(
                  onTab: () => _followUnfollow(followingFollowerController
                      .searchFollowersList![index]?.id.toString()),
                  userId: followingFollowerController.searchFollowersList[index]
                      ?.id.toString() ?? "",
                  text: "Unfollow",
                  bgButton: AppColors.mainColor,
                  name: followingFollowerController.searchFollowersList[index]
                      ?.name ?? "",
                  profile: followingFollowerController
                      .searchFollowersList[index]?.profileImage ?? ""
              );
            },
          )
              : ListView.builder(
            itemCount: followingFollowerController.followersList!.length,
            itemBuilder: (_, index) {
              return singleUser(
                  onTab: () => _followUnfollow(
                      followingFollowerController.followersList[index]?.id
                          .toString()),
                  userId: followingFollowerController.followersList[index]?.id
                      .toString() ?? "",
                  text: "Unfollow",
                  bgButton: AppColors.mainColor,
                  name: followingFollowerController.followersList[index]
                      ?.name ?? "",
                  profile: followingFollowerController.followersList![index]
                      ?.profileImage
              );
            },
          ),
        ) : const Padding(padding: EdgeInsets.only(top: 100),
          child: Text("You are not following anyone."),)
      ],
    );
  }

  //search followers
  void followersSearch(String query, List<Followers?> followers) {
    print("query $query");
    print("query ${followingFollowerController.followersList}");
    // getFollowFollowingList();
    // Clear the filtered list
    followingFollowerController.searchFollowersList.clear();
    // If the query is empty, add all items to the filtered list

    if (query.isEmpty) {
      followingFollowerController.searchFollowersList =
          followingFollowerController.followersList;
    } else {
      // Filter items based on the query
      followers?.forEach((item) {
        final itemName = item?.name;
        if (itemName != null &&
            itemName.toLowerCase().contains(query.toLowerCase())) {
          setState(() {
            followingFollowerController.searchFollowersList.add(item);
          });
        }
      });
    }
  }

  //search follwing
  void followingSearch(String query, List<Following?> following) {
    print("query $query");
    // Clear the filtered list
    followingFollowerController.searchFollowingList.clear();
    // If the query is empty, add all items to the filtered list

    if (query.isEmpty) {
      followingFollowerController.searchFollowingList.value = following;
    } else {
      // Filter items based on the query
      following.forEach((item) {
        final itemName = item?.name;
        if (itemName != null &&
            itemName.toLowerCase().contains(query.toLowerCase())) {
          followingFollowerController.searchFollowingList.add(item);
        }
      });
    }

    // Update the UI
    setState(() {});
  }


  ListTile singleUser({
    required String text,
    required String userId,
    required String name,
    required String? profile,
    required VoidCallback onTab,

    required Color bgButton}) {
    return ListTile(
      onTap: () async {

        SharedPreferences pref = await SharedPreferences.getInstance();
        String? ownUserId = pref.getString("user_id");

        print("user id $userId");
        print("own user id $ownUserId");
        if (userId == ownUserId) {
          print("own user id $ownUserId");

        pref.getString("role")  == AppConst.FREELANCER_ROLE
              ? Get.to(
              FreelancerAppBottomNavigation(pageIndex: 4, userId:ownUserId))
              : Get.to(
              ClientBottomNavigationBar(pageIndex: 3,  userId:ownUserId));
        }
        else{
          Get.to(FreelancerProfileDetails(userId: userId));
        }
      },
      contentPadding: EdgeInsets.only(bottom: 15, left: 20, right: 10),
      leading: Container(
        height: 50, width: 50,
        child: ClipRRect(
            borderRadius: BorderRadius.circular(100),
            child: profile != null ? AppNetworkImage(src: profile!,) : Image
                .asset("asset/image/logo.png", fit: BoxFit.cover)
        ),
      ),
      title: Text("$name",
        style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: AppColors.white
        ),
      ),
      trailing: widget!.userId == followingFollowerController.user_id
          ? InkWell(
        onTap: onTab,
        child: Container(
            height: 50, width: 120,
            decoration: BoxDecoration(
                color: bgButton,
                borderRadius: BorderRadius.circular(5)
            ),
            child: Center(child: Text("$text",
              style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 12,
                color: AppColors.white,
              ),
            ),)
        ),
      ) : SizedBox(height: 1, width: 1,),
    );
  }


  /////////////////////// follow unfollow //////////////////////
  bool isLoading = false;
  bool isFollowing = false;
  var followers = 0;

  _followUnfollow(id) async {
    setState(() => isLoading = true);
    var res = await FollowUnFollowController.followUnfollow(id);
    if (res.statusCode == 200) {
      setState(() {
        followers = followers + 1;
        isFollowing = true;
      });
      AlertController.snackbar(context: context,
          text: "${jsonDecode(res.body)["message"]}",
          bg: Colors.green);
    } else if (res.statusCode == 202) {
      setState(() {
        followers = followers - 1;
        isFollowing = false;
      });
      singleUserFollowFollowingFuture =
          AuthController.getSingleUserInfo(widget.userId.toString());

      AlertController.snackbar(context: context,
          text: "${jsonDecode(res.body)["message"]}",
          bg: Colors.blue);
    } else {
      AlertController.snackbar(context: context,
          text: "Please check your internet connection.",
          bg: Colors.red);
    }
    setState(() => isLoading = false);
  }

}

