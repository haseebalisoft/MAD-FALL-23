import 'package:flutter/material.dart';

class profile_tab extends StatelessWidget {
  const profile_tab({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(length: 2, child: Scaffold());
  }
}
