import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';

import '../../../controller/authController.dart';
import '../../../controller/upload_cover_image_controller.dart';
import '../../../utility/colors.dart';
import '../../../viewController/alartController.dart';

class UploadCoverImage extends StatefulWidget {
  final bool isEdit;
  final String placeholder;
  const UploadCoverImage({Key? key, required this.isEdit, required this.placeholder}) : super(key: key);

  @override
  State<UploadCoverImage> createState() => _UploadCoverImageState();
}

class _UploadCoverImageState extends State<UploadCoverImage> {

  UploadCoverImageController controller = Get.put(UploadCoverImageController());

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Obx(() =>
        Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: 20,
          ),
          Text("Cover photo",
            style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 12,
                color: AppColors.white
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,

            children: [
              Text("Add a cover photo that represent your business",
                style: TextStyle(
                    fontWeight: FontWeight.w400,
                    fontSize: 10,
                    color: Colors.grey
                ),
              ),
              Text("* Size 800X400px",
                style: TextStyle(
                    fontWeight: FontWeight.w400,
                    fontSize: 8,
                    color: AppColors.textgrey
                ),
              ),
            ],
          ),
          SizedBox(
            height: 10,
          ),
          InkWell(
            onTap: ()=>_pickImage(ImageSource.gallery),
            child: ClipRRect(
                child: controller.croppedFile.value != null
                     ?  Image.file(controller.croppedFile.value!, width: MediaQuery.of(context).size.width, height: 200, fit: BoxFit.cover,)
                    : Container(
                  height: 50,
                  decoration: BoxDecoration(
                    color: Colors.black,
                   // borderRadius: BorderRadius.circular(5),
                    border: Border.all(width: 1, color: AppColors.mainColor),
                    borderRadius: BorderRadius.circular(10)
                  ),
                  child: Center(
                    child: Text("+ Upload cover image",
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        color: AppColors.mainColor,
                        fontSize: 14
                      ),
                    ),
                  ),
                )
            ),
          )
        ],
      ),
    );
  }


  showCrop()async{
    showGeneralDialog(
      context: context,
      barrierColor: Colors.black12.withOpacity(0.6), // Background color
      barrierDismissible: true,
      barrierLabel: 'Crop Image',
      transitionDuration: Duration(milliseconds: 400),
      pageBuilder: (context, __, ___) {
        return Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          color: AppColors.black,
          child: Column(
            children: [
              // Container(
              //   width: MediaQuery.of(context).size.width,
              //   height: MediaQuery.of(context).size.height-200,
              //   child: Crop.file(image!, key: cropKey),
              // ),
              Container(
                color: AppColors.white,
                child: TextButton(
                  child: Text("Crop Image & Upload",
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: AppColors.black
                    ),
                  ),
                  onPressed: (){
                   // _cropImages(image);
                    //_uploadCoverImage(controller.image.value);
                    setState(() => isImageCroping = true);
                    Navigator.pop(context);

                  },
                ),
              )
            ],
          ),
        );
      },
    );
  }





  ////////// chossse images /////////

  bool isImageCroping = false;
  ////////// pick profile image////////
  Future<void> _pickImage(ImageSource type) async {
    ImagePicker picker = ImagePicker();
    XFile? pickedFile = await picker.pickImage(source: type);
    if (pickedFile != null) {
      setState(() {
        controller.image.value =  File(pickedFile!.path);
      });
      _cropImage();
      // Handle the picked image, e.g., display it in an image widget or upload it
      // to a server.
    }
  }


  Future<void> _cropImage() async {
    if (controller.image.value != null) {
      final croppedFile = await ImageCropper().cropImage(
        maxHeight: 400,
        maxWidth: 800,
        aspectRatio: CropAspectRatio(
            ratioX: 1, ratioY: 1
        ),
        sourcePath: controller.image.value!.path,
        compressFormat: ImageCompressFormat.jpg,
        compressQuality: 100,
        uiSettings: [
          AndroidUiSettings(
              toolbarTitle: 'Profile Photo',
              toolbarColor: Colors.black,
              toolbarWidgetColor: Colors.white,
              initAspectRatio: CropAspectRatioPreset.original,
              lockAspectRatio: false),
          IOSUiSettings(
            title: 'Profile Photo',
          ),
          WebUiSettings(
            context: context,
            presentStyle: CropperPresentStyle.dialog,
            boundary: const CroppieBoundary(
              width: 520,
              height: 520,
            ),
            viewPort: const CroppieViewPort(width: 480, height: 480, type: 'circle'),
            enableExif: true,
            enableZoom: true,
            showZoomer: true,
          ),
        ],
      );
      if (croppedFile != null) {

        print("croppedFile.path === ${croppedFile.path}");
        setState(() {
          controller.croppedFile.value = File(croppedFile.path);
          _uploadCoverImage(controller.croppedFile.value);
        });
      }
    }
  }




        bool isLoading = false;
        void _uploadCoverImage(file) async{
          setState(() =>isLoading=true);
          AlertController.snackbar( context: context, text: "Cover image uploading....", bg: AppColors.mainColor.withOpacity(0.7));
          var res = await AuthController.uploadCoverImage(images: file);

          print("response === ${res.statusCode}");
          print("response === ${res.stream.map((event) => print(event))}");
          if(res.statusCode == 200){
            AlertController.snackbar(context: context, text: "Cover image uploaded success.", bg: Colors.green);
          }else{
            AlertController.snackbar(context: context, text: "Something went wrong with server.", bg: Colors.red);
          }
          setState(() =>isLoading=false);
        }
}

