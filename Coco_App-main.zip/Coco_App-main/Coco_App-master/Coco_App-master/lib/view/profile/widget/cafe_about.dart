import 'package:flutter/material.dart';


class Cafe_about extends StatefulWidget {
  const Cafe_about({super.key});

  @override
  State<Cafe_about> createState() => _Cafe_aboutState();
}

class _Cafe_aboutState extends State<Cafe_about> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Description',
              style: TextStyle(color: Color(0xff00CC83), fontSize: 18),
            ),
          SizedBox(height: 15,),
          Text("We believe that a meal is more than just sustenance; it's an experience to be savored, cherished, and shared. So come join us and immerse yourself in a world of flavors, where good company and great food come together to create unforgettable memories.",
          style: TextStyle(color: Color(0xff676767)),
          ),

            SizedBox(
              height: 10,
            ),
            Divider(),
            SizedBox(
              height: 10,
            ),
            Text(
              'Location',
              style: TextStyle(color: Color(0xff00CC83), fontSize: 18),
            ),
          SizedBox(height: 10,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(child: Text("Bali Bliss Resort Jalan Sunset No. 123 Seminyak, Kuta Bali 80361 Indonesia")),
              Spacer(),
              SizedBox(
                  width: MediaQuery.of(context).size.width / 3,
                  child: ElevatedButton(
                      style: OutlinedButton.styleFrom(
                        backgroundColor: Color(0xFF00CC83),
                      ),
                      onPressed: (){},
                      child: Text(
                        'View directions',
                        style:
                        TextStyle(fontFamily: 'Poppins_SemiBold'),
                      ))),
            ],
          ),

            SizedBox(
              height: 10,
            ),
            Divider(),
            SizedBox(
              height: 10,
            ),
            Text(
              'Opening Hours',
              style: TextStyle(color: Color(0xff00CC83), fontSize: 16),
            ),
            SizedBox(
              height: 2,
            ),
            Text(
              'Monday to Sunday from 9:00 to 21:00',
              style: TextStyle(fontSize: 17),
            ),
            SizedBox(
              height: 10,
            ),
            Divider(),
            SizedBox(
              height: 10,
            ),
            Text(
              'Follow us',
              style: TextStyle(color: Color(0xff00CC83), fontSize: 18),
            ),
            SizedBox(
              height: 5,
            ),
            Row(
              children: [
                Image.asset(
                  'asset/image/insta.png',
                  width: 45,
                  height: 45,
                ),
                SizedBox(
                  width: 20,
                ),
                Image.asset(
                  'asset/image/youtube.png',
                  width: 45,
                  height: 45,
                ),
                SizedBox(
                  width: 20,
                ),
                Image.asset(
                  'asset/image/bain.png',
                  width: 45,
                  height: 45,
                ),
                SizedBox(
                  width: 20,
                ),
                Image.asset(
                  'asset/image/linkdin.png',
                  width: 45,
                  height: 45,
                ),
              ],
            ),
            SizedBox(height: 20,)
          ],
        ),
      ),
    );
  }
}
