// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import '../../../utility/appAssets.dart';
// import '../../client/Posts/UserPosts.dart';
//
//
// class Cafe_protfolio extends StatefulWidget {
//   const Cafe_protfolio({super.key});
//
//   @override
//   State<Cafe_protfolio> createState() => _Cafe_protfolioState();
// }
//
// class _Cafe_protfolioState extends State<Cafe_protfolio> {
//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Center(
//           child: SingleChildScrollView(
//             scrollDirection: Axis.vertical,
//             child: Wrap(
//               direction: Axis.horizontal,
//               spacing: 10,
//               runAlignment: WrapAlignment.spaceBetween,
//               children: [
//                 InkWell(
//                   onTap: (){
//                     Get.to(Users_Posts());
//                   },
//                   child: Container(
//                     width: 170,
//                     height: 270,
//                     child: Image.asset(AssetUtils.cafe_profile_food),
//                   ),
//                 ),
//                 Container(
//                   width: 170,
//                   height: 270,
//                   child: Image.asset(AssetUtils.cafe_profile_food),
//                 ),
//                 Container(
//                   width: 170,
//                   height: 270,
//                   child: Image.asset(AssetUtils.cafe_profile_food),
//                 ),
//                 Container(
//                   width: 170,
//                   height: 270,
//                   child: Image.asset(AssetUtils.cafe_profile_food),
//                 ),
//                 Container(
//                   width: 170,
//                   height: 270,
//                   child: Image.asset(AssetUtils.cafe_profile_food),
//                 ),
//                 Container(
//                   width: 170,
//                   height: 270,
//                   child: Image.asset(AssetUtils.cafe_profile_food),
//                 ),
//                 Container(
//                   width: 170,
//                   height: 270,
//                   child: Image.asset(AssetUtils.cafe_profile_food),
//                 ),
//                 Container(
//                   width: 170,
//                   height: 270,
//                   child: Image.asset(AssetUtils.cafe_profile_food),
//                 ),
//                 Container(
//                   width: 170,
//                   height: 270,
//                   child: Image.asset(AssetUtils.cafe_profile_food),
//                 ),
//                 Container(
//                   width: 170,
//                   height: 270,
//                   child: Image.asset(AssetUtils.cafe_profile_food),
//                 ),
//                 Container(
//                   width: 170,
//                   height: 270,
//                   child: Image.asset(AssetUtils.cafe_profile_food),
//                 ),
//                 Container(
//                   width: 170,
//                   height: 270,
//                   child: Image.asset(AssetUtils.cafe_profile_food),
//                 ),
//                 Container(
//                   width: 170,
//                   height: 270,
//                   child: Image.asset(AssetUtils.cafe_profile_food),
//                 ),
//                 Container(
//                   width: 170,
//                   height: 270,
//                   child: Image.asset(AssetUtils.cafe_profile_food),
//                 ),
//                 Container(
//                   width: 170,
//                   height: 270,
//                   child: Image.asset(AssetUtils.cafe_profile_food),
//                 ),
//               ],
//             ),
//           ),
//         ));
//   }
// }
