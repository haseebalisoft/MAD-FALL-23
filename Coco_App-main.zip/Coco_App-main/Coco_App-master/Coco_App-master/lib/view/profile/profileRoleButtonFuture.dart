import 'package:coco/utility/colors.dart';
import 'package:coco/view/favoriteList/faveriotList.dart';
import 'package:coco/view/userProfile/Cafe_Edit_profile.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../appConst.dart';
import '../../controller/authController.dart';
import '../../model/authModel/singleUserInfo.dart';
import '../Client/profile/editProfile.dart';
import '../freelancer/profile/UserEditProfile.dart';
import '../freelancer/profile/freelancerProfile.dart';
import '../profile_favorite.dart';
import '../userProfile/cafe_profile.dart';



class ProfileRoleButton extends StatefulWidget {
  const ProfileRoleButton({Key? key}) : super(key: key);

  @override
  State<ProfileRoleButton> createState() => _ProfileRoleButtonState();
}

class _ProfileRoleButtonState extends State<ProfileRoleButton> {


  var user_id;
  Future<SingleUserInfoModel>? getUserFuture()async{
    SharedPreferences _prefs = await SharedPreferences.getInstance();
    var user_id = _prefs.getString("user_id");
    return AuthController.getSingleUserInfo(user_id.toString());
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getUserFuture();
  }


  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 15.0, right: 15, bottom: 5, top: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          SizedBox(
              width: MediaQuery.of(context).size.width / 2.3,
              child: ElevatedButton(
                style:  ButtonStyle(
                  backgroundColor: MaterialStateProperty.all(AppColors.white)
                ),
                  onPressed: () async{
                    SharedPreferences _pref = await SharedPreferences.getInstance();
                    Get.to(UserEditProfile());
                    // debugPrint("role === ${_pref.getString("role")}");
                    // if(_pref.getString("role") == AppConst.FREELANCER_ROLE){
                    //   Get.to( UserEditProfile(), transition: Transition.downToUp);
                    // }else if(_pref.getString("role") == AppConst.CLIENT_ROLE){
                    //   Get.to(ClientEditProfile(), transition: Transition.downToUp);
                    // }

                  },
                  child: const Text('Edit Profile',
                      style: TextStyle(
                        color: AppColors.black,
                          fontFamily: 'Poppins_SemiBold')))),
          SizedBox(
            width: 5,
          ),
          SizedBox(
              width: MediaQuery.of(context).size.width / 2.3,
              child: ElevatedButton(
                  style: OutlinedButton.styleFrom(
                    backgroundColor: Color(0xFF00CC83),
                  ),
                  //onPressed: ()=>Get.to(FavList()),
                  onPressed: ()=>Get.to(ProfileFavorite()),
                  child: const Text(
                    'Favorite',
                    style:
                    TextStyle(fontFamily: 'Poppins_SemiBold'),
                  ))),
        ],
      ),
    );
  }
}
