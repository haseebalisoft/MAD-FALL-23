import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../utility/colors.dart';

class PushNotificationSetting extends StatefulWidget {
  const PushNotificationSetting({Key? key}) : super(key: key);

  @override
  State<PushNotificationSetting> createState() => _PushNotificationSettingState();
}

class _PushNotificationSettingState extends State<PushNotificationSetting> {
  bool isFollowers = true;
  bool isAppUpdate = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.black,
      appBar: AppBar(
        backgroundColor: AppColors.black,
        elevation: 0,
        leading: IconButton(
          onPressed: ()=>Get.back(),
          icon: Icon(Icons.arrow_back, color: Colors.white,),
        ),
        title: Text("Push Notification",
          style: TextStyle(
            fontSize: 18,
            color: Colors.white
          ),
        ),
      ),
      body: SingleChildScrollView(
       
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.only(left: 10, right: 10),

              decoration: BoxDecoration(
                border: Border(
                    bottom: BorderSide(width: 1, color: Colors.grey.shade200)
                ),
                color: AppColors.black,
                //borderRadius: BorderRadius.circular(5)
              ),
              child: ListTile(
                tileColor: AppColors.white,
                selectedTileColor: AppColors.white,
                textColor: AppColors.white,
                title: Text("Followers",
                  style: TextStyle(
                    color: AppColors.white,
                  ),
                ),
                trailing: Switch(
                  inactiveTrackColor: Colors.white,
                  value: isFollowers,
                  onChanged: (value) {
                    setState(() {
                      isFollowers = value;
                    });
                  },
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.only(left: 10, right: 10),

              decoration: BoxDecoration(

                border: Border(
                    bottom: BorderSide(width: 1, color: Colors.grey.shade200)
                ),
                color: AppColors.black,
                //borderRadius: BorderRadius.circular(5)
              ),
              child: ListTile(
                title: Text("App Updates",
                  style: TextStyle(
                    color: AppColors.white,
                  ),
                ),
                trailing: Switch(
                  inactiveTrackColor: Colors.white,
                  value: isAppUpdate,
                  onChanged: (value) {
                    setState(() {
                      isAppUpdate = value;
                    });
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
