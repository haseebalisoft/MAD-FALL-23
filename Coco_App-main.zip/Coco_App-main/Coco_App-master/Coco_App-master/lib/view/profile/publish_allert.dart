import 'dart:convert';

import 'package:coco/controller/authController.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../appConst.dart';
import '../Client/bottomNagivation/buttom_nav.dart';
import '../freelancer/bottomNavigationBar/becameFreelanceBottomNavigation.dart';

class PublishAllert extends StatefulWidget {
  const PublishAllert({Key? key}) : super(key: key);

  @override
  State<PublishAllert> createState() => _PublishAllertState();
}

class _PublishAllertState extends State<PublishAllert> {
  bool isPublishAlert = false;
  final msg = TextEditingController();

  bool primaryDataLoaded = false;
  var role = "";

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getPublishAlert();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.black,
          elevation: 0,
          title: Text("Publish Alert",
            style: TextStyle(
              color: Colors.white
            ),
          ),
          leading: IconButton(
            onPressed: ()=>Get.back(),
            icon: Icon(Icons.arrow_back, color: Colors.white,),
          ),
        ),
        backgroundColor: Colors.black,
        body: primaryDataLoaded
          ? SingleChildScrollView(
          padding: EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Publish Alert",
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                      color: Colors.white
                    ),
                  ),
                  Switch(
                    inactiveTrackColor: Colors.white,
                    value: isPublishAlert,
                    onChanged: (value) {
                      setState(() {
                        isPublishAlert = value;
                      });
                    },
                  ),
                ],
              ),
              SizedBox(height: 40,),
              Text("Alert Message",
                style: TextStyle(
                  color: Colors.white
                ),
              ),
              SizedBox(height: 10,),
              TextFormField(
                maxLines: 4,
                style: TextStyle(
                    fontSize: 14,
                    color: AppColors.white
                ),
                controller: msg,
                validator: (String? value) {
                  if (value?.isEmpty ?? true) {
                    return 'Please Enter your message';
                  }
                },
                decoration: InputDecoration(
                  hintText: ('Type message'),
                ),
              ),
              SizedBox(height: 30,),

            ],
          ),
        )
        : Center(
          child: CircularProgressIndicator(color: AppColors.mainColor,),
         ),
        bottomNavigationBar: primaryDataLoaded
          ? Container(
          margin: EdgeInsets.all(20),
          width: double.infinity,
          child: ElevatedButton(
              style: OutlinedButton.styleFrom(
                backgroundColor: AppColors.mainColor,
              ),
              onPressed: ()=>savePublish(),
              child: isLoading?CircularProgressIndicator(color: Colors.white,) : Text(
                'Save',
                style: TextStyle(color: Colors.white, fontSize: 13),
              )),
        )
        : null,
      ),
    ); 
  }

  bool isLoading = false;
  savePublish() async{
    print("isPublishAlert === ${isPublishAlert}");
    setState(() {
      isLoading = true;
    });
    var res = await AuthController.addPubishAlert(msg: msg.text, status: isPublishAlert? "yes":"no");
    if(res.statusCode == 200){
      AlertController.snackbar(context: context, text: "Your publish alert is save.", bg: Colors.green);

      if(role == AppConst.CLIENT_ROLE) {
        Navigator.pushAndRemoveUntil(context,
            MaterialPageRoute(
                builder: (context) =>
                    ClientBottomNavigationBar(
                        pageIndex: 3)), (route) => false);
      }else{

        Navigator.pushAndRemoveUntil(context,
            MaterialPageRoute(
                builder: (context) =>
                    FreelancerAppBottomNavigation(
                        pageIndex: 3)), (route) => false);
      }
    }else{
      AlertController.snackbar(context: context, text: "Something went wrong.", bg: Colors.green);
    }
    setState(() {
      isLoading = false;
    });
  }

  getPublishAlert() async{
    setState(() {
      primaryDataLoaded = false;
    });

    role = await AuthController.getRole();
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var id = _pref.getString("user_id");
    var res = await AuthController.publishAlert(id);

    setState(() {
      primaryDataLoaded = true;
    });

    if(res.statusCode == 200){
      if(jsonDecode(res.body)["data"] != null ){
        setState(() {
          msg.text = jsonDecode(res.body)["data"]["alert_msg"];
          isPublishAlert = jsonDecode(res.body)["data"]["status"] == "yes" ? true : false;

        });
      }
    }

  }
}
