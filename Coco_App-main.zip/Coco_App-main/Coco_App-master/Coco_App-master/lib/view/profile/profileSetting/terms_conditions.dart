import 'package:coco/controller/settingController.dart';
import 'package:coco/main.dart';
import 'package:coco/utility/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:get/get.dart';

import '../../../model/setting/termsConditionModel.dart';


class TermsConditions extends StatefulWidget {
  const TermsConditions({Key? key}) : super(key: key);

  @override
  State<TermsConditions> createState() => _TermsConditionsState();
}

class _TermsConditionsState extends State<TermsConditions> {

  Future<TermsConditionModel>? getTerms;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getTerms = SettingController.getTramsCondition();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.mainColor,
      child: SafeArea(
        child: Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            backgroundColor: Colors.black,
            elevation: 0,
            leading: IconButton(
              onPressed: ()=>Get.back(),
              icon: Icon(Icons.arrow_back, color: Colors.white,),
            ),
            title: Text("Terms & Conditions",
              style: TextStyle(
                color: Colors.white
              ),
            ),
          ),
          body: FutureBuilder<TermsConditionModel>(
            future: getTerms,
            builder: (_, snapshot){
              if(snapshot.connectionState == ConnectionState.waiting){
                return Center(child: CircularProgressIndicator(color: AppColors.mainColor,),);
              }else if(snapshot.hasData){
                return Html(
                  data: "${snapshot.data?.data?.termsConditions}",style: {
                 "body": Style(
                    fontSize: FontSize(18.0),
                   color: AppColors.white
                  ),
                },
                );
              }else{
                return Center(child: Text("Check your internet connection"),);
              }
            },
          )
        ),
      ),
    );
  }
}
