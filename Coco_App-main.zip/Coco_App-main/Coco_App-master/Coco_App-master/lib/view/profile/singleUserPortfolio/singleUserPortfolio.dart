import 'package:coco/controller/postController.dart';
import 'package:coco/model/postModel/PostModel.dart';
import 'package:coco/view/freelancer/uploadPortfolio/PickerCropResultScreen.dart';
import 'package:coco/view/profile/singleUserPortfolio/singleUserPost.dart';
import 'package:coco/viewController/appNetworkImage.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shimmer/shimmer.dart';
import 'package:path/path.dart' as p;
import '../../../model/postModel/singleUserPostModel.dart';
import '../../../viewController/video_player/src_video_player.dart';
import '../../../viewController/video_player/video_thumblin.dart';


class SingleUserPortfolio extends StatefulWidget {
  final String userId;
  const SingleUserPortfolio({required this.userId});

  @override
  State<SingleUserPortfolio> createState() => _SingleUserPortfolioState();
}

class _SingleUserPortfolioState extends State<SingleUserPortfolio> {

  Future<AllPostModel>? getAllPost;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getAllPost = PostController.getSingleUserPortfolio(widget.userId);
  }


  @override
  Widget build(BuildContext context) {
    return FutureBuilder<AllPostModel>(
        future: getAllPost,
        builder: (context, snapshot) {
          if(snapshot.connectionState == ConnectionState.waiting){
            print("this is data === ${snapshot.data?.data?[0]}");
            return Padding(
              padding: const EdgeInsets.all(16.0),
              child: GridView.builder(
                shrinkWrap: true,
                itemCount: 6,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisExtent: 180,
                  mainAxisSpacing: 5,
                  crossAxisSpacing: 5,
                ),
                physics: const NeverScrollableScrollPhysics(),
                itemBuilder: (BuildContext context, int index) {
                  return Shimmer.fromColors(
                      baseColor: Colors.grey.withOpacity(0.2),
                      highlightColor: Colors.grey.withOpacity(0.1),
                      child:  ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Container(height: 250, width: 120, color: Colors.white,),
                      )
                  );
                },
              ),
            );
          }else if(snapshot.hasData){
            return snapshot.data?.data?.length!=0 && snapshot.data?.data?.length!=null
                ? Padding(
              padding: const EdgeInsets.all(16.0),
              child: GridView.builder(
                shrinkWrap: true,
                itemCount: snapshot.data?.data?.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisExtent: 180,
                  mainAxisSpacing: 5,
                  crossAxisSpacing: 5,
                ),
                physics: const NeverScrollableScrollPhysics(),
                itemBuilder: (BuildContext context, int index) {

                  return p.extension(snapshot.data!.data![index]!.image![0].image.toString()) != ".mp4"
                      ? buildSinglePortfolio(
                    //onClick: ()=>Get.to(Users_Posts()),
                      onClick: ()=>Get.to(SingleUserPost(
                          userId: snapshot.data!.data![index]!.userData![0]!.id.toString(),
                          userName: snapshot.data!.data![index]!.post!.userId.toString(),
                          userImage: snapshot.data!.data![index]!.userData![0]!.profileImage ?? "")),
                      imagePath: "${snapshot.data!.data![index]!.image!.isEmpty
                          ? "https://upload.wikimedia.org/wikipedia/commons/thumb/6/65/No-Image-Placeholder.svg/1665px-No-Image-Placeholder.svg.png"
                          : snapshot.data!.data![index]!.image![0]!.image}"
                  ): InkWell(
                      onTap: ()=>Get.to(SingleUserPost(
                          userId: snapshot.data!.data![index]!.userData![0]!.id.toString(),
                          userName: snapshot.data!.data![index]!.post!.userId.toString(),
                          userImage: snapshot.data!.data![index]!.userData![0]!.profileImage ?? "")),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: VideoThumbnail(snapshot.data!.data![index]!.image![0]!.image.toString()),
                        // child: Center(
                        //     child: VTImageView(
                        //       videoUrl:
                        //       "https://flutter.github.io/assets-for-api-docs/assets/videos/butterfly.mp4",
                        //       width: 200.0,
                        //       height: 200.0,
                        //       errorBuilder: (context, error, stack) {
                        //         return Container(
                        //           width: 200.0,
                        //           height: 200.0,
                        //           color: Colors.blue,
                        //           child: Center(
                        //             child: Text("Image Loading Error"),
                        //           ),
                        //         );
                        //       },
                        //       assetPlaceHolder: 'asset/image/logo.png',
                        //     )),
                      )
                  );
                  //child: SrcVideoPlayerWidget(videoPath: snapshot.data!.data![index]!.image![0].image.toString(), fullAspectRatio: true,)));
                },
              ),
            )
                : Padding(
                  padding: const EdgeInsets.only(top: 60.0),
                  child: Center(
                    child: Text("No Post Found",
                      style: TextStyle(
                        color: Colors.white
                      ),
                    ),
                  ),
                ) ;
          }else{
            return const Center(child: Text("Check your internet."),);
          }
        }
    );
  }

  InkWell buildSinglePortfolio({
    required VoidCallback onClick,
    required String imagePath,
  }) {
    return InkWell(
      onTap: onClick,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: AppNetworkImage(src: imagePath),
      ),
    );
  }




}
