import 'package:coco/controller/authController.dart';
import 'package:coco/controller/postController.dart';
import 'package:coco/model/postModel/PostModel.dart';
import 'package:path/path.dart' as p;
import 'package:coco/utility/appAssets.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:shimmer/shimmer.dart';

import '../../Posts/singlePost.dart';


class SingleUserPost extends StatefulWidget {
  final String userName;
  final String userId;
  final String userImage;
  const SingleUserPost({super.key, required this.userName, required this.userImage, required this.userId});

  @override
  State<SingleUserPost> createState() => _SingleUserPostState();
}

class _SingleUserPostState extends State<SingleUserPost> {
  bool isPressed = false;

  Future<AllPostModel>? getAllPost;

  var name, profile;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getAllPost = PostController.getSingleUserPortfolio(widget.userId);
    getUserInfo();
  }

  getUserInfo()async{
    var userInfo = await AuthController.getUserInfo();
    name = userInfo?.data?.name;
    profile = userInfo?.data?.profileImage;
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Container(
      color: Colors.black,
      child: SafeArea(
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.black,
            elevation: 0,
            title: Text("Post"),
            actions: [
              // IconButton(onPressed: (){}, icon: Icon(Icons.more_horiz, color: Colors.white,))
            ],
          ),
          body: Container(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(color: Colors.black),
            child: FutureBuilder<AllPostModel>(
                future: getAllPost,
                builder: (context, snapshot) {
                  if(snapshot.connectionState == ConnectionState.waiting){
                    return ListView.builder(
                      itemCount: 5,
                      itemBuilder: (_, index){
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 20),
                          child: Shimmer.fromColors(
                            baseColor: Colors.white.withOpacity(0.1),
                            highlightColor: Colors.white.withOpacity(0.1),
                            child: Container(
                              width: size.width,
                              height: 450,
                              color: Colors.white,
                            ),
                          ),
                        );
                      },
                    );
                  }else if(snapshot.hasData){
                    return ListView.builder(
                      itemCount: snapshot.data!.data!.length,
                      itemBuilder: (_, index){
                        return SinglePost(
                          userName: widget.userName ?? "",
                          userImage: widget.userImage ?? '',
                          singlePost: snapshot.data!.data![index],
                          isLiked: snapshot.data!.data![index]!.isLiked,
                          isFav: snapshot.data!.data![index]!.isFav,
                        );
                      },
                    );
                  }else{
                    return Center(
                      child: Text("No post found"),
                    );
                  }
                }
            ),
          ),
        ),
      ),
    );
  }
}
