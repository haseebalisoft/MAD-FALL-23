
import 'package:cached_network_image/cached_network_image.dart';
import 'package:coco/controller/authController.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/view/auth/sign_in.dart';
import 'package:coco/viewController/appNetworkImage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:get/get.dart';
import 'package:onboarding/onboarding.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';

import '../../utility/appAssets.dart';
import '../flashScreen/Splash_screen.dart';


class OnBoarding extends StatefulWidget {
  const OnBoarding({Key? key}) : super(key: key);

  @override
  State<OnBoarding> createState() => _OnBoardingState();
}

class _OnBoardingState extends State<OnBoarding> {
  late Material materialButton;
  late int index;
  final onboardingPagesList = [
  ];
  List<PageModel> pageModel = [];

  late ScrollController _controller;
  late double _startSwipeX;

  getOnBoardingFuture ()async{

    var res = await AuthController.getOnBoarding();
    for(var i in res!.tutorial!){
      setState(() {
        pageModel.add(buildPageModel(context: context, title: i!.title!, image: i!.image!));
      });
    }

  }

  @override
  void initState() {
    super.initState();
    index = 0;
    _controller = ScrollController();
    _controller.addListener(_handleScroll);
    getOnBoardingFuture();

  }

  void _handleScroll() {
    // Your logic for handling the scroll
    // Example: Detecting right-to-left swipe
    if (_controller.position.userScrollDirection == ScrollDirection.forward &&
        _controller.position.pixels > _startSwipeX + 50) {
      // Swipe detected, you can perform any action here
      print("Right-to-Left Swipe Detected");
    }
  }

  getOnBoardingInSharedPre()async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    _pref.setString("onboarding", "1");
    Get.offAll(SignInPage());
  }

  InkWell _skipButton({void Function(int)? setIndex}) {
    return InkWell(
      borderRadius: defaultSkipButtonBorderRadius,
      onTap: () {
        getOnBoardingInSharedPre();
      },
      child:  Container(
        decoration: BoxDecoration(
          border: Border.all(width: 2,color: AppColors.mainColor),
          borderRadius: BorderRadius.circular(10)
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12.0,vertical: 10),
          child: Text(
            'Skip',
            style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w300,
                color: Colors.white
            ),
          ),
        ),
      ),
    );
  }

  void _onHorizontalDragStart(DragStartDetails details) {
    _startSwipeX = details.globalPosition.dx;
    print("Start swipe $_startSwipeX");
  }

  void _onHorizontalDragUpdate(DragUpdateDetails details) {
    // Optional: You can use this callback to update UI during the drag
    print("Update swipe ${details.globalPosition.dx}");
  }

  void _onHorizontalDragEnd(DragEndDetails details) {
    // Optional: You can use this callback to perform actions when the drag ends
    print("End swipe ${details.velocity.pixelsPerSecond.dx}");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: pageModel.isEmpty
          ? Center(child: CircularProgressIndicator(color: Colors.grey,))
          : GestureDetector(
        onHorizontalDragUpdate: (DragUpdateDetails details) {
          print('Delta: ${details.primaryDelta}');
          print('Index before setState: $index');

          if (details.primaryDelta! > 0) {
            print('Moved from left to right');
            setState(() {
              if (index > 0) index = index - 1;
            });
          } else if (details.primaryDelta! < 0) {
            setState(() {
              if (index < pageModel.length - 1) {
                index = index + 1;
              }
            });
          }

          print('Index after setState: $index');
        },
            child: Onboarding(

        pages: pageModel,
        onPageChange: (int pageIndex) {
            index = pageIndex;
        },
        startPageIndex: index,
        footerBuilder: (context, dragDistance, pagesLength, setIndex) {
            return DecoratedBox(
              position: DecorationPosition.background,
              decoration: BoxDecoration(
                color: AppColors.black,
                border: Border.all(
                  width: 0.0,
                  color: AppColors.black,
                ),
              ),
              child: ColoredBox(
                color: AppColors.black,
                child: Padding(
                  padding: const EdgeInsets.only(left: 45.0, top: 20, bottom: 30, right: 45),
                  child:  index == pagesLength - 1
                      ?  InkWell(
                    onTap: ()=>getOnBoardingInSharedPre(),
                    child: Container(
                      width: double.infinity,
                      height: 50,
                      margin: EdgeInsets.only(left: 50, right: 50),
                      decoration: BoxDecoration(
                          color: AppColors.mainColor,
                          borderRadius: BorderRadius.circular(10)
                      ),
                      child: const Center(
                        child: Text("Continue",
                          style: TextStyle(
                              fontSize: 17,
                              color: Colors.white
                          ),
                        ),
                      ),
                    ),
                  )
                      : Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SizedBox(width: 50,),
                      CustomIndicator(
                        netDragPercent: dragDistance,
                        pagesLength: pagesLength,
                        indicator: Indicator(
                          activeIndicator: ActiveIndicator(
                            color: AppColors.white,
                          ),
                          indicatorDesign: IndicatorDesign.polygon(
                            polygonDesign: PolygonDesign(
                              polygon: DesignType.polygon_circle,
                            ),
                          ),
                        ),
                      ),

                      index != pagesLength - 1
                          ? _skipButton(setIndex: setIndex)
                          : Center(),

                    ],
                  ),
                ),
              ),
            );
        },
      ),
          ),
    );
  }


PageModel buildPageModel({
    required BuildContext context,
    required String title,
    required String image,
  }) {
    return PageModel(
      widget: DecoratedBox(
        decoration: BoxDecoration(
          color: AppColors.white,
          border: Border.all(
            width: 0.0,
            color: AppColors.black,
          ),
        ),
        child: Container(
            padding: EdgeInsets.only(top: 20,left: 20, right: 20),
            decoration: BoxDecoration(
                color: Colors.black,
                image: DecorationImage(
                    image: AssetImage(image),
                    fit: BoxFit.cover
                )
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children:  [
                SizedBox(
                  width:300,
                  child: Column(
                    children: [
                      SizedBox(height: 7.h,),
                      Center(child: Html(
                        data: title,
                        style: {
                          "*":Style(
                              fontSize: FontSize.xLarge,
                              textAlign: TextAlign.center
                          ),
                          "p": Style(
                              color: Colors.white
                          ),
                          "b": Style(
                              color: Colors.white
                          ),
                          "h1,": Style(
                              color: Colors.white
                          ),
                          "h2": Style(
                              color: Colors.white
                          ),
                          "h3": Style(
                              color: Colors.white
                          ),
                          "h4": Style(
                              color: Colors.white
                          ),
                          "h5": Style(
                              color: Colors.white
                          ),
                          "h6": Style(
                              color: Colors.white
                          ),
                        },
                      ),),
                    ],
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Center(
                    child: CachedNetworkImage(
                      imageUrl: "$image",
                      height: MediaQuery.of(context).size.height * 0.55,
                      progressIndicatorBuilder: (context, url, downloadProgress) =>
                          SizedBox(height: 30, width: 30, child: Center(child: CircularProgressIndicator(color: AppColors.white,),)),
                      errorWidget: (context, url, error) => Image.asset(AssetUtils.logoPng),
                    )
                )
              ],
            )
        ),
      ),
    );
  }

}
