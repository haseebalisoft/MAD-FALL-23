import 'package:flutter/material.dart';

class Registration_navbar extends StatefulWidget {
   Registration_navbar({super.key, required this.page_button, required this.onclick});

  final Widget page_button;
   final VoidCallback onclick;

  @override
  State<Registration_navbar> createState() => _Registration_navbarState();
}

class _Registration_navbarState extends State<Registration_navbar> {

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
        bottomNavigationBar:Container(
          color: Colors.blue,
          width: 500,
          height: 100,
        )
    );
  }
}
