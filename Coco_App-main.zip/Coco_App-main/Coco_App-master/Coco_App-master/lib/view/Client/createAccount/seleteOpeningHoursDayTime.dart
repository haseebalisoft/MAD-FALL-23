import 'dart:convert';

import 'package:coco/controller/authController.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:coco/viewController/showAllert.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../helper/helperFunctions.dart';
import 'editDayTime.dart';

class SelectOpeningHours extends StatefulWidget {
  final List dayTime;
   final String selectedDay;
  const SelectOpeningHours({Key? key, required this.dayTime, required  this.selectedDay}) : super(key: key);

  @override
  State<SelectOpeningHours> createState() => _SelectOpeningHoursState();
}

class _SelectOpeningHoursState extends State<SelectOpeningHours> {

  // String formattedDate = DateFormat('hh:mm').format(DateTime.now());



  final openCloseKey = GlobalKey<FormState>();
  List _selectedDay = [];

  List listDayTime = ["new"];
  bool isOpen = false;
  bool isClose = false;
  var selectedOption;


  bool isLoading = false;
  List<TextEditingController> openTime = [TextEditingController()];
  List<TextEditingController> closeTime = [TextEditingController()];
  List<FocusNode> openTimeFocusNodes = [FocusNode()];


  var selectedDay;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    selectedDay = widget.selectedDay;

    // openTime[0].text = formattedDate;
    // closeTime[0].text = formattedDate;

    print("formattedDate === ${widget.selectedDay}");
    setState(() {
      _selectedDay.add(widget.selectedDay);
    });
    print(widget.dayTime);

    String time = "";
    for(var i=0; i<widget.dayTime.length; i++){
      if(widget.dayTime[i]["day"] == widget.selectedDay){
        print(widget.dayTime[i]["open"]);
        listDayTime = widget.dayTime[i]["open"];
      }
    }

    print("listDayTime === $listDayTime");
    listDayTime.removeWhere((element) => element.isEmpty);

    if(listDayTime.isNotEmpty && listDayTime[0] != "Close" && listDayTime[0] != "00") {
      openTime = [];
      closeTime = [];
      openTimeFocusNodes = [];

      for (var i = 0; i < listDayTime.length; i++) {
        try{
          openTime.add(TextEditingController(text: listDayTime[i].split("-")[0]));
          closeTime.add(TextEditingController(text: listDayTime[i].split("-")[1]));
          openTimeFocusNodes.add(FocusNode());
        }
        catch(e) {
          print(e);
        }

      }

    }
    else if(listDayTime.isNotEmpty && listDayTime[0] == "Close"){
      setState(() {
        isOpen = false;
        isClose = true;
      });
    }
    else if(listDayTime.isNotEmpty && listDayTime[0] == "00"){
      setState(() {
        isOpen = true;
        isClose = false;
      });
    }


    // listDayTime = time.split(" ");
    print("listDayTime === $listDayTime");
    print("openTime === $openTime");
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      child: SafeArea(
        child: Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            backgroundColor: Colors.black,
              automaticallyImplyLeading: false,
            elevation: 0,
            actions: [
              IconButton(onPressed: (){
                _selectedDay.clear();
                openTime.clear();
                closeTime.clear();
                selectedDay = "";
                //widget!.selectedDay = "";
                Get.to(EditDayTime(), transition: Transition.upToDown);
                },
               icon: Icon(Icons.close, size: 30, color: Colors.white,),),
              SizedBox(width: 20,)
            ],
          ),
          body: Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
              padding: EdgeInsets.only(left: 30, right: 30, bottom: 20),
              child: ListView(
                // mainAxisAlignment: MainAxisAlignment.start,
                // crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Select opening hours",
                    style: TextStyle(
                      fontSize: 18,
                      color: AppColors.mainColor,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 40,),
                  SizedBox(
                    height: 40,
                    child: ListView.builder(
                        itemCount: widget.dayTime.length,
                        shrinkWrap: true,
                        scrollDirection: Axis.horizontal,
                        itemBuilder: (_, index){

                          return GestureDetector(
                            onTap: (){
                             // widget.selectedDay = "";
                              setState((){
                                selectedDay = "";
                                if(_selectedDay.contains(widget.dayTime[index]["day"].toString())){
                                  _selectedDay.remove(widget.dayTime[index]["day"].toString());
                                }else{
                                  _selectedDay.add(widget.dayTime[index]["day"].toString());
                                }

                               // _addValueIntoMap();
                              });
                            },
                            child: Container(
                              height: 40,
                              width: 40,
                              decoration: BoxDecoration(
                                  color: selectedDay == widget.dayTime[index]["day"].toString() ? AppColors.mainColor : _selectedDay.contains(widget.dayTime[index]["day"].toString()) ? AppColors.mainColor :Color(0xffF5F5F5),
                                  borderRadius: BorderRadius.circular(100)
                              ),
                              margin: EdgeInsets.only(right: 10),
                              child: Center(
                                child: Text("${widget.dayTime[index]["day"].toString()[0]}",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      color: selectedDay == widget.dayTime[index]["day"].toString() ? AppColors.white :_selectedDay.contains(widget.dayTime[index]["day"].toString()) ? AppColors.white :  Colors.black
                                  ),
                                ),
                              ),
                            ),
                          );
                        }),
                  ),
                  SizedBox(height: 50,),
                  checkOpenOrClose(setState),
                  SizedBox(height: 20,),

                 isOpen || isClose ? Center() : Form(
                    key: openCloseKey,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        for(var i=0; i<listDayTime.length;i++)
                          Container(
                            margin: EdgeInsets.only(bottom: 10),
                            child: Row(
                              children: [
                                SizedBox(
                                  height: 100,
                                  width: MediaQuery.of(context).size.width*.30,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text("Opening time",
                                        style: TextStyle(
                                            fontWeight:FontWeight.w400,
                                            color: Colors.white,
                                            fontSize: 10
                                        ),
                                      ),
                                      SizedBox(height: 8,),
                                      Expanded(
                                        child: TextFormField(
                                          focusNode: openTimeFocusNodes[i],
                                          maxLength: 5,
                                          controller: openTime[i],
                                          inputFormatters: [DateTimeInputFormatter()],
                                          keyboardType: TextInputType.datetime,
                                         // onChanged: (v)=>_addValueIntoMap(),
                                          decoration: InputDecoration(
                                              filled: true,
                                              fillColor: AppColors.formColor,
                                              hintText: "--:--",
                                              enabledBorder: OutlineInputBorder(
                                                  borderRadius: BorderRadius.circular(5),
                                                  borderSide: BorderSide(width: 1,color: Colors.grey.shade400)
                                              ),
                                              border: OutlineInputBorder(
                                                  borderRadius: BorderRadius.circular(5),
                                                  borderSide: BorderSide(width: 1,color: Colors.grey.shade400)
                                              ),
                                              focusedBorder: OutlineInputBorder(
                                                  borderRadius: BorderRadius.circular(5),
                                                  borderSide: BorderSide(width: 1,color: Colors.grey.shade400)
                                              )
                                          ),
                                          validator: (v){
                                            print(v);
                                            // if(v!.isEmpty){
                                            //   return "";
                                            // }else{
                                            //   return null;
                                            // }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(width: 20,),
                                SizedBox(
                                  height: 100,
                                  width: MediaQuery.of(context).size.width*.30,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text("Closing time",
                                        style: TextStyle(
                                            fontWeight:FontWeight.w400,
                                            color: Colors.white,
                                            fontSize: 10
                                        ),
                                      ),
                                      SizedBox(height: 8,),
                                      Expanded(
                                        child: TextFormField(
                                          maxLength: 5,
                                          controller: closeTime[i],
                                          keyboardType: TextInputType.datetime,
                                          inputFormatters: [DateTimeInputFormatter()],
                                          decoration: InputDecoration(
                                              filled: true,
                                              fillColor: Colors.white,
                                              hintText: "--:--",
                                              enabledBorder: OutlineInputBorder(
                                                  borderRadius: BorderRadius.circular(5),
                                                  borderSide: BorderSide(width: 1,color: Colors.grey.shade400)
                                              ),
                                              border: OutlineInputBorder(
                                                  borderRadius: BorderRadius.circular(5),
                                                  borderSide: BorderSide(width: 1,color: Colors.grey.shade400)
                                              ),
                                              focusedBorder: OutlineInputBorder(
                                                  borderRadius: BorderRadius.circular(5),
                                                  borderSide: BorderSide(width: 1,color: Colors.grey.shade400)
                                              )
                                          ),
                                          validator: (v){
                                            if(v!.isEmpty){
                                              return "";
                                            }else{
                                              return null;
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(width: 15,),
                                IconButton(
                                  onPressed: (){
                                    setState((){
                                      // if(listDayTime.length > 1){
                                        listDayTime.removeAt(i);
                                        closeTime.removeAt(i);
                                        openTime.removeAt(i);
                                      // }

                                    });
                                  },
                                  icon: Icon(Icons.close, color: Colors.white,),
                                )
                              ],
                            ),
                          ),
                        TextButton(onPressed: (){
                          setState((){
                            listDayTime.add("new");
                            closeTime.add(TextEditingController());
                            openTime.add(TextEditingController());

                            // Add new FocusNode instances
                            openTimeFocusNodes.add(FocusNode());

                            // Set focus to the newly added opening time field
                            FocusScope.of(context).requestFocus(openTimeFocusNodes.last);

                          });
                        }, child: Text("+ Add hours",
                          style: TextStyle(
                              color: AppColors.mainColor
                          ),
                        ))
                      ],
                    ),
                  )

                ],
              )
          ),
          bottomNavigationBar:  InkWell(
            //onTap: ()=>addHours(),
            onTap: ()=>_addValueIntoMap(),
            child: Container(
              margin: EdgeInsets.only(left: 30,right: 30,bottom: 20),
              width: double.infinity,
              height: 46,
              decoration: BoxDecoration(
                color: AppColors.mainColor,
                borderRadius: BorderRadius.circular(5),

              ),
              child: Center(child: isLoading? CircularProgressIndicator(color: Colors.white,) : Text('Save',style: TextStyle(color: AppColors.white),),),
            ),
          ),
        ),
      ),
    );
  }


  Row checkOpenOrClose(StateSetter setState) {
    return Row(
      children: [
        InkWell(
          onTap: (){
            setState((){
              isOpen = !isOpen;
              isClose = false;
            });
          },
          child: Row(
            children: [
              Container(
                width: 25, height: 25,
                decoration: BoxDecoration(
                  color: isOpen? AppColors.mainColor : Colors.white,
                  border: Border.all(width: 1,color: isOpen? AppColors.mainColor : Color(0xff979797)),
                  borderRadius: BorderRadius.circular(3),
                ),
                child: isOpen? Icon(Icons.check, color: isOpen? AppColors.white : Colors.black, size: 20,) :Center(),
              ),
              SizedBox(width: 10,),
              Text("Open 24 hours",
                style: TextStyle(
                  color: Colors.white
                ),
              )
            ],
          ),
        ),
        SizedBox(width: 30,),
        InkWell(
          onTap: (){
            setState((){
              isOpen = false;
              isClose = !isClose;
            });
          },
          child: Row(
            children: [
              Container(
                width: 25, height: 25,
                decoration: BoxDecoration(
                  color:isClose? AppColors.mainColor : Colors.white,
                  border: Border.all(width: 1,color:isClose? AppColors.mainColor : Color(0xff979797)),
                  borderRadius: BorderRadius.circular(3),
                ),
                child: isClose? Icon(Icons.check, color: isClose? AppColors.white :Colors.black, size: 20,):Center(),
              ),
              SizedBox(width: 10,),
              Text("Close",
                style: TextStyle(
                    color: Colors.white
                ),
              )
            ],
          ),
        )
      ],
    );
  }


  //// once we click on the day, we store the data into a map 
  var data = [];
  void _addValueIntoMap() async{

    print(isOpen);
    print(isClose);

    if((isOpen && isClose) || (!isOpen && !isClose)){



      if(openTime[0].text.isEmpty || closeTime[0].text.isEmpty){
        AlertController.snackbar(context: context,
            text: "Please fill all the field",
            bg: Colors.red);
        return;
      }

      if((openTime[0].text.isEmpty || closeTime[0].text.isEmpty) && openTime.length == 1 && closeTime.length == 1){
        AlertController.snackbar(context: context,
            text: "Please fill all the field",
            bg: Colors.red);
        return;
      }

      openTime.removeWhere((element) => element.text.isEmpty);
      closeTime.removeWhere((element) => element.text.isEmpty);
      print("openTime ===== $openTime");
      print("closeTime ===== $closeTime");

      if (openTime.length != closeTime.length) {
        AlertController.snackbar(context: context,
            text: "Please fill all the field",
            bg: Colors.red);
        return;
      }

      for (var i = 0; i < openTime.length; i++) {
        String openingTime = openTime[i].text;
        String closingTime = closeTime[i].text;
        print("openingTime ===== $openingTime");
        print("closingTime ===== $closingTime");

        if (!HelperFunction.isTimeValid(openingTime) ||
            !HelperFunction.isTimeValid(closingTime)) {
          AlertController.snackbar(
            context: context,
            text: "Invalid time format",
            bg: Colors.red,
          );
          return;
        }

        if (!HelperFunction.isOpeningBeforeClosing(openingTime, closingTime)) {
          AlertController.snackbar(
            context: context,
            text: "Opening time should be before closing time",
            bg: Colors.red,
          );
          return;
        }
      }
    }


    setState(() {
      isLoading = true;
      //getBusinessHoursFuture =  AuthController.getBusinessHours();
    });


    data.clear();
    ///////// first initial openTimeList arry to store all openTimteTextEditingController data/////
    List openTimeList = [];
    ///////// first initial CloseTimeList arry to store all closeTimteTextEditingController data/////
    List closeTimeList = [];
    ///////// initial conbinedList to combined this openTimeList into closeTimeList/////////////////
    List<String> combinedList = [];

    for(var i =0; i<openTime!.length; i++){
      openTimeList.add(openTime[i].text);
    }
    for(var i =0; i<closeTime!.length; i++){
      closeTimeList.add(closeTime[i].text);
    }

    for(var i=0; i<closeTimeList.length; i++){
      combinedList.add("${openTimeList[i] + "-" + closeTimeList[i]}");
    }

    if(isClose){
      for(var i=0; i<_selectedDay.length; i++){
        data.add({
          "day": "${_selectedDay[i]}",
          "open": ["Close"]
        });
      }
    }else if(isOpen){
      for(var i=0; i<_selectedDay.length; i++){
        data.add({
          "day": "${_selectedDay[i]}",
          "open": ["00"]
        });
      }
    }else{
      for(var i=0; i<_selectedDay.length; i++){
        data.add({
          "day": "${_selectedDay[i]}",
          "open": combinedList
        });
      }
    }
    storeHours(data);

    print("data ===== ${jsonEncode(data)}");
  }

  void storeHours(data) async{

    // ===== now post on api
    ////////////// here first i check if user  select isClose, then i return empty list, else i return combinedList
    var res = await AuthController.addBusinessHours(data: data);
    if(res.statusCode == 200){
      setState(() {
        isLoading = false;
        //getBusinessHoursFuture =  AuthController.getBusinessHours();
      });
      ///// once api call success, that time i clear our hole state//////
      ////// & then redirect to the edit day time pages ////
      Navigator.pop(context, true);
      //Navigator.push(context, MaterialPageRoute(builder: (context)=>EditDayTime()));
      AlertController.snackbar(context: context, text: "Opening & Closing hour set.", bg: Colors.green);

    }
    print("res ===== ${res.body}");
    print("res ===== ${res.statusCode}");
    setState(() {
      isLoading = false;
      //getBusinessHoursFuture =  AuthController.getBusinessHours();
    });
  }

}


class DateTimeInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    // Adjust the format to your needs
    String formattedValue = newValue.text;

    if (formattedValue.length == 3 && oldValue.text.length == 4) {
      // Handle backspace when the length is reduced from 4 to 3
      formattedValue = formattedValue.substring(0, 2);
    } else if (formattedValue.length == 2) {
      formattedValue += ':';
    } else if (formattedValue.length == 4) {
      formattedValue = formattedValue.substring(0, 5);
    }

    return TextEditingValue(
      text: formattedValue,
      selection: TextSelection.collapsed(offset: formattedValue.length),
    );
  }
}

// class DateTimeInputFormatter extends TextInputFormatter {
//   @override
//   TextEditingValue formatEditUpdate(
//       TextEditingValue oldValue, TextEditingValue newValue) {
//     // Adjust the format to your needs
//     String formattedValue = newValue.text;
//
//     print(formattedValue);
//     if (formattedValue.length == 2) {
//       formattedValue += ':';
//     } else if (formattedValue.length == 4) {
//       formattedValue = formattedValue.substring(0, 5);
//     }
//
//     return TextEditingValue(
//       text: formattedValue,
//       selection: TextSelection.collapsed(offset: formattedValue.length),
//     );
//   }
// }
