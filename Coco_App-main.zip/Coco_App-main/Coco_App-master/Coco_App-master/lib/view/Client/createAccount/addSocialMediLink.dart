import 'package:coco/utility/colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';


class ClientAddSocialMidiaLink extends StatefulWidget {
  final String listType;
  final String ? value;
  const ClientAddSocialMidiaLink({Key? key, required this.listType, this.value}) : super(key: key);

  @override
  State<ClientAddSocialMidiaLink> createState() => _ClientAddSocialMidiaLinkState();
}

class _ClientAddSocialMidiaLinkState extends State<ClientAddSocialMidiaLink> {
  TextEditingController _socialController = TextEditingController();


  final GlobalKey<FormState> _Social = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    _socialController.text= 'https://';

    print('from social ======= ${widget.value}');
    return Container(
      color: AppColors.black,
      child: SafeArea(
        child: Scaffold(
          backgroundColor: AppColors.black,
          appBar: AppBar(

            leading: IconButton(
              onPressed: ()=>Get.back(),
              icon: Icon(Icons.arrow_back, color: AppColors.white,),
            ),
            title: Text("${widget.listType}",
              style: TextStyle(
                color: AppColors.mainColor,
                fontSize: 15,
                fontFamily: 'Poppins-Bold'
              ),
            ),
            backgroundColor: AppColors.black,
            elevation: 0,
          ),
          body: SingleChildScrollView(
            padding: EdgeInsets.all(20),
            child: Form(
              key: _Social,
              child: Column(
                children: [
                  TextFormField(
                    style: TextStyle(
                      color: AppColors.white
                    ),
                    controller: _socialController,
                    onChanged: (value){
                      _socialController.value = TextEditingValue(
                        text: value.toLowerCase(),
                        selection: _socialController.selection
                      );
                    },
                    validator: (String? value) {
                      if (value?.isEmpty ?? true) {
                        return 'Please Enter your ${widget.listType} link';
                      }
                    },
                    decoration: InputDecoration(
                      hintText: "https://${widget.listType}.com"
                    ),
                  ),


                ],
              ),
            ),
          ),
          bottomNavigationBar:  InkWell(
            onTap: (){
              if (_Social.currentState!.validate()) {
                Navigator.pop(context, {
                  "key": "${widget.listType}",
                  "value":_socialController.text,
                });
              }
            },
            child: Container(
              margin: EdgeInsets.only(left: 30,right: 30,bottom: 20),
              width: double.infinity,
              height: 46,
             decoration: BoxDecoration(
               color: AppColors.mainColor,
               borderRadius: BorderRadius.circular(5),

             ),
              child: Center(child: Text('save',style: TextStyle(color: AppColors.white),),),
            ),
          ),

        ),
      ),
    );
  }


  // ///TODO: need to work here , api change need
  // bool isLoading = false;
  // void _createFreelancerProfileCreateStepTow() async{
  //   setState(() =>isLoading = true);
  //   var res = await AuthController.freelacnerProfileStepThree(
  //       facebook: facebook,
  //   );
  //   if(res.statusCode == 200){
  //     var userInfo = AuthController.getUserInfo();
  //     AlertController.snackbar(context: context, text: "Profile Create Complete.", bg: Colors.green);
  //     Get.to(Freelancer_profile_info_3());
  //   }else{
  //     AlertController.snackbar(context: context, text: "Something went wrong", bg: Colors.red);
  //   }
  //
  //   setState(() =>isLoading = false);
  // }
}
