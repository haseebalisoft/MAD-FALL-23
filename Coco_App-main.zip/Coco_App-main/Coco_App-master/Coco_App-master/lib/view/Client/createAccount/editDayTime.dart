import 'dart:convert';

import 'package:coco/appJson.dart';
import 'package:coco/controller/authController.dart';
import 'package:coco/model/authModel/businessHoursModel.dart';
import 'package:coco/model/authModel/userInfoModel.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/view/Client/createAccount/seleteOpeningHoursDayTime.dart';
import 'package:coco/view/freelancer/profile/UserEditProfile.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

import '../../client/createAccount/profile_info_1.dart';
import '../bottomNagivation/buttom_nav.dart';
class EditDayTime extends StatefulWidget {
  final dynamic openTime;
  final String? from;
  final String? display_name;
  final String? description;
  final String? country;
  final List<String>? selectBusinessType;
  const EditDayTime({Key? key,  this.openTime, this.display_name, this.description, this.country, this.selectBusinessType, this.from}) : super(key: key);

  @override
  State<EditDayTime> createState() => _EditDayTimeState();
}

class _EditDayTimeState extends State<EditDayTime> {
  final openCloseKey = GlobalKey<FormState>();
  final openHours = TextEditingController();
  final closeHours = TextEditingController();

  List<Datum> hoursList = [];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getBusinessHoursFuture();
  }
  UserInformation? userInfo;
  Future<BusinessHoursModel>? getBusinessHoursFuture()async{
    return AuthController.getBusinessHours();
  }
  List<String> timeComponents = [];
  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.black,
      child: SafeArea(
        child: Scaffold(
          backgroundColor: AppColors.black,
          appBar: AppBar(
            backgroundColor: AppColors.black,
            elevation: 0,
            leading: IconButton(
              onPressed: ()=>widget.from == "edit" ? Get.to(UserEditProfile()):goToProfile1(context),
              icon: Icon(
                Icons.arrow_back,
                color: Colors.white,
              ),
            ),
            title: Text("Edit day & time",
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: Colors.white
              ),
            ),
          ),
          body: Padding(
            padding: EdgeInsets.all(30),
            child: FutureBuilder<BusinessHoursModel>(
              future: getBusinessHoursFuture(),
              builder: (context, snapshot) {
                if(snapshot.connectionState == ConnectionState.waiting){
                    return Center();
                }else if(snapshot.hasData){
                  return Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Select opening hours",
                        style: TextStyle(
                          fontSize: 18,
                          color: AppColors.mainColor,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: 20),
                      Expanded(
                        child: ListView.builder(
                            itemCount: AppJson.dayTimeList.length,
                            itemBuilder: (_, index){
                              var data = AppJson.dayTimeList[index];
                              print(data);
                              print(data["day"]);
                              timeComponents = [];
                              for(var i =0; i< snapshot.data!.data!.length; i++){
                                if(snapshot.data!.data![i]!.day == data["day"]){
                                  timeComponents = snapshot.data!.data![i].open!.replaceAll('[', '').replaceAll(']', '').replaceAll(',', '').split(' ');
                                  print("hoursList === ${timeComponents}");
                                  print(timeComponents.length);
                                  data["open"] = timeComponents;
                                }
                              }



                              return ListTile(
                                contentPadding: EdgeInsets.only(top: 5, bottom: 5),
                                leading: Text("${data["day"]}",
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    fontSize: 15,
                                    color: Colors.white
                                  ),
                                ),
                                title: timeComponents.isNotEmpty ? SizedBox(
                                  width: MediaQuery.of(context).size.width,
                                  child: ListView.builder(
                                      physics: const NeverScrollableScrollPhysics(),
                                      shrinkWrap: true,
                                      itemCount: timeComponents?.length,
                                      itemBuilder: (_,index2){
                                        return Align(
                                            alignment: Alignment.bottomRight,
                                            child:  timeComponents[index2] == "Close"
                                            ? Text("Close",
                                           textAlign: TextAlign.center,
                                           style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.red,
                                            fontWeight: FontWeight.w600
                                          ),
                                        )
                                            :  timeComponents[index2] == "00"
                                                ? SizedBox(
                                              //  width: MediaQuery.of(context).size.width*.30,
                                              child: Text("Open 24 Hours",
                                                style: TextStyle(
                                                    fontSize: 14,
                                                    color: AppColors.mainColor,
                                                    fontWeight: FontWeight.w600
                                                ),
                                              ),
                                            )
                                                :SizedBox(
                                            //  width: MediaQuery.of(context).size.width*.30,
                                              child: Text(timeComponents[index2],
                                                style: TextStyle(
                                                    fontSize: 14,
                                                    color: Colors.white,
                                                    fontWeight: FontWeight.w600
                                                ),
                                              ),
                                            ));
                                      }
                                  ),
                                ):Center(),
                                trailing: InkWell(
                                  onTap: ()=>goToSelectedOpeningHoursPage(context, data),
                                  child: Icon(Icons.edit, color: AppColors.mainColor,)
                                ),
                              );
                            }
                        ),
                      )
                    ],
                  );
                }else{
                  return Center(child: Text("Please check your internet."),);
                }
              }
            ),
          ),
          // bottomNavigationBar:  InkWell(
          //   onTap: (){
          //     // if (_Social.currentState!.validate()) {
          //     //   Navigator.pop(context, {
          //     //     "key": "${widget.listType}",
          //     //     "value":_socialController.text,
          //     //   });
          //     // }
          //   },
          //   child: Container(
          //     margin: EdgeInsets.only(left: 30,right: 30,bottom: 20),
          //     width: double.infinity,
          //     height: 46,
          //     decoration: BoxDecoration(
          //       color: AppColors.mainColor,
          //       borderRadius: BorderRadius.circular(5),
          //
          //     ),
          //     child: Center(child: Text('save',style: TextStyle(color: AppColors.white),),),
          //   ),
          // ),
        ),
      ),
    );
  }

  List _selectedDay = [];

  Future goToProfile1(context)async{
    // First screen
    var result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => CreateProfileStep1(
        display_name: widget.display_name,
        description: widget.description,
        selectBusinessType: widget.selectBusinessType,
      )),
    );
  }


  Future goToSelectedOpeningHoursPage(context, data)async{
    // First screen
    var result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => SelectOpeningHours(dayTime: AppJson.dayTimeList, selectedDay: data["day"].toString(), )),
    );

    if(result){
      getBusinessHoursFuture();
      setState(() {
      });
    }
  }


}


class SquareRadioButton extends StatefulWidget {
  final bool value;
  final ValueChanged<bool?>? onChanged;

  SquareRadioButton({
    required this.value,
    required this.onChanged,
  });

  @override
  _SquareRadioButtonState createState() => _SquareRadioButtonState();
}

class _SquareRadioButtonState extends State<SquareRadioButton> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        print("clicn");
        setState(() {
          widget.onChanged!(!widget.value);
        });
      },
      child: Row(
        children: [
          Container(
            width: 20.0, // Adjust the size as needed
            height: 20.0, // Adjust the size as needed
            decoration: BoxDecoration(
              border: Border.all(
                width: 1.0,
                color: Colors.black, // Border color
              ),
              borderRadius: BorderRadius.circular(4.0), // Adjust the radius to make it look like a square
            ),
            child: widget.value
                ? Icon(
              Icons.check,
              size: 16.0,
              color: Colors.black, // Checkmark color
            )
                : null,
          ),
          Text("Open")
        ],
      ),
    );
  }


}




class DateTimeInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    // Adjust the format to your needs
    String formattedValue = newValue.text;

    if (formattedValue.length == 2) {
      formattedValue += ':';
    } else if (formattedValue.length == 4) {
      formattedValue = formattedValue.substring(0, 5);
    }

    return TextEditingValue(
      text: formattedValue,

      selection: TextSelection.collapsed(offset: formattedValue.length),

    );
  }



}