import 'dart:convert';

import 'package:coco/controller/authController.dart';
import 'package:coco/model/authModel/userInfoModel.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/view/Client/createAccount/editDayTime.dart';
import 'package:coco/view/client/createAccount/profile_info_2.dart';
import 'package:coco/view/profile/widget/uploadCoverImage.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:keyboard_dismisser/keyboard_dismisser.dart';
import 'package:sizer/sizer.dart';
import 'package:wechat_assets_picker/wechat_assets_picker.dart';
import '../../../controller/profile_info_1_controller.dart';
import '../../../model/authModel/allBusinessTypeModel.dart';
import '../../../utility/registation_profile_header.dart';
import '../../../viewController/alartController.dart';

class CreateProfileStep1 extends StatefulWidget {
  final UserInformation? userInfo;
  final String? display_name;
  final String? description;
  final List<String>? selectBusinessType;
 const CreateProfileStep1({super.key,  this.userInfo, this.display_name, this.description, this.selectBusinessType});

  @override
  State<CreateProfileStep1> createState() => _CreateProfileStep1State();
}

class _CreateProfileStep1State extends State<CreateProfileStep1> {
  var startTime = TimeOfDay.now();
  // String nameText = "";


  final List<String> items=[];


 final List<String> allCountry= [];
  List allState = [];
  List allCity = [];
  var selectedCountry;
  var selectedState;
  var selectedCity;


  var openTime, closeTime;
  Future<void> selectTime(BuildContext context, time) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: startTime,
    );
    if (picked != null && picked != startTime) {
      if(time == "open"){
        setState(() {
          openTime = "${picked.hour}:${picked.minute} ${picked.period.name}";
        });
      }else{
        setState(() {
          closeTime = "${picked.hour}:${picked.minute} ${picked.period.name}";
        });
      }

    }
  }

  ProfileInfo1Controller profileInfo1Controller = Get.put(ProfileInfo1Controller());

  final GlobalKey<FormState> ClientStep1 = GlobalKey<FormState>();
  // TextEditingController _display_name = TextEditingController();
  // TextEditingController _description = TextEditingController();
  // TextEditingController profileInfo1Controller.country.value = TextEditingController();
  // TextEditingController profileInfo1Controller.countryId.value = TextEditingController();
  // TextEditingController profileInfo1Controller.zipcode.value = TextEditingController();
  // TextEditingController profileInfo1Controller.city.value = TextEditingController();
  // TextEditingController profileInfo1Controller.cityId.value = TextEditingController();
  // TextEditingController profileInfo1Controller.state.value = TextEditingController();
  // TextEditingController profileInfo1Controller.stateId.value = TextEditingController();
  // TextEditingController profileInfo1Controller.address.value = TextEditingController();
  TextEditingController _open_from = TextEditingController();
  TextEditingController _open_to = TextEditingController();
  TextEditingController CountrySearchController = TextEditingController();

  Future<AllBusnissType>? getEqupmentsList;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    userData();

    initTextController();


    getEqupmentsList = AuthController.getBusinessTypes();
    getCountryFuture = getAllCountryInitially();
    _focusNode = FocusNode();

  }

  Future? getCountryFuture;
  Future? getStateFuture;
  Future? getCityFuture;
  bool isCountry = false;
  bool isAllCity = false;
  Future getAllCountryInitially()async{
    setState(() =>isCountry = true);
    return await AuthController.getAllCountrys();
  }
  var userInfo;
   userData()async{
    setState(() async{
      userInfo = await AuthController.getUserInfo();
    });
  }
  Future getAllCity(id)async{
    setState(() =>isAllCity = true);
    return await AuthController.getAllCity(id);
  }
  Future getAllState(id)async{
    return await AuthController.getAllState(id);
  }

  // List<String> _selectBusinessType = [];


  @override
  Widget build(BuildContext context) {

    return KeyboardDismisser(
      gestures: [GestureType.onTap, GestureType.onPanUpdateDownDirection],
      child: Container(
        color: AppColors.white,
        child: AnnotatedRegion<SystemUiOverlayStyle>(
          value: SystemUiOverlayStyle.dark.copyWith(
            statusBarColor: Colors.transparent, // Set the status bar color
            statusBarIconBrightness: Brightness.dark, // Set the status bar text color
          ),
          child: Obx(()=> Scaffold(
              backgroundColor: AppColors.black,
              // appBar: AppBar(
              //   elevation: 0,
              //   backgroundColor: Colors.white,
              //   // leading: IconButton(
              //   //   onPressed: () => Get.back(),
              //   //   icon: Icon(
              //   //     Icons.arrow_back,
              //   //     color: AppColors.black,
              //   //   ),
              //   // ),
              // ),
              body: SingleChildScrollView(
                child: Column(
                  children: [
                    SizedBox(
                      height: 6.h,
                    ),
                // userInfo.data?.userInfo?.step1Complete == 0 ?  Align(
                //        alignment: Alignment.centerLeft,
                //        child: Padding(
                //          padding: const EdgeInsets.all(10.0),
                //          child: IconButton(
                //            onPressed: ()async{
                //              if(userInfo.data?.userInfo?.step1Complete == 0){
                //                Get.to(Role_selector());
                //              }else
                //                return;
                //            },
                //            icon: Icon(Icons.arrow_back, color: Colors.black,),
                //          ),
                //        ),
                //      ):Center(),
                     registation_profile_header(
                        name: profileInfo1Controller.name.value.isNotEmpty? profileInfo1Controller.name.value : "Full Name", following: '0', follower: '0'),
                    Padding(
                      padding: const EdgeInsets.all(28.0),
                      child: Form(
                        key: ClientStep1,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Text(
                                  'Step 1 of 3',
                                  style: TextStyle(
                                      fontSize: 13,
                                      color: AppColors.white,
                                      fontFamily: 'Poppins_SemiBold'),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 12,
                            ),
                            Text('Business info',
                                style: TextStyle(
                                    fontSize: 18,
                                    color: AppColors.mainColor,
                                    fontFamily: 'Poppins-Bold')),
                            SizedBox(
                              height: 22,
                            ),
                            Row(
                              children: [
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: const [
                                        Text(
                                          'Display name',
                                          style: TextStyle(
                                              fontSize: 12,
                                            color: AppColors.white,
                                              fontFamily: 'Poppins_SemiBold'),
                                        ),
                                        SizedBox(
                                          width: 2,
                                        ),
                                        Padding(
                                          padding: EdgeInsets.only(bottom: 8.0),
                                          child: CircleAvatar(
                                            radius: 2,
                                            backgroundColor: AppColors.mainColor,
                                          ),
                                        ),
                                      ],
                                    ),
                                    Text(
                                      'Name customers will see on your profile',
                                      style: TextStyle(
                                          fontSize: 10,
                                          fontFamily: 'Poppins-Light',
                                          color:AppColors.textgrey),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 18,
                            ),
                            TextFormField(
                              style: TextStyle(
                                  fontSize: 14,
                                color: AppColors.white
                              ),
                              controller: profileInfo1Controller.displayName.value,
                              onSaved: (v){
                                profileInfo1Controller.displayName.value.text = v!;
                              },
                              onChanged: (v){
                                setState(() {
                                  profileInfo1Controller.name.value = v;
                                });
                              },
                              validator: (String? value) {
                                if (value?.isEmpty ?? true) {
                                  return 'Please Enter your Display name';
                                }
                              },
                              decoration: InputDecoration(

                                  hintText: ('Type your display name'),
                                ),
                            ),
                            SizedBox(
                              height: 18,
                            ),
                            Row(
                              children: [
                                Text(
                                  'Description',
                                  style: TextStyle(
                                    color: AppColors.white,
                                      fontSize: 12, fontFamily: 'Poppins_SemiBold'),
                                ),
                                SizedBox(
                                  width: 3,
                                ),
                                // Row(
                                //   children: [
                                //     Padding(
                                //       padding: const EdgeInsets.only(bottom: 8.0),
                                //       child: CircleAvatar(
                                //         radius: 2,
                                //         backgroundColor: AppColors.mainColor,
                                //       ),
                                //     ),
                                //   ],
                                // )
                              ],
                            ),
                            SizedBox(
                              height: 7,
                            ),
                            Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                TextFormField(

                                    style: TextStyle(
                                        fontSize: 14,
                                        color: AppColors.white
                                    ),
                                  controller: profileInfo1Controller.description.value,
                                  textInputAction: TextInputAction.done,

                                  // validator: (String? value) {
                                  //   if (value?.isEmpty ?? true) {
                                  //     return 'Please Enter description';
                                  //   }
                                  // },
                                  maxLines: 4,
                                  decoration: InputDecoration(

                                    hintText:
                                        'Share a bit about your work experience, your projects...',
                                  ),
                                ),
                                Text(
                                  'min:150',
                                  style: TextStyle(
                                      color: AppColors.textgrey,
                                      fontSize: 10,
                                      fontFamily: 'Poppins_Light'),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 15,
                            ),
                            Row(
                              children: [
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          'Business Type',
                                          style: TextStyle(
                                              fontSize: 12,
                                              color: AppColors.white,
                                              fontFamily: 'Poppins_SemiBold'
                                          ),
                                        ),
                                        SizedBox(
                                          width: 2,
                                        ),
                                        Padding(
                                          padding:
                                          const EdgeInsets.only(bottom: 8.0),
                                          child: CircleAvatar(
                                            radius: 2,
                                            backgroundColor: Color(0xFF00CC83),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Text(
                                      'Select one or multiple business types',
                                      style: TextStyle(
                                          fontSize: 12,
                                          fontFamily: 'Poppins-Light',
                                          color: AppColors.textgrey),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            FutureBuilder<AllBusnissType>(
                                future: getEqupmentsList,
                                builder: (context, snapshot) {
                                  print("snapshot == ${snapshot.data}");
                                  if(snapshot.connectionState == ConnectionState.waiting){
                                    return SizedBox(height: 100,);
                                  }else if(snapshot.hasData){
                                    return SizedBox(
                                      //height: 100,
                                      child: snapshot.data?.data?.length == 0 ? Center(child: Text("No Business type."),): GridView.builder(
                                        physics: NeverScrollableScrollPhysics(),
                                        shrinkWrap: true,
                                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                            crossAxisCount: 3,
                                            crossAxisSpacing: 5.0,
                                            mainAxisSpacing: 5.0,
                                            childAspectRatio: (1 / .25)
                                          //controller: new ScrollController(keepScrollOffset: false),
                                        ),
                                        itemCount: snapshot.data?.data?.length,
                                        itemBuilder: (context, index) {
                                          return InkWell(
                                            onTap: (){
                                              print(snapshot.data!.data![index]!.id.toString()!);
                                              setState(() {
                                                if(profileInfo1Controller.selectBusinessType.value.contains(snapshot.data!.data![index]!.id.toString()!)){
                                                  profileInfo1Controller.selectBusinessType.value.remove(snapshot.data!.data![index]!.id.toString()!);
                                                }else{
                                                  profileInfo1Controller.selectBusinessType.value.add(snapshot.data!.data![index]!.id.toString()!);
                                                }
                                              });
                                            },
                                            child: Container(
                                              child: Padding(
                                                padding: const EdgeInsets.symmetric(vertical: 2.0,horizontal:10),
                                                child: Center(child: Text('${snapshot.data?.data?[index]?.name}',style: TextStyle(fontSize: 10,fontFamily: 'Poppins-Medium',color: profileInfo1Controller.selectBusinessType.value.contains(snapshot.data!.data![index]!.id.toString()!) ? AppColors.white : Colors.black),)),
                                              ),
                                              decoration: BoxDecoration(
                                                  color: profileInfo1Controller.selectBusinessType.value.contains(snapshot.data!.data![index]!.id.toString()!) ? AppColors.mainColor : AppColors.white,
                                                  border: Border.all(
                                                      width: 2,
                                                      color:  profileInfo1Controller.selectBusinessType.value.contains(snapshot.data!.data![index]!.id.toString()!) ? AppColors.mainColor : Color(0xffE8E8E8)
                                                  ),
                                                  borderRadius: BorderRadius.circular(15)
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                                    );
                                  }else{
                                    return const Center(child: Text("Check internet connection"),);
                                  }
                                }
                            ),
                            SizedBox(
                              height: 7,
                            ),
                            SizedBox(
                              height: 15,
                            ),
                            Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      'Opening Hours',
                                      style: TextStyle(
                                          fontSize: 12,
                                          color: AppColors.white,
                                          fontFamily: 'Poppins_SemiBold'),
                                    ),
                                    SizedBox(
                                      width: 2,
                                    ),

                                  ],
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                InkWell(
                                    onTap: ()=>goToOpeningOurs(context),
                                    child: Container(
                                      height: 50,
                                      decoration: BoxDecoration(
                                          color: AppColors.black,
                                          // borderRadius: BorderRadius.circular(5),
                                          border: Border.all(width: 1, color: AppColors.mainColor),
                                        borderRadius: BorderRadius.circular(10)
                                      ),
                                      child: Center(
                                        child: Text("+ Create opening hours",
                                          style: TextStyle(
                                              fontWeight: FontWeight.w600,
                                              color: AppColors.mainColor,
                                              fontSize: 14
                                          ),
                                        ),
                                      ),
                                    )
                                )
                              ],
                            ),
                            SizedBox(
                              height: 15,
                            ),
                            Row(
                              children: [
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          'Country',
                                          style: TextStyle(
                                              fontSize: 12,
                                              color: AppColors.white,
                                              fontFamily: 'Poppins_SemiBold'),
                                        ),
                                        SizedBox(
                                          width: 2,
                                        ),
                                        Padding(
                                          padding: EdgeInsets.only(bottom: 8.0),
                                          child: CircleAvatar(
                                            radius: 2,
                                            backgroundColor: AppColors.mainColor,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 5,
                            ),







                            TextFormField(
                              style: TextStyle(
                                  fontSize: 14,
                                  color: AppColors.white
                              ),
                              onTap: ()=>openCountryList(),
                              readOnly: true,
                              controller: profileInfo1Controller.country.value,
                              validator: (String? value) {
                                if (value?.isEmpty ?? true) {
                                  return 'Please Enter your Country';
                                }
                              },
                              decoration: InputDecoration(

                                  hintText: ('Choose a country'),
                                ),
                            ),
                             SizedBox(
                              height: 5,
                            ),
                            TextFormField(
                              style: TextStyle(
                                  fontSize: 14,
                                  color: AppColors.white
                              ),
                              controller: profileInfo1Controller.state.value,
                              readOnly: true,
                              onTap: (){
                                if(profileInfo1Controller.country.value.text.isNotEmpty){
                                  print("profileInfo1Controller.countryId.value.toString() ${profileInfo1Controller.countryId.value.text}");
                                  getStateFuture = getAllState(profileInfo1Controller.countryId.value.text);
                                  openState(getAllState(profileInfo1Controller.countryId.value.text));
                                }else{
                                  AlertController.snackbar(context: context, text: "Please Select Country.", bg: Colors.red);
                                }

                              },
                              // validator: (String? value) {
                              //   if (value?.isEmpty ?? true) {
                              //     return 'Please Enter your State Address';
                              //   }
                              // },
                              decoration: InputDecoration(

                                  hintText: ('State'),
),
                            ),
                            SizedBox(
                              height: 5,
                            ),

                            TextFormField(
                              style: TextStyle(
                                  fontSize: 14,
                                  color: AppColors.white
                              ),
                              controller: profileInfo1Controller.city.value,
                              readOnly: true,
                              onTap: (){
                                if(profileInfo1Controller.state.value.text.isNotEmpty){
                                  openCity();
                                }else{
                                  AlertController.snackbar(context: context, text: "Please Select State.", bg: Colors.red);
                                }
                              },
                              // validator: (String? value) {
                              //   if (value?.isEmpty ?? true) {
                              //     return 'Please Enter your city';
                              //   }
                              // },
                              decoration: const InputDecoration(

                                  hintText: ('Choose a city'),
                              ),
                            ),
                            SizedBox(
                              height: 5,
                            ),

                            TextFormField(
                              style: TextStyle(
                                  fontSize: 14,
                                  color: AppColors.white
                              ),
                              controller: profileInfo1Controller.zipcode.value,
                              validator: (String? value) {
                                if (value?.isEmpty ?? true) {
                                  return 'Please Enter your Zipcode';
                                }
                              },
                              decoration: InputDecoration(

                                  hintText: ('Zip code'),
                                 ),
                            ),
                            SizedBox(
                              height: 5,
                            ),
                            SizedBox(
                              height: 5,
                            ),
                            TextFormField(
                              style: TextStyle(
                                  fontSize: 14,
                                  color: AppColors.white
                              ),
                              focusNode: _focusNode,
                              controller: profileInfo1Controller.address.value,
                              // validator: (String? value) {
                              //   if (value?.isEmpty ?? true) {
                              //     return 'Please Enter your address';
                              //   }
                              // },
                              decoration: InputDecoration(

                                  hintText: ('Address'),
                                ),
                            ),
                            SizedBox(
                              height: 15,
                            ),



                            SizedBox(
                              height: 5,
                            ),
                            ///////Method////
                            UploadCoverImage(
                              isEdit:  false,
                              placeholder: "https://i0.wp.com/thinkfirstcommunication.com/wp-content/uploads/2022/05/placeholder-1-1.png?fit=1200%2C800&ssl=1",
                            ),

                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              bottomNavigationBar: Container(
                margin: EdgeInsets.all(20),
                width: double.infinity,
                child: ElevatedButton(
                    style: OutlinedButton.styleFrom(
                      backgroundColor: AppColors.mainColor,
                    ),
                    onPressed: () {
                      if (!ClientStep1.currentState!.validate()) {
                        return;
                      }
                      _clientProfileStepOne();
                    },
                    child:isLoading?const CircularProgressIndicator(strokeWidth: 1, color: Colors.white,) : const Text(
                      'Continue',
                      style: TextStyle(color: Colors.white, fontSize: 13),
                    )),
              ),
            ),
          ),
        ),
      ),
    );
  }


  ////////////////////////////////////////////////////////////////////////////////////////////
  /////////////////////////================================///////////////////////////////////
  final searchCountryController = TextEditingController();
  final searchStateController = TextEditingController();
  final searchCityController = TextEditingController();
  ////////////////////////////////////
  /////////Country search //////////
  List countryList = [];
  List searchCountryList = [];
  openCountryList()async{
    setState(() {});
    // getAllCountryInitially();
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: AppColors.black,
          title: Align(
            alignment: Alignment.bottomRight,
            child: IconButton(onPressed: (){
                //countryList.clear();
                searchCountryList.clear();
                searchCountryController.clear();
              Get.back();
            }, icon: Icon(Icons.close,color: AppColors.white,),),
          ),
          insetPadding: const EdgeInsets.all(0),
          content: StatefulBuilder(

            builder: (context, setState) {
              return SizedBox(
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width,
                child: Column(
                  children: [

                    TextFormField(
                      style: TextStyle(
                        color: AppColors.white,
                      ),
                      controller: searchCountryController,
                      onChanged: (value){
                        //////// if the role is freelnacer then we store data only searchBusinessList
                        setState(() {
                          searchCountryList.clear();
                          for (var i = 0; i<countryList.length; i++) {
                            if (countryList[i]["name"].toLowerCase().contains(value.toLowerCase())) {
                              searchCountryList?.add(countryList[i]);
                            }
                            print("searchCountryList == ${searchCountryList}");
                          }
                        });
                      },
                      decoration: const InputDecoration(

                          hintText: ('Search country'),
                         ),
                    ),
                    FutureBuilder(
                        future: getCountryFuture,
                        builder: (context,AsyncSnapshot<dynamic> snapshot) {
                          print("snapshot ==== ${snapshot.data}");
                          if(snapshot.connectionState == ConnectionState.waiting){
                            return const Center(child: CircularProgressIndicator(strokeWidth: 1, color: Colors.white,),);
                          }else if(snapshot.hasData){
                            countryList = snapshot.data;
                            return Expanded(
                              // width: MediaQuery.of(context).size.width,
                              child:searchCountryList.isEmpty
                                  ? ListView.builder(
                                shrinkWrap: true,
                                itemCount: snapshot.data.length,
                                itemBuilder: (_, index){
                                  items.add(snapshot.data[index]["name"]);
                                  return ListTile(
                                    onTap: (){
                                      setState(() {
                                        profileInfo1Controller.countryId.value.text = snapshot.data[index]["id"].toString();
                                        profileInfo1Controller.country.value.text = snapshot.data[index]["name"];
                                        profileInfo1Controller.stateId.value.clear();
                                        profileInfo1Controller.state.value.clear();
                                        profileInfo1Controller.city.value.clear();
                                        profileInfo1Controller.cityId.value.clear();
                                        searchCountryList.clear();
                                        searchCountryController.clear();
                                      });
                                      Get.back();
                                    },
                                    title: Text("${snapshot.data[index]["name"]}",style: TextStyle(color: AppColors.white),),
                                  );
                                },
                              )
                                  :  ListView.builder(
                                shrinkWrap: true,
                                itemCount: searchCountryList.length,
                                itemBuilder: (_, index){
                                  items.add(snapshot.data[index]["name"]);
                                  return ListTile(
                                    onTap: (){
                                      setState(() {
                                        profileInfo1Controller.countryId.value.text = searchCountryList[index]["id"].toString();
                                        profileInfo1Controller.country.value.text = searchCountryList[index]["name"];
                                        profileInfo1Controller.stateId.value.clear();
                                        profileInfo1Controller.state.value.clear();
                                        profileInfo1Controller.city.value.clear();
                                        profileInfo1Controller.cityId.value.clear();
                                        searchCountryController.clear();
                                        searchCountryList.clear();
                                      });
                                      Get.back();
                                    },
                                    title: Text("${searchCountryList[index]["name"]}",style: TextStyle(color: AppColors.white),),
                                  );
                                },
                              ),
                              // child: Text("dafasd"),
                            );
                          }else{
                            return Center(child: Text("No Country found",style: TextStyle(color:AppColors.white),),);
                          }
                        }
                    ),
                  ],
                ),
              );
            }
          ),
          actions: [
            TextButton(
              onPressed: ()=>Get.back(),
              child: Text("Close",style: TextStyle(color: AppColors.mainColor),),
            )
          ],
        );
      },
    );
  }

  //////////// open country list ////////////
  List stateList = [];
  List searchStateList = [];
  openState(future)async{
    // getAllCountryInitially();
    getStateFuture = getAllState(profileInfo1Controller.countryId.value.text);
    print("profileInfo1Controller.countryId.value === ${profileInfo1Controller.countryId.value}");
    showDialog(
      context: context,
        barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
            backgroundColor:  AppColors.black,
          title: Align(
            alignment: Alignment.bottomRight,
            child: IconButton(onPressed: (){
              setState(() {
                searchStateList.clear();
                searchStateController.clear();
              });
              Get.back();
            }, icon: Icon(Icons.close,color: AppColors.white,),),
          ),
          insetPadding: EdgeInsets.all(0),
          content: StatefulBuilder(
            builder: (context, setState) {
              return SizedBox(
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width,
                child: Column(
                  children: [
                    TextFormField(
                      style: TextStyle(
                        color: AppColors.white,
                      ),
                      controller: searchStateController,
                      onChanged: (value){
                        //////// if the role is freelnacer then we store data only searchBusinessList
                        setState(() {
                          searchStateList.clear();
                          for (var i = 0; i<stateList.length; i++) {
                            if (stateList[i]["name"].toLowerCase().contains(value.toLowerCase())) {
                              searchStateList?.add(stateList[i]);
                            }
                          }
                        });
                      },
                      decoration: const InputDecoration(
                          hintText: ('Search state'),
                        ),
                    ),
                    FutureBuilder(
                        future: getStateFuture,
                        builder: (context,AsyncSnapshot<dynamic> snapshot) {
                          print("snapshot ==== ${snapshot.data}");
                          if(snapshot.connectionState == ConnectionState.waiting){
                            return Center(child: CircularProgressIndicator(strokeWidth: 1, color: Colors.white,),);
                          }else if(snapshot.hasData){
                            stateList = snapshot.data;
                            return  StatefulBuilder(
                                builder: (context, setState) {
                                  return Expanded(
                                    child: searchStateList.isEmpty
                                        ? ListView.builder(
                                      shrinkWrap: true,
                                      itemCount: snapshot.data.length,
                                      itemBuilder: (_, index){
                                        return ListTile(
                                          onTap: (){
                                            setState(() {
                                              profileInfo1Controller.stateId.value.text = snapshot.data[index]["id"].toString();
                                              profileInfo1Controller.state.value.text = snapshot.data[index]["name"];
                                              searchStateList.clear();
                                              searchStateController.clear();
                                            });
                                            Get.back();
                                            print("selectedCountry === ${selectedCountry}");
                                          },
                                          title: Text("${snapshot.data[index]["name"]}", style: TextStyle(
                                            color: AppColors.white,
                                          ),),
                                        );
                                      },
                                    )
                                        : ListView.builder(
                                      shrinkWrap: true,
                                      itemCount: searchStateList.length,
                                      itemBuilder: (_, index){
                                        return ListTile(
                                          onTap: (){
                                            setState(() {
                                              profileInfo1Controller.stateId.value.text = searchStateList[index]["id"].toString();
                                              profileInfo1Controller.state.value.text = searchStateList[index]["name"];
                                              searchStateList.clear();
                                              searchStateController.clear();
                                            });
                                            Get.back();
                                            print("selectedCountry === ${selectedCountry}");
                                          },
                                          title: Text("${searchStateList[index]["name"]}",style: TextStyle(color: AppColors.white),),
                                        );
                                      },
                                    ),
                                    // child: Text("dafasd"),
                                  );
                                }
                            );
                          }else if(snapshot.hasError){
                            print("shanpshot error ==== ${snapshot.hasError}");
                            return Text("error");
                          }else{
                            return Center(child: Text("No State found", style: TextStyle(
                              color: AppColors.white,
                            ),),);
                          }
                        }
                    ),
                  ],
                ),
              );
            }
          ),
          actions: [
            TextButton(
              onPressed: ()=>Get.back(),
              child: Text("Close", style: TextStyle(
                color: AppColors.mainColor,
              ),),
            )
          ],
        );
      },
    );
  }


  //////////// open country list ////////////
  List cityList = [];
  List searchCityList = [];
  //////////// open country list ////////////
  openCity()async{
    // getAllCountryInitially();
    getCityFuture = getAllCity(profileInfo1Controller.stateId.value.text);

    print("profileInfo1Controller.stateId.value === ${profileInfo1Controller.stateId.value.text}");
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: AppColors.black,
          title: Align(
            alignment: Alignment.bottomRight,
            child: IconButton(onPressed: (){
              setState(() {
                searchCityList.clear();
                searchCityController.clear();
              });
              Get.back();
            }, icon: Icon(Icons.close,color: AppColors.white,),),
          ),
          insetPadding: EdgeInsets.all(0),
          content: StatefulBuilder(
            builder: (context, setState) {
              return SizedBox(
                width: MediaQuery.of(context).size.width,
                height:MediaQuery.of(context).size.height,
                child: Column(
                  children: [
                    TextFormField(
                      controller: searchCityController,
                      onChanged: (value){
                        //////// if the role is freelnacer then we store data only searchBusinessList
                        setState(() {
                          searchCityList.clear();
                          for (var i = 0; i<cityList.length; i++) {
                            if (cityList[i]["name"].toLowerCase().contains(value.toLowerCase())) {
                              searchCityList?.add(cityList[i]);
                            }
                          }
                        });
                      },
                      decoration: const InputDecoration(

                          hintText: ('Search city'),
                        ),
                    ),
                    FutureBuilder(
                        future: getCityFuture,
                        builder: (context,AsyncSnapshot<dynamic> snapshot) {
                          print("snapshot ==== ${snapshot.data}");
                          if(snapshot.connectionState == ConnectionState.waiting){
                            return Center(child: CircularProgressIndicator(strokeWidth: 1, color: Colors.white,),);
                          }else if(snapshot.hasData){
                            cityList = snapshot.data;
                            return  StatefulBuilder(
                                builder: (context, setState) {
                                  return snapshot.data.length == 0
                                      ? const Center(child: Text("No City Found", style: TextStyle(
                                    color: AppColors.white,
                                  ),),)
                                      : Expanded(
                                        child: searchCityList.isEmpty
                                            ? ListView.builder(
                                    shrinkWrap: true,
                                    itemCount: snapshot.data.length,
                                    itemBuilder: (_, index){
                                        return ListTile(
                                          onTap: (){
                                            setState(() {
                                              profileInfo1Controller.cityId.value.text = snapshot.data[index]["id"].toString();
                                              profileInfo1Controller.city.value.text = snapshot.data[index]["name"];
                                              searchCityList.clear();
                                              searchCityController.clear();
                                            });
                                            Get.back();
                                            print("selectedCountry === ${selectedCountry}");
                                          },
                                          title: Text("${snapshot.data[index]["name"]}", style: TextStyle(
                                            color: AppColors.white,
                                          ),),
                                        );
                                    },
                                  )
                                            : ListView.builder(
                                          shrinkWrap: true,
                                          itemCount: searchCityList.length,
                                          itemBuilder: (_, index){
                                            return ListTile(
                                              onTap: (){
                                                setState(() {
                                                  profileInfo1Controller.cityId.value.text = searchCityList[index]["id"].toString();
                                                  profileInfo1Controller.city.value.text = searchCityList[index]["name"];
                                                  searchCityList.clear();
                                                  searchCityController.clear();
                                                });
                                                Get.back();
                                                print("selectedCountry === ${selectedCountry}");
                                              },
                                              title: Text("${searchCityList[index]["name"]}", style: TextStyle(
                                                color: AppColors.white,
                                              ),),
                                            );
                                          },
                                        ),
                                      );
                                }
                            );
                          }else{
                            return Center(child: Text("No City found", style: TextStyle(
                              color: AppColors.white,
                            ),),);
                          }
                        }
                    ),
                  ],
                ),
              );
            }
          ),
          actions: [
            TextButton(
              onPressed: ()=>Get.back(),
              child: Text("Close", style: TextStyle(
                color: AppColors.mainColor,
              ),),
            )
          ],
        );
      },
    );
  }
  /////////////////////////================================///////////////////////////////////
  // //////////////////////////////////////////////////////////////////////////////////////////



  FocusNode? _focusNode;

  //////////selected-date///////////
  var fromDay, toDay;


  bool isLoading = false;
  void _clientProfileStepOne() async{

    print("profileInfo1Controller.countryId.value.text === ${profileInfo1Controller.countryId.value.text}");
    print(profileInfo1Controller.selectBusinessType.value);

    print('addresses issue ==== ${profileInfo1Controller.address.value.text}');
    print("click me ${profileInfo1Controller.selectBusinessType.value}");
    setState(() =>isLoading=true);
    if (ClientStep1.currentState!.validate()) {
      var res = await AuthController.clientProfileStepOne(
          name:  profileInfo1Controller.displayName.value.text,
          description: profileInfo1Controller.description.value.text,
          country: profileInfo1Controller.countryId.value.text,
          zipcode: profileInfo1Controller.zipcode.value.text,
          city: profileInfo1Controller.countryId.value.text,
          state: profileInfo1Controller.stateId.value.text,
          address: profileInfo1Controller.address.value.text,
          open_from: openTime??"-",
          open_to:  closeTime??"-",
          day_to: toDay??"-",
          day_from: fromDay??"-",
          business_list: profileInfo1Controller.selectBusinessType.value
      );
      print("response step one ==== ${res.body}");
      print("response ==== ${res.statusCode}");
      var data = jsonDecode(res.body);
      if(res.statusCode == 200){
        /////////// get user information again
        var userInfo = await AuthController.getUserInfo();
        print("user info ==== ${userInfo.data!.userInfo!.step1Complete}");
        AlertController.snackbar(context: context, text: "First step complete.", bg: Colors.green);
        Navigator.push(context, MaterialPageRoute(builder: (context)=>CreateProfileStep2()));
      }else{
        AlertController.snackbar(context: context, text: "${data["message"]}", bg: Colors.red);
      }
    }
    setState(() =>isLoading=false);

  }


  @override
  void dispose() {
    _focusNode?.dispose();
    super.dispose();
  }


  void searchCounrtyMethod(String value) {
    //////// if the role is freelnacer then we store data only searchBusinessList
    setState(() {
      searchCountryList.clear();
    for (var i = 0; i<countryList.length; i++) {
      if (countryList[i]["name"].toLowerCase().contains(value.toLowerCase())) {

          searchCountryList?.add(countryList[i]);

      }

      print("searchCountryList == ${searchCountryList}");
    }
    });
  }


  Future goToOpeningOurs(context)async{
    // First screen
    var result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => EditDayTime(
        display_name: profileInfo1Controller.displayName.value.text,
        description: profileInfo1Controller.description.value.text,
        selectBusinessType: profileInfo1Controller.selectBusinessType.value,
      )),
    );

    if(result != null){
      setState(() {
        profileInfo1Controller.description.value.text = result;
      });
    }

    print("EditDayTime   =$result");
  }

  void initTextController() {
    setState(() {
     if( widget!.display_name != null){
       profileInfo1Controller.displayName.value.text = widget!.display_name!;
     }
     if(widget!.description != null){
       profileInfo1Controller.description.value.text = widget!.description!;
     }
     if(widget!.selectBusinessType != null){
       profileInfo1Controller.selectBusinessType.value = widget!.selectBusinessType!;
     }
    });
  }





}
