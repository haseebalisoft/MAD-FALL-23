import 'dart:convert';

import 'package:coco/controller/authController.dart';
import 'package:coco/model/authModel/userInfoModel.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/view/Client/createAccount/profile_info_1.dart';
import 'package:coco/view/client/createAccount/profile_info_3.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:intl_phone_number_input/intl_phone_number_input.dart';
import 'package:keyboard_dismisser/keyboard_dismisser.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../utility/registation_profile_header.dart';
import '../../../viewController/alartController.dart';
import '../../../viewController/appLoading.dart';
import '../../../viewController/showAllert.dart';

class CreateProfileStep2 extends StatefulWidget {
  const CreateProfileStep2({super.key});

  @override
  State<CreateProfileStep2> createState() => _CreateProfileStep2State();
}

class _CreateProfileStep2State extends State<CreateProfileStep2> {
  final GlobalKey<FormState> ClientStep2 = GlobalKey<FormState>();
  // TextEditingController _phoneController = TextEditingController();
  TextEditingController _email = TextEditingController();
  TextEditingController _phone = TextEditingController();
  TextEditingController _website = TextEditingController();
  // TextEditingController _WebsiteController = TextEditingController();

  String phone_country_code = "";
  String phone_number = "";
  String phone_iso = "";

  var profileImage, name, step1Complete;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getUserInfo();
    _website.text = "https://";
    getPhn();
  }

  bool isUserDataIsGeting = false;
  var userInfoFuture;
  var countryCode;
  getUserInfo()async{
    SharedPreferences _pref =await SharedPreferences.getInstance();
   setState(() =>isUserDataIsGeting = true);
    userInfoFuture =await AuthController.getUserInfo();
   setState(() {
     countryCode = _pref.getString("isoCode").toString();
     profileImage= userInfoFuture?.data?.profileImage;
     name= userInfoFuture?.data?.name;
     step1Complete = userInfoFuture?.data?.userInfo?.step1Complete;
     _email.text = userInfoFuture!.data!.email!;
     _phone.text = userInfoFuture!.data!.phone!;
   });
   print('phoneeeeee===${countryCode}');
   setState(() =>isUserDataIsGeting = false);

   return userInfoFuture;
  }

  getPhn() async{
    SharedPreferences pref =await SharedPreferences.getInstance();
    setState(() {
      phone_country_code = pref.getString("signUpPhnNumCountryCode").toString();
      phone_number = pref.getString("signUpPhnNum").toString();
      phone_iso = pref.getString("signUpPhnNumISO").toString();
    });
  }
  @override
  Widget build(BuildContext context) {
    return KeyboardDismisser(
      gestures: [GestureType.onTap, GestureType.onPanUpdateDownDirection],
      child:
          Container(
          color: AppColors.black,
          child: SafeArea(
            child: Stack(
              children: [
                Scaffold(
                  backgroundColor: AppColors.black,
                  appBar: AppBar(
                    elevation: 0,
                    backgroundColor: AppColors.black,
                    leading: IconButton(
                      onPressed: () => Get.back(),
                      icon: Icon(
                        Icons.arrow_back,
                        color: AppColors.black,
                      ),
                    ),
                  ),
                  body: SingleChildScrollView(
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          SizedBox(
                            height: 20,
                          ),
                          registation_profile_header(
                              name: '${name??"----"}', following: '0', follower: '0', image: profileImage,),
                          Padding(
                            padding: const EdgeInsets.all(28.0),
                            child: Form(
                              key: ClientStep2,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Text('Step 2 of 3',
                                          style: TextStyle(
                                            fontSize: 13,
                                            color: AppColors.white,
                                            fontFamily: 'Poppins_SemiBold',
                                          )),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 4,
                                  ),
                                  const Text('Contact info',
                                      style: TextStyle(
                                          fontSize: 18,
                                          color: Color(0xFF00CC83),
                                          fontWeight: FontWeight.bold)),
                                  SizedBox(
                                    height: 28,
                                  ),
                                  Row(
                                    children: [
                                      Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            children: [
                                              Text('Phone number',
                                                  style: TextStyle(
                                                      fontSize: 12,
                                                      color: AppColors.white,
                                                      fontFamily: 'Poppins_SemiBold')),
                                              SizedBox(
                                                width: 2,
                                              ),
                                              Padding(
                                                padding:
                                                    const EdgeInsets.only(bottom: 8.0),
                                                child: CircleAvatar(
                                                  radius: 2,
                                                  backgroundColor: Color(0xFF00CC83),
                                                ),
                                              ),
                                            ],
                                          ),
                                          Text(
                                            'Freelancers will call you on this number',
                                            style: TextStyle(
                                                fontSize: 10,
                                                fontFamily: 'Poppins-Light',
                                                color: AppColors.textgrey),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 18,
                                  ),
                                  // IntlPhoneField(
                                  //   controller: _phone,
                                  //   decoration: InputDecoration(
                                  //
                                  //       enabled: false,
                                  //       fillColor: Color(0xFFF8F8F8),
                                  //       hintText: ('Enter phone number'),
                                  //       hintStyle: TextStyle(
                                  //           fontFamily: 'Poppins-Light', fontSize: 10)),
                                  //   initialCountryCode: 'US',
                                  //   onChanged: (phone) {
                                  //     print(phone.completeNumber);
                                  //   },
                                  // ),

                                  // InternationalPhoneNumberInput(
                                  //   selectorTextStyle: TextStyle(
                                  //     color: Colors.white,
                                  //   ),
                                  //
                                  //   initialValue: PhoneNumber(
                                  //     isoCode: countryCode
                                  //   ),
                                  //
                                  //   onInputChanged: (PhoneNumber number) {
                                  //     print(number.phoneNumber);
                                  //   },
                                  //   autoValidateMode: AutovalidateMode.always,
                                  //   searchBoxDecoration: InputDecoration(
                                  //       fillColor: Colors.grey.shade400,
                                  //       filled: true,
                                  //       hintText: "Search",
                                  //       helperStyle: TextStyle(color: Colors.black, fontWeight: FontWeight.normal)
                                  //   ),
                                  //   hintText:'Phone Number',
                                  //   locale:'US',
                                  //   textStyle: TextStyle(
                                  //       fontSize: 14,
                                  //       color: AppColors.white
                                  //   ),
                                  //   // errorMessage : 'Invalid phone number',
                                  //   inputDecoration : InputDecoration(
                                  //     border: OutlineInputBorder(
                                  //         borderRadius: BorderRadius.circular(10),
                                  //         borderSide: BorderSide.none
                                  //     ),
                                  //     fillColor: AppColors.formColorUp,
                                  //     hintText: 'Phone Number',
                                  //     hintStyle: const TextStyle(
                                  //         fontWeight: FontWeight.w400,
                                  //         fontSize: 12,
                                  //         color: AppColors.textgrey),
                                  //   ),
                                  //   selectorConfig: const SelectorConfig(
                                  //     selectorType: PhoneInputSelectorType.BOTTOM_SHEET,
                                  //     setSelectorButtonAsPrefixIcon: true,
                                  //     leadingPadding: 10,
                                  //     showFlags: true,
                                  //     useEmoji: true,
                                  //   ),
                                  //   ignoreBlank: true,
                                  //   // autoValidateMode: Auto validateMode.always,
                                  //   countrySelectorScrollControlled:true,
                                  //   textFieldController: _phone,
                                  //   formatInput: true,
                                  //
                                  //   keyboardType:
                                  //   TextInputType.numberWithOptions(signed: true, decimal: true),
                                  //   onSaved: (PhoneNumber number) {
                                  //     print('On Saved: $number');
                                  //   },
                                  // ),

                                  InternationalPhoneNumberInput(
                                    selectorTextStyle: TextStyle(
                                      color: Colors.white,
                                    ),
                                    onInputChanged: (PhoneNumber number) {
                                      print(number.phoneNumber);
                                    },
                                    autoValidateMode: AutovalidateMode.onUserInteraction, // Changed to validate on user interaction
                                    searchBoxDecoration: InputDecoration(
                                        fillColor: Colors.grey.shade400,
                                        filled: true,
                                        hintText: "Search",
                                        helperStyle: TextStyle(color: Colors.black, fontWeight: FontWeight.normal)
                                    ),
                                    hintText:'Phone Number',
                                    locale:'US',
                                    textStyle: TextStyle(
                                        fontSize: 14,
                                        color: AppColors.white
                                    ),
                                    inputDecoration : InputDecoration(
                                      border: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(10),
                                          borderSide: BorderSide.none
                                      ),
                                      fillColor: AppColors.formColorUp,
                                      hintText: 'Phone Number',
                                      hintStyle: const TextStyle(
                                          fontWeight: FontWeight.w400,
                                          fontSize: 12,
                                          color: AppColors.textgrey),
                                    ),
                                    selectorConfig: const SelectorConfig(
                                      selectorType: PhoneInputSelectorType.BOTTOM_SHEET,
                                      setSelectorButtonAsPrefixIcon: true,
                                      leadingPadding: 10,
                                      showFlags: true,
                                      useEmoji: true,
                                    ),
                                    ignoreBlank: true,
                                    countrySelectorScrollControlled:true,
                                    initialValue: PhoneNumber(
                                        dialCode: phone_country_code,
                                        phoneNumber: phone_number,
                                        isoCode: phone_iso

                                        // dialCode: "+880",
                                        // phoneNumber: "+8801770664065",
                                        // isoCode: "BD"
                                    ),
                                    textFieldController: _phone, // Make sure 'phone' has a valid initial value
                                    formatInput: true,
                                    keyboardType:
                                    TextInputType.numberWithOptions(signed: true, decimal: true),
                                    onSaved: (PhoneNumber number) {
                                      print('On Saved: $number');
                                    },
                                  ),

                                  SizedBox(
                                    height: 20,
                                  ),
                                  Row(
                                    children: [
                                      Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            children: [
                                              Text('Email',
                                                  style: TextStyle(
                                                      fontSize: 12,
                                                      color: AppColors.white,
                                                      fontFamily: 'Poppins_SemiBold')),
                                              SizedBox(
                                                width: 2,
                                              ),
                                              Padding(
                                                padding:
                                                    const EdgeInsets.only(bottom: 8.0),
                                                child: CircleAvatar(
                                                  radius: 2,
                                                  backgroundColor: Color(0xFF00CC83),
                                                ),
                                              ),
                                            ],
                                          ),
                                          Text(
                                            'Freelancer will contact you on this mail',
                                            style: TextStyle(
                                                fontSize: 10,
                                                fontFamily: 'Poppins-Light',
                                                color: AppColors.textgrey),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 18,
                                  ),
                                  TextFormField(
                                    style: TextStyle(
                                        fontSize: 14,
                                      color: AppColors.white,
                                    ),
                                    controller: _email,
                                    validator: (String? value) {
                                      if (value?.isEmpty ?? true) {
                                        return 'Please Enter your Email';
                                      }
                                    },
                                    decoration: InputDecoration(
                                        hintText: ('Enter email address'),
                                     ),
                                  ),
                                  SizedBox(
                                    height: 20,
                                  ),
                                  Row(
                                    children: [
                                      Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            children: [
                                              Text('Website',
                                                  style: TextStyle(
                                                      fontSize: 12,
                                                      color: AppColors.white,
                                                      fontFamily: 'Poppins_SemiBold')),
                                              SizedBox(
                                                width: 2,
                                              ),
                                            ],
                                          ),
                                          Text(
                                            'Freelancer will view your website',
                                            style: TextStyle(
                                                fontSize: 10,
                                                fontFamily: 'Poppins-Light',
                                                color: AppColors.textgrey),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 18,
                                  ),
                                  TextFormField(
                                    style: TextStyle(
                                        fontSize: 14,
                                      color: AppColors.white,
                                    ),
                                    controller: _website,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  bottomNavigationBar: Container(
                    margin: EdgeInsets.all(20),
                    width: double.infinity,
                    child: ElevatedButton(
                        style: OutlinedButton.styleFrom(
                          backgroundColor: AppColors.mainColor,
                        ),
                        onPressed: () {
                          if (!ClientStep2.currentState!.validate()) {
                            return;
                          }
                          _clientProfileStepTwo();
                        },
                        child:isLoading?CircularProgressIndicator(strokeWidth: 1,color: Colors.white,) : Text(
                          'Continue',
                          style: TextStyle(color: Colors.white),
                        )),
                  ),
                ),
                isUserDataIsGeting ? LoadingOverlay():Center()
              ],
            ),
          ),
        ),

    );
  }

  bool isLoading = false;
  void _clientProfileStepTwo() async{
    print("click me");
    setState(() =>isLoading=true);
    if (ClientStep2.currentState!.validate()) {
      var res = await AuthController.ClientProfileStepTwo(
          business_phone: _phone.text,
          business_email: _email.text,
          website: _website.text
      );
      print("response ==== ${res.body}");
      print("response ==== ${res.statusCode}");
      var data = jsonDecode(res.body);
      if(res.statusCode == 200){
        /////////// get user information again
        var userInfo = await AuthController.getUserInfo();
        print("user info ==== ${userInfo.data!.userInfo!.step1Complete}");
        AlertController.snackbar(context: context, text: "Second step complete.", bg: Colors.green);
        Get.to(CreateProfileStep3());
      }else{
        AlertController.snackbar(context: context, text: "${data["message"]}", bg: Colors.red);
      }
    }
    setState(() =>isLoading=false);

  }
}
