
import 'package:coco/appConst.dart';
import 'package:coco/controller/authController.dart';
import 'package:coco/model/authModel/userInfoModel.dart';
import 'package:coco/view/Client/createAccount/addSocialMediLink.dart';
import 'package:coco/view/Client/profile/editProfile.dart';
import 'package:coco/view/client/bottomNagivation/buttom_nav.dart';
import 'package:coco/view/freelancer/profile/UserEditProfile.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:coco/viewController/appLoading.dart';
import 'package:coco/viewController/showAllert.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:keyboard_dismisser/keyboard_dismisser.dart';
import '../../../utility/colors.dart';
import '../../../utility/registation_profile_header.dart';
import '../../freelancer/CreateAccount/addSocialMediLink.dart';

class CreateProfileStep3 extends StatefulWidget {
  final bool isFromEditingScreen;
  final String? role;
  const CreateProfileStep3({super.key,  this.isFromEditingScreen = false, this.role});

  @override
  State<CreateProfileStep3> createState() => _CreateProfileStep3State();
}

class _CreateProfileStep3State extends State<CreateProfileStep3> {
  List list = [
    "facebook", "Instagram", "Youtube", "Tiktok", "Behance", "Dribble", "Vimeo"
  ];

  Map<String, dynamic>? mediasLink;

  var fb, insta, youtube, tiktok;

  Map<String, dynamic>? data;

  Future<UserInformation>? userInfoFuture;


  var profileImage, name, step1Complete;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getUserInfo();
  }

  bool isUserDataIsGeting = false;
  getUserInfo()async{
    setState(() =>isUserDataIsGeting = true);
    var userInfoFuture =await AuthController.getUserInfo();
    setState(() {
      profileImage= userInfoFuture?.data?.profileImage;
      name= userInfoFuture?.data?.name;
      step1Complete = userInfoFuture?.data?.userInfo?.step1Complete;
    });
    setState(() =>isUserDataIsGeting = false);

    return userInfoFuture;
  }
  @override
  Widget build(BuildContext context) {
    return KeyboardDismisser(
      gestures: [GestureType.onTap, GestureType.onPanUpdateDownDirection],
      child: Container(
        color: AppColors.black,
        child: SafeArea(
          child: Stack(
            children: [
              Scaffold(
                backgroundColor: AppColors.black,
                appBar: AppBar(
                  elevation: 0,
                  backgroundColor: AppColors.black,
                  leading: IconButton(
                    onPressed: () =>  Get.back(),
                    icon: Icon(
                      Icons.arrow_back,
                      color: AppColors.black,
                    ),
                  ),
                ),
                body: SingleChildScrollView(
                  child: Column(
                    children: [
                      registation_profile_header(
                        name: '$name', following: '0', follower: '0', image: profileImage,),
                      Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Text(
                                  'Step 3 of 3',
                                  style: TextStyle(
                                      fontSize: 13,
                                      color: AppColors.white,
                                      fontFamily: 'Poppins_SemiBold'
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 15,
                            ),
                            Text(
                              'Social media presence',
                              style: TextStyle(
                                  fontSize: 18,
                                  color: Color(0xFF00CC83),
                                  fontFamily: 'Poppins-Bold'),
                            ),
                            SizedBox(
                              height: 25,
                            ),
                            Row(
                              children: [
                                Text(
                                    'Social media that shows your portfolio',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: AppColors.white,
                                      fontFamily: 'Poppins_SemiBold',
                                    )
                                ),
                                SizedBox(
                                  width: 2,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 8.0),
                                  child: CircleAvatar(
                                    radius: 2,
                                    backgroundColor: Color(0xFF00CC83),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 30,
                            ),
                            SizedBox(
                              height: 80.00*list.length+20,
                              child: ListView.builder(
                                physics: NeverScrollableScrollPhysics(),
                                itemCount: list.length,
                                itemBuilder: (_, index){
                                  return Container(
                                    margin: EdgeInsets.only(bottom: 20),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            width: 2, color: Color(0xFFE6E6E6)),
                                        borderRadius: BorderRadius.circular(10)),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 18.0, vertical: 4),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            '${list[index]}',
                                            style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 13,
                                                color: AppColors.white,
                                                fontFamily: 'Poppins-Bold'),
                                          ),
                                          TextButton(
                                              onPressed: ()async{
                                                addSocialMediaLink(context, list[index]);
                                              },
                                              //onPressed: () =>Get.to(AddSocialMediaLink(listType: "Facebook",), transition: Transition.downToUp),
                                              child: isTrue[index]
                                                  ?Icon(Icons.check_circle, color: AppColors.mainColor,)
                                                  : Text(

                                                'Add link',
                                                style: TextStyle(
                                                    color: Color(0xFF00CC83),
                                                    fontFamily: 'Poppins_SemiBold',
                                                    fontSize: 11,
                                                    fontWeight: FontWeight.bold),
                                              ))
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              ),
                            )

                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                bottomNavigationBar:  Container(
                  margin: EdgeInsets.all(20),
                  child:ElevatedButton(
                      style: OutlinedButton.styleFrom(
                        backgroundColor: Color(0xFF00CC83),
                      ),
                      onPressed: () {
                        submit();
                      },
                      child: isLoading ? CircularProgressIndicator(strokeWidth: 1, color: Colors.white,) : Text(
                        'Continue',
                        style: TextStyle(color: Colors.white),
                      )),
                ),
              ),
              isUserDataIsGeting ? LoadingOverlay():Center()
            ],
          ),
        ),
      ),
    );
  }

  List isTrue= [
    false, false, false, false, false, false, false
  ];
  var fbUr, youtubeUrl, instaUrl, tiktokUrl, behanceUrl, dribbleUrl, vimeoUrl;
  //show selected location
  Future addSocialMediaLink(BuildContext context, item)async{
    // Navigator.push returns a Future that completes after calling
    // Navigator.pop on the Selection Screen.

    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) =>  ClientAddSocialMidiaLink(listType: item,)),
    );
    // When a BuildContext is used from a StatefulWidget, the mounted property
    // must be checked after an asynchronous gap.
    if (!mounted) return;
    print("this is result location $result");
    setState(() {
      //mediaUrl = result;
      if(result["key"] == "Youtube"){
        isTrue[2] = true;
        youtubeUrl = result["value"];
      }
      if(result["key"] == "facebook"){
        isTrue[0] = true;
        fbUr = result["value"];
      }

      if(result["key"] == "Instagram"){
        instaUrl = result["value"];
        isTrue[1] = true;
      }
      if(result["key"] == "Tiktok"){
        tiktokUrl = result["value"];
        isTrue[3] = true;
      }
      if(result["key"] == "Behance"){
        behanceUrl = result["value"];
        isTrue[4] = true;
      }
      if(result["key"] == "Dribble"){
        dribbleUrl = result["value"];
        isTrue[5] = true;
      }
      if(result["key"] == "Vimeo"){
        vimeoUrl = result["value"];
        isTrue[6] = true;
      }
    });
  }

  bool isLoading = false;
  void submit() async{
    setState(() =>isLoading = true);
    print('fbUr === ${fbUr}');
    var res = await AuthController.clientProfileStepThree(
        facebook: fbUr == 'https://' ? 'null' : fbUr ?? 'null',
        instagram: instaUrl == 'https://' ? 'null' : instaUrl ?? 'null',
        youtube: youtubeUrl == 'https://' ? 'null' : youtubeUrl ?? 'null',
        tiktok: tiktokUrl == 'https://' ? 'null' : tiktokUrl ?? 'null',
        behance: behanceUrl == 'https://' ? 'null' : behanceUrl ?? 'null',
        dribble: dribbleUrl == 'https://' ? 'null' : dribbleUrl ?? 'null',
        vimeo: vimeoUrl == 'https://' ? 'null' : vimeoUrl ?? 'null',
    );
    print("res.body === ${res.body}");
    print("res.body === ${res.statusCode}");
    if(res.statusCode==200){
      AlertController.snackbar(context: context, text: "Social media link added.", bg: Colors.green);
      Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context)=>UserEditProfile()), (route) => false);
      // if(widget.isFromEditingScreen == true){
      //   if(widget.role == AppConst.CLIENT_ROLE){
      //     Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context)=>ClientEditProfile()), (route) => false);
      //   }else{
      //     Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context)=>UserEditProfile()), (route) => false);
      //   }
      // }else{
      //   Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context)=>ClientBottomNavigationBar()), (route) => false);
      // }
    }else{
      AlertController.snackbar(context: context, text: "Something went wrong with server.", bg: Colors.red);
    }
    setState(() =>isLoading = false);
  }
}
