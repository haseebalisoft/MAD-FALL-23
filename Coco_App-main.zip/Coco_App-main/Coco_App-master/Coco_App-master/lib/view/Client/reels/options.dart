import 'package:flutter/material.dart';

class OptionsScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          SizedBox(),
          Padding(
            padding: const EdgeInsets.only(left: 15, right: 15),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 300),
                    Row(
                      children: [
                        CircleAvatar(
                          child: Icon(Icons.person, size: 18),
                          radius: 20,
                        ),
                        SizedBox(width: 6),
                        Text('Coco Stories',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                            fontSize: 18
                          ),
                        ),
                        SizedBox(width: 10),
                      ],
                    ),
                    SizedBox(height:10),
                    Text('Flutter is beautiful and fast 💙❤💛 ,,, More',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w400,
                        color: Colors.white
                      ),
                    ),
                    SizedBox(height: 10),
                    Text('2 hours ago',
                      style: TextStyle(
                          fontSize: 9,
                          fontWeight: FontWeight.w400,
                          color: Colors.white
                      ),
                    ),
                  ],
                ),
                Column(
                  children: [
                    InkWell(
                        child: Icon(Icons.favorite_outline, color: Colors.white,)),

                    Text('601k',style: TextStyle(color: Colors.white),),
                    SizedBox(height: 20),
                    Icon(Icons.send, color: Colors.white,),
                    Text('1123',style: TextStyle(color: Colors.white),),

                  ],
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}