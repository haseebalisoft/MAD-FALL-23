import 'package:coco/controller/postController.dart';
import 'package:coco/view/storys/dashboardStory.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get_connect/http/src/response/response.dart';
import '../../../controller/authController.dart';
import '../../../model/postModel/PostModel.dart';
import '../../Posts/singlePost.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  var name, profile;
  getUserInfo()async{
    var userInfo = await AuthController.getUserInfo();
    name = userInfo?.data?.name;
    profile = userInfo?.data?.profileImage;
    setState(() {
      isLoading = false;
    });
  }
  Future<AllPostModel>? getAllPost;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getAllPost = PostController.getAllPost();

    print("I am here");
    getUserInfo();
  }



  bool isLoading = true;

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Container(
      //color: Colors.black,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: AnnotatedRegion<SystemUiOverlayStyle>(
          value: SystemUiOverlayStyle.dark.copyWith(
            statusBarColor: Colors.transparent, // Set the status bar color
            statusBarIconBrightness: Brightness.light, // Set the status bar text color
          ),
          child: Container(

            decoration: BoxDecoration(color: Colors.black),
            child: ListView(
              children: [
                SizedBox(
                  height: 20,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 5.0, right: 5),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: const [
                          // Icon(
                          //   Icons.arrow_back_rounded,
                          //   color: Colors.white,
                          // ),
                          SizedBox(
                            width: 10,
                          ),
                          Text(
                            'Stories',
                            style: TextStyle(
                                color: Color(0xFF00CC83),
                                fontFamily: 'source-sans-pro-bold',
                                fontSize: 14
                            ),
                          ),
                        ],
                      ),


                      // Row(
                      //   children: [
                      //     Icon(
                      //       Icons.arrow_right,
                      //       color: Color(0xFFA1A1A1),
                      //     ),
                      //     Text(
                      //       'View All',
                      //       style: TextStyle(
                      //           color: Colors.white.withOpacity(0.54),   fontFamily: 'source-sans-pro-bold',
                      //           fontSize: 14),
                      //     ),
                      //   ],
                      // )
                    ],
                  ),
                ),
                SizedBox(
                  height: 20,
                ),

                //
                ///TODO: once api is calling we change the value dynamically.
                /////////////this is storey part//////////
                /////////////--------/////////////////////
                DashboardStory(),
                /////////////this is storey part//////////

                Column(
                  children: [
                    // Padding(
                    //   padding: const EdgeInsets.symmetric(vertical: 10.0,horizontal: 10),
                    //   child: Row(
                    //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    //     children: [
                    //       Text(
                    //         'Services',
                    //         style: TextStyle(color: Color(0xFF00CC83),
                    //             fontFamily: 'source-sans-pro-bold',
                    //             fontSize: 14
                    //         ),
                    //       ),
                    //       Row(
                    //         children: [
                    //           Icon(
                    //             Icons.arrow_right,
                    //             color: Colors.white.withOpacity(0.54),
                    //           ),
                    //           Text(
                    //             'View All',
                    //             style: TextStyle(
                    //                 color: Colors.white.withOpacity(0.54),   fontFamily: 'source-sans-pro-bold',
                    //                 fontSize: 14),
                    //           )
                    //         ],
                    //       ),
                    //     ],
                    //   ),
                    // ),

                    //// this is service text list /////
                    // SizedBox(
                    //   height: 30,
                    //   child: ListView.builder(
                    //     itemCount: 20,
                    //     scrollDirection: Axis.horizontal,
                    //     itemBuilder: (_, index) {
                    //       return buildSingleServiceList(
                    //           text: "Photographer",
                    //           color: service.contains(index)
                    //               ? Colors.white
                    //               : Colors.transparent,
                    //           textColor: service.contains(index)
                    //               ? Colors.black
                    //               : Colors.white,
                    //           onClick: () {
                    //             setState(() {
                    //               service.clear(); //first we clear all
                    //               service.add(index); //then add the unick index
                    //             });
                    //           });
                    //     },
                    //   ),
                    // ),
                    /////-----------///

                    SizedBox(
                      height: 30,
                    ),
                    // SizedBox(
                    //   child: ListView.builder(
                    //     physics: NeverScrollableScrollPhysics(),
                    //     shrinkWrap: true,
                    //     itemCount: AppJson.serviceForHome.length,
                    //     itemBuilder: (_, index) {
                    //       var data = AppJson.serviceForHome[index];
                    //       return SingleServiceDashboard(
                    //         size: size,
                    //         name: "${data["name"]}",
                    //         profile: "${data['profile']}",
                    //         amount: "${data["left"]}",
                    //         bgImage: AssetUtils.post_2,
                    //         onClick: () {
                    //           print("cleck profile");
                    //           Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientBottomNavigationBar(pageIndex: 5, userId: "1",)));
                    //         },
                    //         isCollabration: true,
                    //         category: '${data["category"]}',
                    //         isPrice: true ,
                    //       );
                    //     },
                    //   ),
                    // )
                    FutureBuilder<AllPostModel>(
                        future: getAllPost,
                        builder: (context, snapshot) {
                          if(snapshot.connectionState == ConnectionState.waiting){
                            return Center(child: CircularProgressIndicator(color: Colors.white,),);
                            // return ListView.builder(
                            //   itemCount: 5,
                            //   physics: NeverScrollableScrollPhysics(),
                            //   shrinkWrap: true,
                            //   itemBuilder: (_, index){
                            //     return Padding(
                            //       padding: const EdgeInsets.only(bottom: 20),
                            //       child: Shimmer.fromColors(
                            //         baseColor: Colors.grey.shade300,
                            //         highlightColor: Colors.grey.shade200,
                            //         child: Container(
                            //           width: size.width,
                            //           height: 450,
                            //           color: Colors.white,
                            //         ),
                            //       ),
                            //     );
                            //   },
                            // );
                          }else if(snapshot.hasData){
                            return ListView.builder(
                              itemCount: snapshot.data!.data!.length,
                              physics: NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              itemBuilder: (_, index){
                                print("snapshot.data!.data![index]!.userData![0]!.id == ${snapshot.data!.data![index]!.userData![0]!.id}");
                                return SinglePost(
                                  userName: snapshot.data!.data![index]!.userData![0]!.name ?? "",
                                  userImage: snapshot.data!.data![index]!.userData![0]!.profileImage,
                                  singlePost: snapshot.data!.data![index],
                                  isLiked: snapshot.data!.data![index]!.isLiked,
                                  isFav: snapshot.data!.data![index]!.isFav,

                                );
                              },
                            );
                          }else{
                            return const Center(
                              child: Text("No post found"),
                            );
                          }
                        }
                    )
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  //this is the single service method.
  ///TODO: once api is calling we change the value dynamically
  //
  List service = [0];
  InkWell buildSingleServiceList(
      {required String text,
        required Color color,
        required Color textColor,
        required VoidCallback onClick}) {
    return InkWell(
      onTap: onClick,
      child: Container(
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(50),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 20),
            child: Text(
              text,
              style: TextStyle(color: textColor,fontFamily: ' Poppins-Bold',fontSize: 11,fontWeight: FontWeight.bold),
            ),
          ),
        ),
      ),
    );
  }
//we can use it any where in this file.
}

