
import 'package:coco/controller/authController.dart';
import 'package:coco/controller/camera_gallery_controller/cameraGalleryController.dart';
import 'package:coco/controller/locationController.dart';
import 'package:coco/model/authModel/userInfoModel.dart';
import 'package:coco/model/service/filterServiceModel.dart';
import 'package:coco/model/service/serviceModel.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/view/profile/followingFollower.dart';
import 'package:coco/view/profile/myProfile.dart';
import 'package:coco/viewController/uploadVideoPreviews.dart';
import 'package:coco/viewController/uploadphotos_videos.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:wechat_assets_picker/wechat_assets_picker.dart';

import '../../../helper/helperFunctions.dart';
import '../../../utility/appAssets.dart';
import '../../client/profile/freelancerProfileDetails.dart';
import '../../freelancer/uploadPortfolio/PickerCropResultScreen.dart';
import '../../location/location_map.dart';
import '../../location/not_used_location.dart';
import '../../profile/profileSetting.dart';
import '../../search/searchFreelancerClientProfile.dart';
import '../../search/searchFreelancerClientProfileNotUsed.dart';
import '../dashboard/dashboard.dart';
import 'dart:io' show Platform;
import '../../storys/clientStory.dart';

class ClientBottomNavigationBar extends StatefulWidget {
  final dynamic ownFollowList;
  final int pageIndex;
  final int pageInderForFollowing;
  final String ? ProfileUserId;
  final dynamic userId;
  final List<FilterServiceList>? serviceListFromFilter;

  const ClientBottomNavigationBar({
    super.key,
    this.pageIndex = 0,
    this.userId,
    this.ownFollowList = true,
    this.pageInderForFollowing = 0,
    this.ProfileUserId,
    this.serviceListFromFilter
  });

  @override
  State<ClientBottomNavigationBar> createState() => _ClientBottomNavigationBarState();
}

class _ClientBottomNavigationBarState extends State<ClientBottomNavigationBar> {
  late String _role;
  Future<UserInformation>? getUserInfoFuture;



  int page_index = 0;
  var userId;
  final List<Widget> _screens = [
    Dashboard(),//index0
    ///////// it add into initial state //index1
    LocationMap(), //index 2
    MyProfile(),// (), //index 3
    ////// 5 no index come /////

    ClientStory(), //index 8
    ProfileSetting(),//
  ];

  bool hometap = false;
  bool searchtap = false;
  bool locationtap = false;
  bool boxtap = false;
  bool istap = true;




  @override
  void initState() {
    super.initState();
    getLocationLatLng();
    setState(() {
      _screens.insert(5, FreelancerProfileDetails(userId: '${widget.userId??"1"}',)); //index 7);
      _screens.insert(1, SearchFreelancerClientProfile(service: '${widget.userId}', serviceListFromFilter: widget.serviceListFromFilter,)); //index 7);
      _screens[4] = FollowingFollowers(ownFollowList: widget.ownFollowList, userId: widget.userId.toString(), initPage: widget.pageInderForFollowing,);//index 4
      page_index = widget.pageIndex!;
      userId = widget.userId;
      getUserInfoFuture = AuthController.getUserInfo();

    });




    print("page_index === ${widget.pageIndex!}");
    print("page_index === ${_screens[widget.pageIndex!]}");
  }


  getLocationLatLng() async {
    HelperFunction.locationData().then((value) {
      setState(() {
        lat = value.latitude;
        lng = value.longitude;
      });
      updateLatLng();
    });
  }
  var lat, lng;
  updateLatLng()async{
    print("dasfadsfasd");
    var res = await AuthController.updateLatLong(lat: lat.toString(), lng: lng.toString());
    print("res.body == ${res.body}");
    print("res.body == ${res.statusCode}");
    if(res.statusCode == 200){
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: _screens[page_index],
      bottomNavigationBar:   FutureBuilder<UserInformation>(
          future: getUserInfoFuture,
          builder: (context, snapshot) {
         if(snapshot.connectionState ==true){
           return Container(
             padding: const EdgeInsets.only(top: 5, bottom: 0, ),
             decoration: BoxDecoration(color: AppColors.black, boxShadow: [
               BoxShadow(
                   color: Color(0xFFA1A1A1).withOpacity(0.5),
                   blurRadius: 20,
                   offset: Offset(5, 10),
                   spreadRadius: 0.1,
                   blurStyle: BlurStyle.normal)
             ]),
             height: Platform.isIOS ? 75 : 61,
             child: Row(
               mainAxisAlignment: MainAxisAlignment.spaceBetween,
               children: [
                 InkWell(
                   onTap: () {
                     page_index = 0;
                     if (mounted) {
                       setState(() {});
                     }
                   },
                   child: Padding(
                     padding: const EdgeInsets.all(15.0),
                     child: Column(
                       children: [
                         SvgPicture.asset(
                           AssetUtils.nav_bar,
                           width: 16,
                         ),
                         SizedBox(
                           height: 2,
                         ),
                         page_index == 0
                             ? CircleAvatar(
                           backgroundColor: Color(0xFF00CC83),
                           radius: 3,
                         )
                             : SizedBox(
                         )
                       ],
                     ),
                   ),
                 ),
                 InkWell(
                   onTap: () {
                     page_index = 1;
                     if (mounted) {
                       setState(() {});
                     }
                   },
                   child: Padding(
                     padding: const EdgeInsets.all(15.0),
                     child: Column(
                       children: [
                         SvgPicture.asset(
                           AssetUtils.nav_search,
                           width: 16,
                         ),
                         SizedBox(
                           height: 2,
                         ),
                         page_index == 1
                             ? CircleAvatar(
                           backgroundColor: Color(0xFF00CC83),
                           radius: 3,
                         )
                             : SizedBox(

                         )
                       ],
                     ),
                   ),
                 ),
                 InkWell(
                   onTap: ()=>CameraGalleryController.pickGalleryAndCameraForPost(context: context),
                   child: Container(
                     height: 24,
                     width: 25,
                     margin:  EdgeInsets.only(bottom:  Platform.isIOS ? 33 :8),
                     // padding: EdgeInsets.all(6),
                     decoration: BoxDecoration(
                         border: Border.all(width: 1.5, color:AppColors.white),
                         borderRadius: BorderRadius.circular(3)
                     ),
                     child: const Center(child: Icon(Icons.add, size: 18,color: AppColors.white,)),
                   ),
                 ),
                 InkWell(
                   onTap: () {
                     page_index = 2;
                     if (mounted) {
                       setState(() {});
                     }
                   },
                   child: Padding(
                     padding: const EdgeInsets.all(15.0),
                     child: Column(
                       children: [
                         SvgPicture.asset(
                           AssetUtils.nav_location,
                           width: 13.5,
                         ),
                         SizedBox(
                           height: 2,
                         ),
                         page_index == 2
                             ? CircleAvatar(
                           backgroundColor: Color(0xFF00CC83),
                           radius: 3,
                         )
                             : SizedBox(

                         )
                       ],
                     ),
                   ),
                 ),


                 InkWell(
                   onTap: () {
                     page_index = 3;
                     if (mounted) {
                       setState(() {});
                     }
                   },
                   child: Padding(
                     padding: const EdgeInsets.only(bottom: 15.0),
                     child: CircleAvatar(
                       radius: 15,
                       child: ClipOval(
                         child: Image.asset(
                           AssetUtils.logoPng,
                           width: double.infinity,
                           height: double.infinity,
                         ),
                       ),
                     ),
                   ),
                 ),

                 SizedBox(
                   width: 1,
                 )
               ],
             ),
           );
         }
         else if(snapshot.hasData){
           //print("snapshot.data!.data!.profileImage == ${snapshot.data!.data!.profileImage}");

           // Save user profile  to shared preferred
          HelperFunction.saveUserProfilePic(snapshot.data!.data!.profileImage ?? "");
          HelperFunction.saveUserID(snapshot.data!.data!.id.toString() ?? "");

           return Container(
             padding: const EdgeInsets.only(top: 5, bottom: 0, ),
             decoration: BoxDecoration(color: AppColors.black, boxShadow: [
               BoxShadow(
                   color: Color(0xFFA1A1A1).withOpacity(0.5),
                   blurRadius: 20,
                   offset: Offset(5, 10),
                   spreadRadius: 0.1,
                   blurStyle: BlurStyle.normal)
             ]),
             height: Platform.isIOS ? 75 : 61,
             child: Row(
               mainAxisAlignment: MainAxisAlignment.spaceBetween,
               children: [
                 InkWell(
                   onTap: () {
                     page_index = 0;
                     if (mounted) {
                       setState(() {});
                     }
                   },
                   child: Padding(
                     padding: const EdgeInsets.all(15.0),
                     child: Column(
                       children: [
                         SvgPicture.asset(
                           AssetUtils.nav_bar,
                           width: 16,
                         ),
                         SizedBox(
                           height: 2,
                         ),
                         page_index == 0
                             ? CircleAvatar(
                           backgroundColor: Color(0xFF00CC83),
                           radius: 3,
                         )
                             : SizedBox(
                         )
                       ],
                     ),
                   ),
                 ),
                 InkWell(
                   onTap: () {
                     page_index = 1;
                     if (mounted) {
                       setState(() {});
                     }
                   },
                   child: Padding(
                     padding: const EdgeInsets.all(15.0),
                     child: Column(
                       children: [
                         SvgPicture.asset(
                           AssetUtils.nav_search,
                           width: 16,
                         ),
                         SizedBox(
                           height: 2,
                         ),
                         page_index == 1
                             ? CircleAvatar(
                           backgroundColor: Color(0xFF00CC83),
                           radius: 3,
                         )
                             : SizedBox(

                         )
                       ],
                     ),
                   ),
                 ),
                 InkWell(
                   onTap: ()=>CameraGalleryController.pickGalleryAndCameraForPost(context: context),
                   child: Container(
                     height: 24,
                     width: 25,
                     margin:  EdgeInsets.only(bottom:  Platform.isIOS ? 33 :8),
                     // padding: EdgeInsets.all(6),
                     decoration: BoxDecoration(
                         border: Border.all(width: 1.5, color: AppColors.white),
                         borderRadius: BorderRadius.circular(3)
                     ),
                     child: const Center(child: Icon(Icons.add, size: 18,color: AppColors.white,)),
                   ),
                 ),
                 InkWell(
                   onTap: () {
                     page_index = 2;
                     if (mounted) {
                       setState(() {});
                     }
                   },
                   child: Padding(
                     padding: const EdgeInsets.all(15.0),
                     child: Column(
                       children: [
                         SvgPicture.asset(
                           AssetUtils.nav_location,
                           width: 13.5,
                         ),
                         SizedBox(
                           height: 2,
                         ),
                         page_index == 2
                             ? CircleAvatar(
                           backgroundColor: Color(0xFF00CC83),
                           radius: 3,
                         )
                             : SizedBox(

                         )
                       ],
                     ),
                   ),
                 ),


                 InkWell(
                   onTap: () {
                     page_index = 3;
                     if (mounted) {
                       setState(() {});
                     }
                   },
                   child: Padding(
                     padding: const EdgeInsets.only(bottom: 15.0),
                     child: CircleAvatar(
                       radius: 15,
                       child: ClipOval(
                         child:  snapshot.data!.data!.profileImage != null ? Image.network(
                           snapshot.data?.data?.profileImage,
                           fit: BoxFit.cover,
                           width: double.infinity,
                           height: double.infinity,
                         ) : Image.asset(
                           AssetUtils.logoPng,
                           width: double.infinity,
                           height: double.infinity,
                         ),
                       ),
                     ),
                   ),
                 ),

                 SizedBox(
                   width: 1,
                 )
               ],
             ),
           );
         }else{
           return Container(
             padding: const EdgeInsets.only(top: 5, bottom: 0, ),
             decoration: BoxDecoration(color: AppColors.black, boxShadow: [
               BoxShadow(
                   color: Color(0xFFA1A1A1).withOpacity(0.5),
                   blurRadius: 20,
                   offset: Offset(5, 10),
                   spreadRadius: 0.1,
                   blurStyle: BlurStyle.normal)
             ]),
             height: Platform.isIOS ? 75 : 61,
             child: Row(
               mainAxisAlignment: MainAxisAlignment.spaceBetween,
               children: [
                 InkWell(
                   onTap: () {
                     page_index = 0;
                     if (mounted) {
                       setState(() {});
                     }
                   },
                   child: Padding(
                     padding: const EdgeInsets.all(15.0),
                     child: Column(
                       children: [
                         SvgPicture.asset(
                           AssetUtils.nav_bar,
                           width: 16,
                         ),
                         SizedBox(
                           height: 2,
                         ),
                         page_index == 0
                             ? CircleAvatar(
                           backgroundColor: Color(0xFF00CC83),
                           radius: 3,
                         )
                             : SizedBox(
                         )
                       ],
                     ),
                   ),
                 ),
                 InkWell(
                   onTap: () {
                     page_index = 1;
                     if (mounted) {
                       setState(() {});
                     }
                   },
                   child: Padding(
                     padding: const EdgeInsets.all(15.0),
                     child: Column(
                       children: [
                         SvgPicture.asset(
                           AssetUtils.nav_search,
                           width: 16,
                         ),
                         SizedBox(
                           height: 2,
                         ),
                         page_index == 1
                             ? CircleAvatar(
                           backgroundColor: Color(0xFF00CC83),
                           radius: 3,
                         )
                             : SizedBox(

                         )
                       ],
                     ),
                   ),
                 ),
                 InkWell(
                   onTap: ()=>CameraGalleryController.pickGalleryAndCameraForPost(context: context),
                   child: Container(
                     height: 24,
                     width: 25,
                     margin:  EdgeInsets.only(bottom:  Platform.isIOS ? 33 :8),
                     // padding: EdgeInsets.all(6),
                     decoration: BoxDecoration(
                         border: Border.all(width: 1.5, color: AppColors.white),
                         borderRadius: BorderRadius.circular(3)
                     ),
                     child: const Center(child: Icon(Icons.add, size: 18,color:  AppColors.white,)),
                   ),
                 ),
                 InkWell(
                   onTap: () {
                     page_index = 2;
                     if (mounted) {
                       setState(() {});
                     }
                   },
                   child: Padding(
                     padding: const EdgeInsets.all(15.0),
                     child: Column(
                       children: [
                         SvgPicture.asset(
                           AssetUtils.nav_location,
                           width: 13.5,
                         ),
                         SizedBox(
                           height: 2,
                         ),
                         page_index == 2
                             ? CircleAvatar(
                           backgroundColor: Color(0xFF00CC83),
                           radius: 3,
                         )
                             : SizedBox(

                         )
                       ],
                     ),
                   ),
                 ),

                 InkWell(
                   onTap: () {
                     page_index = 3;
                     if (mounted) {
                       setState(() {});
                     }
                   },
                   child: Padding(
                     padding: const EdgeInsets.only(bottom: 15.0),
                     child: CircleAvatar(
                       radius: 15,
                       child: ClipOval(
                         child: Image.asset(
                           AssetUtils.logoPng,
                           fit: BoxFit.cover,
                           width: double.infinity,
                           height: double.infinity,
                         ),
                       ),
                     ),
                   ),
                 ),

                 SizedBox(
                   width: 1,
                 )
               ],
             ),
           );
         }
        }
      ),
    );
  }




}
