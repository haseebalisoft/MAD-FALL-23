import 'package:coco/appConst.dart';
import 'package:coco/controller/authController.dart';
import 'package:coco/model/ClientAboutModel.dart';
import 'package:coco/model/FreelancerModel.dart';
import 'package:coco/model/authModel/userAboutMe.dart';
import 'package:coco/utility/colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'Equipments.dart';

class AboutMeSection extends StatefulWidget {
  String UserId;
  AboutMeSection({super.key, required this.UserId});

  @override
  State<AboutMeSection> createState() => _AboutMeSectionState();
}

class _AboutMeSectionState extends State<AboutMeSection> {

  Future<FreelancerModel>? profileAbout;
  Future<ClientAboutMe>? ClientAbout;


  @override
  void initState() {
    // TODO: implement initState


    super.initState();
    getRole();
    profileAbout = AuthController.profileAboutMe(widget.UserId);
    ClientAbout = AuthController.clientAbout(widget.UserId);

  }


  String? role;

  getRole() async {
    SharedPreferences _pref = await SharedPreferences.getInstance();
    setState(() {
      role = _pref.getString("role");
    });
  }




  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return  role == AppConst.CLIENT_ROLE ? FutureBuilder<FreelancerModel>(
        future: profileAbout,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: Container(
                width: 50,
                height: 50,
                color: Colors.black,
                child: CircularProgressIndicator(
                  color: AppColors.white,
                ),
              ),
            );
          } else if (snapshot.hasData) {
            print( "snapshot.data!.data == ${snapshot.data!.data}");
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                      Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Services',
                              style: TextStyle(
                                  color: Color(0xff00CC83),
                                  fontSize: 15,
                                  fontFamily: 'SourceSansPro-Semibold'),
                            ),
                            Container(
                              height: 35,
                              child: ListView.builder(
                                scrollDirection: Axis.horizontal,
                                itemCount:
                                    snapshot.data?.data?.serviceName?.length,
                                itemBuilder: (_, index) {
                                  return Container(
                                    margin: EdgeInsets.all(4),
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(50),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.grey.withOpacity(0.2),
                                          spreadRadius: 1,
                                          blurRadius: 2,
                                          offset: Offset(1,
                                              1), // changes position of shadow
                                        ),
                                      ],
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 20.0, vertical: 5),
                                      child: Text(
                                        '${snapshot.data?.data?.serviceName?[index].name}',
                                        style: TextStyle(
                                            fontFamily: 'Poppins-Medium',
                                            fontSize: 11),
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                          ],
                        ),

                  // role == AppConst.FREELANCER_ROLE ?

                  snapshot.data!.data!.equipmentsName != null &&
                      snapshot.data!.data!.user!.role == AppConst.FREELANCER_ROLE
                      ? Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Equipment',
                              style: TextStyle(
                                  color: Color(0xff00CC83),
                                  fontSize: 15,
                                  fontFamily: 'SourceSansPro-Semibold'),
                            ),
                            Row(
                              mainAxisAlignment:
                                  MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                 // width: size.width * .27 * snapshot.data!.data?.equipmentsName?.length,
                                  child: SizedBox(
                                    height: 35,
                                    child: ListView.builder(
                                      shrinkWrap: true,
                                        scrollDirection: Axis.horizontal,
                                        itemCount: snapshot.data?.data?.equipmentsName?.length,
                                        itemBuilder: (_, index) {
                                          return Container(
                                            margin: EdgeInsets.all(4),
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius: BorderRadius.circular(50),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.grey.withOpacity(0.2),
                                                  spreadRadius: 1,
                                                  blurRadius: 2,
                                                  offset: Offset(1,
                                                      1), // changes position of shadow
                                                ),
                                              ],
                                            ),
                                            child: Padding(
                                              padding: const EdgeInsets.symmetric(
                                                  horizontal: 20.0, vertical: 5),
                                              child: Text(
                                                '${snapshot.data?.data?.equipmentsName?[index].name}',
                                                style: TextStyle(
                                                    fontFamily: 'Poppins-Medium',
                                                    fontSize: 11),
                                              ),
                                            ),
                                          );
                                        }),
                                  ),
                                )
                              ],
                            ),

                            SizedBox(
                              height: 20,
                            ),
                            SizedBox(
                              width: double.infinity,
                              child: OutlinedButton(
                                style: OutlinedButton.styleFrom(
                                  side: BorderSide(
                                      width: 1.5, color: Color(0xff4AC07C)),
                                ),
                                onPressed: () {
                                  Navigator.push(context, MaterialPageRoute(builder: (context)=>Equipments(equipments: snapshot.data?.data!.equipmentsName,)));
                                },
                                child: Text(
                                  '+View full equipment list here',
                                  style: TextStyle(
                                    color: Color(0xff4AC07C),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 20,
                            ),
                          ],
                        )
                      : SizedBox(
                          height: 0,
                        ),


                  snapshot.data!.data!.location != null? Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Location',
                        style: TextStyle(
                            color: Color(0xff00CC83),
                            fontSize: 15,
                            fontFamily: 'SourceSansPro-Semibold'),
                      ),
                      SizedBox(
                        height: 2,
                      ),
                      Text(
                        '${snapshot.data!.data!.location!.address != null ? snapshot.data!.data!.location!.address : ''},${snapshot.data!.data!.location!.city != null ? snapshot.data!.data!.location!.city : ''},${snapshot.data!.data!.location!.state != null ? snapshot.data!.data!.location!.state : ''},${snapshot.data!.data!.location!.country != null ? snapshot.data!.data!.location!.country : ''}',
                        style: TextStyle(
                          color: Colors.white,
                            fontSize: 16, fontFamily: 'source-sans-pro-regular'),
                      ),

                    ],
                  ):Center(),

                  SizedBox(
                    height: 30,
                  ),
                  Text(
                    'Social media',
                    style: TextStyle(
                        color: Color(0xff00CC83),
                        fontSize: 15,
                        fontFamily: 'SourceSansPro-Semibold'),
                  ),
                  SizedBox(
                    height: 5,
                  ),

                  snapshot!.data!.data!.socialLink != null
                      ? Row(
                          children: [
                            snapshot!.data!.data!.socialLink!.instagram != 'null'
                                ? Row(
                                  children: [
                                    InkWell(
                                      onTap: (){
                                        print(snapshot.data!.data!.socialLink!.instagram!);
                                        if(snapshot.data!.data!.socialLink!.instagram!.contains("https://")){
                                          launchUrl(Uri.parse("${snapshot.data!.data!.socialLink!.instagram!}"));
                                        }else{
                                          launchUrl(Uri.parse("https://${snapshot.data!.data!.socialLink!.instagram!}"));
                                        }
                                      },
                                      child: Image.asset(
                                          'asset/image/insta.png',
                                          width: 45,
                                          height: 45,
                                        ),
                                    ),
                                    SizedBox(
                                      width: 20,
                                    ),
                                  ],
                                )
                                : SizedBox(
                                    width: 0,
                                  ),
                            snapshot!.data!.data!.socialLink!.youtube != 'null'
                                ? Row(
                                    children: [
                                      InkWell(
                                        onTap: (){
                                          if(snapshot.data!.data!.socialLink!.youtube!.contains("https://")){
                                            launchUrl(Uri.parse("${snapshot.data!.data!.socialLink!.youtube!}"));
                                          }else{
                                            launchUrl(Uri.parse("https://${snapshot.data!.data!.socialLink!.youtube!}"));
                                          }
                                        },
                                        child: Image.asset(
                                          'asset/image/youtube.png',
                                          width: 45,
                                          height: 45,
                                        ),
                                      ),
                                      SizedBox(
                                        width: 20,
                                      ),
                                    ],
                                  )
                                : SizedBox(
                                    width: 0,
                                  ),
                            snapshot!.data!.data!.socialLink!.behance != 'null'
                                ? Row(
                                    children: [
                                      InkWell(
                                        onTap: (){
                                          if(snapshot.data!.data!.socialLink!.behance!.contains("https://")){
                                            launchUrl(Uri.parse("${snapshot.data!.data!.socialLink!.behance!}"));
                                          }else{
                                            launchUrl(Uri.parse("https://${snapshot.data!.data!.socialLink!.behance!}"));
                                          }
                                        },
                                        child: Image.asset(
                                          'asset/image/bain.png',
                                          width: 45,
                                          height: 45,
                                        ),
                                      ),
                                      SizedBox(
                                        width: 20,
                                      ),
                                    ],
                                  )
                                : SizedBox(
                                    width: 0,
                                  ),
                          ],
                        )
                      : SizedBox(
                          height: 0,
                        ),
                  SizedBox(
                    height: 20,
                  )
                ],
              ),
            );
          } else {
            return Center(
              child: Text("Check your internet connection ${snapshot.error}"),
            );
          }
        }) : FutureBuilder<ClientAboutMe>(
        future: ClientAbout,
        builder: (context, snapshot) {
          print('about data ========  ${snapshot.data}');
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: Container(
                width: 50,
                height: 50,
                color: Colors.black,
                child: CircularProgressIndicator(
                  color: AppColors.white,
                ),
              ),
            );
          } else if (snapshot.hasData) {
            print(snapshot.data!.data);
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                 Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Business',
                        style: TextStyle(
                            color: Color(0xff00CC83),
                            fontSize: 15,
                            fontFamily: 'SourceSansPro-Semibold'),
                      ),
                      Container(
                        height: 35,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount:
                          snapshot.data?.data?.businessName?.length,
                          itemBuilder: (_, index) {
                            return Container(
                              margin: EdgeInsets.all(4),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(50),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.withOpacity(0.2),
                                    spreadRadius: 1,
                                    blurRadius: 2,
                                    offset: Offset(1,
                                        1), // changes position of shadow
                                  ),
                                ],
                              ),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 20.0, vertical: 5),
                                child: Text(
                                  '${snapshot.data?.data?.businessName?[index].name}',
                                  style: TextStyle(
                                      fontFamily: 'Poppins-Medium',
                                      fontSize: 11),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                    ],
                  ),
                  snapshot.data!.data!.location != null? Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Location',
                        style: TextStyle(
                            color: Color(0xff00CC83),
                            fontSize: 15,
                            fontFamily: 'SourceSansPro-Semibold'),
                      ),
                      SizedBox(
                        height: 2,
                      ),
                      Text(
                        '${snapshot.data!.data!.location!.address != null ? snapshot.data!.data!.location!.address : ''},${snapshot.data!.data!.location!.city != null ? snapshot.data!.data!.location!.city : ''},${snapshot.data!.data!.location!.state != null ? snapshot.data!.data!.location!.state : ''},${snapshot.data!.data!.location!.country != null ? snapshot.data!.data!.location!.country : ''}',
                        style: TextStyle(
                          color: Colors.white,
                            fontSize: 16, fontFamily: 'source-sans-pro-regular'),
                      ),

                    ],
                  ):Center(),
                  SizedBox(
                    height: 30,
                  ),
              snapshot!.data!.data!.socialLink != null
                  ?  Column(
                   children: [
                     Text(
                       'Social media',
                       style: TextStyle(
                           color: Color(0xff00CC83),
                           fontSize: 15,
                           fontFamily: 'SourceSansPro-Semibold'),
                     ),
                     SizedBox(
                       height: 5,
                     ),
                     Row(
                       children: [
                         snapshot!.data!.data!.socialLink!.instagram != 'null'
                             ? Row(
                           children: [
                             InkWell(
                               onTap: (){
                                 launchUrl(Uri.parse("${snapshot.data!.data!.socialLink!.instagram!}"));
                               },
                               child: Image.asset(
                                 'asset/image/insta.png',
                                 width: 45,
                                 height: 45,
                               ),
                             ),
                             SizedBox(
                               width: 20,
                             ),
                           ],
                         )
                             : SizedBox(
                           width: 0,
                         ),
                         snapshot!.data!.data!.socialLink!.youtube != 'null'
                             ? Row(
                           children: [
                             InkWell(
                               onTap: (){
                                 launchUrl(Uri.parse("${snapshot.data!.data!.socialLink!.youtube!}"));
                               },
                               child: Image.asset(
                                 'asset/image/youtube.png',
                                 width: 45,
                                 height: 45,
                               ),
                             ),
                             SizedBox(
                               width: 20,
                             ),
                           ],
                         )
                             : SizedBox(
                           width: 0,
                         ),
                         snapshot!.data!.data!.socialLink!.behance != 'null'
                             ? Row(
                           children: [
                             InkWell(
                               onTap: (){
                                 launchUrl(Uri.parse("${snapshot.data!.data!.socialLink!.behance}"));
                               },
                               child: Image.asset(
                                 'asset/image/bain.png',
                                 width: 45,
                                 height: 45,
                               ),
                             ),
                             SizedBox(
                               width: 20,
                             ),
                           ],
                         )
                             : SizedBox(
                           width: 0,
                         ),
                         snapshot!.data!.data!.socialLink!.dribble != 'null'
                             ? Row(
                           children: [
                             InkWell(
                               onTap: (){
                                 launchUrl(Uri.parse("${snapshot.data!.data!.socialLink!.instagram!}"));
                               },
                               child: Image.asset(
                                 'asset/image/linkdin.png',
                                 width: 45,
                                 height: 45,
                               ),
                             ),
                             SizedBox(
                               width: 20,
                             ),
                           ],
                         )
                             : SizedBox(
                           width: 0,
                         )
                       ],
                     ),
                   ],
              ) : SizedBox(
                    height: 0,
                  ),
                  SizedBox(
                    height: 20,
                  )
                ],
              ),
            );
          } else {
            return Center(
              child: Text("Check your internet connection ${snapshot.error}"),
            );
          }
        });
  }
}
