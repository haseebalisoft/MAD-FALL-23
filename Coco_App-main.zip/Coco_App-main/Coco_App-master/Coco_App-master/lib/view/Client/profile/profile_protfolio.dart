import 'package:coco/controller/camera_gallery_controller/cameraGalleryController.dart';
import 'package:coco/controller/postController.dart';
import 'package:coco/model/postModel/PostModel.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/view/freelancer/uploadPortfolio/PickerCropResultScreen.dart';
import 'package:coco/view/profile/singleUserPortfolio/singleUserPost.dart';
import 'package:coco/viewController/appNetworkImage.dart';
import 'package:coco/viewController/uploadphotos_videos.dart';
import 'package:coco/viewController/video_player/video_thumblin.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:path/path.dart' as p;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shimmer/shimmer.dart';
import 'package:video_thumbnail_imageview/video_thumbnail_imageview.dart';
import 'package:wechat_assets_picker/wechat_assets_picker.dart';




class ProfileProtfolio extends StatefulWidget {
  final String? postUserId;
  ProfileProtfolio({this.postUserId});

  @override
  State<ProfileProtfolio> createState() => _ProfileProtfolioState();
}

class _ProfileProtfolioState extends State<ProfileProtfolio> {

  Future<AllPostModel>? getAllPost;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getAllPostByUser();
  }

  var userId;
  var videoThumblin;
  getAllPostByUser()async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var userId = _pref.getString("user_id");
    print("userId => ");
    print(userId.toString());
    getAllPost = PostController.getPostByUser(userId.toString());
    setState((){});

    return getAllPost;
  }


  @override
  Widget build(BuildContext context) {
    return FutureBuilder<AllPostModel>(
        future: getAllPost,
        builder: (context, snapshot) {
          if(snapshot.connectionState == ConnectionState.waiting){
            return Padding(
              padding: const EdgeInsets.all(16.0),
              child: GridView.builder(
                shrinkWrap: true,
                itemCount: 6,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisExtent: 180,
                  mainAxisSpacing: 5,
                  crossAxisSpacing: 5,
                ),
                physics: const NeverScrollableScrollPhysics(),
                itemBuilder: (BuildContext context, int index) {
                  return Shimmer.fromColors(
                      baseColor: Colors.grey.withOpacity(0.2),
                      highlightColor: Colors.grey.withOpacity(0.1),
                      child:  ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Container(height: 250, width: 120, color: Colors.white,),
                      )
                  );
                },
              ),
            );
          }else if(snapshot.hasData){
            print("snapshot.data?.data?.length => ");
            print(snapshot.data?.data?.length);
            print(snapshot.data?.data?.length != 0);
            print(snapshot.data?.data?.length != null);

            return snapshot.data?.data?.length!=0 && snapshot.data?.data?.length != null
                ? Padding(
              padding: const EdgeInsets.all(16.0),
              child: GridView.builder(
                shrinkWrap: true,
                itemCount: snapshot.data?.data?.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisExtent: 180,
                  mainAxisSpacing: 5,
                  crossAxisSpacing: 5,
                ),
                physics: const NeverScrollableScrollPhysics(),
                itemBuilder: (BuildContext context, int index) {

                  return p.extension(snapshot.data!.data![index]!.image![0].image.toString()) != ".mp4"
                      ? buildSinglePortfolio(
                    //onClick: ()=>Get.to(Users_Posts()),
                      onClick: ()=>Get.to(SingleUserPost(
                          userId: snapshot.data!.data![index]!.userData![0]!.id.toString(),
                          userName: snapshot.data!.data![index]!.post!.userId.toString(),
                          userImage: snapshot.data!.data![index]!.userData![0]!.profileImage ?? "")),
                      imagePath: "${snapshot.data!.data![index]!.image!.isEmpty
                          ? "https://upload.wikimedia.org/wikipedia/commons/thumb/6/65/No-Image-Placeholder.svg/1665px-No-Image-Placeholder.svg.png"
                          : snapshot.data!.data![index]!.image![0]!.image}"
                  ):

                  // InkWell(
                  //     onTap: ()=>Get.to(SingleUserPost(
                  //         userId: snapshot.data!.data![index]!.userData![0]!.id.toString(),
                  //         userName: snapshot.data!.data![index]!.post!.userId.toString(),
                  //         userImage: snapshot.data!.data![index]!.userData![0]!.profileImage ?? "")),
                  //     child: ClipRRect(
                  //       borderRadius: BorderRadius.circular(10),
                  //       child: VideoThumbnail(snapshot.data!.data![index]!.image![0]!.image.toString()),
                  //     )
                  // );

                  InkWell(
                    onTap: () => Get.to(SingleUserPost(
                      userId: snapshot.data!.data![index]!.userData![0]!.id.toString(),
                      userName: snapshot.data!.data![index]!.post!.userId.toString(),
                      userImage: snapshot.data!.data![index]!.userData![0]!.profileImage ?? "",
                    )),
                    child: Stack(
                      children: [
                        // VideoThumbnail or your main content
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: VideoThumbnail(snapshot.data!.data![index]!.image![0]!.image.toString()),
                        ),
                        // Positioned widget to position the PNG image at the top right corner
                        Positioned(
                          top: 10, // Adjust the top spacing as needed
                          right: 10, // Adjust the right spacing as needed
                          child: Image.asset(
                            'asset/image/heart-circle.png',
                            width: 24, // Adjust the width as needed
                            height: 24, // Adjust the height as needed
                          ),
                        ),
                      ],
                    ),
                  );

                  //child: SrcVideoPlayerWidget(videoPath: snapshot.data!.data![index]!.image![0].image.toString(), fullAspectRatio: true,)));
                },
              ),
            )
                : userId == widget.postUserId ?  InkWell(
              onTap: ()=> CameraGalleryController.pickGalleryAndCameraForPost(context: context),
              child: Row(
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width*.46,
                    height: 180,
                    margin: const EdgeInsets.only(left: 20, top: 20, right: 20),
                    decoration: BoxDecoration(
                        border: Border.all(width: 1,color: AppColors.mainColor),
                        color: Colors.transparent,
                        borderRadius: BorderRadius.circular(10)
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Icon(Icons.add, color: AppColors.mainColor, size: 40,),
                        SizedBox(height: 5,),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 13.0),
                          child: Text("Add a portfolio", textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                              color: AppColors.mainColor,
                            ),
                          ),
                        )
                      ],
                    ),

                  ),
                ],
              ),
            ) : SizedBox(height: 0,);
          }else{
            return const Center(child: Text(""),);
          }
        }
    );
  }

  InkWell buildSinglePortfolio({
    required VoidCallback onClick,
    required String imagePath,
  }) {
    return InkWell(
      onTap: onClick,
      child: Stack(
        children: [
          // Your main image or content (AppNetworkImage in this case)
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: AppNetworkImage(src: imagePath),
          ),
          // Positioned widget to position the PNG image at the top right corner
          // Positioned(
          //   top: 10, // Adjust the top spacing as needed
          //   right: 10, // Adjust the right spacing as needed
          //   child: Image.asset(
          //     'asset/image/heart-circle.png',
          //     width: 24, // Adjust the width as needed
          //     height: 24, // Adjust the height as needed
          //   ),
          // ),
        ],
      ),
    );

  }






}
