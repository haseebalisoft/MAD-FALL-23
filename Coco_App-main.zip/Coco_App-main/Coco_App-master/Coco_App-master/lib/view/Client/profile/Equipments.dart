import 'package:coco/model/authModel/userAboutMe.dart';
import 'package:coco/utility/colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Equipments extends StatefulWidget {
  final dynamic equipments;
  Equipments({ this.equipments});

  @override
  State<Equipments> createState() => _EquipmentsState();
}

class _EquipmentsState extends State<Equipments> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                IconButton(
                    onPressed: () {
                      Get.back();
                    },
                    icon: Icon(Icons.arrow_back_rounded, color: Colors.white,)),
                Text(
                  'Equipments',
                  style: TextStyle(fontSize: 18, color: AppColors.mainColor, fontWeight: FontWeight.bold),
                )
              ],
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 0),
              child: ListView.builder(
                shrinkWrap: true,
                  itemCount: widget!.equipments.length,
                  itemBuilder: (_, index){
                    return  Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: Text(
                        '- ${widget!.equipments![index]!.name}',
                        style: TextStyle(fontSize: 17, color: Colors.white),
                      ),
                    );
                  }
              )
            )
          ],
        ),
      ),
    );
  }
}