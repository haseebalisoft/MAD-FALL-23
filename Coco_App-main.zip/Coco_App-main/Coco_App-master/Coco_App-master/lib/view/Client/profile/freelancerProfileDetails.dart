import 'dart:convert';

import 'package:coco/controller/authController.dart';
import 'package:coco/controller/followUnFollowList.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/utility/topbarmassage.dart';
import 'package:coco/view/profile/singleUserPortfolio/singleUserPortfolio.dart';
import 'package:coco/view/storys/story.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:coco/viewController/appLoading.dart';
import 'package:coco/viewController/appNetworkImage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';
import 'package:sticky_headers/sticky_headers/widget.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../appConfig.dart';
import '../../../controller/inAppLinkController.dart';
import '../../../controller/storyController.dart';
import '../../../helper/helperWidgets.dart';
import '../../../model/AllFavorite.dart';
import '../../../model/authModel/singleUserInfo.dart';
import '../../../model/storyModel/allStoryModel.dart';
import '../../../utility/appAssets.dart';
import '../../../viewController/StoryViewinsta.dart';
import '../bottomNagivation/buttom_nav.dart';
import 'Profile_about.dart';
import 'profile_protfolio.dart';
import 'package:http/http.dart' as http;


class FreelancerProfileDetails extends StatefulWidget {
  final String userId;

  const FreelancerProfileDetails({required this.userId});
  @override
  State<FreelancerProfileDetails> createState() => _FreelancerProfileDetailsState();
}

class _FreelancerProfileDetailsState extends State<FreelancerProfileDetails>
    with SingleTickerProviderStateMixin {
  late TabController tabController;
  Future<SingleUserInfoModel>? getUserInfoFuture;


  Future ? alert;
  String ? massage;
  String ? user_id;
  bool isPublisNo = false;

  List<Favorites> allFav = [];


  bool isAboutMe = false;
  bool isPortfolioTab = true;

  var followers = 0;

  bool isFollowButtonDisabled = false;

  bool isFavButtonDisabled = false;
  String favButtonText = '+ Favorite';
  int favCount = 0;

  fetchData() async {
    var alert = await AuthController.publishAlert(widget.userId);
    if(alert.statusCode == 200){
      var jsonResponse = json.decode(alert.body);
      print("jsonResponse == ${jsonResponse}");

      if(jsonResponse["data"] != null) {
        setState(() {
          massage = jsonResponse["data"]['alert_msg'];
          isPublisNo = jsonResponse["data"]["status"] == "yes" ? true : false;
          print("massage == ${massage}");
        });
      }
      else{
        setState(() {
          massage = null;
          isPublisNo = false;
        });
      }
    }

    print('notiiiifiiii====${massage}');
    return alert;
    // Do something with the notification data
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    tabController = TabController(length: 2, vsync: this);
    getUserInfoFuture = AuthController.getSingleUserInfo(widget.userId);
    getStoryChecker();
    alert = fetchData();
    getFallFavorite();
  }
  Future<AllStoryModel>? _getAllStory;
  List<Story> myStory = [];
  bool haveStory = false;
  getStoryChecker()async{
    _getAllStory = StoryController.getStroyList();
    _getAllStory?.then((value) {
      for(var i in value!.userStories!){
        if( i.id.toString() == widget.userId.toString()){
          setState(() {
            haveStory = true;
          });

        }
      }

    });
  }


  getFallFavorite() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var token = prefs.getString("token");

    var response = await http.get(Uri.parse(AppConfig.GET_ALL_FAV),
        headers: {
          "Authorization": "Bearer $token",
          "Accept": "application/json",
        }
    );
    print("user ==== ${response.body}");

    var jsonResponse = json.decode(response.body);
    print("jsonResponse == ${jsonResponse}");


    if(jsonResponse["favorites"] != null) {
      setState(() {
        allFav = AllFavorite.fromJson(jsonResponse).favorites!;

        for (var i = 0; i < allFav.length; i++) {
          if (allFav[i].favoriteUserId.toString() == widget.userId.toString()) {
            favButtonText = 'Unfavorite';
          }
        }
      });
    }
  }




  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    HelperWidget.changeSystemUIColor(Colors.black, Colors.black);

    return Container(
      color: AppColors.black,
      child:  Scaffold(
        backgroundColor: Colors.black,
        // appBar: AppBar(
        //   elevation: 0,
        //   backgroundColor: Colors.black,
        //   toolbarHeight: 10,
        //   flexibleSpace: Container(
        //     color: AppColors.mainColor,
        //   ),
        //   leading: IconButton(
        //       onPressed: () {
        //         Get.back();
        //       },
        //       icon: const Icon(Icons.arrow_back_outlined, color: AppColors.white,)),
        //   actions: [
        //     // IconButton(
        //     //   onPressed: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientBottomNavigationBar(pageIndex: 5,))),
        //     //   icon: Icon(Icons.settings, color: AppColors.black,),
        //     // ),
        //     SizedBox(width: 10,)
        //   ],
        // ),
        body:  FutureBuilder<SingleUserInfoModel>(
            future: getUserInfoFuture,
            builder: (context, snapshot) {

              print("following");
              if(snapshot.connectionState == ConnectionState.waiting){
                return Center(
                  child: Container(
                    width: 50,
                    height: 50,
                  //  color: Colors.white,
                    child: CircularProgressIndicator(color: AppColors.white,),
                  ),
                );
              }
              else if(snapshot.hasData){

                if(followers == 0){
                  followers = snapshot.data!.data!.user![0].followers!.length;
                }



                for(var i=0; i<snapshot.data!.data!.user![0].followers!.length;i++){
                  if(snapshot.data!.data!.user![0].followers![i]!.pivot!.userId.toString() == user_id.toString()){
                    isFollow = true;
                    print("following ${isFollow}");
                  }
                }


                if (favCount == 0) {
                  favCount = snapshot.data!.data!.user![0].userFavoriteCount!;
                }
                return Stack(
                  children: [
                    ListView(
                      //crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        massage !=null ?  AppTopBarMassage(massage: '${massage}',) : Center(),
                       Align(
                         alignment: Alignment.centerLeft,
                         child: IconButton(
                           onPressed: (){
                             Navigator.pop(context);
                             },
                           icon: Icon(Icons.arrow_back, color: Colors.white,),
                         ),
                       ),

                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 20),
                              child: InkWell(
                                onTap:(){
                                  haveStory
                                      ? Navigator.push(context, MaterialPageRoute(builder: (context)=>StoryInsta(allStoryModel: myStory, user_name: snapshot.data!.data!.user![0].name!, user_img: snapshot.data!.data!.user![0].profileImage!, )))
                                      : null;
                                },
                                // onTap:()=>haveStory? Get.to(StoryList(allStoryModel: myStory, user_name: snapshot.data!.data![0]!.name!)) : null,
                                child: Container(
                                  width: 100,
                                  height: 100,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    gradient:haveStory ? LinearGradient(colors: [
                                      Color(0xFF00CC83),
                                      Color(0xFF53E0DB),
                                    ]):LinearGradient(colors: [
                                      Color(0xFFFFFFFF),
                                      Color(0xFFFFFFFF),
                                    ]),
                                  ),
                                  child: Container(
                                    margin: EdgeInsets.all(4),
                                    child: CircleAvatar(
                                      radius: 80,
                                      backgroundColor: Color(0xFFF6F6F6),
                                      child: CircleAvatar(
                                        backgroundColor: Color(0xFF0452D8),
                                        radius: 80,
                                        child: ClipOval(
                                          child: ClipOval(
                                            child: snapshot.data!.data!.user![0].profileImage != null
                                                ? AppNetworkImage(
                                              src: snapshot.data!.data!.user![0].profileImage!,  width: double.infinity,
                                              height: double.infinity,
                                              fit: BoxFit.cover,)
                                                : Image.asset(
                                              "asset/image/logo.png",
                                              width: double.infinity,
                                              height: double.infinity,
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            // SizedBox(
                            //   width: 15,
                            // ),
                            Padding(
                              padding: const EdgeInsets.only(right: 30),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    '${snapshot.data!.data!.user![0].name ?? snapshot.data!.data!.user![0].userName}',
                                    style: TextStyle(
                                        fontSize: 20,
                                        fontFamily: 'Poppins-Bold',
                                        color: Colors.white
                                    ),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      InkWell(
                                        onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientBottomNavigationBar(pageIndex: 4, userId: widget.userId.toString(), pageInderForFollowing: 1 ))),//this is outside o bottomnavigation, but we need still button navigation
                                        child: Column(
                                          children: [
                                            Text(
                                              '${snapshot.data!.data!.user![0].following?.length}',
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontFamily: "arial-bold",
                                                  color: Colors.white,
                                                  fontSize: 17),
                                            ),
                                            Text(
                                              'Following',
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 12),
                                            ),
                                          ],
                                        ),
                                      ),
                                      SizedBox(
                                        width: 15.w,
                                      ),
                                      InkWell(
                                        onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientBottomNavigationBar(pageIndex: 4, userId: widget.userId.toString(),  pageInderForFollowing: 0))),//this is outside o bottomnavigation, but we need still button navigation
                                        child: Column(
                                          children: [
                                            Text(
                                              '${followers}',
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.white,
                                                  fontFamily: "arial-bold",
                                                  fontSize: 17),
                                            ),
                                            Text(
                                              'Followers',
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 12),
                                            ),
                                          ],
                                        ),
                                      ),

                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 15,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 5.0, bottom: 15.0, left: 10, right: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              SizedBox(
                                width: (MediaQuery.of(context).size.width - 35) / 3,
                                height: 45,
                                child: ElevatedButton(
                                  style: ButtonStyle(
                                    backgroundColor: MaterialStateProperty.all(Colors.white),
                                  ),
                                  onPressed: () {
                                    _follow(widget.userId.toString());
                                  },
                                  child: isFollowButtonDisabled
                                      ? Container(
                                    width: 15.0,  // Adjust the width as needed
                                    height: 15.0, // Adjust the height as needed
                                    child: const CircularProgressIndicator(
                                      valueColor: AlwaysStoppedAnimation<Color>(AppColors.mainColor),
                                    ),
                                  )
                                  : Text(
                                    isFollow ? 'Unfollow' : '+ Follow',
                                    style: const TextStyle(
                                      color: Colors.black,
                                      fontFamily: 'Poppins_SemiBold',
                                      fontSize: 12
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              SizedBox(
                                width: (MediaQuery.of(context).size.width - 35) / 3,
                                height: 45,
                                child: ElevatedButton(
                                  style: ButtonStyle(
                                    backgroundColor: MaterialStateProperty.all(Colors.white),
                                  ),
                                  onPressed: () async {
                                    // Disable the button
                                    setState(() {
                                      isFavButtonDisabled = true;
                                    });

                                    SharedPreferences prefs = await SharedPreferences.getInstance();
                                    var token = prefs.getString("token");



                                    var response = await http.post(Uri.parse(AppConfig.ADD_TO_FAV),
                                        headers: {
                                          "Authorization": "Bearer $token",
                                          "Accept": "application/json",
                                        },
                                        body: {
                                          "favorite_user_id": widget.userId.toString(),
                                        }
                                    );
                                    print("user ==== ${response.body}");


                                    if(response.statusCode == 200) {
                                      response = await http.get(Uri.parse(
                                          AppConfig.SINGLE_USER_INFO +
                                              widget.userId),
                                          headers: {
                                            "Accept": "application/json",
                                          }
                                      );

                                      setState(() {
                                        favCount = json.decode(response
                                            .body)["data"]["user"][0]["user_favorite_count"];
                                      });


                                      // Update the button text and enable the button
                                      setState(() {
                                        isFavButtonDisabled = false;
                                        if (favButtonText == 'Unfavorite') {
                                          favButtonText = '+ Favorite';
                                        } else
                                        if (favButtonText == '+ Favorite') {
                                          favButtonText = 'Unfavorite';
                                        }
                                      });
                                    }else{
                                      setState(() {
                                        isFavButtonDisabled = false;
                                        favButtonText == '+ Favorite';
                                      });
                                    }



                                  },
                                  child: isFavButtonDisabled
                                      ? Container(
                                    width: 15.0,  // Adjust the width as needed
                                    height: 15.0, // Adjust the height as needed
                                    child: const CircularProgressIndicator(
                                      valueColor: AlwaysStoppedAnimation<Color>(AppColors.mainColor),
                                    ),
                                  )
                                      : Text(
                                    favButtonText,
                                    style: TextStyle(fontFamily: 'Poppins_SemiBold', color: Colors.black, fontSize: 12),
                                  ),
                                ),
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              SizedBox(
                                width: (MediaQuery.of(context).size.width - 35) / 3,
                                height: 45,
                                child: ElevatedButton(
                                  style: OutlinedButton.styleFrom(
                                    backgroundColor: Color(0xFF00CC83),
                                  ),
                                  onPressed: () => ShowContactInfo(snapshot.data!.data!),
                                  child: Text(
                                    'Contact me',
                                    style: TextStyle(fontFamily: 'Poppins_SemiBold', color: Colors.white, fontSize: 12),
                                  ),
                                ),
                              )
                            ],
                          )
                          ,
                        ),
                        SizedBox(height: 10,),
                        StickyHeader(
                            header: Container(
                                padding: EdgeInsets.only(top: 0, bottom: 10),
                                color: Colors.black,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    InkWell(
                                      onTap: (){
                                        setState(() {
                                          isPortfolioTab = true;
                                          isAboutMe = false;
                                        });
                                      },
                                      child: Container(
                                        width: size.width*.45,
                                        padding: EdgeInsets.only(bottom: 10),
                                        height: 30,
                                        decoration: BoxDecoration(
                                            border: isPortfolioTab ? const Border(
                                                bottom: BorderSide(width: 2, color: AppColors.mainColor)
                                            ):Border(bottom: BorderSide.none)
                                        ),
                                        child: Center(
                                          child: Text("Portfolio",
                                            style: TextStyle(
                                                fontSize: 14,
                                                fontWeight: FontWeight.w600,
                                                color:isPortfolioTab ? AppColors.mainColor : Colors.white
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(width: 10,),
                                    InkWell(
                                      onTap: (){
                                        setState(() {
                                          isPortfolioTab = false;
                                          isAboutMe = true;
                                        });
                                      },
                                      child: Container(
                                        width: size.width*.45,
                                        height: 30,
                                        padding: EdgeInsets.only(bottom: 10),
                                        decoration: BoxDecoration(
                                            border: isAboutMe ? Border(
                                                bottom: BorderSide(width: 2, color: AppColors.mainColor)
                                            ): Border(bottom: BorderSide.none)
                                        ),
                                        child: Center(child: Text("About Me",
                                          style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w600,
                                              color:isAboutMe ? AppColors.mainColor : Colors.white
                                          ),

                                        )),
                                      ),
                                    )
                                  ],
                                )
                            ),
                            content: isPortfolioTab
                                ? SingleUserPortfolio(userId: widget.userId)
                                : AboutMeSection(UserId: widget.userId,)
                        ),
                      ],
                    ),
                    // isLoading?  LoadingOverlay() : Center()
                  ],
                );
              }else{
                print("${snapshot.error}");
                return  Center(child: Text( style: TextStyle(color: Colors.white),"Check your internet connection ${snapshot.error}"),);
              }
            }
        ),

      ),
    );
  }
  //
  // ProfileProtfolio(),
  // AboutMeSection(),
  ShowContactInfo( Datum? data) async{
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(		//the rounded corner is created here
          borderRadius: BorderRadius.circular(20.0),
        ),
        builder: (context) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Container(
                margin: EdgeInsets.only(top: 10),
                height: 2, width: 100,
                color: Colors.grey.shade500,
              ),
              SizedBox(height: 30,),
              ListTile(
                leading: Container(
                  height: 40, width: 40,
                  padding: EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(100),
                    color: AppColors.mainColor,
                  ),
                  child: Icon(Icons.call, color: AppColors.white,),
                ),
                title: Text('Call Me',
                  style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w600
                  ),
                ),
                onTap: () {
                  InAppLinkController.makePhoneCall("${data?.user?[0].userInfo?.businessPhone}");
                },
              ),
              ListTile(
                leading: Container(
                  height: 40, width: 40,
                  padding: EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(100),
                    color: AppColors.mainColor,
                  ),
                  child: Icon(Icons.email_outlined, color: AppColors.white,),
                ),
                title: const Text('Send me a mail',
                  style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w600
                  ),
                ),

                onTap: () {
                  InAppLinkController.makeEmail("${data?.user?[0].userInfo?.businessEmail}");
                },
              ),
              // ListTile(
              //   leading: Container(
              //     height: 40, width: 40,
              //     padding: EdgeInsets.all(5),
              //     decoration: BoxDecoration(
              //       borderRadius: BorderRadius.circular(100),
              //       color: AppColors.mainColor,
              //     ),
              //     child: Icon(Icons.call, color: AppColors.white,),
              //   ),
              //   title: SizedBox(
              //     width: double.infinity,
              //     height: 35,
              //     child: Row(
              //       children: [
              //         new Text('Contact via',
              //           style: TextStyle(
              //               fontSize: 17,
              //               fontWeight: FontWeight.w600
              //           ),
              //         ),
              //         const SizedBox(width: 20,),
              //       ],
              //     ),
              //   ),
              //   onTap: () {
              //     Navigator.pop(context);
              //   },
              // ),
              ListTile(
                title: data!.user![0].social != null
                    ?  Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Social media',
                      style: TextStyle(
                          color: Color(0xff00CC83),
                          fontSize: 15,
                          fontFamily: 'SourceSansPro-Semibold'),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Row(
                      children: [
                        data?.user?[0].social!.instagram != 'null'
                            ? Row(
                          children: [
                            InkWell(
                              onTap: (){
                                String? instagramUrl = data?.user?[0].social!.instagram;

                                if (instagramUrl != null) {
                                  if (instagramUrl.contains("https://")) {
                                    launchUrl(Uri.parse(instagramUrl));
                                  } else {
                                    launchUrl(Uri.parse("https://${instagramUrl}"));
                                  }
                                }


                              },
                              child: Image.asset(
                                'asset/image/insta.png',
                                width: 45,
                                height: 45,
                              ),
                            ),
                            SizedBox(
                              width: 20,
                            ),
                          ],
                        )
                            : SizedBox(
                          width: 0,
                        ),
                        data.user![0].social!.facebook != 'null'
                            ? Row(
                          children: [
                            InkWell(
                              onTap: (){
                                if( data.user![0].social!.facebook!.contains("https://")){
                                  launchUrl(Uri.parse("${ data.user![0].social!.facebook!}"));
                                }else{
                                  launchUrl(Uri.parse("https://${ data.user![0].social!.facebook!}"));
                                }
                              },
                              child: Image.asset(
                                'asset/image/insta.png',
                                width: 45,
                                height: 45,
                              ),
                            ),
                            SizedBox(
                              width: 20,
                            ),
                          ],
                        )
                            : SizedBox(
                          width: 0,
                        ),
                        data.user![0].social!.youtube != 'null'
                            ? Row(
                          children: [
                            InkWell(
                              onTap: (){
                                if(data.user![0].social!.youtube!.contains("https://")){
                                  launchUrl(Uri.parse("${data.user![0].social!.youtube!}"));
                                }else{
                                  launchUrl(Uri.parse("https://${data.user![0].social!.youtube!}"));
                                }
                              },
                              child: Image.asset(
                                'asset/image/youtube.png',
                                width: 45,
                                height: 45,
                              ),
                            ),
                            SizedBox(
                              width: 20,
                            ),
                          ],
                        )
                            : SizedBox(
                          width: 0,
                        ),
                        data.user![0].social!.behance != 'null'
                            ? Row(
                          children: [
                            InkWell(
                              onTap: (){
                                if(data.user![0].social!.behance!.contains("https://")){
                                  launchUrl(Uri.parse("${data.user![0].social!.behance!}"));
                                }else{
                                  launchUrl(Uri.parse("https://${data.user![0].social!.behance!}"));
                                }
                              },
                              child: Image.asset(
                                'asset/image/bain.png',
                                width: 45,
                                height: 45,
                              ),
                            ),
                            SizedBox(
                              width: 20,
                            ),
                          ],
                        )
                            : SizedBox(
                          width: 0,
                        ),
                      ],
                    ),
                  ],
                ) : SizedBox(
                  height: 0,
                ),
                onTap: () {
                  Navigator.pop(context);
                },
              ),

              SizedBox(height: 40,),
            ],
          );
        });
  }


  bool isLoading = false;
  bool isFollow = false;
  ///TODO:
  _follow(id)async{

    setState(() =>isFollowButtonDisabled=true);
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var token = prefs.getString("token");

    var res = await FollowUnFollowController.followUnfollow(id);
    if(res.statusCode == 200){

      var response = await http.get(Uri.parse(AppConfig.SINGLE_USER_INFO+widget.userId),
          headers: {
            "Accept" : "application/json",
          }
      );


        isFollow = true;
        followers = jsonDecode(response.body)["data"]["user"][0]["followers"].length;


    }else{
      setState(() {
        isFollow = false;
        followers = followers-1;
      });
    }
    print("follow body == ${res.statusCode}");
    setState(() =>isFollowButtonDisabled=false);
  }





}

