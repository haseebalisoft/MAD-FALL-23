import 'package:flutter/material.dart';

class Customer_profile_info extends StatefulWidget {
  const Customer_profile_info({super.key});

  @override
  State<Customer_profile_info> createState() => _Customer_profile_infoState();
}

class _Customer_profile_infoState extends State<Customer_profile_info> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
