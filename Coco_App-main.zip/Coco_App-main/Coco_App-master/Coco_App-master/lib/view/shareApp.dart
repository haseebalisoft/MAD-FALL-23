import 'package:coco/appConfig.dart';
import 'package:flutter/material.dart';
import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:share_plus/share_plus.dart';


class ShareApp{


  static Future<void> createDynamicLink({required String link, required String text, required BuildContext context}) async {

    FirebaseDynamicLinks dynamicLinks = FirebaseDynamicLinks.instance;
    final String _testString =
        'To test: long press link and then copy and click from a non-browser '
        "app. Make sure this isn't being tested on iOS simulator and iOS xcode "
        'is properly setup. Look at firebase_dynamic_links/README.md for more '
        'details.';

    final String DynamicLink = 'coco-d95f7.firebaseapp.com';
    final String Link = 'https://flutterfiretests.page.link/MEGs';


    final DynamicLinkParameters parameters = DynamicLinkParameters(
      uriPrefix: '${AppConfig.DOMAIN}',
      longDynamicLink: Uri.parse(
        'coco-d95f7.firebaseapp.com?efr=0&ibi=com.coco.app&apn=com.coco-app&ofl=${AppConfig.DOMAIN}',
      ),
      link: Uri.parse(DynamicLink),
      androidParameters: const AndroidParameters(
        packageName: 'com.coco.app',
        minimumVersion: 0,
      ),
      iosParameters: const IOSParameters(
        bundleId: 'com.coco-app',
        minimumVersion: '0',
      ),
    );

    Uri url;
    final ShortDynamicLink shortLink =
    await dynamicLinks.buildShortLink(parameters);
    url = shortLink.shortUrl;

    final PendingDynamicLinkData? data = await dynamicLinks.getInitialLink();
    final Uri? deepLink = data?.link;
    print("data ===$url");
    print("data ===${data?.android}");
    print("data ===${data?.ios}");
    print("data ===${data?.utmParameters}");

    if (deepLink != null) {
      // ignore: unawaited_futures
      Share.share("$text \n $deepLink");
    }
    Share.share("$text \n $deepLink");

  }

}