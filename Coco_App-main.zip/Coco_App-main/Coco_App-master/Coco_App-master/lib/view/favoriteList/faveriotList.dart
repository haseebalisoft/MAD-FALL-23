import 'package:coco/under_dev.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/view/Client/profile/profile_protfolio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';


class FavList extends StatefulWidget {
  const FavList({Key? key}) : super(key: key);

  @override
  State<FavList> createState() => _FavListState();
}

class _FavListState extends State<FavList> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.black,
      child: SafeArea(
        child: Scaffold(
          backgroundColor: AppColors.black,
          appBar: AppBar(
            backgroundColor: AppColors.black,
            elevation: 0,
            leading: IconButton(
              onPressed: ()=>Get.back(),
              icon: Icon(Icons.arrow_back, color: AppColors.white,),
            ),
            title: Text("Favourite",
              style: TextStyle(
                fontSize: 16,
                color: AppColors.white
              ),
            ),
          ),
          body: Column(
children: [
  ProfileProtfolio(postUserId:'13'),
],
          )
        ),
      ),
    );
  }
}
