import 'package:animator/animator.dart';
import 'package:coco/utility/colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:card_swiper/card_swiper.dart';


class ClientStory extends StatefulWidget {
  const ClientStory({Key? key}) : super(key: key);

  @override
  State<ClientStory> createState() => _ClientStoryState();
}

class _ClientStoryState extends State<ClientStory> {


  final List<String> images = [
    'https://plus.unsplash.com/premium_photo-1688522732312-176d19f60af2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8c2FkfGVufDB8fDB8fHwx&w=1000&q=80',
    'https://images.unsplash.com/photo-1572092438785-6c0f9eb45656?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1yZWxhdGVkfDEzfHx8ZW58MHx8fHx8&w=1000&q=80',
    'https://w0.peakpx.com/wallpaper/976/894/HD-wallpaper-alone-girl-standing-on-water-standing-water-sunset-pose.jpg',
    'https://images.unsplash.com/photo-1572092438785-6c0f9eb45656?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1yZWxhdGVkfDEzfHx8ZW58MHx8fHx8&w=1000&q=80',
    'https://plus.unsplash.com/premium_photo-1688522732312-176d19f60af2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8c2FkfGVufDB8fDB8fHwx&w=1000&q=80',
    'https://w0.peakpx.com/wallpaper/976/894/HD-wallpaper-alone-girl-standing-on-water-standing-water-sunset-pose.jpg',
  ];



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.black,
      body: Stack(
        children: [
          Swiper(
            itemBuilder: (BuildContext context, int index) {
              return Center();
              // return ClientContentScreen(
              //   src: images[index],
              // );
            },
            itemCount: images.length,
            scrollDirection: Axis.vertical,
          ),
          Container(
            margin: EdgeInsets.only(top: 20),
            padding: const EdgeInsets.all(10),
            child: Row(
              children: [
                IconButton(
                  onPressed: ()=>Get.back(),
                  icon: Icon(Icons.arrow_back,color: Colors.white,),
                ),
                Text("Post",
                  style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w600,
                      color: Colors.white
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
