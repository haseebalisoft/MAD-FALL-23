import 'dart:io';

import 'package:coco/utility/colors.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:coco/viewController/video_player/file_videoplayers.dart';
import 'package:path/path.dart' as p;
import 'package:coco/appConst.dart';
import 'package:coco/controller/authController.dart';
import 'package:coco/view/freelancer/bottomNavigationBar/becameFreelanceBottomNavigation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../client/bottomNagivation/buttom_nav.dart';

class UploadStroyProview extends StatefulWidget {
  final List? list;
  final String form;
  final dynamic cameraFile;
  const UploadStroyProview({Key? key,  this.list, this.cameraFile, required this.form}) : super(key: key);

  @override
  State<UploadStroyProview> createState() => _UploadStroyProviewState();
}

class _UploadStroyProviewState extends State<UploadStroyProview> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getAllData();
  }


  final discription = TextEditingController();

  var cameraFile;
  final postKey = GlobalKey<FormState>();
  // Get the video file
  List videoFile = [];
  List videoFilePath = [];


  getAllData()async{

    if(widget.cameraFile ==null){
      ///============== if camera image or vide is null then check have any list =======//
      for(var i = 0; i<widget.list!.length!; i++){
        videoFile.add(await widget.list![i].file);
      }
      //
      for(var i = 0; i<videoFile.length; i++){
        videoFilePath.add(videoFile[i].path);

        print("this === ${p.extension(videoFile[i].path) }");
      }
    }else{
      ///============ if camera file is have, then assign it into camera file =====//
      cameraFile = await widget.cameraFile;
    }
    setState(() {});

  }









  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Container(
      color: Colors.black,
      child: SafeArea(
        child: Scaffold(
          backgroundColor: Colors.black,
          body: Stack(
            children: [
             cameraFile == null
                 ? Container(
                height: size.height,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.1),
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(30),
                    bottomRight: Radius.circular(30),
                  ),
                ),
                child:  p.extension(videoFile[0].path.toString()) == ".mp4"
                     ? FileVideoPlayerWidget(videoPath: videoFilePath[0])
                     : Container(
                  child: ClipRRect(
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(30),
                      bottomRight: Radius.circular(30),
                    ),
                    child: Image.file(
                      videoFile[0],
                      fit: BoxFit.contain,
                      width: size.width,
                    ),
                  ),
                )
              )
                 : Container(
                 height: size.height,
                 decoration: BoxDecoration(
                   color: Colors.white.withOpacity(0.1),
                   borderRadius: BorderRadius.only(
                     bottomLeft: Radius.circular(30),
                     bottomRight: Radius.circular(30),
                   ),
                 ),
                 child:  p.extension(cameraFile!.path.toString()) == ".mp4"
                     ? FileVideoPlayerWidget(videoPath: cameraFile!.path)
                     : Container(
                   child: ClipRRect(
                     borderRadius: BorderRadius.only(
                       bottomLeft: Radius.circular(30),
                       bottomRight: Radius.circular(30),
                     ),
                     child: Image.file(
                       cameraFile!,
                       fit: BoxFit.contain,
                       width: size.width,
                     ),
                   ),
                 )
             ),
              Container(
                margin: EdgeInsets.all(20),
                decoration: BoxDecoration(
                    color: Colors.black,
                    borderRadius: BorderRadius.circular(100)
                ),
                child: IconButton(
                  onPressed: (){
                    Get.back();
                  },
                  icon:  Icon(Icons.arrow_back, color: Colors.white,),
                ),
              ),
            ],
          ),
          bottomNavigationBar: BottomButtonSendStory(
            onClick: ()=>_uploadSotry(),
          ),
        ),
      ),
    );
  }


  ////================= upload a story ==========///
  bool isLoading = false;
  void _uploadSotry() async{

    print("widget.form ${widget.form}");
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var role = _pref.getString("role");
    setState(() {
      isLoading=true;
    });
    AlertController.snackbar(context: context, text: "Story uploading...", bg: AppColors.mainColor.withOpacity(0.7));
    var  res = await AuthController.uploadStory(images: videoFilePath.isEmpty? cameraFile!.path : videoFilePath[0] , description: discription.text);

    if(res.statusCode == 200){
      AlertController.snackbar(context: context, text: "Story uploaded successfully.", bg: Colors.green);
      if(role == AppConst.FREELANCER_ROLE){
        if(widget.form == "dashboard"){
          Get.to(FreelancerAppBottomNavigation());
        }else{
          Get.to(FreelancerAppBottomNavigation(pageIndex: 4,));
        }
      }else{
        if(widget.form == "dashboard"){
          Get.to(ClientBottomNavigationBar());
        }else{
          Get.to(ClientBottomNavigationBar(pageIndex: 3,));
        }
      }
    }else{
      AlertController.snackbar(context: context, text: "Something went wrong with server.", bg: Colors.red);
    }
    setState(() {
      isLoading=false;
    });
    if (mounted) {
      // Perform actions that depend on the widget being active.
      // Update the state or modify the UI.
    }
  }



}

class BottomButtonSendStory extends StatelessWidget {
  const BottomButtonSendStory({
    super.key, required this.onClick,
  });

  final VoidCallback onClick;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 70,
      margin: EdgeInsets.only(right: 30,  bottom: 20, top: 20),
      decoration: BoxDecoration(
        color: Colors.black
      ),
      child:  Align(
        alignment: Alignment.centerRight,
        child: InkWell(
          onTap: onClick,
          child: Container(
              width: 50, height: 50,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(100)
              ),
              child: Icon(Icons.arrow_forward_ios)),
        ),
      ),
    );
  }
}
