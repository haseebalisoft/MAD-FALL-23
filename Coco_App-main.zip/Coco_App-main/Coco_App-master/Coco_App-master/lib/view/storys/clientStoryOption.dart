import 'package:animator/animator.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../appConst.dart';
import '../../controller/storyController.dart';
import '../../model/storyModel/allStoryModel.dart';
import '../../viewController/alartController.dart';
import '../client/bottomNagivation/buttom_nav.dart';
import '../freelancer/bottomNavigationBar/becameFreelanceBottomNavigation.dart';

class ClientSotryOptionsScreen extends StatefulWidget {
  final Story info;
  final String user_name;
  final bool isLike;
  ClientSotryOptionsScreen({required this.info, required this.user_name,  this.isLike = false});
  @override
  State<ClientSotryOptionsScreen> createState() => _ClientSotryOptionsScreenState();
}

class _ClientSotryOptionsScreenState extends State<ClientSotryOptionsScreen> {
  bool isLike = false;


  var user_id;
  getUserId()async{
    SharedPreferences _prefs = await SharedPreferences.getInstance();
    setState(() {
      user_id = _prefs.getString("user_id");
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getUserId();
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onDoubleTap: (){
        if(isLike == true){
          _postUnList(widget.info!.id.toString());
          return;
        }else{
          _postList(widget.info!.id.toString());
          return;
        }
      },
      child: Container(
        padding: const EdgeInsets.all(8.0),
        decoration: BoxDecoration(
            gradient: new LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.transparent,
                Colors.black.withOpacity(0.5)
              ],
            )
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            SizedBox(),
            Padding(
              padding: const EdgeInsets.only(left: 15, right: 15, bottom: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 140),
                      InkWell(
                        onTap: ()=> user_id!= null && user_id == widget.info.userId.toString()
                            ? Get.to(const ClientBottomNavigationBar(pageIndex: 3,))
                            : Get.to(ClientBottomNavigationBar(
                                pageIndex: 4,
                                userId: widget.info.userId.toString().isEmpty
                                  ?  "1"
                                  : widget.info.userId.toString(),)),
                        child: Row(
                          children: [
                            const CircleAvatar(
                              child: Icon(Icons.person, size: 18),
                              radius: 15,
                            ),
                            const SizedBox(width: 6),
                            Text(widget!.user_name,
                              style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white,
                                  fontSize: 15
                              ),
                            ),
                            SizedBox(width: 10),
                          ],
                        ),
                      ),
                      SizedBox(height:5),
                      widget!.info!.description!= null ? SizedBox(
                        width: MediaQuery.of(context).size.width*.70,
                        child: Text('${widget!.info!.description}',
                          style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w400,
                              color: Colors.white
                          ),
                        ),
                      ):Center( ),
                      SizedBox(height: 5),
                      Text('${widget!.info!.time!}',
                        style: TextStyle(
                            fontSize: 9,
                            fontWeight: FontWeight.w400,
                            color: Colors.white
                        ),
                      ),
                    ],
                  ),
                  Column(
                    children: [
                      InkWell(
                          onTap: (){
                            if(isLike == true){
                              _postUnList(widget.info!.id.toString());
                              return;
                            }else{
                              _postList(widget.info!.id.toString());
                              return;
                            }
                          },
                          child: isLikeList.contains(widget.info.id.toString()) ? Animator<double>(
                            duration: Duration(milliseconds: 1000),
                            cycles: 0,
                            repeats: 1,
                            tween:  Tween<double>(begin: 10.00, end: 12.0),
                            curve: Curves.elasticIn,
                            builder: (_, animatorState, child)=>Column(
                              children: [
                                Icon(Icons.favorite, color: Colors.red, size: animatorState.value*3,),
                                Text('$likeCount',style: TextStyle(color: Colors.white),),
                              ],
                            ),
                          )
                          : Column(
                            children: [
                              Icon(Icons.favorite, color: Colors.white, size: 30,),
                              Text('${likeCount}',style: TextStyle(color: Colors.white),),
                            ],
                          )
                      ),


                      SizedBox(height: 20),
                      Icon(Icons.share_outlined, color: Colors.white,),
                      SizedBox(height: 50),
                      user_id!= null && user_id == widget.info.userId.toString() ?IconButton(
                        onPressed: ()=>showBottomNavigation(),
                        icon: Icon(Icons.more_horiz, color: Colors.white,),
                      ) : Center(),
                      SizedBox(height: 20,)

                    ],
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  like() {
  }

  showBottomNavigation() async {
    showModalBottomSheet(
        context: context,
        builder: (context) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              ListTile(
                leading: new Icon(Icons.delete),
                title: Text('Delete story'),
                onTap: () {
                 // StoryController.deleteStory(story_id:  widget!.info!.id.toString());
                  _deleteStory();
                },
              ),
            ],
          );
        });
  }


  _deleteStory() async{
    var res = await   StoryController.deleteStory(story_id:  widget!.info!.id.toString());
    print("delete post res === ${res.body}");
    print("delete post res === ${res.statusCode}");
    print("delete post res === ${widget!.info!.id.toString()}");
    if(res.statusCode == 200){

      // Navigator.pop(context);
      Get.back();
      SharedPreferences _pref = await SharedPreferences.getInstance();

      debugPrint("role === ${_pref.getString("role")}");
      if(_pref.getString("role") == AppConst.FREELANCER_ROLE){
        Get.to( (FreelancerAppBottomNavigation(pageIndex: 0,)));
      }else if(_pref.getString("role") == AppConst.CLIENT_ROLE){
        Get.to(ClientBottomNavigationBar(pageIndex: 0,));
      }
      AlertController.snackbar(context: context, text: "Story deleted", bg: Colors.green);
    }else if(res.statusCode ==400){
      AlertController.snackbar(context: context, text: "This is not your Story", bg: Colors.red);
    }else{
      AlertController.snackbar(context: context, text: "Something went wrong with server.", bg: Colors.red);
    }
  }



  /////////////// story like and unlike ///////////////
  List isLikeList = [];
  var likeCount = 0;
  bool isPressed = false;
  _postList(story_id)async{
    await StoryController.likeStory(story_id: story_id);
    setState(() {
      isLike = true;
      isLikeList.add(story_id);
      likeCount = (likeCount!+1)!;
    });
    print("like this post id: $likeCount");

    setState(() {
      isPressed ? isPressed = false : isPressed = true;
    });
  }
  ///////////unlike///////
  _postUnList(story_id)async{
    await StoryController.dislikeStory(story_id: story_id);
    setState(() {
      isLike = false;
      isLikeList.remove(story_id);
      likeCount = (likeCount!-1)!;
    });
    print("like this post id: ${likeCount}");

    setState(() {
      isPressed ? isPressed = false : isPressed = true;
    });
  }

}