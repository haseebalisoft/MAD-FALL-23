import 'dart:io';

import 'package:coco/appConst.dart';
import 'package:coco/controller/authController.dart';
import 'package:coco/main.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/view/Client/bottomNagivation/buttom_nav.dart';
import 'package:coco/view/freelancer/bottomNavigationBar/becameFreelanceBottomNavigation.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';


class StoryDescription extends StatefulWidget {
  final File? file;
  const StoryDescription({Key? key, this.file}) : super(key: key);

  @override
  State<StoryDescription> createState() => _StoryDescriptionState();
}

class _StoryDescriptionState extends State<StoryDescription> {

  final discription = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: SafeArea(
        child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            backgroundColor: Colors.white,
            elevation: 0,
            leading: IconButton(onPressed: ()=>Get.back(), icon: Icon(Icons.arrow_back, color: Colors.black,)),
            title: const Text("Description",
              style: TextStyle(
                fontSize: 15,
                color: Colors.black
              ),
            ),
            actions: [
              IconButton(
                onPressed: ()=>isLoading? null : _uploadSotry(),
                icon: isLoading?CircularProgressIndicator(color: AppColors.mainColor,) : Icon(Icons.arrow_forward, color: AppColors.mainColor, size: 25,),
              ),
              SizedBox(width: 10,),
            ],
          ),
          body: SingleChildScrollView(
            padding: EdgeInsets.all(0),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 20.0, right: 20, top: 30),
                  child: Row(
                    children: const [
                      Text("Description",
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            color: Colors.black
                        ),
                      ),
                      Icon(Icons.star, color: AppColors.mainColor, size: 15,)
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 20, right: 20, top: 10),
                  child: TextFormField(
                    textInputAction: TextInputAction.done,
                    autofocus: true,
                    maxLines: 7,
                    controller: discription,
                    decoration: const InputDecoration(
                        contentPadding: EdgeInsets.all(10),
                        border: OutlineInputBorder(
                            borderSide: BorderSide(width: 1, color: Color(0xffE1E1E1))
                        ),
                        enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(width: 1, color: Color(0xffE1E1E1))
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(width: 1, color: Color(0xffE1E1E1))
                        ),
                        hintText: "Share a bit about your work experience, your projects...",
                        hintStyle: TextStyle(
                            fontWeight: FontWeight.w200,
                            fontSize: 10
                        )
                    ),
                    validator: (v){
                      if(v!.isEmpty){
                        return "Description must not be empty";
                      }else{
                        return null;
                      }
                    },
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }




  bool isLoading = false;
  void _uploadSotry() async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    var role = _pref.getString("role");
    setState(() {
      isLoading=true;
    });
    AlertController.snackbar(context: context, text: "Story uploading...", bg: AppColors.mainColor.withOpacity(0.7));
    var  res = await AuthController.uploadStory(images: widget.file, description: discription.text);
    print("response === ${res.statusCode}");

    if(res.statusCode == 200){
      AlertController.snackbar(context: context, text: "Story uploaded successfully.", bg: Colors.green);
      if(role == AppConst.FREELANCER_ROLE){
        Get.to(FreelancerAppBottomNavigation());
      }else{
        Get.to(ClientBottomNavigationBar());
      }
    }else{
      AlertController.snackbar(context: context, text: "Something went wrong with server.", bg: Colors.red);
    }
    setState(() {
      isLoading=false;
    });
    if (mounted) {
      // Perform actions that depend on the widget being active.
      // Update the state or modify the UI.
    }
  }
}
