import 'package:chewie/chewie.dart';
import 'package:coco/model/storyModel/allStoryModel.dart';
import 'package:coco/viewController/appNetworkImage.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import 'clientStoryOption.dart';
import 'likeIcon.dart';

class ClientContentScreen extends StatefulWidget {
  final String? src;
  final String user_name;
  final Story info;
  final bool isLike;

  const ClientContentScreen({Key? key, this.src, required this.info, required this.user_name,  this.isLike = false}) : super(key: key);

  @override
  _ClientContentScreenState createState() => _ClientContentScreenState();
}

class _ClientContentScreenState extends State<ClientContentScreen> {
  late VideoPlayerController _videoPlayerController;
  ChewieController? _chewieController;

  bool _liked = false;


  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        GestureDetector(
            onDoubleTap: () {
              setState(() {
                _liked = !_liked;
              });
            },
            child: AppNetworkImage(src: widget.src!,)
        ),
        if (_liked)
          Center(
            child: LikeIcon(),
          ),
        ClientSotryOptionsScreen(info: widget.info!, user_name: widget.user_name, isLike: widget.isLike,)
      ],
    );
  }
}