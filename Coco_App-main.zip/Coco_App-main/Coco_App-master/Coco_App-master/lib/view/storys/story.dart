import 'package:animator/animator.dart';
import 'package:coco/controller/postController.dart';
import 'package:coco/controller/storyController.dart';
import 'package:coco/model/storyModel/allStoryModel.dart';
import 'package:coco/utility/colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:card_swiper/card_swiper.dart';

import 'clientStoryContent.dart';


class StoryList extends StatefulWidget {
  final List<Story>? allStoryModel;
  final String user_name;
  const StoryList({Key? key, required this.allStoryModel, required this.user_name}) : super(key: key);

  @override
  State<StoryList> createState() => _StoryListState();
}

class _StoryListState extends State<StoryList> {





  bool isLiking = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: SafeArea(
        child: Scaffold(
          backgroundColor: AppColors.black,
          body: InkWell(

            child: Stack(
              children: [
                Swiper(
                  // itemHeight: 500,
                  // itemWidth: 400,
                  // layout: SwiperLayout.values[2],
                  itemBuilder: (BuildContext context, int index) {
                    return InkWell(
                      onDoubleTap: () {
                        // if(isLike == true){
                        //   _postUnList(widget.allStoryModel![index]!.id.toString());
                        //   return;
                        // }else{
                        //   _postList(widget.allStoryModel![index]!.id.toString());
                        //   return;
                        // }
                      },
                      child:  ClientContentScreen(
                        src: widget!.allStoryModel![index]!.image ?? "https://media.istockphoto.com/id/1451587807/vector/user-profile-icon-vector-avatar-or-person-icon-profile-picture-portrait-symbol-vector.jpg?s=612x612&w=0&k=20&c=yDJ4ITX1cHMh25Lt1vI1zBn2cAKKAlByHBvPJ8gEiIg=",
                        info: widget!.allStoryModel![index],
                        user_name: widget.user_name,
                        //isLike: isLike,
                      ),
                    );
                  },
                  itemCount: widget!.allStoryModel!.length,
                  scrollDirection: Axis.vertical,
                ),
                Container(
                  margin: EdgeInsets.only(top: 20),
                  padding: const EdgeInsets.all(10),
                  child: Row(
                    children: [
                      IconButton(
                        onPressed: ()=>Get.back(),
                        icon: Icon(Icons.arrow_back,color: Colors.white,),
                      ),
                      const Text("Story",
                        style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w600,
                            color: Colors.white
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }



/////////////// story like and unlike ///////////////





}
