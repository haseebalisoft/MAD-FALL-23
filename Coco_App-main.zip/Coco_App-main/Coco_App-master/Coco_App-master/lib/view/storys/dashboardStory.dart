
import 'package:coco/controller/camera_gallery_controller/cameraGalleryController.dart';
import 'package:coco/controller/storyController.dart';
import 'package:coco/model/storyModel/allStoryModel.dart';
import 'package:coco/view/storys/story.dart';
import 'package:coco/viewController/StoryViewinsta.dart';
import 'package:coco/viewController/storyContainer.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';
import 'package:wechat_assets_picker/wechat_assets_picker.dart';
import '../freelancer/uploadPortfolio/PickerCropResultScreen.dart';

class DashboardStory extends StatefulWidget {

  const DashboardStory({
    super.key,
  });

  @override
  State<DashboardStory> createState() => _DashboardStoryState();
}

class _DashboardStoryState extends State<DashboardStory> {

  Future<AllStoryModel>? _getAllStory;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getRole();
    _getAllStory = StoryController.getStroyList();
  }

  var role, userID;
  getRole()async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    setState(() {
      role = _pref.getString("role");
      userID = _pref.getString("user_id");
    });

    print("user id ==$userID");
  }
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 20, right: 20),
      child: FutureBuilder<AllStoryModel>(
          future: _getAllStory,
          builder: (context, snapshot) {
            if(snapshot.connectionState == ConnectionState.waiting){
              return SizedBox(
                height: 250,
                // child: ListView.builder(
                //   scrollDirection: Axis.horizontal,
                //   itemCount: 10,
                //   itemBuilder: (_, index) {
                //     return Shimmer.fromColors(
                //         child: Container(
                //           margin: EdgeInsets.only(right: 18),
                //           child: Column(
                //             mainAxisAlignment: MainAxisAlignment.center,
                //             crossAxisAlignment: CrossAxisAlignment.center,
                //             children: [
                //               Container(
                //                 width: 76,
                //                 height: 76,
                //                 padding: EdgeInsets.all(3),
                //                 decoration: BoxDecoration(
                //                   shape: BoxShape.circle,
                //                   gradient: LinearGradient(
                //                     colors: [
                //                       Color(0xFF00CC83),
                //                       Color(0xFF53E0DB),
                //                     ],
                //                   ),
                //                 ),
                //                 child: Container(
                //                   width: 63,
                //                   height: 63,
                //                   padding: EdgeInsets.all(0),
                //
                //                   decoration: BoxDecoration(
                //                     shape: BoxShape.circle,
                //                     color: Color(0xff3f3d3d),
                //                   ),
                //                   child: ClipOval(
                //                       child: Container(color: Colors.white,)
                //                   ),
                //                 ),
                //               ),
                //               SizedBox(
                //                 height: 3,
                //               ),
                //             ],
                //           ),
                //         ),
                //         baseColor: Colors.grey.shade300,
                //         highlightColor: Colors.grey.shade200
                //     );
                //   },
                // ),
              );
            }else if(snapshot.hasData){
              List<UserStory> storyList = [];
              List<UserStory> myStory = [];
              for(var i=0;i<snapshot.data!.userStories!.length;i++){

                print("snapshot.data!.userStories![i].id.toString() == userID => ");
                print(snapshot.data!.userStories![i].id.toString() == userID);
                print("snapshot.data!.userStories![i].id.toString() => ");
                print(snapshot.data!.userStories![i].id.toString());
                print("userID => ");
                print(userID);
                if(snapshot.data!.userStories![i].id.toString() == userID){
                  myStory.add(snapshot.data!.userStories![i]);
                }
              }
              for(var i in snapshot.data!.userStories!){

                if(i.role != role){
                  storyList.add(i);
                }

              }
              return SizedBox(
                height: 100,
                width: MediaQuery.of(context).size.width,
                child:  Row(
                  children: [
                    SizedBox(
                        height: 100,
                        width: MediaQuery.of(context).size.width*.20,
                        child: InkWell(
                          onTap: ()=>CameraGalleryController.pickGalleryAndCameraForStory(context: context, from: "dashboard"),
                          child: Container(
                            margin: EdgeInsets.only(right: 7),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                    width: 72,
                                    height: 72,
                                    padding: EdgeInsets.all(3),
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: Colors.grey.shade200,
                                      gradient: LinearGradient(
                                        colors: [
                                          Color(0xFF00CC83),
                                          Color(0xFF53E0DB),
                                        ],
                                      ),
                                    ),
                                    child: Center(child: Icon(Icons.add),
                                    )
                                ),
                                // SizedBox(
                                //   height: 2,
                                // ),
                                const Expanded(
                                  child: Text(
                                    "Add new",
                                    style: TextStyle(
                                        color: Color(0xFF777777),
                                        fontSize: 15,
                                        fontWeight: FontWeight.w500,
                                        fontFamily: 'source-sans-pro-regular'),
                                  ),
                                )
                              ],
                            ),
                          ),
                        )
                    ),
                    myStory.isNotEmpty ? SizedBox(
                      height: 100,
                      width: MediaQuery.of(context).size.width*.20,
                      child: ListView.builder(
                        physics: NeverScrollableScrollPhysics(),
                        scrollDirection: Axis.horizontal,
                        itemCount:myStory.length,
                        itemBuilder: (_, index) {
                          return Row(
                            children: [
                              SizedBox(width: 1.8,),
                              StoryContainer(
                                text: "My Story",
                                image: myStory[index].profileImage,
                                height: 75,
                                width: 75,
                                onClick: () {

                                  Get.to(StoryInsta(
                                    allStoryModel: myStory[index].stories,
                                    user_name: myStory[index]?.name ?? myStory[index]?.userName ?? "No Name",
                                    user_img: myStory[index]?.profileImage,
                                    isThisOwnStory: true,

                                  ));
                                  // Get.to(StoryList(allStoryModel: myStory[index].stories, user_name: myStory[index]?.name ?? "No Name",));
                                },
                              ),

                            ],
                          );
                        },
                      ),
                    ) : const Center(),
                    SizedBox(
                      height: 100,
                      width: myStory.isNotEmpty ?  MediaQuery.of(context).size.width*.45 : MediaQuery.of(context).size.width*.65,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: storyList.length,
                        itemBuilder: (_, index) {
                          return Row(
                            children: [
                              SizedBox(width: 6,),
                              StoryContainer(
                                text: storyList[index]?.name ?? storyList[index].userName ?? "No Name",
                                image: storyList[index]!.profileImage,
                                onClick: () {
                                  //  Get.to(StoryList(allStoryModel: storyList[index].stories, user_name: storyList[index]?.name ?? "No Name",));
                                  Get.to(
                                      StoryInsta(
                                        allStoryModel: storyList[index].stories,
                                        user_name: storyList[index]?.name ?? storyList[index].userName ?? "No Name",
                                        user_img: storyList[index]?.profileImage,
                                        isThisOwnStory: false,
                                      )
                                  );
                                },
                              ),
                            ],
                          );
                        },
                      ),
                    ),
                  ],
                ),
              );

            }else{
              return SizedBox(
                height: 100,
                child: InkWell(
                  onTap: ()=>CameraGalleryController.pickGalleryAndCameraForStory(context: context, from: "dashboard"),
                  child: Container(
                    margin: EdgeInsets.only(right: 18),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                            width: 76,
                            height: 76,
                            padding: EdgeInsets.all(3),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.grey.shade200,
                              gradient: LinearGradient(
                                colors: [
                                  Color(0xFF00CC83),
                                  Color(0xFF53E0DB),
                                ],
                              ),
                            ),
                            child: Center(child: Icon(Icons.add),)
                        ),
                        SizedBox(
                          height: 3,
                        ),
                        const Expanded(
                          child: Text(
                            "Add new",
                            style: TextStyle(
                                color: Color(0xFF777777),
                                fontSize: 14,
                                fontWeight: FontWeight.w500,

                                fontFamily: 'source-sans-pro-regular'),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              );
            }
          }
      ),
    );
  }





  ///////////
///////////////////////
//////////////
////////////////////









}



