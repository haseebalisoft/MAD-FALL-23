import 'package:flutter/material.dart';
import 'package:photo_manager/photo_manager.dart';

class CustomMediaPicker extends StatefulWidget {
  @override
  _CustomMediaPickerState createState() => _CustomMediaPickerState();
}

class _CustomMediaPickerState extends State<CustomMediaPicker> {
  List<AssetEntity> selectedAssets = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Custom Media Picker'),
      ),
      body: FutureBuilder<List<AssetPathEntity>>(
        future: PhotoManager.getAssetPathList(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return CircularProgressIndicator();
          } else if (snapshot.hasError) {
            return Text('Error: ${snapshot.error}');
          } else {
            List<AssetPathEntity>? assetPathList = snapshot.data;
            return Column(
              children: [
                Expanded(
                  child: GridView.builder(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      crossAxisSpacing: 4.0,
                      mainAxisSpacing: 4.0,
                    ),
                    itemCount: assetPathList?.length ?? 0,
                    itemBuilder: (context, index) {
                      AssetPathEntity pathEntity = assetPathList![index];
                      return GestureDetector(
                        onTap: () {
                          _loadAssets(pathEntity);
                        },
                        child: GridTile(
                          child: Image.network(
                            "",
                            // pathEntity.assetList!.isNotEmpty
                            //     ? pathEntity.assetList!.first.thumbDataUrl
                            //     : '',
                            fit: BoxFit.cover,
                          ),
                        ),
                      );
                    },
                  ),
                ),
                SizedBox(height: 8),
                Text('Selected Assets: ${selectedAssets.length}'),
                SizedBox(height: 8),
                ElevatedButton(
                  onPressed: () {
                    // Handle the selected assets as needed
                    print('Selected Assets: ${selectedAssets.map((e) => e.id).toList()}');
                  },
                  child: Text('Done'),
                ),
              ],
            );
          }
        },
      ),
    );
  }

  Future<void> _loadAssets(AssetPathEntity pathEntity) async {
    List<AssetEntity> assets = await pathEntity.getAssetListPaged(page: 0, size: pathEntity.assetCount ?? 0, );
    setState(() {
      selectedAssets = assets;
    });
  }
}
