import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'logic.dart';

class SearchFreelancerClientProfilePage extends StatelessWidget {
  final logic = Get.put(SearchFreelancerClientProfileLogic());
  final state = Get.find<SearchFreelancerClientProfileLogic>().state;

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
