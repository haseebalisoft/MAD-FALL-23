import 'package:coco/appConst.dart';
import 'package:coco/controller/authController.dart';
import 'package:coco/controller/searchFreelancerClientProfileController.dart';
import 'package:coco/controller/serviceController.dart';
import 'package:coco/model/authModel/allBusinessTypeModel.dart';
import 'package:coco/model/authModel/allUserList.dart';
import 'package:coco/model/authModel/serviceModle.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/view/freelancer/bottomNavigationBar/becameFreelanceBottomNavigation.dart';
import 'package:coco/view/search/all_filter_not_used.dart';
import 'package:coco/view/search_user.dart';
import 'package:coco/viewController/singleServiceDashboard.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../helper/helperWidgets.dart';
import '../../model/service/filterServiceModel.dart';
import '../../model/service/serviceModel.dart';
import '../Client/bottomNagivation/buttom_nav.dart';
import 'all_filter.dart';

class SearchFreelancerClientProfile extends StatefulWidget {
  final dynamic service;
  final List<FilterServiceList>? serviceListFromFilter;

  const SearchFreelancerClientProfile(
      {Key? key, this.service, this.serviceListFromFilter}) : super(key: key);

  @override
  State<SearchFreelancerClientProfile> createState() =>
      _SearchFreelancerClientProfileState();
}

class _SearchFreelancerClientProfileState
    extends State<SearchFreelancerClientProfile> {

  List service = [];

  final searchByUserName = TextEditingController();
  List serviceList = [];

  Future<AllUserModel>? getAllUser;
  Future<ServiceDataModel>? getAllSearchUsers;
  Future<ServiceDataModel>? getAllSearchByBusinessTypeUser;
  Future<ServiceModel>? getServices;
  Future<AllBusnissType>? getBusinessType;

  final SearchFreelancerClientProfileController searchFreelancerClientProfileController = Get
      .put(SearchFreelancerClientProfileController());
  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    proceedWithAllFunctions();

  }

  proceedWithAllFunctions() async {
    await searchFreelancerClientProfileController.getAllBusinessTypeOrServices();
  }

  //all service data
  getDataFromViewAllServices() {
    service.clear();
    setState(() {
      service.add(widget.service.toString());
    });
  }




  @override
  Widget build(BuildContext context) {

    return Obx(() {
      return SafeArea(
        child: Scaffold(
          backgroundColor: Colors.black,
          body: searchFreelancerClientProfileController.isLoadingForAllData.value
              ? const Center(
            child: CircularProgressIndicator(
              color: Colors.white,
            ),
          )
              :

            Column(
            children: [

              Padding(
                padding: const EdgeInsets.only(left: 15.0,
                    right: 15,
                    top: 20),
                child: Row(
                  children: [
                    // SizedBox(
                    //   width: 50,
                    //   height: 50,
                    //   child: IconButton(
                    //     onPressed: () {
                    //       searchFreelancerClientProfileController
                    //           .role == AppConst.CLIENT_ROLE
                    //           ? Navigator.push(context,
                    //           MaterialPageRoute(builder: (context) =>
                    //               ClientBottomNavigationBar()))
                    //           : Navigator.push(context,
                    //           MaterialPageRoute(builder: (context) =>
                    //               FreelancerAppBottomNavigation()));
                    //     },
                    //     icon: Icon(
                    //       Icons.arrow_back, color: Colors.white,),
                    //   ),
                    // ),
                    Expanded(
                      child: TextFormField(
                        controller: searchByUserName,
                        onChanged: (value) {
                          searchFreelancerClientProfileController.searchByName(value);
                        },
                        style: const TextStyle(
                          fontWeight: FontWeight.w400,
                          color: Colors.white,
                        ),
                        decoration: InputDecoration(
                          fillColor: Colors.white.withOpacity(0.15),
                          filled: true,
                          contentPadding: EdgeInsets.only(left: 15, right: 15, top: 0, bottom: 0),
                          border: InputBorder.none,
                          enabledBorder: OutlineInputBorder(
                           // borderSide: BorderSide(width: 1, color: AppColors.mainColor),
                            borderRadius: BorderRadius.circular(0),
                          ),
                          focusedBorder: OutlineInputBorder(
                           // borderSide: BorderSide(width: 1, color: AppColors.mainColor),
                            borderRadius: BorderRadius.circular(0),
                          ),
                          hintText: "Search services",
                          hintStyle: TextStyle(
                            fontWeight: FontWeight.w400,
                            color: Colors.grey,
                          ),
                          prefixIcon: Padding(
                            padding: const EdgeInsets.all(15.0), // Adjust padding as needed
                            child: Icon(
                              Icons.search,
                              color: Colors.grey,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              SizedBox(height: 20,),

              Row(
                children: [
                  InkWell(
                    onTap: () => Get.to(AllFilters(),
                        transition: Transition.downToUp),
                    child: Container(
                      height: 37,
                      margin: EdgeInsets.only(right: 0, left: 10),
                      decoration: BoxDecoration(
                          color: Colors.grey.shade900,
                          borderRadius: BorderRadius.circular(7),
                          border: Border.all(
                              width: 1, color: Colors.grey.shade600)
                      ),
                      child: Center(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              vertical: 5.0, horizontal: 12),
                          child: Row(
                            children: [
                              Icon(Icons.tune, color: Colors.white,
                                size: 20,),
                              SizedBox(width: 7,),
                              Text(
                                "All Filters",
                                style: TextStyle(color: Colors.white,
                                    fontFamily: ' Poppins-Bold',
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),

                Expanded(
                child: Container(
                padding: EdgeInsets.only(left: 10),
                height: 37,
                child:
                  searchFreelancerClientProfileController.role ==
                      AppConst.CLIENT_ROLE
                      ?
                  ListView.builder(
                    itemCount: searchFreelancerClientProfileController
                        .getServices.value!.data!.length,
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (_, index) {
                      return HelperWidget.buildSingleServiceList(
                          text: "${searchFreelancerClientProfileController
                              .getServices.value!.data![index].name}",
                          color: searchFreelancerClientProfileController
                              .service.contains(index.toString())
                              ? AppColors.mainColor
                              : Colors.grey.shade900,
                          borderColor: searchFreelancerClientProfileController
                              .service.contains(index.toString())
                              ? AppColors.mainColor
                              : Colors.grey.shade600,
                          textColor: searchFreelancerClientProfileController
                              .service.contains(index.toString())
                              ? Colors.black
                              : Colors.white,
                          onClick: () {
                            setState(() {

                              searchFreelancerClientProfileController.filterByServiceClick(index);

                            });
                          });
                    },
                  )
                      :

                  ListView.builder(
                    itemCount: searchFreelancerClientProfileController
                        .getBusinessType.value!.data!.length,
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (_, index) {
                      return HelperWidget.buildSingleServiceList(
                          text: "${searchFreelancerClientProfileController
                              .getBusinessType.value!.data![index]
                              .name}",
                          color: searchFreelancerClientProfileController
                              .service.contains(index.toString())
                              ? AppColors.mainColor
                              : Colors.grey.shade900,
                          borderColor: searchFreelancerClientProfileController
                              .service.contains(index.toString())
                              ? AppColors.mainColor
                              : Colors.grey.shade600,
                          textColor: searchFreelancerClientProfileController
                              .service.contains(index.toString())
                              ? Colors.black
                              : Colors.white,
                          onClick: () {
                            setState(() {

                              searchFreelancerClientProfileController.filterByServiceClick(index);
                              // searchFreelancerClientProfileController
                              //     .service.clear(); //first we clear all
                              // searchFreelancerClientProfileController
                              //     .service.add(index
                              //     .toString()); //then add the unick index
                              // searchFreelancerClientProfileController.getUserByIDWithRole(searchFreelancerClientProfileController.getBusinessType.value!.data![index].id!);
                            });
                          });
                    },
                  ),
        )
        ),
                ],
              ),

              SizedBox(height: 20,),




                    Expanded(
                      child: searchFreelancerClientProfileController.isLoadingForAllData.value == false &&
                             searchFreelancerClientProfileController.isLoadingForCards.value == true
                          ? const Center(
                        child: CircularProgressIndicator(
                          color: Colors.white,
                        ),
                      )
                          :


                      Container(
                        padding: EdgeInsets.only(left: 8, right: 8),
                        child: RefreshIndicator(
                          color: AppColors.mainColor,
                          onRefresh: () async {
                            await Future.delayed(const Duration(seconds: 2));
                            await searchFreelancerClientProfileController.getAllBusinessTypeOrServices();
                          },
                          child: ListView.builder(
                            //physics: NeverScrollableScrollPhysics(),
                            shrinkWrap: true,
                            itemCount: searchFreelancerClientProfileController.getAllUser.value?.data!.length,
                            itemBuilder: (_, index) {
                              var data = searchFreelancerClientProfileController.getAllUser.value?.data![index];
                              print("services ====== data === ${data}");
                              return SingleServiceDashboard(
                                size: MediaQuery.of(context).size,
                                name: "${data?.name}",
                                profile: "${data?.profileImage}",
                                amount: data?.userInfo?.pricePerDay ??
                                    "0",
                                bgImage: data?.coverImage ??
                                    "https://st4.depositphotos.com/14953852/24787/v/450/depositphotos_247872612-stock-illustration-no-image-available-icon-vector.jpg",
                                onClick: () {
                                  print("click profile");
                                  //searchFreelancerClientProfileController.reset();
                                  searchFreelancerClientProfileController.getAllBusinessTypeOrServices();

                                  Navigator.push(context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              ClientBottomNavigationBar(
                                                pageIndex: 6,
                                                userId: "${data!.userInfo!
                                                    .userId
                                                    .toString()}",)));
                                },
                                isCollabration: data?.role ==
                                    AppConst.CLIENT_ROLE ? false : true,
                                isPrice: data?.role == AppConst.CLIENT_ROLE
                                    ? false
                                    : true,
                                isClient: data?.role ==
                                    AppConst.CLIENT_ROLE ? true : false,
                              );
                            },
                          ),
                        ),
                      ),
                    )
            ],
          ),
        ),
      );
    });
  }


}