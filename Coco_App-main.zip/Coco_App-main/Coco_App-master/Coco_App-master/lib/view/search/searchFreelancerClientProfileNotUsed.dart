import 'package:coco/appConst.dart';
import 'package:coco/controller/authController.dart';
import 'package:coco/controller/serviceController.dart';
import 'package:coco/model/authModel/allBusinessTypeModel.dart';
import 'package:coco/model/authModel/allUserList.dart';
import 'package:coco/model/authModel/serviceModle.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/view/freelancer/bottomNavigationBar/becameFreelanceBottomNavigation.dart';
import 'package:coco/view/search/all_filter_not_used.dart';
import 'package:coco/view/search_user.dart';
import 'package:coco/viewController/singleServiceDashboard.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../helper/helperWidgets.dart';
import '../../model/service/filterServiceModel.dart';
import '../../model/service/serviceModel.dart';
import '../Client/bottomNagivation/buttom_nav.dart';
import 'all_filter.dart';

class SearchFreelancerClientProfileNotUsed extends StatefulWidget {
  final dynamic service;
  final List<FilterServiceList>? serviceListFromFilter;
  const SearchFreelancerClientProfileNotUsed({Key? key, this.service, this.serviceListFromFilter}) : super(key: key);

  @override
  State<SearchFreelancerClientProfileNotUsed> createState() => _SearchFreelancerClientProfileNotUsedState();
}

class _SearchFreelancerClientProfileNotUsedState extends State<SearchFreelancerClientProfileNotUsed> {

  List service = [];

  final searchByUserName = TextEditingController();
  List serviceList = [];

  Future<AllUserModel>? getAllUser;
  Future<ServiceDataModel>? getAllSearchUsers;
  Future<ServiceDataModel>? getAllSearchByBusinessTypeUser;
  Future<ServiceModel>? getServices;
  Future<AllBusnissType>? getBusinessType;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    getUserByIDWithRole();


    print("service ---- ${service.isEmpty}");
    print("serviceListFromFilter ---- ${widget.serviceListFromFilter}");

    
    getAllUser = AuthController.getAllUsers();
    getServices = AuthController.getServiceList();
    getBusinessType = AuthController.getBusinessTypes();


  }

  //all service data
  getDataFromViewAllServices(){
    service.clear();
    setState((){
      service.add(widget.service.toString());
    });
  }

  //current user role
  var role;
  getUserByIDWithRole()async{
    print("object");
    SharedPreferences _pref = await SharedPreferences.getInstance();
     setState(() {
       role = _pref.getString("role");
       print(role);
     });
    if(service.isNotEmpty && role == AppConst.CLIENT_ROLE) {
      getAllSearchUsers = ServiceController.getUserByServiceId(service[0].toString());
      return;
    }
    if(service.isNotEmpty && role == AppConst.FREELANCER_ROLE){
      getAllSearchUsers =  ServiceController.getUserByBusinessTypeId(service[0].toString());
      return;
    }
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Container(
      color: Colors.black,
      child: SafeArea(
        child: Scaffold(
          backgroundColor: Colors.black,
          body: Column(
            children: [

              Expanded(
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 15.0, right: 15, top: 20),
                      child: Row(
                        children: [
                          SizedBox(
                            width: 50,
                            height: 50,
                            child: IconButton(
                              onPressed: (){
                                role == AppConst.CLIENT_ROLE ?   Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientBottomNavigationBar())):  Navigator.push(context, MaterialPageRoute(builder: (context)=>FreelancerAppBottomNavigation()));
                              },
                              icon: Icon(Icons.arrow_back, color: Colors.white,),
                            ),
                          ),
                          Expanded(
                            child: TextFormField(
                              onTap: ()=>Get.to(SearchUser()),
                              readOnly: true,
                              controller: searchByUserName,
                              decoration:  InputDecoration(
                                  fillColor: Color(0xff5D5D5D5A),
                                  filled: true,
                                  contentPadding: EdgeInsets.only(left: 15, right: 15, top: 0, bottom: 0),
                                  border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(100)
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(width: 1,color: AppColors.formColorUp),
                                      borderRadius: BorderRadius.circular(100)
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(width: 1,color: AppColors.formColorUp),
                                      borderRadius: BorderRadius.circular(100)
                                  ),
                                  hintText: "Search",
                                  hintStyle:TextStyle(fontWeight: FontWeight.w400, color: Colors.grey),
                                  prefixIcon: Icon(Icons.search, color: Colors.grey)
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    SizedBox(height: 20,),
                    ////////////////////////////
                    /////// service///////////
                    ///////////////////////////
                    role == AppConst.CLIENT_ROLE
                        ? FutureBuilder<ServiceModel>(
                        future: getServices,
                        builder: (context, snapshot) {
                          if(snapshot.connectionState == ConnectionState.waiting){
                            return Container(
                                padding: EdgeInsets.only(left: 20, right: 20),
                                height: 30,
                          //  child: CircularProgressIndicator(color: Colors.white,),
                            //     child: ListView.builder(
                            //   itemCount: 20,
                            //   scrollDirection: Axis.horizontal,
                            //   itemBuilder: (_, index) {
                            //     return Shimmer.fromColors(
                            //       highlightColor: Colors.grey.shade300,
                            //       baseColor: Colors.white,
                            //       child: Container(
                            //         height: 30,
                            //         width: 130,
                            //         margin: EdgeInsets.only(right: 10),
                            //         decoration: BoxDecoration(
                            //             borderRadius: BorderRadius.circular(100),
                            //             color: Colors.white
                            //         ),
                            //       ),
                            //     );
                            //   },
                            // )
                            );
                          } else if(snapshot.hasData){
                            return  Row(
                              children: [
                                role == AppConst.CLIENT_ROLE ?   InkWell(
                                  onTap: ()=>Get.to(AllFilters(), transition: Transition.downToUp),
                                  child: Container(
                                    height: 37,
                                    margin: EdgeInsets.only(right: 0, left: 10),
                                    decoration: BoxDecoration(
                                        color: Colors.grey.shade900,
                                        borderRadius: BorderRadius.circular(7),
                                        border: Border.all(width: 1, color: Colors.grey.shade600)
                                    ),
                                    child: Center(
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 12),
                                        child: Row(
                                          children: [
                                            Icon(Icons.tune, color: Colors.white, size: 20,),
                                            SizedBox(width: 7,),
                                            Text(
                                              "All Filters",
                                              style: TextStyle(color: Colors.white,fontFamily: ' Poppins-Bold',fontSize: 11,fontWeight: FontWeight.bold),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ) : Center(),
                                Expanded(
                                  child: Container(
                                    padding: EdgeInsets.only(left: 20, right: 20),
                                    height: 37,
                                    child: ListView.builder(
                                      itemCount: snapshot.data!.data!.length,
                                      scrollDirection: Axis.horizontal,
                                      itemBuilder: (_, index) {
                                        return HelperWidget.buildSingleServiceList(
                                            text: "${snapshot.data!.data![index]!.name}",
                                            color: service.contains(index.toString())
                                                ? AppColors.mainColor
                                                :  Colors.grey.shade900,
                                            borderColor: service.contains(index.toString())
                                                ? AppColors.mainColor
                                                :  Colors.grey.shade600,
                                            textColor: service.contains(index.toString())
                                                ? Colors.black
                                                : Colors.white,
                                            onClick: () {
                                              setState(() {
                                                service.clear(); //first we clear all
                                                service.add(index.toString()); //then add the unick index
                                                getUserByIDWithRole();
                                              });
                                            });
                                      },
                                    ),
                                  ),
                                ),
                              ],
                            );
                          }else{
                            return Center(child: Text("Something went wrong"),);
                          }
                        }
                    )
                        : FutureBuilder<AllBusnissType>(
                        future: getBusinessType,
                        builder: (context, snapshot) {
                          if(snapshot.connectionState == ConnectionState.waiting){
                            return Container(
                                padding: EdgeInsets.only(left: 20, right: 20),
                                height: 30,
                                // child: CircularProgressIndicator(color: Colors.white,),
                                // child: ListView.builder(
                                //   itemCount: 20,
                                //   scrollDirection: Axis.horizontal,
                                //   itemBuilder: (_, index) {
                                //     return Shimmer.fromColors(
                                //       highlightColor: Colors.grey.shade300,
                                //       baseColor: Colors.white,
                                //       child: Container(
                                //         height: 30,
                                //         width: 130,
                                //         margin: EdgeInsets.only(right: 10),
                                //         decoration: BoxDecoration(
                                //             borderRadius: BorderRadius.circular(100),
                                //             color: Colors.white
                                //         ),
                                //       ),
                                //     );
                                //   },
                                // )
                            );
                          } else if(snapshot.hasData){
                            return  Row(
                              children: [
                                InkWell(
                                  onTap: ()=>Get.to(AllFilters(), transition: Transition.downToUp),
                                  child: Container(
                                    height: 37,
                                    margin: EdgeInsets.only(right: 0, left: 10),
                                    decoration: BoxDecoration(
                                        color: Colors.grey.shade900,
                                        borderRadius: BorderRadius.circular(7),
                                        border: Border.all(width: 1, color: Colors.grey.shade600)
                                    ),
                                    child: Center(
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 12),
                                        child: Row(
                                          children: [
                                            Icon(Icons.tune, color: Colors.white, size: 20,),
                                            SizedBox(width: 7,),
                                            Text(
                                              "All Filters",
                                              style: TextStyle(color: Colors.white,fontFamily: ' Poppins-Bold',fontSize: 11,fontWeight: FontWeight.bold),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Container(
                                    padding: EdgeInsets.only(left: 20, right: 20),
                                    height: 37,
                                    child: ListView.builder(
                                      itemCount: snapshot.data!.data!.length,
                                      scrollDirection: Axis.horizontal,
                                      itemBuilder: (_, index) {
                                        return HelperWidget.buildSingleServiceList(
                                            text: "${snapshot.data!.data![index]!.name}",
                                            color: service.contains(index.toString())
                                                ? AppColors.mainColor
                                                :  Colors.grey.shade900,
                                            borderColor: service.contains(index.toString())
                                                ? AppColors.mainColor
                                                :  Colors.grey.shade600,
                                            textColor: service.contains(index.toString())
                                                ? Colors.black
                                                : Colors.white,
                                            onClick: () {
                                              setState(() {
                                                service.clear(); //first we clear all
                                                service.add(index.toString()); //then add the unick index
                                                getUserByIDWithRole();
                                              });
                                            });
                                      },
                                    ),
                                  ),
                                ),
                              ],
                            );
                          }else{
                            return Center(child: Text("Something went wrong"),);
                          }
                        }
                    ),

                    ////////////////////////////
                    /////// service///////////
                    ///////////////////////////


                    SizedBox(height: 20,),

                    widget.serviceListFromFilter != null  //if widget service is not is null then open blew List
                        ? Expanded(
                      child: Container(
                        padding: EdgeInsets.only(left: 8, right: 8),
                        child: widget.serviceListFromFilter!.length == 0
                            ? const Center(child: Text("Freelancer not found",
                          style: TextStyle(
                              fontSize: 16,
                              color: Colors.white
                          ),
                        ),)
                            :ListView.builder(
                          //physics: NeverScrollableScrollPhysics(),
                            shrinkWrap: true,
                            itemCount: widget.serviceListFromFilter!.length,
                            itemBuilder: (_, index) {
                              var data = widget.serviceListFromFilter![index];

                              print("search is not empty === ${data}");

                              return SingleServiceDashboard(
                                size: size,
                                name: "${data.user!.name}",
                                profile: "${data.user!.profileImage}",
                                amount: "${data.pricePerDay ?? "0"}",
                                bgImage: data!.user!.coverImage ?? "https://st4.depositphotos.com/14953852/24787/v/450/depositphotos_247872612-stock-illustration-no-image-available-icon-vector.jpg",
                                onClick: () {
                                  print("cleck profile");
                                  Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientBottomNavigationBar(pageIndex: 6, userId: "${data!.userId.toString()}",ProfileUserId:"${data!.userId.toString()}")));

                                },
                                isCollabration: data.user!.role == AppConst.CLIENT_ROLE ? false:true ,
                                isPrice:  data.user!.role == AppConst.CLIENT_ROLE ? false:true ,
                                isClient: data.user!.role == AppConst.CLIENT_ROLE ? true : false ,
                              );
                            }

                        ),
                      ),
                    )
                        : service.isNotEmpty
                       ? FutureBuilder<ServiceDataModel>(
                         future: getAllSearchUsers,
                         builder: (_, snapshot){
                           if(snapshot.connectionState == ConnectionState.waiting){
                             return Center(
                               child: Container(
                                 height: 50,
                                 width: 50,
                                 child: SizedBox(height: 50,    width: 50, child: CircularProgressIndicator(color: Colors.white,)),
                               ),
                             );
                           }else if(snapshot.hasData){
                             return  Expanded(
                               child: Container(
                                 padding: EdgeInsets.only(left: 8, right: 8),
                                 child: snapshot.data!.data!.length == 0
                                     ? const Center(child: Text("Data not found",
                                  style: TextStyle(
                                    fontSize: 16,
                                    color: Colors.white
                                  ),
                                 ),)
                                     :ListView.builder(
                                   //physics: NeverScrollableScrollPhysics(),
                                   shrinkWrap: true,
                                   itemCount: snapshot.data!.data!.length,
                                   itemBuilder: (_, index) {
                                     var data = snapshot.data!.data![index];

                                     print("search is not empty === ${data}");

                                       return SingleServiceDashboard(
                                         size: size,
                                         name: "${data.name}",
                                         profile: "${data.profileImage}",
                                         amount: "${data.userInfo?.pricePerDay ?? "0"}",
                                         bgImage: data!.coverImage ?? "https://st4.depositphotos.com/14953852/24787/v/450/depositphotos_247872612-stock-illustration-no-image-available-icon-vector.jpg",
                                         onClick: () {
                                           print("cleck profile");
                                           Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientBottomNavigationBar(pageIndex: 6, userId: "${data!.userInfo!.userId.toString()}",ProfileUserId:"${data!.userInfo!.userId.toString()}")));

                                         },
                                         isCollabration: data.role == AppConst.CLIENT_ROLE ? false:true ,
                                         isPrice:  data.role == AppConst.CLIENT_ROLE ? false:true ,
                                         isClient: data.role == AppConst.CLIENT_ROLE ? true : false ,
                                       );
                                     }

                                 ),
                               ),
                             );
                           }else{
                             return Center(child: Text("Please check your internet."),);
                           }
                         },
                       )
                       : FutureBuilder<AllUserModel>(
                      future: getAllUser,
                      builder: (_, snapshot){
                        if(snapshot.connectionState == ConnectionState.waiting){
                          return Center(
                            child: Container(
                              height: 50,
                              width: 50,
                             // padding: EdgeInsets.only(left: 8, right: 8),
                              child: SizedBox(height: 50,  width: 50,  child: CircularProgressIndicator(color: Colors.white,)),
                              // child: ListView.builder(
                              //   //physics: NeverScrollableScrollPhysics(),
                              //   shrinkWrap: true,
                              //   itemCount: 10,
                              //   itemBuilder: (_, index) {
                              //     return Shimmer.fromColors(
                              //       highlightColor: Colors.grey.shade300,
                              //       baseColor: Colors.white,
                              //       child: Container(
                              //         height: 200,
                              //         width: MediaQuery.of(context).size.width,
                              //         margin: EdgeInsets.only(bottom: 20),
                              //         decoration: BoxDecoration(
                              //             borderRadius: BorderRadius.circular(5),
                              //             color: Colors.white
                              //         ),
                              //       ),
                              //     );
                              //   },
                              // ),
                            ),
                          );
                        }else if(snapshot.hasData){
                         return  Expanded(
                              child: Container(
                              padding: EdgeInsets.only(left: 8, right: 8),
                                child: ListView.builder(
                                //physics: NeverScrollableScrollPhysics(),
                                shrinkWrap: true,
                                itemCount: snapshot.data!.data!.length,
                                itemBuilder: (_, index) {
                                var data = snapshot.data!.data![index];
                                print("services ====== data === ${data}");
                                return SingleServiceDashboard(
                                    size: size,
                                    name: "${data.name}",
                                    profile: "${data.profileImage}",
                                    amount: "${data.userInfo?.pricePerDay ?? "0"}",
                                    bgImage: data!.coverImage ?? "https://st4.depositphotos.com/14953852/24787/v/450/depositphotos_247872612-stock-illustration-no-image-available-icon-vector.jpg",
                                    onClick: () {
                                    print("click profile");
                                    Navigator.push(context, MaterialPageRoute(builder: (context)=>ClientBottomNavigationBar(pageIndex: 6, userId: "${data!.userInfo!.userId.toString()}",)));
                                    },
                                    isCollabration: data.role == AppConst.CLIENT_ROLE ? false:true ,
                                    isPrice:  data.role == AppConst.CLIENT_ROLE ? false:true ,
                                    isClient: data.role == AppConst.CLIENT_ROLE ? true : false ,
                                  );
                                },
                                ),
                                ),
                          );
                        }else{
                          return Center(child: Text("Please check your internet."),);
                        }
                      },
                    )


                  ],
                ),
              )



            ],
          ),
        ),
      ),
    );
  }


}