class SearchFreelancerClientProfileState {
  SearchFreelancerClientProfileState() {
    ///Initialize variables
  }
}
