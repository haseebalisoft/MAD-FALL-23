import 'package:get/get.dart';

import 'state.dart';

class SearchFreelancerClientProfileLogic extends GetxController {
  final SearchFreelancerClientProfileState state = SearchFreelancerClientProfileState();
}
