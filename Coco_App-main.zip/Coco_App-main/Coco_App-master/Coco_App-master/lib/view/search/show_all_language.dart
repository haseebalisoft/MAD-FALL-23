import 'package:coco/controller/authController.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../appConst.dart';
import '../../controller/all_filter_controller.dart';
import '../../model/authModel/languesModel.dart';
import '../../utility/colors.dart';

class ShowAllLanguages extends StatefulWidget {
  const ShowAllLanguages({Key? key}) : super(key: key);

  @override
  State<ShowAllLanguages> createState() => _ShowAllLanguagesState();
}

class _ShowAllLanguagesState extends State<ShowAllLanguages> {
  //////// empty languages future ///////


  List<Datum>? searchLaguages = [];
  final AllFilterController allFilterController = Get.find<
      AllFilterController>();

  bool showSearchField = false;


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      return Container(
        color: Colors.black,
        child: SafeArea(
          child: Scaffold(
            backgroundColor: Colors.black,
            appBar: AppBar(
              backgroundColor: Colors.black,
              elevation: 0,
              leading: IconButton(
                onPressed: () => Get.back(),
                icon: Icon(Icons.arrow_back, color: Colors.white,),
              ),
                title: showSearchField == true
                    ? Container(
                  padding: EdgeInsets.all(0),
                  child: TextFormField(
                    autofocus: true,
                    cursorColor: AppColors.mainColor,
                    style: TextStyle(
                        fontSize: 15,
                        color: Colors.white
                    ),
                    onChanged: searchServiceOneChange,
                    decoration: InputDecoration(
                        contentPadding: EdgeInsets.zero,
                        fillColor: Colors.transparent,
                        border: OutlineInputBorder(
                          borderSide: BorderSide.none,
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide.none,
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide.none,
                        )
                    ),
                  ),
                )
                    : Text(
                  "Languages",
                  style: TextStyle(
                      fontWeight: FontWeight.w500,
                      color: Colors.white
                  ),
                ),
                actions: [
                  showSearchField == false
                      ? IconButton(
                    onPressed: () {
                      setState(() {
                        showSearchField = !showSearchField;
                      });
                    },
                    icon: Icon(Icons.search, color: Colors.white,),
                  )
                      : const SizedBox()
                ]
            ),
            body: searchLaguages!.isEmpty ? ListView.builder(
                      shrinkWrap: true,
                      itemCount: allFilterController.languages.value!.data!.length,
                      itemBuilder: (_, index) {
                        return Column(
                          children: [
                            ListTile(
                              onTap: () {
                                setState(() {
                                  //  _selectedSearchItems.clear();
                                  if (allFilterController.selectedLangauges.contains(
                                      allFilterController.languages.value!.data![index].id.toString())) {
                                    allFilterController.selectedLangauges.remove(
                                        allFilterController.languages.value!.data![index].id.toString());
                                  } else {
                                    allFilterController.selectedLangauges.add(
                                        allFilterController.languages.value!.data![index].id.toString());
                                  }
                                });
                              },
                              title: Row(
                                children: [
                                  Text("${allFilterController.languages.value!.data![index].name}",
                                    style: TextStyle(
                                        fontWeight: FontWeight.w500,
                                        color: Colors.white
                                    ),
                                  ),
                                  SizedBox(width: 10),
                                  Text("(${allFilterController.languages.value!.data![index].totalUser})",
                                    style: TextStyle(
                                        fontWeight: FontWeight.w500,
                                        color: Colors.white
                                    ),
                                  ),

                                ],
                              ),
                              trailing: Container(
                                width: 25,
                                height: 25,
                                decoration: BoxDecoration(
                                  color: allFilterController.selectedLangauges.contains(
                                      allFilterController.languages.value!.data![index]!.id.toString())
                                      ? AppColors.mainColor
                                      : Colors.transparent,
                                  borderRadius: BorderRadius.circular(100),
                                  border: Border.all(color: Colors.white, width: 1),
                                ),
                                child: allFilterController.selectedLangauges.contains(
                                    allFilterController.languages.value!.data![index]!.id.toString())
                                    ? Icon(
                                  Icons.check, color: Colors.black, size: 17,)
                                    : Center(),
                              ),
                            ),
                            Container(
                              height: 1,
                              color: Colors.grey,
                            )
                          ],
                        );
                      },
                    )
                        : ListView.builder(
                      shrinkWrap: true,
                      itemCount: searchLaguages?.length,
                      itemBuilder: (_, index) {
                        return Column(
                          children: [
                            ListTile(
                              onTap: () {
                                setState(() {
                                  //  _selectedSearchItems.clear();
                                  if (allFilterController.selectedLangauges.contains(
                                      searchLaguages![index].id.toString())) {
                                    allFilterController.selectedLangauges.remove(
                                        searchLaguages![index].id.toString());
                                  } else {
                                    allFilterController.selectedLangauges.add(
                                        searchLaguages![index].id.toString());
                                  }
                                });
                              },
                              title: Row(
                                children: [
                                  Text("${searchLaguages?[index].name}",
                                    style: TextStyle(
                                        fontWeight: FontWeight.w500,
                                        color: Colors.white
                                    ),
                                  ),
                                  SizedBox(width: 10),
                                  Text("(${searchLaguages?[index].totalUser})",
                                    style: TextStyle(
                                        fontWeight: FontWeight.w500,
                                        color: Colors.white
                                    ),
                                  ),

                                ],
                              ),

                              trailing: Container(
                                width: 25,
                                height: 25,
                                decoration: BoxDecoration(
                                  color: allFilterController.selectedLangauges.contains(
                                      searchLaguages![index]!.id.toString())
                                      ? AppColors.mainColor
                                      : Colors.transparent,
                                  borderRadius: BorderRadius.circular(100),
                                  border: Border.all(color: Colors.white, width: 1),
                                ),
                                child: allFilterController.selectedLangauges.contains(
                                    searchLaguages![index]!.id.toString())
                                    ? Icon(
                                  Icons.check, color: Colors.black, size: 17,)
                                    : Center(),
                              ),
                            ),
                            Container(
                              height: 1,
                              color: Colors.grey,
                            )
                          ],
                        );
                      },
                    ),
            bottomNavigationBar: allFilterController.selectedLangauges.isNotEmpty
                ? Container(
              margin: EdgeInsets.all(30),
              width: double.infinity,
              child: ElevatedButton(
                  style: OutlinedButton.styleFrom(
                    backgroundColor: AppColors.mainColor,
                  ),
                  onPressed: () async {
                    allFilterController.refreshUI();
                    Get.back();
                    // Navigator.push(context, MaterialPageRoute(
                    //     builder: (context) =>
                    //         ClientBottomNavigationBar(pageIndex: 1, userId: _selectedSearchItems[0].toString() ,)));
                  },
                  child: Text(
                    'Apply',
                    style: TextStyle(color: Colors.white, fontSize: 13),
                  )),
            )
                : Container(height: 1,),
          ),
        ),
      );
    });
  }

  void searchServiceOneChange(String value) {
    setState(() {
      searchLaguages!.clear();
    });
    //////// if the role is freelnacer then we store data only searchBusinessList
    for (var data in allFilterController.languages.value!.data!) {
      if (data!.name!.toLowerCase().contains(value.toLowerCase())) {
        setState(() {
          searchLaguages?.add(data);
        });
      }
    }
    return;
  }
}
