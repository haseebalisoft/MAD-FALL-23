import 'package:coco/appConst.dart';
import 'package:coco/controller/authController.dart';
import 'package:coco/controller/serviceController.dart';
import 'package:coco/main.dart';
import 'package:coco/model/authModel/allBusinessTypeModel.dart';
import 'package:coco/model/authModel/businessHoursModel.dart';
import 'package:coco/model/authModel/serviceModle.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/view/Client/bottomNagivation/buttom_nav.dart';
import 'package:coco/view/search/clientSearch.dart';
import 'package:coco/view/search/searchFreelancerClientProfileNotUsed.dart';
import 'package:coco/view/search/show_all_language.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:coco/viewController/showAllert.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../controller/all_filter_controller.dart';
import '../../controller/searchFreelancerClientProfileController.dart';
import '../../model/authModel/languesModel.dart';
import 'view_more_Category.dart';

class AllFilters extends StatefulWidget {
  const AllFilters({Key? key}) : super(key: key);

  @override
  State<AllFilters> createState() => _AllFiltersState();
}

class _AllFiltersState extends State<AllFilters> {

  final minPrice = TextEditingController();
  final maxPrice = TextEditingController();
  var minPriceFocusNode = FocusNode();
  var maxPriceFocusNode = FocusNode();



  final SearchFreelancerClientProfileController searchFreelancerClientProfileController = Get
      .find<SearchFreelancerClientProfileController>();
  final AllFilterController allFilterController = Get.put(
      AllFilterController());

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    searchFreelancerClientProfileController.service.clear();
    allFilterController.getAllNecessaryData();

  }


  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      systemNavigationBarColor: Colors.black,
      statusBarColor: Colors.black,
    ));
    return Container(
      color: Colors.black,
      child: SafeArea(
        child: Obx(() {
          return allFilterController.isLoading.value ? const Center(
            child: CircularProgressIndicator(
              color: AppColors.white,
            ),
          )
        : Scaffold(
            backgroundColor: Colors.black,
            appBar: AppBar(
              backgroundColor: Colors.black,
              automaticallyImplyLeading: false,
              elevation: 0,
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      IconButton(
                        onPressed: () {
                          SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
                            systemNavigationBarColor: Colors.black,
                            statusBarColor: Colors.black,
                          ));
                          Navigator.of(context).pop();
                        },
                        icon: Icon(
                          Icons.close,
                          color: Colors.white,
                          size: 30,
                        ),
                      ),
                      Text(
                        "All Filters",
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      )
                    ],
                  ),
                  TextButton(
                    onPressed: () => clearAll(),
                    child: const Text(
                      "Clear All",
                      style: TextStyle(
                        color: AppColors.mainColor,
                      ),
                    ),
                  )
                ],
              ),
            ),
            body: SingleChildScrollView(
              padding: EdgeInsets.all(20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [

                  const SizedBox(height: 20,),
                  Text(allFilterController.role.value == AppConst.CLIENT_ROLE
                      ? "Service Type"
                      : "Business Type",
                    style: const TextStyle(
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                        fontSize: 15
                    ),
                  ),
                  const SizedBox(height: 10,),


                  allFilterController.role.value == AppConst.CLIENT_ROLE
                      ? Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [

                              Container(
                                // padding: EdgeInsets.only(left: 20, right: 20),
                                child: GridView.builder(
                                  physics: NeverScrollableScrollPhysics(),
                                  shrinkWrap: true,
                                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 3,
                                    crossAxisSpacing: 5.0,
                                    mainAxisSpacing: 10.0,
                                    childAspectRatio: MediaQuery
                                        .of(context)
                                        .size
                                        .width /
                                        (MediaQuery
                                            .of(context)
                                            .size
                                            .height / 7),
                                  ),
                                  itemCount: allFilterController.getServices.value!.data!.length > 4
                                      ? 4
                                      : allFilterController.getServices.value!.data!.length,
                                  itemBuilder: (context, index) {
                                    return buildSingleServiceList(
                                        text: "${allFilterController.getServices.value!.data![index]
                                            .name}",
                                        color: allFilterController.service.contains(
                                            allFilterController.getServices.value!.data![index].id.toString())
                                            ? AppColors.mainColor
                                            : Colors.grey.shade900,
                                        borderColor: allFilterController.service.contains(
                                            allFilterController.getServices.value!.data![index].id.toString())
                                            ? AppColors.mainColor
                                            : Colors.grey.shade600,
                                        textColor: allFilterController.service.contains(
                                            allFilterController.getServices.value!.data![index].id.toString())
                                            ? Colors.black
                                            : Colors.white,
                                        onClick: () {
                                          setState(() {
                                            //service.clear(); //
                                            // first we clear all
                                            if (allFilterController.service.contains(
                                                allFilterController.getServices.value!.data![index].id.toString())) {
                                              allFilterController.service.remove(allFilterController.getServices.value!.data![index].id.toString());
                                            } else {
                                              allFilterController.service.add(allFilterController.getServices.value!.data![index].id.toString()); //then add the unick index
                                            }
                                          });
                                        });
                                  },
                                ),

                              ),
                              allFilterController.leftTypeLength.value != 0 ? TextButton(
                                onPressed: () =>
                                    Get.to(ViewMoreCategoryForFilter(
                                        role: "${allFilterController.role}")),
                                child: Text(" ${allFilterController.leftTypeLength.value} + More",
                                  style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      color: AppColors.mainColor
                                  ),
                                ),
                              ) : Center(),
                            ],
                          )
                      : Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [

                              Container(
                                // padding: EdgeInsets.only(left: 20, right: 20),
                                child: GridView.builder(
                                  physics: NeverScrollableScrollPhysics(),
                                  shrinkWrap: true,
                                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 3,
                                    crossAxisSpacing: 5.0,
                                    mainAxisSpacing: 10.0,
                                    childAspectRatio: MediaQuery
                                        .of(context)
                                        .size
                                        .width /
                                        (MediaQuery
                                            .of(context)
                                            .size
                                            .height / 7),
                                  ),
                                  itemCount: allFilterController.getBusinessType.value!.data!.length > 4
                                      ? 4
                                      : allFilterController.getBusinessType.value!.data!.length,
                                  itemBuilder: (context, index) {
                                    return buildSingleServiceList(
                                        text: "${allFilterController.getBusinessType.value!.data![index]
                                            .name}",
                                        color: allFilterController.service.contains(
                                            allFilterController.getBusinessType.value!.data![index].id.toString())
                                            ? AppColors.mainColor
                                            : Colors.black,
                                        borderColor: allFilterController.service.contains(
                                            allFilterController.getBusinessType.value!.data![index].id.toString())
                                            ? AppColors.mainColor
                                            : Colors.white.withOpacity(0.4),
                                        textColor: allFilterController.service.contains(
                                            allFilterController.getBusinessType.value!.data![index].id.toString())
                                            ? Colors.black
                                            : Colors.white,
                                        onClick: () {
                                          setState(() {
                                            //service.clear(); //first we clear all
                                            if (allFilterController.service.contains(
                                                allFilterController.getBusinessType.value!.data![index].id.toString())) {
                                              allFilterController.service.remove(allFilterController.getBusinessType.value!.data![index].id.toString());
                                              searchFreelancerClientProfileController.selectedEffectByServiceClick(index); //then add the unick index
                                            } else {
                                              allFilterController.service.add(allFilterController.getBusinessType.value!.data![index].id.toString()); //then add the unick index
                                              searchFreelancerClientProfileController.selectedEffectByServiceClick(index); //then add the unick index

                                            }
                                          });
                                        });
                                  },
                                ),
                              ),
                            allFilterController.leftTypeLength.value != 0 ? TextButton(
                                onPressed: () =>
                                    Get.to(ViewMoreCategoryForFilter(
                                        role: "${allFilterController.role}"),
                                        transition: Transition.rightToLeft),

                                child: Text("${allFilterController.leftTypeLength.value} + More",
                                  style: const TextStyle(
                                      fontSize: 16,
                                      color: AppColors.mainColor
                                  ),
                                ),
                              ) : Center(),
                            ],
                          ),

                  /////////////////// price range ///////////////////////
                  const SizedBox(height: 30,),
                  const Text("Price range",
                    style: TextStyle(
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                        fontSize: 15
                    ),
                  ),
                  const SizedBox(height: 10,),
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Min",
                              style: TextStyle(
                                  fontSize: 10, color: Colors.white
                              ),
                            ),
                            SizedBox(height: 5,),
                            TextFormField(
                              style: TextStyle(color: Colors.white,
                                  fontSize: 12
                              ),
                              // Set the text color to white
                              controller: minPrice,
                              focusNode: minPriceFocusNode,
                              keyboardType: TextInputType.number,
                              decoration: InputDecoration(
                                labelStyle: TextStyle(
                                    color: Colors.white
                                ),
                                fillColor: Colors.black,
                                filled: true,
                                contentPadding: EdgeInsets.only(
                                    left: 15, right: 15, top: 0, bottom: 0),
                                border: OutlineInputBorder(
                                    borderSide: BorderSide(width: 0.5,
                                        color: Colors.white.withOpacity(0.5)),
                                    borderRadius: BorderRadius.circular(5)
                                ),
                                enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(width: 0.5,
                                        color: Colors.white.withOpacity(0.5)),
                                    borderRadius: BorderRadius.circular(5)
                                ),
                                focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(width: 0.5,
                                        color: Colors.white.withOpacity(0.5)),
                                    borderRadius: BorderRadius.circular(5)
                                ),
                                hintText: "\$",
                                hintStyle: TextStyle(
                                    fontWeight: FontWeight.w400,
                                    color: Colors.grey),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(width: 10,),
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Max",
                              style: TextStyle(
                                  fontSize: 10, color: Colors.white
                              ),
                            ),
                            SizedBox(height: 5,),
                            TextFormField(
                              focusNode: maxPriceFocusNode,
                              style: TextStyle(color: Colors.white,
                                  fontSize: 12
                              ),
                              //
                              controller: maxPrice,
                              keyboardType: TextInputType.number,
                              decoration: InputDecoration(
                                fillColor: Colors.black,
                                filled: true,
                                contentPadding: EdgeInsets.only(
                                    left: 15, right: 15, top: 0, bottom: 0),
                                border: OutlineInputBorder(
                                    borderSide: BorderSide(width: 0.5,
                                        color: Colors.white.withOpacity(0.5)),
                                    borderRadius: BorderRadius.circular(5)
                                ),
                                enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(width: 0.5,
                                        color: Colors.white.withOpacity(0.5)),
                                    borderRadius: BorderRadius.circular(5)
                                ),
                                focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(width: 0.5,
                                        color: Colors.white.withOpacity(0.5)),
                                    borderRadius: BorderRadius.circular(5)
                                ),
                                hintText: "\$",
                                hintStyle: TextStyle(
                                    fontWeight: FontWeight.w400,
                                    color: Colors.grey),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20,),
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        allFilterController.isOpenForCollaration.value = !allFilterController.isOpenForCollaration.value;
                        if (allFilterController.isOpenForCollaration.value) {
                          minPrice.clear();
                          maxPrice.clear();
                          minPriceFocusNode.unfocus();
                          maxPriceFocusNode.unfocus();
                        }
                      });
                    },
                    child: Container(
                      height: 40,
                      width: 150,
                      margin: EdgeInsets.only(right: 10),
                      decoration: BoxDecoration(
                          color: allFilterController.isOpenForCollaration.value
                              ? AppColors.mainColor
                              : Colors.black,
                          borderRadius: BorderRadius.circular(7),
                          border: Border.all(width: 0.5,
                              color: allFilterController.isOpenForCollaration.value
                                  ? AppColors.mainColor
                                  : Colors.white.withOpacity(0.5))
                      ),
                      child: const Center(
                        child: Padding(
                          padding: EdgeInsets.symmetric(
                              vertical: 7.0, horizontal: 12),
                          child: Text(
                            "Open For Collaboration",
                            style: TextStyle(color: Colors.white,
                                fontFamily: ' Poppins-Bold',
                                fontSize: 11,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    ),
                  ),


                  /////////language ///////
                  const SizedBox(height: 30,),
                  const Text("Languages",
                    style: TextStyle(
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                        fontSize: 15
                    ),
                  ),
                  const SizedBox(height: 10,),
                  Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // padding: EdgeInsets.only(left: 20, right: 20),
                                child: GridView.builder(
                                  physics: NeverScrollableScrollPhysics(),
                                  shrinkWrap: true,
                                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 3,
                                    crossAxisSpacing: 5.0,
                                    mainAxisSpacing: 10.0,
                                    childAspectRatio: MediaQuery
                                        .of(context)
                                        .size
                                        .width /
                                        (MediaQuery
                                            .of(context)
                                            .size
                                            .height / 7),
                                  ),
                                  itemCount: allFilterController.languages.value!.data!.length > 7
                                      ? 7
                                      : allFilterController.languages.value!.data!.length,
                                  itemBuilder: (context, index) {
                                    return buildSingleServiceList(
                                        text: "${allFilterController.languages.value!.data![index]
                                            .name}",
                                        color: allFilterController.selectedLangauges.contains(
                                            allFilterController.languages.value!.data![index].id.toString())
                                            ? AppColors.mainColor
                                            : Colors.black,
                                        borderColor: allFilterController.selectedLangauges
                                            .contains(allFilterController.languages.value!.data![index].id.toString())
                                            ? AppColors.mainColor
                                            : Colors.white.withOpacity(0.4),
                                        textColor: allFilterController.selectedLangauges.contains(
                                            allFilterController.languages.value!.data![index].id.toString())
                                            ? Colors.black
                                            : Colors.white,
                                        onClick: () {
                                          setState(() {
                                            //service.clear(); //first we clear all
                                            if (allFilterController.selectedLangauges.contains(
                                                allFilterController.languages.value!.data![index].id.toString())) {
                                              allFilterController.selectedLangauges.remove(
                                                  allFilterController.languages.value!.data![index].id.toString());
                                            } else {
                                              allFilterController.selectedLangauges.add(allFilterController.languages.value!.data![index].id.toString()); //then add the unick index
                                            }
                                          });
                                        });
                                  },
                                ),

                              ),
                              allFilterController.leftLanguagelengh.value != 0 ? TextButton(
                                onPressed: () => Get.to(ShowAllLanguages()),
                                child: Text(" ${allFilterController.leftLanguagelengh.value} + More",
                                  style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      color: AppColors.mainColor
                                  ),
                                ),
                              ) : Center(),
                            ],
                          )

                ],
              ),
            ),
            bottomNavigationBar: InkWell(
              onTap: () {
                _filtter();
                Navigator.of(context).pop(context);
              },
              child: Container(
                margin: EdgeInsets.only(left: 30, right: 30, bottom: 20),
                width: double.infinity,
                height: 46,
                decoration: BoxDecoration(
                  color: AppColors.mainColor,
                  borderRadius: BorderRadius.circular(5),

                ),
                child: const Center(child: Text(
                  'Show result', style: TextStyle(color: AppColors.white),),),
              ),
            ),
          );
        }),
      ),
    );
  }


  GestureDetector buildSingleServiceList({required String text,
    required Color color,
    required Color borderColor,
    required Color textColor,
    required VoidCallback onClick}) {
    return GestureDetector(
      onTap: onClick,
      child: Container(

        margin: const EdgeInsets.only(right: 10),
        decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(7),
            border: Border.all(width: 0.5, color: borderColor)
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 7.0, horizontal: 12),
            child: Text(
              text,
              style: const TextStyle(color: Colors.white,
                  fontFamily: ' Poppins-Bold',
                  fontSize: 11,
                  fontWeight: FontWeight.bold),
            ),
          ),
        ),
      ),
    );
  }

  clearAll() async {
    setState(() {
      minPrice.clear();
      maxPrice.clear();
      allFilterController.selectedLangauges.clear();
      allFilterController.service.clear();
      allFilterController.isOpenForCollaration.value = false;
    });
  }

  _filtter() async {
    searchFreelancerClientProfileController.allFilter(
        allFilterController.isOpenForCollaration.value ? "collaboration" : "",
        maxPrice.text,
        minPrice.text,
        allFilterController.service,
        allFilterController.selectedLangauges
    );
  }


}
