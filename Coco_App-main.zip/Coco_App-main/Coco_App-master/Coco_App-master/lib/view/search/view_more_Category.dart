import 'package:coco/model/authModel/serviceModle.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

import '../../appConst.dart';
import '../../controller/all_filter_controller.dart';
import '../../controller/authController.dart';
import '../../controller/searchFreelancerClientProfileController.dart';
import '../../model/authModel/allBusinessTypeModel.dart';
import '../../utility/colors.dart';

class ViewMoreCategoryForFilter extends StatefulWidget {
  final String role;

  const ViewMoreCategoryForFilter({Key? key, required this.role})
      : super(key: key);

  @override
  State<ViewMoreCategoryForFilter> createState() =>
      _ViewMoreCategoryForFilterState();
}

class _ViewMoreCategoryForFilterState extends State<ViewMoreCategoryForFilter> {



//this is empty service list, once wi getdata we will store.
  List<ServiceDatum>? searchServiceList = [
  ]; //this is empty service list, once wi getdata we will store.
  List<BusiessTypeDatum>? searchBusinessList = [
  ]; //this is empty service list, once wi getdata we will store.

  bool showSearchField = false;

  final AllFilterController allFilterController = Get.find<AllFilterController>();
  final SearchFreelancerClientProfileController searchFreelancerClientProfileController = Get
      .find<SearchFreelancerClientProfileController>();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

  }


  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      systemNavigationBarColor: Colors.black,
      statusBarColor: Colors.black,
    ));
    return Obx(() {
      return Container(
        color: Colors.black,
        child: SafeArea(
          child: Scaffold(
            backgroundColor: Colors.black,
            appBar: AppBar(
              backgroundColor: Colors.black,
              elevation: 0,
              leading: IconButton(
                onPressed: () => Get.back(),
                icon: Icon(Icons.arrow_back, color: Colors.white,),
              ),
              title: showSearchField == true
                ? Container(
                padding: EdgeInsets.all(0),
                child: TextFormField(
                  autofocus: true,
                  cursorColor: AppColors.mainColor,
                  style: TextStyle(
                      fontSize: 15,
                      color: Colors.white
                  ),
                  onChanged: searchServiceOneChange,
                  decoration: InputDecoration(
                      contentPadding: EdgeInsets.zero,
                      fillColor: Colors.transparent,
                      border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide.none,
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide.none,
                      )
                  ),
                ),
              )
                : Text(
                widget.role == AppConst.CLIENT_ROLE ? "Services" : "Business Types",
                style: TextStyle(
                    fontWeight: FontWeight.w500,
                    color: Colors.white
                ),
              ),
              actions: [
                  showSearchField == false
                  ? IconButton(
                    onPressed: () {
                      setState(() {
                        showSearchField = !showSearchField;
                      });
                    },
                    icon: Icon(Icons.search, color: Colors.white,),
                  )
                  : const SizedBox()
                ]

              // Right side search ivon button

            ),
            body: widget.role == AppConst.CLIENT_ROLE
                ? searchServiceList!.isEmpty
                        ? Container(
              color: Colors.black,
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: allFilterController.getServices.value!.data!.length,
                itemBuilder: (_, index) {
                  return Column(
                    children: [
                      ListTile(
                        onTap: () {
                          setState(() {
                            if (allFilterController.service.contains(
                                allFilterController.getServices.value!.data![index].id.toString())) {
                              allFilterController.service.remove(
                                  allFilterController.getServices.value!.data![index].id.toString());
                            } else {
                              allFilterController.service.add(
                                  allFilterController.getServices.value!.data![index].id.toString());
                            }
                          });
                        },
                        title: Row(
                          children: [
                            Text(
                              "${allFilterController.getServices.value!.data![index].name}",
                              style: const TextStyle(
                                fontWeight: FontWeight.w500,
                                color: Colors.white,
                              ),
                            ),
                            SizedBox(width: 10), // Adjust the width as needed
                            Text(
                              " (${allFilterController.getServices.value!.data![index].totalUser})",
                              style: const TextStyle(
                                fontWeight: FontWeight.w300, // Set your desired style
                                color: Colors.white70, // Set your desired color
                              ),
                            ),
                          ],
                        ),

                        trailing: Container(
                          width: 25,
                          height: 25,
                          decoration: BoxDecoration(
                            color: allFilterController.service.contains(
                                allFilterController.getServices.value!.data![index].id.toString())
                                ? AppColors.mainColor
                                : Colors.transparent,
                            borderRadius: BorderRadius.circular(100),
                            border: Border.all(color: Colors.white, width: 1),
                          ),
                          child: allFilterController.service.contains(
                              allFilterController.getServices.value!.data![index].id.toString())
                              ? Icon(
                            Icons.check,
                            color: Colors.black,
                            size: 17,
                          )
                              : Center(),
                        ),
                      ),
                      Container(
                        height: 1,
                        color: Colors.grey,
                      ),
                    ],
                  );
                },
              ),
            )
                        : Container(
                          color: Colors.black,
                          child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: searchServiceList?.length,
                      itemBuilder: (_, index) {
                          return Column(
                            children: [
                              ListTile(
                                onTap: () {
                                  setState(() {
                                    //  allFilterController.service.clear();
                                    if (allFilterController.service.contains(
                                        searchServiceList![index]!.id.toString())) {
                                      allFilterController.service.remove(
                                          searchServiceList![index]!.id.toString());
                                    } else {
                                      allFilterController.service.add(
                                          searchServiceList![index]!.id.toString());
                                    }
                                  });
                                },
                                title: Row(
                                  children: [
                                    Text(
                                      "${searchServiceList?[index]?.name}",
                                      style: TextStyle(
                                        fontWeight: FontWeight.w500,
                                        color: Colors.white,
                                      ),
                                    ),
                                    SizedBox(width: 10), // Adjust the width as needed
                                    Text(
                                      " (${searchServiceList?[index]?.totalUser})",
                                      style: TextStyle(
                                        fontWeight: FontWeight.w300, // Set your desired style
                                        color: Colors.white70, // Set your desired color
                                      ),
                                    ),
                                  ],
                                ),

                                trailing: Container(
                                  width: 25,
                                  height: 25,
                                  decoration: BoxDecoration(
                                    color: allFilterController.service.contains(
                                        searchServiceList![index]!.id.toString())
                                        ? AppColors.mainColor
                                        : Colors.transparent,
                                    borderRadius: BorderRadius.circular(100),
                                    border: Border.all(color: Colors.white, width: 1),
                                  ),
                                  child: allFilterController.service.contains(
                                      searchServiceList![index]!.id.toString())
                                      ? Icon(
                                    Icons.check, color: Colors.black, size: 17,)
                                      : Center(),
                                ),
                              ),
                              Container(
                                height: 1,
                                color: Colors.grey,
                              ),
                            ],
                          );
                      },
                    ),
                        )

                : searchBusinessList!.isEmpty
                ? Container(
              color: Colors.black,
              child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: allFilterController.getBusinessType.value!.data!.length,
                        itemBuilder: (_, index) {
                          return Column(
                            children: [
                              ListTile(
                                onTap: () {
                                  setState(() {
                                    //  allFilterController.service.clear();
                                    if (allFilterController.service.contains(
                                        allFilterController.getBusinessType.value!.data![index].id.toString())) {
                                      allFilterController.service.remove(allFilterController.getBusinessType.value!.data![index].id.toString());
                                      searchFreelancerClientProfileController.selectedEffectByServiceClick(index); //then add the unick index

                                    } else {
                                      allFilterController.service.add(allFilterController.getBusinessType.value!.data![index].id.toString());
                                      searchFreelancerClientProfileController.selectedEffectByServiceClick(index); //then add the unick index
                                    }
                                  });
                                },
                                title: Row(
                                  children: [
                                    Text(
                                      "${allFilterController.getBusinessType.value!.data![index].name}",
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w500,
                                        color: Colors.white,
                                      ),
                                    ),
                                    SizedBox(width: 10), // Adjust the width as needed
                                    Text(
                                      " (${allFilterController.getBusinessType.value!.data![index].totalUser})",
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w300, // Set your desired style
                                        color: Colors.white70, // Set your desired color
                                      ),
                                    ),
                                  ],
                                ),
                                trailing: Container(
                                  width: 25,
                                  height: 25,
                                  decoration: BoxDecoration(
                                    color: allFilterController.service.contains(
                                    allFilterController.getBusinessType.value!.data![index].id.toString())
                                        ? AppColors.mainColor
                                        : Colors.transparent,
                                    borderRadius: BorderRadius.circular(100),
                                    border: Border.all(color: Colors.white, width: 1),
                                  ),
                                  child: allFilterController.service.contains(
                                      allFilterController.getBusinessType.value!.data![index].id.toString())
                                      ? const Icon(
                                    Icons.check, color: Colors.black, size: 17,)
                                      : Center(),
                                ),
                              ),
                              Container(
                                height: 1,
                                color: Colors.grey,
                              ),
                            ],
                          );
                        },
                      ),
            )
                : Container(
                          color: Colors.black,
                          child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: searchBusinessList?.length,
                      itemBuilder: (_, index) {
                          return Column(
                            children: [
                              ListTile(
                                onTap: () {
                                  setState(() {
                                    //  allFilterController.service.clear();
                                    if (allFilterController.service.contains(
                                        searchBusinessList![index]!.id.toString())) {

                                      allFilterController.service.remove(
                                          searchBusinessList![index]!.id.toString());
                                      searchFreelancerClientProfileController.selectedEffectByServiceClick(index); //then add the unick index

                                    } else {
                                      allFilterController.service.add(
                                          searchBusinessList![index]!.id.toString());
                                      searchFreelancerClientProfileController.selectedEffectByServiceClick(index); //then add the unick index

                                    }
                                  });
                                },
                                title: Row(
                                  children: [
                                    Text(
                                      "${searchBusinessList?[index]?.name}",
                                      style: TextStyle(
                                        fontWeight: FontWeight.w500,
                                        color: Colors.white,
                                      ),
                                    ),
                                    SizedBox(width: 10), // Adjust the width as needed
                                    Text(
                                      " (${searchBusinessList?[index]?.totalUser})",
                                      style: TextStyle(
                                        fontWeight: FontWeight.w300, // Set your desired style
                                        color: Colors.white70, // Set your desired color
                                      ),
                                    ),
                                  ],
                                ),
                                trailing: Container(
                                  width: 25,
                                  height: 25,
                                  decoration: BoxDecoration(
                                    color: allFilterController.service.contains(
                                        searchBusinessList![index]!.id.toString())
                                        ? AppColors.mainColor
                                        : Colors.transparent,
                                    borderRadius: BorderRadius.circular(100),
                                    border: Border.all(color: Colors.white, width: 1),
                                  ),
                                  child: allFilterController.service.contains(
                                      searchBusinessList![index]!.id.toString())
                                      ? Icon(
                                    Icons.check, color: Colors.black, size: 17,)
                                      : Center(),
                                ),
                              ),
                              Container(
                                height: 1,
                                color: Colors.grey,
                              ),
                            ],
                          );
                      },
                    ),
                        ),
            bottomNavigationBar: allFilterController.service.isNotEmpty
                ? Container(
              margin: EdgeInsets.all(30),
              width: double.infinity,
              child: ElevatedButton(
                  style: OutlinedButton.styleFrom(
                    backgroundColor: AppColors.mainColor,
                  ),
                  onPressed: () async {
                    allFilterController.refreshUI();
                    Get.back();
                    // Navigator.push(context, MaterialPageRoute(
                    //     builder: (context) =>
                    //         ClientBottomNavigationBar(pageIndex: 1, userId: allFilterController.service[0].toString() ,)));
                  },
                  child: Text(
                    'Apply',
                    style: TextStyle(color: Colors.white, fontSize: 13),
                  )),
            )
                : Container(height: 1,),
          ),
        ),
      );
    });
  }

  void searchServiceOneChange(String value) {
    setState(() {
      searchServiceList!.clear();
      searchBusinessList!.clear();
    });
    // Filter the original list based on the search text
    if (widget.role == AppConst.CLIENT_ROLE) {
      ////////// first check is the rolw is client then only story the data on service list for client//////
      for (var data in allFilterController.getServices.value!.data!) {
        if (data.name!.toLowerCase().contains(value.toLowerCase())) {
          setState(() {
            searchServiceList?.add(data);
          });
        }
      }
      return;
    }
    if (widget.role == AppConst.FREELANCER_ROLE) {
      //////// if the role is freelnacer then we store data only searchBusinessList
      for (var data in allFilterController.getBusinessType.value!.data!) {
        if (data.name!.toLowerCase().contains(value.toLowerCase())) {
          setState(() {
            searchBusinessList?.add(data);
          });
          print("business type =name== ${searchBusinessList![0].name}");
        }
      }
      return;
    }
  }

}
