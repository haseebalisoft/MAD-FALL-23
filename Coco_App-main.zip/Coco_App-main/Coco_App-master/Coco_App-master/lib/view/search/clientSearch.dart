import 'package:coco/appConst.dart';
import 'package:coco/model/authModel/serviceModle.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import '../../../controller/authController.dart';
import '../../../utility/colors.dart';
import '../../model/authModel/allBusinessTypeModel.dart';
import '../Client/bottomNagivation/buttom_nav.dart';

class ClientSearch extends StatefulWidget {
  final String role;
  const ClientSearch({super.key, required this.role});

  @override
  State<ClientSearch> createState() => _ClientSearchState();
}

class _ClientSearchState extends State<ClientSearch> {
  List _selectedSearchItems = []; //this is empty list.
  //we add items/value when someone tap on search items.

  //this is Service list
  //show list of service according to this list.
  final List _serviceList = [
    "Restaurant",
    "Accommodation",
    "Bar/Club",
    "Health & wellness",
    "Sports"
  ];

  Future<ServiceModel>? getServiceModel;
  Future<AllBusnissType>? getBusinessType;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    if(widget.role == AppConst.CLIENT_ROLE){
      getServiceModel = AuthController.getServiceList();
    }

    if(widget.role == AppConst.FREELANCER_ROLE){
      getBusinessType = AuthController.getBusinessTypes();
    }


  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      child: SafeArea(
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.black,
            elevation: 0,
            leading: InkWell(
              onTap: () {
                Get.back();
              },
              child: Icon(Icons.arrow_back, color: Colors.white,),
            ),
          ),
          body: Container(
            // width: double.infinity,
            // height: double.infinity,
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(color: Colors.black),
            child: Column(
              children: [
               Center(
                 child: Text(
                 widget.role == AppConst.CLIENT_ROLE ? "Freelancer categories" : "Client Business Category",
                 style: TextStyle(
                     color: Colors.white,
                     fontFamily: 'Poppins-Bold',
                     fontSize: 16),
               ),),
                SizedBox(
                  height: 5.h,
                ),

                widget.role == AppConst.CLIENT_ROLE
                    ? FutureBuilder<ServiceModel>(
                    future: getServiceModel,
                    builder: (context, snapshot) {
                      if(snapshot.connectionState == ConnectionState.waiting){
                        return Center(child: CircularProgressIndicator(color: Colors.white,),);
                      }else if(snapshot.hasData){
                        return Expanded(
                          child: ListView.builder(
                            itemCount: snapshot.data?.data?.length,
                            itemBuilder: (_, index) {
                              return Padding(
                                padding: const EdgeInsets.only(
                                    left: 15, right: 15, bottom: 5, top: 10),
                                child: GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      _selectedSearchItems.clear();
                                      if (_selectedSearchItems.contains(index)) {
                                        _selectedSearchItems.remove(index);
                                      } else {
                                        _selectedSearchItems.add(index);
                                      }
                                    });
                                  },
                                  child: Container(
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(5),
                                        color: _selectedSearchItems.contains(index)
                                            ? AppColors.white
                                            : Colors.black,
                                        border: Border.all(
                                            width: 1, color: Color(0xFFA1A1A1))),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 18.0, vertical: 12),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          SizedBox(
                                            width: 20,
                                            child: _selectedSearchItems.contains(index)
                                                ? Icon(
                                              Icons.check_circle,
                                              size: 18,
                                              color: AppColors.mainColor,
                                            )
                                                : Center(),
                                          ),
                                          Text(
                                            '${snapshot.data?.data?[index]?.name}',
                                            style: TextStyle(
                                                color:
                                                _selectedSearchItems.contains(index)
                                                    ? Colors.black
                                                    : AppColors.white,
                                                fontSize: 13,
                                                fontFamily: 'Poppins-Bold'),
                                          ),
                                          SizedBox(
                                            width: 20,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        );
                      }else{
                        return Center(child: Text("Check your internet connection.",
                          style: TextStyle(
                              color: Colors.white
                          ),
                        ),);
                      }
                    }
                )
                    : FutureBuilder<AllBusnissType>(
                    future: getBusinessType,
                    builder: (context, snapshot) {
                      if(snapshot.connectionState == ConnectionState.waiting){
                        return Center(child: CircularProgressIndicator(color: Colors.white,),);
                      }else if(snapshot.hasData){
                        return Expanded(
                          child: ListView.builder(
                            itemCount: snapshot.data?.data?.length,
                            itemBuilder: (_, index) {
                              return Padding(
                                padding: const EdgeInsets.only(
                                    left: 15, right: 15, bottom: 5, top: 10),
                                child: GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      _selectedSearchItems.clear();
                                      if (_selectedSearchItems.contains(snapshot.data?.data?[index]?.id.toString())) {
                                        _selectedSearchItems.remove(snapshot.data?.data?[index]?.id.toString());
                                      } else {
                                        _selectedSearchItems.add(snapshot.data?.data?[index]?.id.toString());
                                      }
                                    });
                                  },
                                  child: Container(
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(5),
                                        color: _selectedSearchItems.contains(snapshot.data?.data?[index]?.id.toString())
                                            ? AppColors.white
                                            : Colors.black,
                                        border: Border.all(
                                            width: 1, color: Color(0xFFA1A1A1))),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 18.0, vertical: 12),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          SizedBox(
                                            width: 20,
                                            child: _selectedSearchItems.contains(snapshot.data?.data?[index]?.id.toString())
                                                ? Icon(
                                              Icons.check_circle,
                                              size: 18,
                                              color: AppColors.mainColor,
                                            )
                                                : Center(),
                                          ),
                                          Text(
                                            '${snapshot.data?.data?[index]?.name}',
                                            style: TextStyle(
                                                color:
                                                _selectedSearchItems.contains(snapshot.data?.data?[index]?.id.toString())
                                                    ? Colors.black
                                                    : AppColors.white,
                                                fontSize: 13,
                                                fontFamily: 'Poppins-Bold'),
                                          ),
                                          SizedBox(
                                            width: 20,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        );
                      }else{
                        return Center(child: Text("Check your internet connection.",
                          style: TextStyle(
                              color: Colors.white
                          ),
                        ),);
                      }
                    }
                ),
                SizedBox(
                  height: 40,
                ),
                _selectedSearchItems.isNotEmpty
                    ? SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                      style: OutlinedButton.styleFrom(
                        backgroundColor: Colors.white,
                      ),
                      onPressed: () async{

                        Navigator.push(context, MaterialPageRoute(
                            builder: (context) =>
                                ClientBottomNavigationBar(pageIndex: 1, userId: _selectedSearchItems[0].toString() ,)));
                      },
                      child: Text(
                        'Continue',
                        style: TextStyle(color: Colors.black, fontSize: 13),
                      )),
                )
                    : Container(),
                SizedBox(
                  height: 20,
                ),

                //CheckboxListTile
              ],
            ),
          ),
        ),
      ),
    );
  }
}
