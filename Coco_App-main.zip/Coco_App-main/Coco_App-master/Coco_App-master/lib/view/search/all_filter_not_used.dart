import 'package:coco/appConst.dart';
import 'package:coco/controller/authController.dart';
import 'package:coco/controller/serviceController.dart';
import 'package:coco/main.dart';
import 'package:coco/model/authModel/allBusinessTypeModel.dart';
import 'package:coco/model/authModel/businessHoursModel.dart';
import 'package:coco/model/authModel/serviceModle.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/view/Client/bottomNagivation/buttom_nav.dart';
import 'package:coco/view/search/clientSearch.dart';
import 'package:coco/view/search/searchFreelancerClientProfileNotUsed.dart';
import 'package:coco/view/search/show_all_language.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:coco/viewController/showAllert.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../controller/searchFreelancerClientProfileController.dart';
import '../../model/authModel/languesModel.dart';
import 'view_more_Category.dart';

class AllFiltersNotUsed extends StatefulWidget {
  const AllFiltersNotUsed({Key? key}) : super(key: key);

  @override
  State<AllFiltersNotUsed> createState() => _AllFiltersNotUsedState();
}

class _AllFiltersNotUsedState extends State<AllFiltersNotUsed> {

  final minPrice = TextEditingController();
  final maxPrice = TextEditingController();
  var minPriceFocusNode = FocusNode();
  var maxPriceFocusNode = FocusNode();

  List service = [];
  List _selectedLangauges = [];
  List serviceList = [];

  bool isOpenForCollaration = false;
  Future<LanguesModel>? languages;

  Future<ServiceModel>? getServices;
  Future<AllBusnissType>? getBusinessType;


  int _leftTypeLength = 0;
  int _leftLanguagelengh = 0;

  final SearchFreelancerClientProfileController searchFreelancerClientProfileController = Get.find<SearchFreelancerClientProfileController>();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    languages = AuthController.getLanguages();

    getUserRole();
    getServices = AuthController.getServiceList();
    getBusinessType = AuthController.getBusinessTypes();

    setState((){});

  }
  var role;
  getUserRole()async{
    SharedPreferences _pref = await SharedPreferences.getInstance();
    setState(() {
      role = _pref.getString("role");
    });
  }


  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      child: SafeArea(
        child: Scaffold(
          backgroundColor: Colors.black,
          body: SingleChildScrollView(
            padding: EdgeInsets.all(20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        IconButton(
                            onPressed: ()=>Get.back(),
                            icon: Icon(Icons.close, color: Colors.white, size: 30,)
                        ),
                        Text("All Filters",
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w600,
                            color: Colors.white
                          ),
                        )
                      ],
                    ),
                    TextButton(
                        onPressed: ()=>clearAll(),
                        child: Text("Clear All",
                          style: TextStyle(
                            color: AppColors.mainColor
                          ),
                        )
                    )
                  ],
                ),

                SizedBox(height: 20,),
                Text("${role == AppConst.CLIENT_ROLE ? "Service Type" : "Business Type"}",
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                    fontSize: 15
                  ),
                ),
                SizedBox(height: 10,),


                role == AppConst.CLIENT_ROLE
                    ? FutureBuilder<ServiceModel>(
                  future: getServices,
                  builder: (context, snapshot) {
                    if(snapshot.connectionState == ConnectionState.waiting){
                      return SizedBox(height: 150,);
                    }else if(snapshot.hasData){
                      _leftTypeLength = snapshot.data!.data!.length-4;
                      print("_leftTypeLength === ${_leftTypeLength}");
                      return Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [

                          Container(
                            // padding: EdgeInsets.only(left: 20, right: 20),
                            child: GridView.builder(
                              physics: NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 3,
                                crossAxisSpacing: 5.0,
                                mainAxisSpacing: 10.0,
                                childAspectRatio: MediaQuery.of(context).size.width /
                                    (MediaQuery.of(context).size.height / 7),
                              ),
                              itemCount: snapshot.data!.data!.length > 4 ? 4 : snapshot.data!.data!.length,
                              itemBuilder: (context, index) {
                                return buildSingleServiceList(
                                    text: "${snapshot.data!.data![index]!.name}",
                                    color: service.contains(index.toString())
                                        ? AppColors.mainColor
                                        :  Colors.grey.shade900,
                                    borderColor: service.contains(index.toString())
                                        ? AppColors.mainColor
                                        :  Colors.grey.shade600,
                                    textColor: service.contains(index.toString())
                                        ? Colors.black
                                        : Colors.white,
                                    onClick: () {
                                      setState(() {
                                        //service.clear(); //
                                        // first we clear all
                                        if(service.contains(index.toString())){
                                          service.remove(index.toString());
                                        }else{
                                          service.add(index.toString()); //then add the unick index
                                        }
                                      });
                                    });
                              },
                            ),
                            // child: ListView.builder(
                            //   itemCount: snapshot.data!.data!.length > 4 ? 3 : snapshot.data!.data!.length,
                            //   scrollDirection: Axis.horizontal,
                            //   itemBuilder: (_, index) {
                            //     return buildSingleServiceList(
                            //         text: "${snapshot.data!.data![index]!.name}",
                            //         color: service.contains(index.toString())
                            //             ? AppColors.mainColor
                            //             :  Colors.grey.shade900,
                            //         borderColor: service.contains(index.toString())
                            //             ? AppColors.mainColor
                            //             :  Colors.grey.shade600,
                            //         textColor: service.contains(index.toString())
                            //             ? Colors.black
                            //             : Colors.white,
                            //         onClick: () {
                            //           setState(() {
                            //             //service.clear(); //first we clear all
                            //            if(service.contains(index.toString())){
                            //              service.remove(index.toString());
                            //            }else{
                            //              service.add(index.toString()); //then add the unick index
                            //            }
                            //           });
                            //         });
                            //   },
                            // ),
                          ),
                          _leftTypeLength != 0 ? TextButton(
                            onPressed: ()=>Get.to(ViewMoreCategoryForFilter(role: "${role}")),
                            child: Text(" $_leftTypeLength+ More",
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.mainColor
                              ),
                            ),
                          ) :Center(),
                        ],
                      );
                    }else{
                      return Center(child: Text("Check your internet connection",
                        style: TextStyle(
                          color: Colors.white
                        ),
                        ),);
                    }
                  }
                )
                    : FutureBuilder<AllBusnissType>(
                    future: getBusinessType,
                    builder: (context, snapshot) {
                      if(snapshot.connectionState == ConnectionState.waiting){
                        return SizedBox(height: 150,);
                      }else if(snapshot.hasData){
                        _leftTypeLength = snapshot.data!.data!.length-4;
                        print("_leftTypeLength === ${_leftTypeLength}");
                        return Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [

                            Container(
                              // padding: EdgeInsets.only(left: 20, right: 20),
                              child: GridView.builder(
                                physics: NeverScrollableScrollPhysics(),
                                shrinkWrap: true,
                                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: 3,
                                  crossAxisSpacing: 5.0,
                                  mainAxisSpacing: 10.0,
                                  childAspectRatio: MediaQuery.of(context).size.width /
                                      (MediaQuery.of(context).size.height / 7),
                                ),
                                itemCount: snapshot.data!.data!.length > 4 ? 4 : snapshot.data!.data!.length,
                                itemBuilder: (context, index) {
                                  return buildSingleServiceList(
                                      text: "${snapshot.data!.data![index]!.name}",
                                      color: service.contains(index.toString())
                                          ? AppColors.mainColor
                                          :  Colors.black,
                                      borderColor: service.contains(index.toString())
                                          ? AppColors.mainColor
                                          :  Colors.white.withOpacity(0.4),
                                      textColor: service.contains(index.toString())
                                          ? Colors.black
                                          : Colors.white,
                                      onClick: () {
                                        setState(() {
                                          //service.clear(); //first we clear all
                                          if(service.contains(index.toString())){
                                            service.remove(index.toString());
                                          }else{
                                            service.add(index.toString()); //then add the unick index
                                          }
                                        });
                                      });
                                },
                              ),
                              // child: ListView.builder(
                              //   itemCount: snapshot.data!.data!.length > 4 ? 3 : snapshot.data!.data!.length,
                              //   scrollDirection: Axis.horizontal,
                              //   itemBuilder: (_, index) {
                              //     return buildSingleServiceList(
                              //         text: "${snapshot.data!.data![index]!.name}",
                              //         color: service.contains(index.toString())
                              //             ? AppColors.mainColor
                              //             :  Colors.grey.shade900,
                              //         borderColor: service.contains(index.toString())
                              //             ? AppColors.mainColor
                              //             :  Colors.grey.shade600,
                              //         textColor: service.contains(index.toString())
                              //             ? Colors.black
                              //             : Colors.white,
                              //         onClick: () {
                              //           setState(() {
                              //             //service.clear(); //first we clear all
                              //            if(service.contains(index.toString())){
                              //              service.remove(index.toString());
                              //            }else{
                              //              service.add(index.toString()); //then add the unick index
                              //            }
                              //           });
                              //         });
                              //   },
                              // ),
                            ),
                            _leftTypeLength != 0 ? TextButton(
                              onPressed: ()=>Get.to(ViewMoreCategoryForFilter(role: "${role}"), transition: Transition.rightToLeft),
                              child: Text("$_leftTypeLength+ More",
                                style: TextStyle(
                                    fontSize: 16,
                                    color: AppColors.mainColor
                                ),
                              ),
                            ) :Center(),
                          ],
                        );
                      }else{
                        return Center(child: Text("Check your internet connection",
                          style: TextStyle(
                              color: Colors.white
                          ),
                        ),);
                      }
                    }
                ),


                /////////////////// price range ///////////////////////
                SizedBox(height: 30,),
                Text("Price range",
                  style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                      fontSize: 15
                  ),
                ),
                SizedBox(height: 10,),
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Min",
                            style: TextStyle(
                                fontSize: 10, color: Colors.white
                            ),
                          ),
                          SizedBox(height: 5,),
                          TextFormField(
                            style: TextStyle(color: Colors.white,
                              fontSize: 12
                            ), // Set the text color to white
                            controller: minPrice,
                            focusNode: minPriceFocusNode,
                            keyboardType: TextInputType.number,
                            decoration:  InputDecoration(
                                labelStyle: TextStyle(
                                  color: Colors.white
                                ),
                                fillColor: Colors.black,
                                filled: true,
                                contentPadding: EdgeInsets.only(left: 15, right: 15, top: 0, bottom: 0),
                                border: OutlineInputBorder(
                                    borderSide: BorderSide(width: 0.5,color: Colors.white.withOpacity(0.5)),
                                    borderRadius: BorderRadius.circular(5)
                                ),
                                enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(width: 0.5,color: Colors.white.withOpacity(0.5)),
                                    borderRadius: BorderRadius.circular(5)
                                ),
                                focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(width: 0.5,color: Colors.white.withOpacity(0.5)),
                                    borderRadius: BorderRadius.circular(5)
                                ),
                                hintText: "\$",
                                hintStyle:TextStyle(fontWeight: FontWeight.w400, color: Colors.grey),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width: 10,),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Max",
                            style: TextStyle(
                                fontSize: 10, color: Colors.white
                            ),
                          ),
                          SizedBox(height: 5,),
                          TextFormField(
                            focusNode: maxPriceFocusNode,
                            style: TextStyle(color: Colors.white,
                                fontSize: 12
                            ), //
                            controller: maxPrice,
                            keyboardType: TextInputType.number,
                            decoration:  InputDecoration(
                              fillColor: Colors.black,
                              filled: true,
                              contentPadding: EdgeInsets.only(left: 15, right: 15, top: 0, bottom: 0),
                              border: OutlineInputBorder(
                                  borderSide: BorderSide(width: 0.5,color: Colors.white.withOpacity(0.5)),
                                  borderRadius: BorderRadius.circular(5)
                              ),
                              enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(width: 0.5,color: Colors.white.withOpacity(0.5)),
                                  borderRadius: BorderRadius.circular(5)
                              ),
                              focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(width: 0.5,color: Colors.white.withOpacity(0.5)),
                                  borderRadius: BorderRadius.circular(5)
                              ),
                                hintText: "\$",
                                hintStyle:TextStyle(fontWeight: FontWeight.w400, color: Colors.grey),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 20,),
                GestureDetector(
                  onTap: (){
                    setState(() {
                      isOpenForCollaration = !isOpenForCollaration;
                      if(isOpenForCollaration){
                        minPrice.clear();
                        maxPrice.clear();
                        minPriceFocusNode.unfocus();
                        maxPriceFocusNode.unfocus();
                      }
                    });
                  },
                  child: Container(
                    height: 40,
                    width: 150,
                    margin: EdgeInsets.only(right: 10),
                    decoration: BoxDecoration(
                        color: isOpenForCollaration ? AppColors.mainColor : Colors.black,
                        borderRadius: BorderRadius.circular(7),
                        border: Border.all(width: 0.5, color: isOpenForCollaration ? AppColors.mainColor : Colors.white.withOpacity(0.5))
                    ),
                    child: const Center(
                      child: Padding(
                        padding: EdgeInsets.symmetric(vertical: 7.0, horizontal: 12),
                        child: Text(
                          "Open For Collaborate",
                          style: TextStyle(color:  Colors.white,fontFamily: ' Poppins-Bold',fontSize: 11,fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ),
                ),




                /////////language ///////
                SizedBox(height: 30,),
                Text("Languages",
                  style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                      fontSize: 15
                  ),
                ),
                SizedBox(height: 10,),
                FutureBuilder<LanguesModel>(
                    future: languages,
                    builder: (context, snapshot) {
                      if(snapshot.connectionState == ConnectionState.waiting){
                        return SizedBox(height: 150,);
                      }else if(snapshot.hasData){
                        _leftLanguagelengh = snapshot.data!.data!.length-7;
                        print("_leftLanguagelengh === ${_leftLanguagelengh}");
                        return Column(

                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              // padding: EdgeInsets.only(left: 20, right: 20),
                              child: GridView.builder(
                                physics: NeverScrollableScrollPhysics(),
                                shrinkWrap: true,
                                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: 3,
                                  crossAxisSpacing: 5.0,
                                  mainAxisSpacing: 10.0,
                                  childAspectRatio: MediaQuery.of(context).size.width /
                                      (MediaQuery.of(context).size.height / 7),
                                ),
                                itemCount: snapshot.data!.data!.length > 7 ? 7 : snapshot.data!.data!.length,
                                itemBuilder: (context, index) {
                                  return buildSingleServiceList(
                                      text: "${snapshot.data!.data![index]!.name}",
                                      color: _selectedLangauges.contains(index.toString())
                                          ? AppColors.mainColor
                                          :  Colors.black,
                                      borderColor: _selectedLangauges.contains(index.toString())
                                          ? AppColors.mainColor
                                          :  Colors.white.withOpacity(0.4),
                                      textColor: _selectedLangauges.contains(index.toString())
                                          ? Colors.black
                                          : Colors.white,
                                      onClick: () {
                                        setState(() {
                                          //service.clear(); //first we clear all
                                          if(_selectedLangauges.contains(index.toString())){
                                            _selectedLangauges.remove(index.toString());
                                          }else{
                                            _selectedLangauges.add(index.toString()); //then add the unick index
                                          }
                                        });
                                      });
                                },
                              ),

                            ),
                            _leftLanguagelengh != 0 ? TextButton(
                              onPressed: ()=>Get.to(ShowAllLanguages()),
                              child: Text(" $_leftLanguagelengh+ More",
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                    color: AppColors.mainColor
                                ),
                              ),
                            ) :Center(),
                          ],
                        );
                      }else{
                        return Center(child: Text("Check your internet connection",
                          style: TextStyle(
                              color: Colors.white
                          ),
                        ),);
                      }
                    }
                ),

                // _leftLanguagelengh != 0 ? TextButton(
                //   onPressed: ()=>Get.to(ShowAllLanguages()),
                //   child: Text(" $_leftLanguagelengh+ More",
                //     style: TextStyle(
                //         fontSize: 16,
                //         fontWeight: FontWeight.w600,
                //         color: AppColors.mainColor
                //     ),
                //   ),
                // ) :Center(),

        

              ],
            ),
          ),
          bottomNavigationBar:  InkWell(
            onTap: ()=>_filtter(),
            child: Container(
              margin: EdgeInsets.only(left: 30,right: 30,bottom: 20),
              width: double.infinity,
              height: 46,
              decoration: BoxDecoration(
                color: AppColors.mainColor,
                borderRadius: BorderRadius.circular(5),

              ),
              child: Center(child: Text('Show result',style: TextStyle(color: AppColors.white),),),
            ),
          ),
        ),
      ),
    );
  }




  GestureDetector buildSingleServiceList(
      {required String text,
        required Color color,
        required Color borderColor,
        required Color textColor,
        required VoidCallback onClick}) {
    return GestureDetector(
      onTap: onClick,
      child: Container(

        margin: EdgeInsets.only(right: 10),
        decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(7),
            border: Border.all(width: 0.5, color: borderColor)
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 7.0, horizontal: 12),
            child: Text(
              text,
              style: TextStyle(color: Colors.white,fontFamily: ' Poppins-Bold',fontSize: 11,fontWeight: FontWeight.bold),
            ),
          ),
        ),
      ),
    );
  }

  clearAll() async{
    setState(() {
      minPrice.clear();
      maxPrice.clear();
      _selectedLangauges.clear();
      service.clear();
      isOpenForCollaration = false;
    });
  }

  _filtter() async{

    searchFreelancerClientProfileController.allFilter(
       isOpenForCollaration ? "collaboration" : "",
      maxPrice.text,
      minPrice.text,
      service,
       _selectedLangauges
    );


    // var res = await ServiceController.filterForClient(
    //     collaboration: isOpenForCollaration ? "collaboration" : "",
    //     maxPrice: maxPrice.text,
    //     minPrice: minPrice.text,
    //     serviceId: service,
    //     languageId: _selectedLangauges
    // );


    // if(res!.status!){
    //   Get.to(ClientBottomNavigationBar(pageIndex: 1, serviceListFromFilter: res.data,));
    // }else{
    //   AlertController.snackbar(context: context, text: "Something went wrong. Please try again.", bg: Colors.red);
    //   //AppAllerts.showAlert(text: "Something is wrong. Please try again.", yesClick: (){}, context: context);
    // }
    // print("res =========== ${res!.data}");
    // print("res =========== ${res!.status}");
  }


}
