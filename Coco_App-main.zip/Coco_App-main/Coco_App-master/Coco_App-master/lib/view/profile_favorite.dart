import 'package:coco/controller/profile_favorite_controller.dart';
import 'package:coco/view/profile/singleUserPortfolio/singleUserPost.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controller/profileToInfoController.dart';
import '../model/FavUserWithDetails.dart';
import '../utility/colors.dart';
import '../viewController/appNetworkImage.dart';
import 'package:path/path.dart' as p;

import '../viewController/video_player/video_thumblin.dart';
import 'Client/profile/freelancerProfileDetails.dart';


class ProfileFavorite extends StatefulWidget {
  const ProfileFavorite({
    super.key,
  });

  @override
  State<ProfileFavorite> createState() => _ProfileFavoriteState();
}

class _ProfileFavoriteState extends State<ProfileFavorite>  with SingleTickerProviderStateMixin{

  ProfileFavoriteController profileFavoriteController = Get.put(ProfileFavoriteController());
  late TabController tabController;




  @override
  void initState() {
    super.initState();
    tabController =
        TabController(length: 2, initialIndex: 0, vsync: this);

    profileFavoriteController.getAllData();
  }





  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      child: Obx(() {
        return profileFavoriteController.isLoading.value
            ? Center(child: CircularProgressIndicator( color: Colors.white,),)
            : Scaffold(
            backgroundColor: Colors.black,
            appBar: AppBar(
              backgroundColor: Colors.black,
              elevation: 0,
              leading: IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.arrow_back, color: Colors.white,),
              ),
              title: const Text("Favorite",
                style: TextStyle(
                    fontSize: 16,
                    color: Colors.white
                ),
              ),
            ),
            body: profileFavoriteController.isLoading.value
                ? Center(child: CircularProgressIndicator( color: Colors.white,),)
                : Column(
              children: [
                TabBar(
                    controller: tabController,
                    labelColor: Colors.white,
                    dividerColor: AppColors.mainColor,
                    unselectedLabelColor: Colors.grey,
                    indicatorColor: AppColors.mainColor,
                    tabs: [
                      Tab(
                        child: Text("Users",
                          style: TextStyle(
                              fontWeight: FontWeight.w400,
                              fontSize: 14
                          ),
                        ),
                      ),
                      Tab(
                        child: Text("Portfolio",
                          style: TextStyle(
                              fontWeight: FontWeight.w400,
                              fontSize: 14
                          ),
                        ),
                      ),

                      // Padding(
                      //   padding: const EdgeInsets.all(10.0),
                      //   child: Text('Protfolio',),
                      // ),
                      // Padding(
                      //   padding: const EdgeInsets.all(10.0),
                      //   child: Text('About me',),
                      // ),
                    ]),
                Expanded(
                  child: TabBarView(
                    controller: tabController,
                    children: [
                      // Text('data'),
                      // Text('data'),
                      buildFavoriteList(),

                  profileFavoriteController.getAllFavPost.value?.data?.length!=0 && profileFavoriteController.getAllFavPost.value?.data?.length != null
                      ? Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: GridView.builder(
                      shrinkWrap: true,
                      itemCount: profileFavoriteController.getAllFavPost.value?.data?.length,
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        mainAxisExtent: 180,
                        mainAxisSpacing: 5,
                        crossAxisSpacing: 5,
                      ),
                      physics: const NeverScrollableScrollPhysics(),
                      itemBuilder: (BuildContext context, int index) {

                        return p.extension(profileFavoriteController.getAllFavPost.value!.data![index]!.image![0].image.toString()) != ".mp4"
                            ? buildSinglePortfolio(
                          //onClick: ()=>Get.to(Users_Posts()),
                            onClick: ()=>Get.to(SingleUserPost(
                                userId: profileFavoriteController.getAllFavPost.value!.data![index]!.userData![0]!.id.toString(),
                                userName: profileFavoriteController.getAllFavPost.value!.data![index]!.post!.userId.toString(),
                                userImage: profileFavoriteController.getAllFavPost.value!.data![index]!.userData![0]!.profileImage ?? "")),
                            imagePath: "${profileFavoriteController.getAllFavPost.value!.data![index]!.image!.isEmpty
                                ? "https://upload.wikimedia.org/wikipedia/commons/thumb/6/65/No-Image-Placeholder.svg/1665px-No-Image-Placeholder.svg.png"
                                : profileFavoriteController.getAllFavPost.value!.data![index]!.image![0]!.image}"
                        ):

                        InkWell(
                          onTap: () => Get.to(SingleUserPost(
                            userId: profileFavoriteController.getAllFavPost.value!.data![index]!.userData![0]!.id.toString(),
                            userName: profileFavoriteController.getAllFavPost.value!.data![index]!.post!.userId.toString(),
                            userImage: profileFavoriteController.getAllFavPost.value!.data![index]!.userData![0]!.profileImage ?? "",
                          )),
                          child: Stack(
                            children: [
                              // VideoThumbnail or your main content
                              ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: VideoThumbnail(profileFavoriteController.getAllFavPost.value!.data![index]!.image![0]!.image.toString()),
                              ),
                              // Positioned widget to position the PNG image at the top right corner
                              // Positioned(
                              //   top: 10, // Adjust the top spacing as needed
                              //   right: 10, // Adjust the right spacing as needed
                              //   child: Image.asset(
                              //     'asset/image/heart-circle.png',
                              //     width: 24, // Adjust the width as needed
                              //     height: 24, // Adjust the height as needed
                              //   ),
                              // ),
                            ],
                          ),
                        );

                      },
                    ),
                  ):
                  Container(
                    child: const Center(
                      child: Text(
                        "No Post Found",
                        style: TextStyle(
                          color: Colors.white, // Set the desired color here
                        ),
                      ),
                    ),
                  )


                    ],
                  ),
                )
              ],
            )
        );
      }),
    );
  }



  Column buildFavoriteList() {
    return Column(
      children: [
        SizedBox(height: 20,),
        Container(
          margin: EdgeInsets.only(left: 20, right: 20),
          child: TextFormField(
              onChanged: (v) {
                followersSearch(v, profileFavoriteController.favoriteListWithDetails);
              },
              decoration: InputDecoration(
                  contentPadding: EdgeInsets.only(left: 10, right: 10),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(100),
                    borderSide: BorderSide.none,
                  ),
                  fillColor: Colors.grey.shade200,
                  filled: true,
                  hintText: "Search",
                  prefixIcon: Icon(Icons.search, color: Colors.grey,)
              )
          ),
        ),
        SizedBox(height: 20,),
        profileFavoriteController.favoriteListWithDetails.isNotEmpty ? Expanded(
          child: profileFavoriteController.searchFavoriteList.isNotEmpty
              ? ListView.builder(
            itemCount: profileFavoriteController.searchFavoriteList.length,
            itemBuilder: (_, index) {
              return singleUser(
                  onTab: () => profileFavoriteController.removeFromFav(profileFavoriteController.favoriteListWithDetails[index]?.id ?? 0),
                  userId: profileFavoriteController.searchFavoriteList[index]
                      ?.id.toString() ?? "",
                  text: "Remove",
                  bgButton: AppColors.mainColor,
                  name: profileFavoriteController.searchFavoriteList[index]
                      ?.name ?? "",
                  profile: profileFavoriteController.searchFavoriteList[index]?.profileImage ?? "",
              );
            },
          )
              : ListView.builder(
            itemCount: profileFavoriteController.favoriteListWithDetails.length,
            itemBuilder: (_, index) {
              return singleUser(
                  onTab: () => profileFavoriteController.removeFromFav(profileFavoriteController.favoriteListWithDetails[index]?.id ?? 0),
                  userId: profileFavoriteController.favoriteListWithDetails[index]?.id
                      .toString() ?? "",
                  text: "Remove",
                  bgButton: AppColors.mainColor,
                  name: profileFavoriteController.favoriteListWithDetails[index]
                      ?.name ?? "",
                  profile: profileFavoriteController.favoriteListWithDetails![index]
                      ?.profileImage,
              );
            },
          ),
        ) : const Padding(padding: EdgeInsets.only(top: 100),
          child: Text("You are not following anyone."),)
      ],
    );
  }

  //search followers
  void followersSearch(String query, List<FavUserWithDetails?> favorites) {
    print("query $query");
    print("query ${profileFavoriteController.favoriteListWithDetails}");
    // getFollowFollowingList();
    // Clear the filtered list
    profileFavoriteController.searchFavoriteList.clear();
    // If the query is empty, add all items to the filtered list

    if (query.isEmpty) {
      profileFavoriteController.searchFavoriteList =
          profileFavoriteController.favoriteListWithDetails;
    } else {
      // Filter items based on the query
      favorites.forEach((item) {
        final itemName = item?.name;
        if (itemName != null &&
            itemName.toLowerCase().contains(query.toLowerCase())) {
          setState(() {
            profileFavoriteController.searchFavoriteList.add(item);
          });
        }
      });
    }
  }

  //search follwing


  ListTile singleUser({
    required String text,
    required String userId,
    required String name,
    required String? profile,
    required VoidCallback onTab,

    required Color bgButton}) {
    return ListTile(
      onTap: () {
        Get.to(FreelancerProfileDetails(userId: userId));
        //print("user id $name");
      },
      contentPadding: EdgeInsets.only(bottom: 15, left: 20, right: 10),
      leading: Container(
        height: 50, width: 50,
        child: ClipRRect(
            borderRadius: BorderRadius.circular(100),
            child: profile != null ? AppNetworkImage(src: profile!,) : Image
                .asset("asset/image/logo.png", fit: BoxFit.cover)
        ),
      ),
      title: Text("$name",
        style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: AppColors.white
        ),
      ),
      trailing: InkWell(
        onTap: onTab,
        child: Container(
            height: 50, width: 120,
            decoration: BoxDecoration(
                color: bgButton,
                borderRadius: BorderRadius.circular(5)
            ),
            child: Center(child: Text("$text",
              style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 12,
                color: AppColors.white,
              ),
            ),)
        ),
      ),
    );
  }


  InkWell buildSinglePortfolio({
    required VoidCallback onClick,
    required String imagePath,
  }) {
    return InkWell(
      onTap: onClick,
      child: Stack(
        children: [
          // Your main image or content (AppNetworkImage in this case)
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: AppNetworkImage(src: imagePath),
          ),
          // Positioned widget to position the PNG image at the top right corner
        ],
      ),
    );

  }

}