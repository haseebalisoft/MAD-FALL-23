import 'package:coco/utility/appAssets.dart';
import 'package:coco/utility/colors.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';

class Cafe_edit_profile extends StatefulWidget {
  const Cafe_edit_profile({super.key});

  @override
  State<Cafe_edit_profile> createState() => _Cafe_edit_profileState();
}

class _Cafe_edit_profileState extends State<Cafe_edit_profile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                        onPressed: () {
                          Get.back();
                        },
                        icon: Icon(Icons.clear),),
                    IconButton(
                        onPressed: () {
                          Get.back();
                        },
                        icon: Icon(Icons.arrow_forward_outlined,color: Colors.green,size: 30,)
                    ),
                  ],
                ),
                SizedBox(
                  height: 15,
                ),
                Center(
                  child: Column(
                    children: [
                      Container(
                        height: 120,
                        width: 120,
                        decoration: BoxDecoration(
                          // color: AppColors.mainColor,
                          gradient: LinearGradient(colors: [
                            Color(0xFF00CC83),
                            Color(0xFF53E0DB),
                          ]),
                          shape: BoxShape.circle,
                        ),
                        child: Center(
                          child: CircleAvatar(
                            backgroundColor: Colors.white,
                            radius: 55,
                            child: Image.asset(AssetUtils.profile_image),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 7,
                      ),
                      Text(
                        'Edit Profile',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                ),
                Text(
                  'Description',
                  style: TextStyle(color: Color(0xff00CC83), fontSize: 18),
                ),
                SizedBox(
                  height: 15,
                ),
                Text(
                  "We believe that a meal is more than just sustenance; it's an experience to be savored, cherished, and shared. So come join us and immerse yourself in a world of flavors, where good company and great food come together to create unforgettable memories.",
                  style: TextStyle(color: Color(0xff676767)),
                ),
                SizedBox(
                  height: 10,
                ),
                Divider(),
                SizedBox(
                  height: 10,
                ),
                Text(
                  'Location',
                  style: TextStyle(color: Color(0xff00CC83), fontSize: 18),
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                        child: Text(
                            "Bali Bliss Resort Jalan Sunset No. 123 Seminyak, Kuta Bali 80361 Indonesia")),
                    Spacer(),
                    SizedBox(
                        width: 100,
                        child: ElevatedButton(
                            style: OutlinedButton.styleFrom(
                              backgroundColor: Color(0xFF00CC83),
                            ),
                            onPressed: () {},
                            child: Text(
                              'Edit',
                              style: TextStyle(fontFamily: 'Poppins_SemiBold'),
                            ))),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Divider(),
                SizedBox(
                  height: 10,
                ),
                Text(
                  'Opening Hours',
                  style: TextStyle(color: Color(0xff00CC83), fontSize: 16),
                ),
                SizedBox(
                  height: 2,
                ),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        'Monday to Sunday from 9:00 to 21:00',
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                    SizedBox(
                        width: 100,
                        child: ElevatedButton(
                            style: OutlinedButton.styleFrom(
                              backgroundColor: Color(0xFF00CC83),
                            ),
                            onPressed: () {},
                            child: Text(
                              'Edit',
                              style: TextStyle(fontFamily: 'Poppins_SemiBold'),
                            ))),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Divider(),
                SizedBox(
                  height: 10,
                ),
                Text(
                  'Follow us',
                  style: TextStyle(color: Color(0xff00CC83), fontSize: 18),
                ),
                SizedBox(
                  height: 5,
                ),
                Row(
                  children: [
                    Image.asset(
                      'asset/image/insta.png',
                      width: 45,
                      height: 45,
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Image.asset(
                      'asset/image/youtube.png',
                      width: 45,
                      height: 45,
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Image.asset(
                      'asset/image/bain.png',
                      width: 45,
                      height: 45,
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Image.asset(
                      'asset/image/linkdin.png',
                      width: 45,
                      height: 45,
                    ),
                    Spacer(),
                    SizedBox(
                        width: 100,
                        child: ElevatedButton(
                            style: OutlinedButton.styleFrom(
                              backgroundColor: Color(0xFF00CC83),
                            ),
                            onPressed: () {},
                            child: Text(
                              'Edit',
                              style: TextStyle(fontFamily: 'Poppins_SemiBold'),
                            ))),
                  ],
                ),
                SizedBox(
                  height: 20,
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
