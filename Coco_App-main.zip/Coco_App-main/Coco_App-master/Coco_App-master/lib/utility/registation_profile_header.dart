import 'dart:io';

import 'package:coco/controller/authController.dart';
import 'package:coco/controller/camera_gallery_controller/cameraGalleryController.dart';
import 'package:coco/utility/colors.dart';
import 'package:coco/viewController/alartController.dart';
import 'package:coco/viewController/appNetworkImage.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:wechat_assets_picker/wechat_assets_picker.dart';
import 'package:wechat_camera_picker/wechat_camera_picker.dart';

import '../controller/registration_profile_header_controller.dart';
import 'appAssets.dart';

class registation_profile_header extends StatefulWidget {
  const registation_profile_header({
    super.key, required  this.name, required  this.following,required  this.follower, this.image
  });

  final String name;
  final String following;
  final String follower;
  final String? image;

  @override
  State<registation_profile_header> createState() => _registation_profile_headerState();
}

class _registation_profile_headerState extends State<registation_profile_header> {

  RegistrationProfileHeaderController controller = Get.put(RegistrationProfileHeaderController());

  @override
  Widget build(BuildContext context) {
    return Obx(()=> Padding(
        padding: const EdgeInsets.fromLTRB(33, 0, 0, 0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            InkWell(
             // onTap: ()=>CameraGalleryController.pickProfilePic(context: context),
              onTap: ()=>_pickImage(ImageSource.gallery),
              child: Stack(
                children: [
                  CircleAvatar(
                    radius: 50,
                    backgroundColor: Colors.white,
                    child: widget!.image != null
                        ?ClipRRect(
                        borderRadius: BorderRadius.circular(100),
                        child: AppNetworkImage(src: widget!.image.toString(), height: 111, width: 111,)
                    ) :  controller.croppedFile.value != null
                        ?ClipRRect(
                      borderRadius: BorderRadius.circular(100),
                      child: Image.file(controller.croppedFile.value!, width: 111,
                        height: 111, fit: BoxFit.cover,),
                      )
                        : isLoading
                        ? CircularProgressIndicator()
                        : Image.asset(
                      AssetUtils.user_place_holder,
                      width: 111,
                      height: 111,
                    ),
                  ),
                  Positioned(
                    bottom: 0, right: 0,
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.blue,
                        borderRadius: BorderRadius.circular(100)
                      ),
                      child: Icon(Icons.add, color: Colors.white,),
                    ),
                  )
                ],
              ),
            ),
            SizedBox(
              width: 20,
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: MediaQuery.of(context).size.width*.50,
                  child: Text(
                    widget.name,
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: AppColors.white,
                        fontFamily: 'Poppins-Bold'),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment:
                  MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      children: [
                        Text(
                          widget.following,
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: AppColors.white,
                              fontSize: 17,
                              fontFamily: 'arial-bold'),
                        ),
                        Text(
                          'Following',
                          style: TextStyle(

                              fontWeight: FontWeight.bold,
                              color: AppColors.textgrey,
                              fontSize: 13),
                        ),
                      ],
                    ),
                    SizedBox(
                      width: 25,
                    ),
                    Container(
                      height: 30,
                      width: 2,
                      color: Colors.black12,
                    ),
                    SizedBox(
                      width: 25,
                    ),
                    Column(
                      children: [
                        Text(
                         widget.follower,
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 17,
                              color: AppColors.white,
                              fontFamily: 'arial-bold'),
                        ),
                        Text(
                          'Followers',
                          style: TextStyle(
                              color: AppColors.textgrey,
                              fontWeight: FontWeight.bold,
                              fontSize: 13),
                        ),
                      ],
                    ),
                  ],
                )
              ],
            )
          ],
        ),
      ),
    );
  }

  bool isLoading = false;


  ////////// pick profile image////////
  Future<void> _pickImage(ImageSource type) async {
    ImagePicker picker = ImagePicker();
    XFile? pickedFile = await picker.pickImage(source: type);
    if (pickedFile != null) {
      setState(() {
        controller.image.value =  File(pickedFile!.path);
      });
      _cropImage();
      // Handle the picked image, e.g., display it in an image widget or upload it
      // to a server.
    }
  }

  ///= =============------ use set here isStory = true =========//



  Future<void> _cropImage() async {
    if (controller.image.value != null) {
      final croppedFile = await ImageCropper().cropImage(
        sourcePath: controller.image.value!.path,
        compressFormat: ImageCompressFormat.jpg,
        compressQuality: 100,
        aspectRatio: CropAspectRatio(
            ratioX: 1, ratioY: 1
        ),

        uiSettings: [
          AndroidUiSettings(
              toolbarTitle: 'Profile Photo',
              toolbarColor: Colors.black,
              toolbarWidgetColor: Colors.white,
              initAspectRatio: CropAspectRatioPreset.original,
              lockAspectRatio: false),
          IOSUiSettings(
            title: 'Profile Photo',
          ),
          WebUiSettings(
            context: context,
            presentStyle: CropperPresentStyle.dialog,
            boundary: const CroppieBoundary(
              width: 520,
              height: 520,
            ),
            viewPort: const CroppieViewPort(width: 480, height: 480, type: 'circle'),
            enableExif: true,
            enableZoom: true,
            showZoomer: true,
          ),
        ],
      );
      if (croppedFile != null) {
        setState(() {
          controller.croppedFile.value = File(croppedFile.path);
          _uploadPortfolio(controller.croppedFile.value);
        });
      }
    }
  }



  void _uploadPortfolio(file) async{
    setState(() =>isLoading=true);
    AlertController.snackbar(context: context, text: "Profile uploading....", bg: AppColors.mainColor.withOpacity(0.7));
    var res = await AuthController.uploadProfile(images: file);

    print("response === ${res.statusCode}");
    print("response === ${res.stream.map((event) => print(event))}");
    if(res.statusCode == 200){
      AlertController.snackbar(context: context, text: "Profile uploaded success.", bg: Colors.green);
    }else{
      AlertController.snackbar(context: context, text: "Something went wrong with server.", bg: Colors.red);
    }
    setState(() =>isLoading=false);
  }



  ////////// chossse images /////////
  void chosePhoto()async{
    showModalBottomSheet(
        context: context,
        builder: (context) {
          return Padding(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                SizedBox(height: 20,),
                Text("Choose Image", style: TextStyle(color: AppColors.black, fontSize: 15, fontWeight: FontWeight.w600),),
                SizedBox(height: 30,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () {
                        _pickImage(ImageSource.camera); Navigator.pop(context);
                      },
                      child: Column(
                        children: [
                          Icon(Icons.camera_alt, color: AppColors.mainColor, size: 30,),
                          SizedBox(height: 10,),
                          Text("Take Photo", style: TextStyle(color: AppColors.mainColor),),
                        ],
                      ),
                    ),

                    SizedBox(width: 50,),
                    InkWell(
                      onTap: () {
                        _pickImage(ImageSource.gallery); Navigator.pop(context);
                      },
                      child: Column(
                        children: const [
                          Icon(Icons.photo, color: Colors.blueAccent, size: 30,),
                          SizedBox(height: 10,),
                          Text("Choose from Gallery", style: TextStyle(color: Colors.blueAccent),),
                        ],
                      ),
                    )
                  ],
                ),
                SizedBox(height: 20,),
              ],
            ),
          );
        });
  }}
