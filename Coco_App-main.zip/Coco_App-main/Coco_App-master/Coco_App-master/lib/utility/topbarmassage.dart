import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:text_scroll/text_scroll.dart';

import 'colors.dart';



class AppTopBarMassage extends StatefulWidget {
  final String massage;
  const AppTopBarMassage({super.key, required this.massage});

  @override
  State<AppTopBarMassage> createState() => _AppTopBarMassageState();
}

class _AppTopBarMassageState extends State<AppTopBarMassage> {

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    print("widget.massage.length ${widget.massage.length}");
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: AppColors.mainColor,
      margin: EdgeInsets.only(bottom: 10),
      padding: EdgeInsets.all(10),
      child: Center(
        child: TextScroll(
          '${widget.massage}',
          mode: widget.massage.length > 50 ? TextScrollMode.endless : TextScrollMode.bouncing,
          velocity: Velocity(pixelsPerSecond: Offset(50, 0)),
          delayBefore: Duration(milliseconds: 2000),
          numberOfReps: 5,
          pauseBetween: Duration(milliseconds: 50),
          style: TextStyle(color: Colors.white),
          textAlign: TextAlign.right,
          selectable: true,
        ),
      ),
      // child: Center(child: Text(widget.massage,
      //   style: TextStyle(
      //     fontWeight: FontWeight.w400,
      //     fontSize: 13,
      //     color: Colors.white
      //   ),
      // ), ),
    );
  }
}
