import 'package:flutter/material.dart';

class AppColors{
  static const Color mainColor = Color(0xFF4AC07C);
  static const Color black = Colors.black;
  static const Color white = Colors.white;
  static const Color formColor = Color(0xfff7f7f7);
  static const Color formBorder = Color(0xff2E2E2E);
  static const Color formColorUp = Color(0xff222222);
  static const Color textgrey = Color(0xff918F8F);
}