import 'package:coco/viewController/appNetworkImage.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';


class UnderDev extends StatefulWidget {
  const UnderDev({Key? key}) : super(key: key);

  @override
  State<UnderDev> createState() => _UnderDevState();
}

class _UnderDevState extends State<UnderDev> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          title: Text("Under Develepment",
            style: TextStyle(
              fontWeight: FontWeight.w600,
              color: Colors.black
            ),
          ),
          leading: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.black,),
            onPressed: ()=>Get.back(),
          ),
        ),
        body: Center(
          child: AppNetworkImage(src: "https://pngimg.com/d/under_construction_PNG40.png", fit: BoxFit.contain,),
        ),
      ),
    );
  }
}
