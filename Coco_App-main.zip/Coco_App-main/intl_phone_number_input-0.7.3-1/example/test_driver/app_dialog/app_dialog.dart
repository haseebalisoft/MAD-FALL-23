import 'package:flutter_driver/driver_extension.dart';
import 'package:intlphonenumberinputtest/main_dialog.dart' as app;

main() {
  enableFlutterDriverExtension();

  app.main();
}
