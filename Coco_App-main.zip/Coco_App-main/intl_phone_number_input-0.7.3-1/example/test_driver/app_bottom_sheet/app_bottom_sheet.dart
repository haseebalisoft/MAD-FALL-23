import 'package:flutter_driver/driver_extension.dart';
import 'package:intlphonenumberinputtest/main_bottom_sheet.dart' as app;

main() {
  enableFlutterDriverExtension();

  app.main();
}
