import 'package:flutter_driver/driver_extension.dart';
import 'package:intlphonenumberinputtest/main.dart' as app;

main() {
  enableFlutterDriverExtension();

  app.main();
}
